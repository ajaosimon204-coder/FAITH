export interface PublishedCmsPage {
  readonly id: string;
  readonly slug: string;
  readonly title: string;
  readonly contentJson: unknown;
}

/**
 * The only frontend code path that talks to the App Backend's public CMS
 * endpoint (`GET /api/v1/public/cms/pages/:slug`, no auth required — see
 * PublicCmsController). Deliberately the ONLY place this URL pattern is
 * constructed, so a future change to the API shape only touches one file.
 *
 * Returns `null` on any failure (network error, 404, backend not running)
 * rather than throwing — the caller is responsible for rendering a
 * meaningful empty state (Design System Contract Section 5: "Empty: an
 * icon + one sentence... Never a blank white area"), never fabricated
 * content, and never a raw error to the visitor.
 */
export async function fetchPublishedPage(
  campusId: string,
  slug: string,
): Promise<PublishedCmsPage | null> {
  const apiBaseUrl = process.env.NEXT_PUBLIC_API_BASE_URL;
  if (!apiBaseUrl) {
    // No backend configured for this environment — treat exactly like "no
    // content yet" rather than crashing the page. This is expected during
    // local frontend-only development.
    return null;
  }

  try {
    const response = await fetch(
      `${apiBaseUrl}/api/v1/public/cms/pages/${encodeURIComponent(slug)}?campusId=${encodeURIComponent(campusId)}`,
      { next: { revalidate: 60 } },
    );

    if (!response.ok) {
      return null;
    }

    const data = (await response.json()) as PublishedCmsPage | null;
    return data ?? null;
  } catch {
    return null;
  }
}
