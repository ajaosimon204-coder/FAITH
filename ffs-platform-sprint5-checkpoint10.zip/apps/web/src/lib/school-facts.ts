/**
 * Every value here is taken verbatim from the master specification
 * ("FAITH FOUNDATION SCHOOLS — WORLD-CLASS DIGITAL SCHOOL PLATFORM" brief,
 * Section 1). Nothing here is invented — per the No Fake Data rule, any
 * fact NOT listed in that document is represented as a placeholder
 * elsewhere in the UI, never guessed at here.
 */
export const SCHOOL_FACTS = {
  name: 'Faith Foundation Schools',
  address: 'Oniyefun Zone A1, Thywill, Amuloko, Ibadan, Oyo State, Nigeria',
  establishedYear: 2015,
  motto: 'Every Child Is a Potential.',
  schoolType: 'Premium day school',
  curriculumDirection:
    'Blends the Nigerian curriculum with strong British/international educational practices where appropriate.',
} as const;

/**
 * The full level sequence, in order — a real sequence (a student's actual
 * multi-year progression through the school), which is why it's presented
 * as a pathway rather than an arbitrary numbered list (frontend-design
 * skill: numbering should encode something true, not decorate).
 */
export const SCHOOL_LEVELS: readonly string[] = [
  'Preparatory',
  'KG',
  'Nursery 1',
  'Nursery 2',
  'Basic 1',
  'Basic 2',
  'Basic 3',
  'Basic 4',
  'Basic 5',
  'JSS 1',
  'JSS 2',
  'JSS 3',
  'SS 1',
  'SS 2',
  'SS 3',
];
