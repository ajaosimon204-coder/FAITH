import type { Metadata } from 'next';
import { Source_Serif_4, Inter } from 'next/font/google';
import { SCHOOL_FACTS } from '@/lib/school-facts';
import './globals.css';

/**
 * Sprint 4 adversarial audit, Medium finding (Section 7): the Design
 * System Contract specifies "Source Serif 4" and "Inter" as deliberately
 * chosen typefaces, but neither was ever actually loaded — the CSS
 * `font-family` stacks referenced them by name only, so every browser
 * silently fell through to the fallback fonts (Georgia, system-ui). Fixed
 * by loading both via next/font/google, which self-hosts the font files
 * (no external network dependency at request time) and exposes them as
 * CSS custom properties consumed directly by globals.css.
 */
const sourceSerif = Source_Serif_4({
  subsets: ['latin'],
  weight: ['400', '600', '700'],
  style: ['normal', 'italic'],
  variable: '--font-display-loaded',
  display: 'swap',
});

const inter = Inter({
  subsets: ['latin'],
  weight: ['400', '500', '600'],
  variable: '--font-body-loaded',
  display: 'swap',
});

export const metadata: Metadata = {
  title: `${SCHOOL_FACTS.name}`,
  description: SCHOOL_FACTS.motto,
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}): JSX.Element {
  return (
    <html lang="en" className={`${sourceSerif.variable} ${inter.variable}`}>
      <body>{children}</body>
    </html>
  );
}
