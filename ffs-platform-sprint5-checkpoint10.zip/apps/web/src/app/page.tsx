import { Header } from '@/components/Header';
import { Footer } from '@/components/Footer';
import { LevelsPathway } from '@/components/LevelsPathway';
import { getPublishedPageContent, PublishedPageSection } from '@/components/PublishedPageSection';
import { SCHOOL_FACTS } from '@/lib/school-facts';
import styles from './page.module.css';

/**
 * The campus this public site renders content for. Read from environment
 * configuration rather than hardcoded, since the actual campus UUID (seeded
 * in migration 0004, with its display NAME still [CONTENT REQUIRED]) is
 * deployment-specific data, not something that belongs directly in
 * page code.
 */
const CAMPUS_ID = process.env.NEXT_PUBLIC_CAMPUS_ID ?? '';

export default async function HomePage(): Promise<JSX.Element> {
  const newsPage = await getPublishedPageContent(CAMPUS_ID, 'latest-news');

  return (
    <>
      <Header />
      <main>
        <section className={styles.hero}>
          <div className="container">
            <p className={styles.eyebrow}>Est. {SCHOOL_FACTS.establishedYear}</p>
            <h1 className={styles.heroHeading}>{SCHOOL_FACTS.name}</h1>
            <p className={styles.motto}>&ldquo;{SCHOOL_FACTS.motto}&rdquo;</p>
            <p className={styles.heroDetail}>
              {SCHOOL_FACTS.schoolType} in Ibadan, Oyo State — {SCHOOL_FACTS.curriculumDirection}
            </p>
          </div>
        </section>

        <section id="academics" className={`container ${styles.section}`}>
          <h2>A Clear Path, From Preparatory to SS3</h2>
          <p className={styles.sectionIntro}>
            Every student&rsquo;s journey at {SCHOOL_FACTS.name} follows the same fifteen-level
            path, from Preparatory through Senior Secondary 3.
          </p>
          <LevelsPathway />
        </section>

        <section className={`container ${styles.section}`}>
          <h2>About {SCHOOL_FACTS.name}</h2>
          <div className={styles.aboutPlaceholder}>
            <p>
              [CONTENT REQUIRED: full history, mission &amp; vision statement, and leadership
              profiles have not yet been supplied. This section will be populated once the
              school provides that content — see the platform&rsquo;s No Fake Data policy.]
            </p>
          </div>
        </section>

        <section className={`container ${styles.section}`}>
          <h2>Latest News</h2>
          <PublishedPageSection page={newsPage} fallbackHeading="News" />
        </section>

        <section id="admissions" className={`container ${styles.section}`}>
          <h2>Admissions</h2>
          <div className={styles.aboutPlaceholder}>
            <p>
              Online admissions are not yet available on this platform (planned for a future
              sprint). [CONTENT REQUIRED: interim contact details for prospective families.]
            </p>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
