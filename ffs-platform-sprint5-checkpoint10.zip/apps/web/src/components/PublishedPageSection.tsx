import { fetchPublishedPage, PublishedCmsPage } from '@/lib/cms-client';
import styles from './PublishedPageSection.module.css';

/**
 * Split deliberately into a data-fetching function and a synchronous
 * presentational component. An async Server Component nested inside
 * another async Server Component cannot be exercised by
 * @testing-library/react outside Next's actual RSC rendering pipeline —
 * this shape keeps exactly one async boundary (the page itself) and makes
 * every rendering concern unit-testable with plain React DOM rendering.
 */
export async function getPublishedPageContent(
  campusId: string,
  slug: string,
): Promise<PublishedCmsPage | null> {
  return fetchPublishedPage(campusId, slug);
}

/**
 * Design System Contract Section 5: "Empty: an icon + one sentence
 * explaining why it's empty... Never a blank white area." This is the
 * concrete implementation of that rule for CMS-sourced content — it NEVER
 * falls back to invented copy when nothing has been published yet (No
 * Fake Data rule), only an honest, clearly-labeled empty state.
 */
export function PublishedPageSection({
  page,
  fallbackHeading,
}: {
  page: PublishedCmsPage | null;
  fallbackHeading: string;
}): JSX.Element {
  if (!page) {
    return (
      <div className={styles.empty}>
        <p className={styles.emptyIcon} aria-hidden="true">
          ○
        </p>
        <p>{fallbackHeading} content has not been published yet.</p>
      </div>
    );
  }

  return (
    <div>
      <h3>{page.title}</h3>
      {/* content_json is block-based structured content (Architecture
          Section 12) — a real block renderer mapping block types to
          trusted components is a follow-up sprint item; Sprint 4 only
          proves the fetch-and-render pipeline end to end with an honest
          placeholder for the block renderer itself. */}
      <p className={styles.rendererPlaceholder}>
        [Block content renderer not yet implemented —{' '}
        {Array.isArray(page.contentJson) ? page.contentJson.length : 0} block(s) available]
      </p>
    </div>
  );
}
