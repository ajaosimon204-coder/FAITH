import Link from 'next/link';
import { SCHOOL_FACTS } from '@/lib/school-facts';
import styles from './Header.module.css';

export function Header(): JSX.Element {
  return (
    <header className={styles.header}>
      <div className={`container ${styles.inner}`}>
        <Link href="/" className={styles.brand}>
          {SCHOOL_FACTS.name}
        </Link>
        <nav aria-label="Primary" className={styles.nav}>
          <a href="#academics">Academics</a>
          <a href="#admissions" className={styles.ctaLink}>
            Admissions
          </a>
        </nav>
      </div>
    </header>
  );
}
