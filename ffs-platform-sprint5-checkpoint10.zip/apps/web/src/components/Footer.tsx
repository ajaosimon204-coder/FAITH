import { SCHOOL_FACTS } from '@/lib/school-facts';
import styles from './Footer.module.css';

export function Footer(): JSX.Element {
  return (
    <footer className={styles.footer}>
      <div className={`container ${styles.inner}`}>
        <div>
          <p className={styles.brand}>{SCHOOL_FACTS.name}</p>
          <p className={styles.address}>{SCHOOL_FACTS.address}</p>
        </div>
        <p className={styles.placeholder}>
          [CONTENT REQUIRED: phone number, email address, and social media links —
          not yet supplied]
        </p>
        <p className={styles.copyright}>
          &copy; {new Date().getFullYear()} {SCHOOL_FACTS.name}. Est. {SCHOOL_FACTS.establishedYear}.
        </p>
      </div>
    </footer>
  );
}
