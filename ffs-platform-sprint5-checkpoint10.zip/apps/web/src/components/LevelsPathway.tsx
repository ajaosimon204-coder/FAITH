import { SCHOOL_LEVELS } from '@/lib/school-facts';
import styles from './LevelsPathway.module.css';

/**
 * The one deliberate visual signature for this page (frontend-design
 * skill: "spend your boldness in one place"). Grounded in real content —
 * SCHOOL_LEVELS is the actual, verified 15-level progression a student
 * moves through at this school, grouped into its real stages. This is
 * exactly the case where a sequential/numbered treatment is earned: the
 * content genuinely is an ordered sequence, not decoration imposed on
 * unordered facts.
 */
const STAGES: ReadonlyArray<{ label: string; levels: readonly string[] }> = [
  { label: 'Early Years', levels: SCHOOL_LEVELS.slice(0, 4) },
  { label: 'Primary', levels: SCHOOL_LEVELS.slice(4, 9) },
  { label: 'Junior Secondary', levels: SCHOOL_LEVELS.slice(9, 12) },
  { label: 'Senior Secondary', levels: SCHOOL_LEVELS.slice(12, 15) },
];

export function LevelsPathway(): JSX.Element {
  return (
    <div className={styles.pathway} role="list" aria-label="Academic levels, in order">
      {STAGES.map((stage, stageIndex) => (
        <div key={stage.label} className={styles.stage}>
          <p className={styles.stageLabel}>{stage.label}</p>
          <div className={styles.levelRow}>
            {stage.levels.map((level) => (
              <span key={level} role="listitem" className={styles.level}>
                {level}
              </span>
            ))}
          </div>
          {stageIndex < STAGES.length - 1 && (
            <span className={styles.connector} aria-hidden="true" />
          )}
        </div>
      ))}
    </div>
  );
}
