import { render, screen } from '@testing-library/react';
import HomePage from '../src/app/page';
import * as cmsClient from '../src/lib/cms-client';

jest.mock('../src/lib/cms-client');

describe('HomePage', () => {
  beforeEach(() => {
    jest.spyOn(cmsClient, 'fetchPublishedPage').mockResolvedValue(null);
  });

  afterEach(() => {
    jest.resetAllMocks();
  });

  it('renders the real, verified school name and motto', async () => {
    const element = await HomePage();
    render(element);

    expect(screen.getAllByText('Faith Foundation Schools').length).toBeGreaterThan(0);
    expect(screen.getByText(/Every Child Is a Potential/)).toBeInTheDocument();
  });

  it('renders the real established year', async () => {
    const element = await HomePage();
    render(element);

    expect(screen.getAllByText(/Est\. 2015/).length).toBeGreaterThan(0);
  });

  it('marks unsupplied About content as [CONTENT REQUIRED], never fabricated narrative copy', async () => {
    const element = await HomePage();
    render(element);

    expect(screen.getAllByText(/CONTENT REQUIRED/).length).toBeGreaterThan(0);
  });

  it('marks the admissions section as not yet available, rather than a fake application form', async () => {
    const element = await HomePage();
    render(element);

    expect(screen.getByText(/Online admissions are not yet available/i)).toBeInTheDocument();
  });

  it('renders all 15 real academic levels via the LevelsPathway', async () => {
    const element = await HomePage();
    render(element);

    expect(screen.getByText('Preparatory')).toBeInTheDocument();
    expect(screen.getByText('SS 3')).toBeInTheDocument();
  });
});
