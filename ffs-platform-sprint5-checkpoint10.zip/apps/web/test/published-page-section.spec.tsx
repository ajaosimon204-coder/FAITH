import { render, screen } from '@testing-library/react';
import { PublishedPageSection } from '../src/components/PublishedPageSection';

describe('PublishedPageSection', () => {
  it('renders a clearly-labeled empty state when no CMS content has been published — never fabricated copy', () => {
    render(<PublishedPageSection page={null} fallbackHeading="News" />);

    expect(screen.getByText(/News content has not been published yet/i)).toBeInTheDocument();
  });

  it('renders the real published title when content exists', () => {
    render(
      <PublishedPageSection
        page={{
          id: 'page-1',
          slug: 'latest-news',
          title: 'A Real Published Headline',
          contentJson: [{ type: 'paragraph' }],
        }}
        fallbackHeading="News"
      />,
    );

    expect(screen.getByText('A Real Published Headline')).toBeInTheDocument();
    expect(screen.queryByText(/has not been published yet/i)).not.toBeInTheDocument();
  });

  it('never renders invented content when nothing was fetched — falls back to the same honest empty state', () => {
    render(<PublishedPageSection page={null} fallbackHeading="News" />);

    // No lorem-ipsum, no placeholder headline text pretending to be real —
    // just the same honest empty-state message.
    expect(screen.getByText(/News content has not been published yet/i)).toBeInTheDocument();
  });
});
