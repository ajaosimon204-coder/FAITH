import { render, screen } from '@testing-library/react';
import { LevelsPathway } from '../src/components/LevelsPathway';
import { SCHOOL_LEVELS } from '../src/lib/school-facts';

describe('LevelsPathway', () => {
  it('renders every one of the 15 verified school levels, and nothing extra', () => {
    render(<LevelsPathway />);

    for (const level of SCHOOL_LEVELS) {
      expect(screen.getByText(level)).toBeInTheDocument();
    }

    const items = screen.getAllByRole('listitem');
    expect(items).toHaveLength(SCHOOL_LEVELS.length);
  });

  it('groups levels into their real stages (Early Years, Primary, Junior Secondary, Senior Secondary)', () => {
    render(<LevelsPathway />);

    expect(screen.getByText('Early Years')).toBeInTheDocument();
    expect(screen.getByText('Primary')).toBeInTheDocument();
    expect(screen.getByText('Junior Secondary')).toBeInTheDocument();
    expect(screen.getByText('Senior Secondary')).toBeInTheDocument();
  });

  it('preserves the real progression order (Preparatory first, SS 3 last)', () => {
    render(<LevelsPathway />);

    const items = screen.getAllByRole('listitem').map((el) => el.textContent);
    expect(items[0]).toBe('Preparatory');
    expect(items[items.length - 1]).toBe('SS 3');
  });
});
