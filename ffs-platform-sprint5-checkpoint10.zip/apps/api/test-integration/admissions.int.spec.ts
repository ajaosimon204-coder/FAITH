import { createClient, SupabaseClient } from '@supabase/supabase-js';
import * as jwt from 'jsonwebtoken';
import {
  AdmissionsRuleViolationError,
  SupabaseAdmissionsRepository,
} from '../src/modules/admissions/admissions.repository';
import { AdmissionsReviewService } from '../src/modules/admissions/admissions-review.service';
import { AdmissionsSubmissionService } from '../src/modules/admissions/admissions-submission.service';
import { ADMISSIONS_PERMISSIONS, NewApplicationInput } from '../src/modules/admissions/admissions.types';
import { ResolvedIdentity } from '../src/modules/identity/identity.types';

/**
 * Integration suite: the application's own repository and services, the REAL supabase-js client,
 * the REAL PostgREST (the API layer Supabase runs), PostgreSQL with all migrations, and real JWTs.
 * Run via supabase/local-test-harness/run_integration.sh, which provisions all of that.
 *
 * What this proves that the hermetic suites cannot: the RPC argument names and result shapes as
 * PostgREST really sends them, that a database `RAISE EXCEPTION` really arrives as SQLSTATE P0001,
 * that JWT claims really reach `auth.uid()` and therefore RLS, and that the privilege layer holds
 * through the actual API.
 */
const URL = process.env.INTEGRATION_URL;
const SECRET = process.env.INTEGRATION_JWT_SECRET;
if (!URL || !SECRET) {
  throw new Error('INTEGRATION_URL / INTEGRATION_JWT_SECRET not set — run supabase/local-test-harness/run_integration.sh');
}

const ID = {
  campusA: 'c2000000-0000-0000-0000-000000000001',
  campusB: 'c2000000-0000-0000-0000-000000000002',
  authAdminA: 'c3000000-0000-0000-0000-000000000001',
  authVpA: 'c3000000-0000-0000-0000-000000000002',
  authAccountantA: 'c3000000-0000-0000-0000-000000000003',
  authGuardianA: 'c3000000-0000-0000-0000-000000000004',
  authAdminB: 'c3000000-0000-0000-0000-000000000005',
  userAdminA: 'c4000000-0000-0000-0000-000000000001',
  userAdminB: 'c4000000-0000-0000-0000-000000000005',
  defJss1A: 'c6000000-0000-0000-0000-000000000001',
  defSs1A: 'c6000000-0000-0000-0000-000000000002',
  defJss1B: 'c6000000-0000-0000-0000-000000000003',
  classJss1A: 'c7000000-0000-0000-0000-000000000001',
  classSs1A: 'c7000000-0000-0000-0000-000000000002',
  classJss1B: 'c7000000-0000-0000-0000-000000000003',
  guardianLinked: 'c8000000-0000-0000-0000-000000000001',
};

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
const mint = (claims: Record<string, unknown>) => jwt.sign(claims, SECRET, { algorithm: 'HS256', expiresIn: '1h' });
const serviceKey = mint({ role: 'service_role' });
const anonKey = mint({ role: 'anon' });

function clientWithKey(key: string, userToken?: string): SupabaseClient {
  return createClient(URL as string, key, {
    auth: { persistSession: false, autoRefreshToken: false },
    ...(userToken ? { global: { headers: { Authorization: `Bearer ${userToken}` } } } : {}),
  });
}
const service = clientWithKey(serviceKey);
const anon = clientWithKey(anonKey);
const asUser = (authUserId: string) =>
  clientWithKey(anonKey, mint({ role: 'authenticated', sub: authUserId, aud: 'authenticated' }));

const repo = new SupabaseAdmissionsRepository(service);

let counter = 0;
const unique = () => `${Date.now().toString(36)}${(counter += 1)}`;

function application(overrides: Partial<NewApplicationInput> = {}): NewApplicationInput {
  return {
    campusId: ID.campusA,
    applicantFirstName: `Ada${unique()}`,
    applicantLastName: 'Obi',
    applicantDateOfBirth: '2014-05-05',
    applicantGender: 'female',
    classDefinitionId: ID.defJss1A,
    guardianFirstName: 'Ngozi',
    guardianLastName: 'Obi',
    guardianEmail: `parent-${unique()}@int.test`,
    guardianPhone: null,
    possibleDuplicateOf: null,
    ...overrides,
  };
}

const transition = (id: string, toStatus: 'under_review' | 'approved' | 'rejected' | 'info_requested', campusId = ID.campusA) =>
  repo.transitionApplication({
    id,
    campusId,
    toStatus,
    actorId: ID.userAdminA,
    action: `application.${toStatus}`,
    reviewNotes: null,
    decisionReason: null,
  });

async function approvedApplication(overrides: Partial<NewApplicationInput> = {}) {
  const created = await repo.createApplication(application(overrides));
  await transition(created.id, 'under_review');
  await transition(created.id, 'approved');
  return created;
}

/** Denied by the PRIVILEGE layer (not merely by an RLS policy): SQLSTATE 42501 and "permission denied". */
const expectPrivilegeDenied = (result: { error: { code?: string; message: string } | null }) => {
  expect(result.error?.code).toBe('42501');
  expect(result.error?.message).toMatch(/permission denied/i);
};

/** A valid raw table row (snake_case columns). Direct-write attempts must be well-formed, so that the
 *  privilege layer — not column validation — is what refuses them. */
const rawApplicationRow = () => ({
  campus_id: ID.campusA,
  applicant_first_name: `Raw${unique()}`,
  applicant_last_name: 'Obi',
  applicant_date_of_birth: '2014-05-05',
  class_definition_id: ID.defJss1A,
  guardian_first_name: 'Ngozi',
  guardian_last_name: 'Obi',
});

const manager: ResolvedIdentity = {
  authUserId: ID.authAdminA,
  appUserId: ID.userAdminA,
  email: 'admin-a@int.test',
  status: 'active',
  campusId: ID.campusA,
  organizationId: 'c1000000-0000-0000-0000-000000000001',
  roles: ['school_administrator'],
  permissions: [ADMISSIONS_PERMISSIONS.APPLICATIONS_READ, ADMISSIONS_PERMISSIONS.APPLICATIONS_MANAGE],
};
const managerB: ResolvedIdentity = { ...manager, appUserId: ID.userAdminB, campusId: ID.campusB, authUserId: ID.authAdminB };

describe('repository against real PostgREST', () => {
  it('creates an application: the database assigns status and reference number', async () => {
    const created = await repo.createApplication(application());
    expect(created.id).toMatch(UUID);
    expect(created.status).toBe('submitted');
    expect(created.referenceNo).toMatch(/^APP-\d{4}-\d{6}$/);
    expect(new Date(created.submittedAt).getTime()).not.toBeNaN();
    expect(created.reviewedBy).toBeNull();
    expect(created.convertedStudentId).toBeNull();
  });

  it('a database RAISE EXCEPTION arrives as SQLSTATE P0001 and becomes AdmissionsRuleViolationError', async () => {
    const attempt = repo.createApplication(application({ classDefinitionId: ID.defJss1B })); // another campus's level
    await expect(attempt).rejects.toBeInstanceOf(AdmissionsRuleViolationError);
    await expect(attempt).rejects.toThrow('does not belong to the application');
  });

  it('a non-rule database error stays a plain Error (a foreign-key violation is not a business rule)', async () => {
    const attempt = repo.addDocument({
      applicationId: '00000000-0000-4000-8000-000000000000',
      docType: 'x',
      fileUrl: 'https://files.example.test/x.pdf',
    });
    await expect(attempt).rejects.toThrow('Failed to add application document');
    await expect(attempt).rejects.not.toBeInstanceOf(AdmissionsRuleViolationError);
  });

  it('reads back by id, returns null for an unknown id', async () => {
    const created = await repo.createApplication(application());
    expect((await repo.findApplicationById(created.id))?.referenceNo).toBe(created.referenceNo);
    expect(await repo.findApplicationById('00000000-0000-4000-8000-000000000000')).toBeNull();
  });

  it('lists a campus newest first, filters by status, and never returns another campus', async () => {
    const first = await repo.createApplication(application({ applicantLastName: `List${unique()}` }));
    const second = await repo.createApplication(application({ applicantLastName: `List${unique()}` }));
    await transition(first.id, 'under_review');

    const all = await repo.listApplications(ID.campusA);
    const times = all.map((a) => Date.parse(a.submittedAt));
    expect([...times].sort((a, b) => b - a)).toEqual(times);
    expect(all.every((a) => a.campusId === ID.campusA)).toBe(true);
    expect(all.map((a) => a.id)).toEqual(expect.arrayContaining([first.id, second.id]));

    const reviewing = await repo.listApplications(ID.campusA, 'under_review');
    expect(reviewing.map((a) => a.id)).toContain(first.id);
    expect(reviewing.map((a) => a.id)).not.toContain(second.id);
  });

  it('stores and lists documents oldest first', async () => {
    const created = await repo.createApplication(application());
    const d1 = await repo.addDocument({ applicationId: created.id, docType: 'birth_certificate', fileUrl: 'https://files.example.test/1.pdf' });
    const d2 = await repo.addDocument({ applicationId: created.id, docType: 'report_card', fileUrl: 'https://files.example.test/2.pdf' });
    expect((await repo.listDocuments(created.id)).map((d) => d.id)).toEqual([d1.id, d2.id]);
  });

  describe('duplicate lookup (ILIKE escaping as PostgreSQL really behaves)', () => {
    it('matches case-insensitively and ignores surrounding whitespace', async () => {
      const first = `Dupe${unique()}`;
      const created = await repo.createApplication(application({ applicantFirstName: first, applicantLastName: 'Case', applicantDateOfBirth: '2013-03-03' }));
      const found = await repo.findPossibleDuplicate({
        campusId: ID.campusA,
        applicantFirstName: `  ${first.toUpperCase()} `,
        applicantLastName: 'case',
        applicantDateOfBirth: '2013-03-03',
      });
      expect(found?.id).toBe(created.id);
    });

    it('treats an underscore literally — it must not act as a one-character wildcard', async () => {
      const tag = unique();
      const underscored = await repo.createApplication(application({ applicantFirstName: `Zed_${tag}`, applicantLastName: 'Wild', applicantDateOfBirth: '2012-02-02' }));
      await repo.createApplication(application({ applicantFirstName: `ZedX${tag}`, applicantLastName: 'Wild', applicantDateOfBirth: '2012-02-02' })); // newer, would win if "_" were a wildcard
      const found = await repo.findPossibleDuplicate({
        campusId: ID.campusA, applicantFirstName: `Zed_${tag}`, applicantLastName: 'Wild', applicantDateOfBirth: '2012-02-02',
      });
      expect(found?.id).toBe(underscored.id);
    });

    it('treats a percent sign literally, and does not match across campuses or dates of birth', async () => {
      const tag = unique();
      await repo.createApplication(application({ applicantFirstName: `Pct${tag}`, applicantLastName: 'Wild', applicantDateOfBirth: '2012-02-03' }));
      expect(await repo.findPossibleDuplicate({ campusId: ID.campusA, applicantFirstName: '%', applicantLastName: 'Wild', applicantDateOfBirth: '2012-02-03' })).toBeNull();
      expect(await repo.findPossibleDuplicate({ campusId: ID.campusB, applicantFirstName: `Pct${tag}`, applicantLastName: 'Wild', applicantDateOfBirth: '2012-02-03' })).toBeNull();
      expect(await repo.findPossibleDuplicate({ campusId: ID.campusA, applicantFirstName: `Pct${tag}`, applicantLastName: 'Wild', applicantDateOfBirth: '2012-02-04' })).toBeNull();
    });
  });

  describe('app_application_transition over RPC', () => {
    it('applies a transition, returns the updated row, and writes the audit entry atomically', async () => {
      const created = await repo.createApplication(application());
      const updated = await repo.transitionApplication({
        id: created.id, campusId: ID.campusA, toStatus: 'under_review', actorId: ID.userAdminA,
        action: 'application.under_review', reviewNotes: 'checked', decisionReason: null,
      });
      expect(updated).toMatchObject({ id: created.id, status: 'under_review', reviewedBy: ID.userAdminA, reviewNotes: 'checked' });

      const { data, error } = await service.from('audit_logs').select('action, actor_id, metadata_json').eq('target_id', created.id);
      expect(error).toBeNull();
      expect(data).toEqual([
        { action: 'application.under_review', actor_id: ID.userAdminA, metadata_json: expect.objectContaining({ from: 'submitted', to: 'under_review' }) },
      ]);
    });

    it('an illegal transition is a P0001 rule violation and leaves no audit entry', async () => {
      const created = await repo.createApplication(application());
      const attempt = transition(created.id, 'approved'); // submitted -> approved is illegal
      await expect(attempt).rejects.toBeInstanceOf(AdmissionsRuleViolationError);
      await expect(attempt).rejects.toThrow('Invalid application status transition');
      const { data } = await service.from('audit_logs').select('action').eq('target_id', created.id);
      expect(data).toEqual([]);
    });

    it('treats a campus mismatch as not found', async () => {
      const created = await repo.createApplication(application());
      await expect(transition(created.id, 'under_review', ID.campusB)).rejects.toThrow(`application ${created.id} not found`);
    });
  });

  describe('app_convert_application over RPC', () => {
    it('converts an approved application: result shape, student, guardian link, enrollment, audit', async () => {
      const approved = await approvedApplication({ applicantFirstName: `Conv${unique()}`, applicantLastName: 'Obi' });
      const result = await repo.convertApplication({ applicationId: approved.id, campusId: ID.campusA, classId: ID.classJss1A, actorId: ID.userAdminA });

      expect(result.studentId).toMatch(UUID);
      expect(result.guardianId).toMatch(UUID);
      expect(result.admissionNo).toMatch(/^FFS-\d{4}-\d{5}$/);

      const student = await service.from('students').select('lifecycle_status, admission_no, display_name').eq('id', result.studentId).single();
      expect(student.data).toMatchObject({ lifecycle_status: 'admitted', admission_no: result.admissionNo });
      const link = await service.from('guardian_students').select('relationship').eq('student_id', result.studentId).eq('guardian_id', result.guardianId).single();
      expect(link.data).toEqual({ relationship: 'guardian' });
      const enrollment = await service.from('enrollments').select('class_id, status').eq('student_id', result.studentId).single();
      expect(enrollment.data).toEqual({ class_id: ID.classJss1A, status: 'active' });
      expect((await repo.findApplicationById(approved.id))).toMatchObject({ status: 'converted', convertedStudentId: result.studentId });
      const audit = await service.from('audit_logs').select('metadata_json').eq('target_id', approved.id).eq('action', 'application.converted').single();
      expect(audit.data?.metadata_json).toMatchObject({ student_id: result.studentId, admission_no: result.admissionNo });
    });

    it('rejects each wrong input as a P0001 rule violation, creating nothing', async () => {
      const submitted = await repo.createApplication(application());
      const approved = await approvedApplication({ guardianEmail: `atomic-${unique()}@int.test` });
      const studentsBefore = (await service.from('students').select('id', { count: 'exact', head: true })).count;
      const convert = (applicationId: string, classId: string, campusId = ID.campusA) =>
        repo.convertApplication({ applicationId, campusId, classId, actorId: ID.userAdminA });

      await expect(convert(submitted.id, ID.classJss1A)).rejects.toThrow('must be approved before conversion');
      await expect(convert(approved.id, ID.classSs1A)).rejects.toThrow('not a class of the level applied for');
      await expect(convert(approved.id, ID.classJss1B)).rejects.toThrow('does not belong to this campus');
      await expect(convert(approved.id, ID.classJss1A, ID.campusB)).rejects.toThrow('not found');
      await expect(convert(submitted.id, ID.classJss1A)).rejects.toBeInstanceOf(AdmissionsRuleViolationError);

      expect((await service.from('students').select('id', { count: 'exact', head: true })).count).toBe(studentsBefore);
      expect((await repo.findApplicationById(approved.id))?.status).toBe('approved');
    });

    it('two simultaneous conversions in one campus both succeed with distinct admission numbers', async () => {
      const [a, b] = await Promise.all([approvedApplication(), approvedApplication()]);
      const [ra, rb] = await Promise.all([
        repo.convertApplication({ applicationId: a.id, campusId: ID.campusA, classId: ID.classJss1A, actorId: ID.userAdminA }),
        repo.convertApplication({ applicationId: b.id, campusId: ID.campusA, classId: ID.classJss1A, actorId: ID.userAdminA }),
      ]);
      expect(ra.admissionNo).not.toBe(rb.admissionNo);
    });
  });

  it('looks up a placement class and a class definition, and returns null for unknown ids', async () => {
    expect(await repo.findPlacementClass(ID.classJss1A)).toEqual({ id: ID.classJss1A, campusId: ID.campusA, classDefinitionId: ID.defJss1A });
    expect(await repo.findClassDefinition(ID.defJss1A)).toEqual({ id: ID.defJss1A, campusId: ID.campusA });
    expect(await repo.findPlacementClass('00000000-0000-4000-8000-000000000000')).toBeNull();
    expect(await repo.findClassDefinition('00000000-0000-4000-8000-000000000000')).toBeNull();
  });
});

describe('services end to end over the real stack', () => {
  const submission = new AdmissionsSubmissionService(repo);
  const review = new AdmissionsReviewService(repo);

  const form = (overrides = {}) => ({
    campusId: ID.campusA,
    applicantFirstName: `Svc${unique()}`,
    applicantLastName: 'Obi',
    applicantDateOfBirth: '2014-05-05',
    applicantGender: 'female',
    classDefinitionId: ID.defJss1A,
    guardianFirstName: 'Ngozi',
    guardianLastName: 'Obi',
    guardianEmail: `Svc-${unique()}@INT.test`,
    documents: [{ docType: 'birth_certificate', fileUrl: 'https://files.example.test/a.pdf' }],
    ...overrides,
  });

  it('submit → review → request info → approve → convert, with the full audit trail in the database', async () => {
    const receipt = await submission.submit(form());
    expect(receipt.documentsStored).toBe(1);

    await review.startReview(manager, receipt.applicationId);
    await review.requestInfo(manager, receipt.applicationId, { notes: 'Please send the report card.' });
    await review.resumeReview(manager, receipt.applicationId);
    await review.approve(manager, receipt.applicationId);
    const converted = await review.convert(manager, receipt.applicationId, ID.classJss1A);

    expect(converted.admissionNo).toMatch(/^FFS-\d{4}-\d{5}$/);
    const audit = await service.from('audit_logs').select('action').eq('target_id', receipt.applicationId).order('created_at', { ascending: true });
    expect(audit.data?.map((r) => r.action)).toEqual([
      'application.under_review', 'application.info_requested', 'application.under_review', 'application.approved', 'application.converted',
    ]);
  });

  it('stores the guardian email lower-cased and flags a second submission for the same child as a possible duplicate', async () => {
    const base = form({ applicantFirstName: `Twin${unique()}`, applicantLastName: 'Pair', applicantDateOfBirth: '2011-01-01' });
    const first = await submission.submit(base);
    const second = await submission.submit(base);
    const stored = await repo.findApplicationById(first.applicationId);
    expect(stored?.guardianEmail).toBe(stored?.guardianEmail?.toLowerCase());
    expect((await repo.findApplicationById(second.applicationId))?.possibleDuplicateOf).toBe(first.applicationId);
    expect(stored?.possibleDuplicateOf).toBeNull();
  });

  it('a manager in another campus gets "not found" for this campus’s application', async () => {
    const receipt = await submission.submit(form());
    await expect(review.startReview(managerB, receipt.applicationId)).rejects.toThrow('not found');
    expect((await repo.findApplicationById(receipt.applicationId))?.status).toBe('submitted');
  });

  it('losing a race on a transition surfaces as a conflict, not a server error', async () => {
    const receipt = await submission.submit(form());
    const results = await Promise.allSettled([
      review.startReview(manager, receipt.applicationId),
      review.startReview(manager, receipt.applicationId),
    ]);
    // The service read may see "submitted" for both; the database allows an identical re-assertion
    // of under_review, so both can succeed. What must never happen is an unclassified failure.
    for (const r of results) {
      if (r.status === 'rejected') expect(r.reason.constructor.name).toMatch(/Conflict|Forbidden|NotFound|BadRequest/);
    }
    expect((await repo.findApplicationById(receipt.applicationId))?.status).toBe('under_review');
  });
});

describe('access control through real JWTs and the real API layer', () => {
  let sample: { id: string };
  beforeAll(async () => {
    sample = await repo.createApplication(application());
  });

  describe('anonymous (anon key only)', () => {
    it('sees no applications at all', async () => {
      const { data, error } = await anon.from('applications').select('*');
      expect(error).toBeNull();
      expect(data).toEqual([]);
    });

    it('cannot insert, update or delete, and cannot call the atomic functions', async () => {
      expectPrivilegeDenied(await anon.from('applications').insert(rawApplicationRow()));
      expectPrivilegeDenied(await anon.from('guardians').insert({ campus_id: ID.campusA, first_name: 'X', last_name: 'Y' }));
      expectPrivilegeDenied(await anon.from('applications').update({ review_notes: 'x' }).eq('id', sample.id));
      expectPrivilegeDenied(await anon.from('applications').delete().eq('id', sample.id));
      expectPrivilegeDenied(await anon.rpc('app_convert_application', { p_application_id: sample.id, p_campus_id: ID.campusA, p_class_id: ID.classJss1A, p_actor_id: ID.userAdminA }));
      expectPrivilegeDenied(await anon.rpc('app_application_transition', { p_id: sample.id, p_campus_id: ID.campusA, p_to_status: 'under_review', p_actor_id: ID.userAdminA, p_action: 'x', p_review_notes: null, p_decision_reason: null }));
    });
  });

  describe('authenticated staff — claims reach auth.uid() and RLS', () => {
    it('a Campus A administrator reads Campus A applications and nothing else', async () => {
      const { data, error } = await asUser(ID.authAdminA).from('applications').select('campus_id');
      expect(error).toBeNull();
      expect((data ?? []).length).toBeGreaterThan(0);
      expect((data ?? []).every((r) => r.campus_id === ID.campusA)).toBe(true);
    });

    it('a Campus B administrator sees none of Campus A’s applications', async () => {
      const { data } = await asUser(ID.authAdminB).from('applications').select('campus_id');
      expect((data ?? []).every((r) => r.campus_id === ID.campusB)).toBe(true);
    });

    it('a vice principal (read only) can read; an accountant (no permission) sees nothing', async () => {
      expect(((await asUser(ID.authVpA).from('applications').select('id')).data ?? []).length).toBeGreaterThan(0);
      expect((await asUser(ID.authAccountantA).from('applications').select('id')).data).toEqual([]);
    });

    it('even a manager cannot write directly or call the atomic functions — writes go through the App Backend only', async () => {
      const admin = asUser(ID.authAdminA);
      expectPrivilegeDenied(await admin.from('applications').insert(rawApplicationRow()));
      expectPrivilegeDenied(await admin.from('applications').update({ review_notes: 'x' }).eq('id', sample.id));
      expectPrivilegeDenied(await admin.rpc('app_convert_application', { p_application_id: sample.id, p_campus_id: ID.campusA, p_class_id: ID.classJss1A, p_actor_id: ID.userAdminA }));
    });
  });

  describe('student_current_enrollments (migration 0029): the view must not bypass row-level security', () => {
    beforeAll(async () => {
      // One real current enrollment in Campus A, so "sees nothing" is a meaningful result.
      const student = await service.from('students').insert({ campus_id: ID.campusA, display_name: `ViewProbe${unique()}` }).select('id').single();
      await service.from('enrollments').insert({
        student_id: student.data?.id, class_id: ID.classJss1A,
        academic_session_id: 'c5000000-0000-0000-0000-000000000001', campus_id: ID.campusA, status: 'active',
      });
    });

    it('anonymous callers are refused outright (the view once returned every campus to anyone)', async () => {
      expectPrivilegeDenied(await anon.from('student_current_enrollments').select('*'));
    });

    it('an authenticated user with no role sees nothing', async () => {
      expect((await asUser(ID.authAccountantA).from('student_current_enrollments').select('*')).data).toEqual([]);
    });

    it('a Campus B administrator sees none of Campus A’s enrollments', async () => {
      const { data } = await asUser(ID.authAdminB).from('student_current_enrollments').select('campus_id');
      expect((data ?? []).every((r) => r.campus_id === ID.campusB)).toBe(true);
    });

    it('a Campus A administrator sees their own campus’s enrollments, and nothing else', async () => {
      const { data } = await asUser(ID.authAdminA).from('student_current_enrollments').select('campus_id');
      expect((data ?? []).length).toBeGreaterThan(0);
      expect((data ?? []).every((r) => r.campus_id === ID.campusA)).toBe(true);
    });

    it('the App Backend (service role) still reads it', async () => {
      const { data, error } = await service.from('student_current_enrollments').select('campus_id');
      expect(error).toBeNull();
      expect((data ?? []).length).toBeGreaterThan(0);
    });
  });

  describe('guardian self-access', () => {
    it('a guardian sees only their own guardian record and link, and no applications', async () => {
      const guardian = asUser(ID.authGuardianA);
      const own = await guardian.from('guardians').select('id');
      expect(own.data).toEqual([{ id: ID.guardianLinked }]);
      expect(((await guardian.from('guardian_students').select('guardian_id')).data ?? []).length).toBe(1);
      expect((await guardian.from('applications').select('id')).data).toEqual([]);
    });
  });

  describe('token handling', () => {
    it('PostgREST refuses a token signed with the wrong secret', async () => {
      const forged = jwt.sign({ role: 'authenticated', sub: ID.authAdminA }, 'not-the-secret-not-the-secret-0000', { algorithm: 'HS256' });
      const res = await fetch(`${URL}/rest/v1/applications?select=id`, { headers: { apikey: anonKey, Authorization: `Bearer ${forged}` } });
      expect(res.status).toBe(401);
    });

    it('a token whose claimed role is privileged but whose signature is forged cannot become service_role', async () => {
      const forged = jwt.sign({ role: 'service_role' }, 'not-the-secret-not-the-secret-0000', { algorithm: 'HS256' });
      const res = await fetch(`${URL}/rest/v1/applications?select=id`, { headers: { apikey: forged, Authorization: `Bearer ${forged}` } });
      expect(res.status).toBe(401);
    });
  });
});
