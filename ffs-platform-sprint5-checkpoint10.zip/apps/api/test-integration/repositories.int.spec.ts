import { createClient, SupabaseClient } from '@supabase/supabase-js';
import * as jwt from 'jsonwebtoken';
import { SupabaseAcademicRepository } from '../src/modules/academic/academic.repository';
import { AuditController } from '../src/modules/audit/audit.controller';
import { CmsGalleryRepository } from '../src/modules/cms/cms-gallery.repository';
import { CmsNewsRepository } from '../src/modules/cms/cms-news.repository';
import { CmsPagesRepository } from '../src/modules/cms/cms-pages.repository';
import { CmsStaffProfilesRepository } from '../src/modules/cms/cms-staff-profiles.repository';
import { SupabaseConfigRepository } from '../src/modules/config/config.repository';
import { SupabaseIdentityRepository } from '../src/modules/identity/identity.repository';
import { ResolvedIdentity } from '../src/modules/identity/identity.types';

/**
 * Every repository, every method, against the REAL stack (PostgreSQL + PostgREST + supabase-js).
 *
 * Why this exists: these repositories were written against in-memory fakes and had never met a database.
 * That is how SupabaseIdentityRepository shipped selecting a column (`users.organization_id`) that does not
 * exist — which made every authenticated request fail. A fake cannot catch a wrong column name, a wrong
 * embed, a wrong RPC argument, or a type the database rejects; only the real thing can. These tests are
 * deliberately thin on business rules (the unit suites own those) and strict on one question:
 * does each method actually work against the real schema?
 */
const URL = process.env.INTEGRATION_URL;
const SECRET = process.env.INTEGRATION_JWT_SECRET;
if (!URL || !SECRET) throw new Error('INTEGRATION_URL / INTEGRATION_JWT_SECRET not set — run supabase/local-test-harness/run_integration.sh');

const client: SupabaseClient = createClient(URL, jwt.sign({ role: 'service_role' }, SECRET, { algorithm: 'HS256', expiresIn: '1h' }), {
  auth: { persistSession: false, autoRefreshToken: false },
});

const ID = {
  campusA: 'c2000000-0000-0000-0000-000000000001',
  orgA: 'c1000000-0000-0000-0000-000000000001',
  authAdminA: 'c3000000-0000-0000-0000-000000000001',
  userAdminA: 'c4000000-0000-0000-0000-000000000001',
  userVpA: 'c4000000-0000-0000-0000-000000000002',
  defJss1: 'c6000000-0000-0000-0000-000000000001',
};
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
let n = 0;
const uniq = () => `${Date.now().toString(36)}${(n += 1)}`;

describe('SupabaseIdentityRepository', () => {
  const repo = new SupabaseIdentityRepository(client);

  it('findUserByAuthId resolves the user, including the organization through the campus', async () => {
    expect(await repo.findUserByAuthId(ID.authAdminA)).toEqual({
      appUserId: ID.userAdminA,
      authUserId: ID.authAdminA,
      email: 'admin-a@int.test',
      status: 'active',
      campusId: ID.campusA,
      organizationId: ID.orgA,
    });
  });

  it('findUserByAuthId returns null for an unknown auth user', async () => {
    expect(await repo.findUserByAuthId('00000000-0000-4000-8000-000000000000')).toBeNull();
  });

  it('findRolesForUser returns role keys', async () => {
    expect(await repo.findRolesForUser(ID.userAdminA)).toEqual(['school_administrator']);
    expect(await repo.findRolesForUser('00000000-0000-4000-8000-000000000000')).toEqual([]);
  });

  it('findPermissionsForRoles resolves permission keys from role keys', async () => {
    const permissions = await repo.findPermissionsForRoles(['school_administrator']);
    expect(permissions).toEqual(expect.arrayContaining(['admissions.applications.read', 'admissions.applications.manage']));
    expect(await repo.findPermissionsForRoles([])).toEqual([]);
    expect(await repo.findPermissionsForRoles(['no_such_role'])).toEqual([]);
  });

  it('assignRole writes a user_roles row, and an unknown role is refused', async () => {
    const { data: user } = await client.from('users').select('id').eq('id', ID.userVpA).single();
    await repo.assignRole({ appUserId: user?.id, roleKey: 'accountant', campusId: ID.campusA, assignedBy: ID.userAdminA });
    expect(await repo.findRolesForUser(ID.userVpA)).toEqual(expect.arrayContaining(['accountant', 'vice_principal']));
    await expect(repo.assignRole({ appUserId: ID.userVpA, roleKey: 'no_such_role', campusId: ID.campusA, assignedBy: ID.userAdminA })).rejects.toThrow('Unknown role key');
  });

  it('recordAudit writes an audit_logs row', async () => {
    const targetId = `id-${uniq()}`;
    await repo.recordAudit({ actorId: ID.userAdminA, campusId: ID.campusA, action: 'int.identity', targetType: 'int_test', targetId, metadata: { a: 1 } });
    const { data } = await client.from('audit_logs').select('action, metadata_json').eq('target_id', targetId);
    expect(data).toEqual([{ action: 'int.identity', metadata_json: { a: 1 } }]);
  });
});

describe('SupabaseConfigRepository', () => {
  const repo = new SupabaseConfigRepository(client);

  it('reads definitions by key and by category', async () => {
    const def = await repo.findDefinitionByKey('finance.default_currency');
    expect(def).toMatchObject({ key: 'finance.default_currency', category: 'finance', dataType: 'string' });
    expect(await repo.findDefinitionByKey('no.such.key')).toBeNull();
    expect((await repo.listDefinitionsByCategory('finance')).map((d) => d.key)).toContain('finance.default_currency');
  });

  it('writes a value atomically with its audit entry, then reads it back', async () => {
    const def = await repo.findDefinitionByKey('school.timezone');
    expect(await repo.findValue(def?.id as string, ID.campusA)).toBeNull();

    const written = await repo.upsertValueWithAudit({ configDefinitionId: def?.id as string, campusId: ID.campusA, newValue: 'Africa/Lagos', actorId: ID.userAdminA });
    expect(written).toMatchObject({ key: 'school.timezone', category: 'school', value: 'Africa/Lagos', campusId: ID.campusA, updatedBy: ID.userAdminA });

    expect(await repo.findValue(def?.id as string, ID.campusA)).toMatchObject({ value: 'Africa/Lagos' });
    expect((await repo.listValuesByCategory('school', ID.campusA)).map((v) => v.key)).toContain('school.timezone');

    const audit = await client.from('config_audit_log').select('old_value_json, new_value_json, actor_id').eq('config_definition_id', def?.id).eq('campus_id', ID.campusA);
    expect(audit.error).toBeNull();
    expect(audit.data).toEqual([{ old_value_json: null, new_value_json: 'Africa/Lagos', actor_id: ID.userAdminA }]);
  });
});

describe('SupabaseAcademicRepository', () => {
  const repo = new SupabaseAcademicRepository(client);
  const tag = uniq();
  const year = 2040 + (n % 50) * 2; // far-future, non-overlapping with fixtures and with reruns of this suite
  const state: Record<string, string> = {};

  // This suite makes a new session "current" for the campus. Put the fixture session back, so tests in other
  // files that depend on it (e.g. the enrollments view only shows current-session enrollments) are unaffected.
  afterAll(async () => {
    await repo.setCurrentSession(ID.campusA, 'c5000000-0000-0000-0000-000000000001');
  });

  it('sessions and terms: create, then make current', async () => {
    const session = await repo.createSession({ campusId: ID.campusA, name: `S-${tag}`, startDate: `${year}-09-01`, endDate: `${year + 1}-07-31` });
    expect(session).toMatchObject({ campusId: ID.campusA, name: `S-${tag}`, isCurrent: false });
    state.session = session.id;

    expect(await repo.setCurrentSession(ID.campusA, session.id)).toMatchObject({ id: session.id, isCurrent: true });

    const term = await repo.createTerm({ academicSessionId: session.id, campusId: ID.campusA, name: `T-${tag}`, startDate: `${year}-09-01`, endDate: `${year}-12-15` });
    expect(term).toMatchObject({ academicSessionId: session.id, isCurrent: false });
    state.term = term.id;
    expect(await repo.setCurrentTerm(session.id, term.id)).toMatchObject({ id: term.id, isCurrent: true });
  });

  it('class definitions, classes and subjects: create, link, read', async () => {
    const definition = await repo.createClassDefinition({ campusId: ID.campusA, name: `Level-${tag}`, level: 'basic' });
    expect(definition).toMatchObject({ campusId: ID.campusA, name: `Level-${tag}`, level: 'basic' });

    const classA = await repo.createClass({ classDefinitionId: definition.id, academicSessionId: state.session, campusId: ID.campusA, name: `ClassA-${tag}`, section: 'A' });
    const classB = await repo.createClass({ classDefinitionId: definition.id, academicSessionId: state.session, campusId: ID.campusA, name: `ClassB-${tag}`, section: null });
    state.classA = classA.id;
    state.classB = classB.id;
    expect(await repo.findClassById(classA.id)).toMatchObject({ id: classA.id, classDefinitionId: definition.id, academicSessionId: state.session, section: 'A' });
    expect(await repo.findClassById('00000000-0000-4000-8000-000000000000')).toBeNull();

    const subject = await repo.createSubject({ campusId: ID.campusA, name: `Maths-${tag}`, code: `M${tag}`.slice(0, 12) });
    expect(subject).toMatchObject({ campusId: ID.campusA, name: `Maths-${tag}` });
    state.subject = subject.id;
    await repo.linkSubjectToClass(classA.id, subject.id);
    expect(await repo.getSubjectById(subject.id)).toMatchObject({ id: subject.id, name: `Maths-${tag}` });
    expect(await repo.getSubjectById('00000000-0000-4000-8000-000000000000')).toBeNull();
  });

  it('enrollments: create, find, list history, transfer, close', async () => {
    const student = await client.from('students').insert({ campus_id: ID.campusA, display_name: `Acad ${tag}` }).select('id').single();
    const studentId = student.data?.id as string;
    state.student = studentId;

    expect(await repo.getStudentCampusId(studentId)).toBe(ID.campusA);
    expect(await repo.getStudentCampusId('00000000-0000-4000-8000-000000000000')).toBeNull();
    expect(await repo.getStudentUsersId(studentId)).toBeNull();
    expect(await repo.findCurrentEnrollment(studentId)).toBeNull();

    const enrolled = await repo.createEnrollment({ studentId, classId: state.classA, academicSessionId: state.session, termId: state.term, campusId: ID.campusA });
    expect(enrolled).toMatchObject({ studentId, classId: state.classA, status: 'active', termId: state.term });
    expect(await repo.findActiveEnrollment(studentId, state.session)).toMatchObject({ id: enrolled.id });
    expect(await repo.findCurrentEnrollment(studentId)).toMatchObject({ id: enrolled.id });

    const moved = await repo.transferEnrollment({ studentId, fromEnrollmentId: enrolled.id, newClassId: state.classB, reason: 'integration test' });
    expect(moved).toMatchObject({ studentId, classId: state.classB, status: 'active' });
    const history = await repo.listEnrollmentHistory(studentId);
    expect(history.map((e) => e.status).sort()).toEqual(['active', 'transferred']);
    expect(history.find((e) => e.id === enrolled.id)).toMatchObject({ status: 'transferred', exitReason: 'integration test' });

    const closed = await repo.closeEnrollment(moved.id, 'withdrawn', 'left the school');
    expect(closed).toMatchObject({ id: moved.id, status: 'withdrawn', exitReason: 'left the school' });
    expect(await repo.findCurrentEnrollment(studentId)).toBeNull();
  });

  it('teacher assignments: resolve staff, assign, check, list, remove', async () => {
    expect(await repo.getStaffIdForUser(ID.userAdminA)).toBeNull();
    const staff = await client.from('staff').insert({ campus_id: ID.campusA, users_id: ID.userAdminA, display_name: `Teacher ${tag}` }).select('id').single();
    const staffId = staff.data?.id as string;
    expect(await repo.getStaffIdForUser(ID.userAdminA)).toBe(staffId);

    expect(await repo.isAssignedToClass(staffId, state.classA)).toBe(false);
    const assignment = await repo.createTeacherAssignment({
      staffId, classId: state.classA, subjectId: state.subject, academicSessionId: state.session,
      campusId: ID.campusA, role: 'subject_teacher', assignedBy: ID.userAdminA,
    });
    expect(assignment).toMatchObject({ staffId, classId: state.classA, subjectId: state.subject, role: 'subject_teacher', assignedBy: ID.userAdminA });
    expect(await repo.isAssignedToClass(staffId, state.classA)).toBe(true);
    expect((await repo.listAssignmentsForStaff(staffId)).map((a) => a.id)).toContain(assignment.id);

    await repo.removeTeacherAssignment(assignment.id);
    expect(await repo.isAssignedToClass(staffId, state.classA)).toBe(false);
  });

  it('recordAudit writes an audit_logs row', async () => {
    const targetId = `id-${uniq()}`;
    await repo.recordAudit({ actorId: ID.userAdminA, campusId: ID.campusA, action: 'int.academic', targetType: 'int_test', targetId, metadata: {} });
    expect((await client.from('audit_logs').select('action').eq('target_id', targetId)).data).toEqual([{ action: 'int.academic' }]);
  });
});

describe('CMS repositories', () => {
  const tag = uniq();
  const cases = [
    {
      name: 'pages',
      repo: new CmsPagesRepository(client),
      table: 'cms_pages',
      create: (r: CmsPagesRepository) => r.create({ campusId: ID.campusA, slug: `page-${tag}`, title: `Page ${tag}`, contentJson: { blocks: [] }, createdBy: ID.userAdminA }),
    },
    {
      name: 'news',
      repo: new CmsNewsRepository(client),
      table: 'cms_news',
      create: (r: CmsNewsRepository) => r.create({ campusId: ID.campusA, title: `News ${tag}`, bodyJson: { blocks: [] }, coverImageUrl: null, createdBy: ID.userAdminA }),
    },
    {
      name: 'gallery',
      repo: new CmsGalleryRepository(client),
      table: 'cms_gallery',
      create: (r: CmsGalleryRepository) => r.create({ campusId: ID.campusA, title: `Photo ${tag}`, imageUrl: 'https://files.example.test/p.jpg', category: null, createdBy: ID.userAdminA }),
    },
    {
      name: 'staff profiles',
      repo: new CmsStaffProfilesRepository(client),
      table: 'cms_staff_profiles',
      create: (r: CmsStaffProfilesRepository) => r.create({ campusId: ID.campusA, staffId: null, displayName: `Profile ${tag}`, bio: null, photoUrl: null, displayOrder: 1, createdBy: ID.userAdminA }),
    },
  ] as const;

  it.each(cases)('$name: create, find, list, transition (atomic with audit), record audit', async (c) => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const repo = c.repo as any;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const created = await (c.create as any)(repo);
    expect(created.id).toMatch(UUID);
    expect(created).toMatchObject({ campusId: ID.campusA, status: 'draft', createdBy: ID.userAdminA });

    expect((await repo.findById(created.id)).id).toBe(created.id);
    expect(await repo.findById('00000000-0000-4000-8000-000000000000')).toBeNull();
    expect((await repo.listByStatus(ID.campusA, 'draft')).map((x: { id: string }) => x.id)).toContain(created.id);
    expect((await repo.listByStatus(ID.campusA)).map((x: { id: string }) => x.id)).toContain(created.id);

    const submitted = await repo.transitionStatus({
      id: created.id, toStatus: 'in_review', actorField: null, actorId: ID.userAdminA,
      campusId: ID.campusA, action: `cms.${c.table}.submitted`, metadata: { via: 'integration' },
    });
    expect(submitted.status).toBe('in_review');
    const audit = await client.from('audit_logs').select('action, actor_id').eq('target_id', created.id);
    expect(audit.data).toEqual([{ action: `cms.${c.table}.submitted`, actor_id: ID.userAdminA }]);

    const targetId = `id-${uniq()}`;
    await repo.recordAudit({ actorId: ID.userAdminA, campusId: ID.campusA, action: 'int.cms', targetType: c.table, targetId, metadata: {} });
    expect((await client.from('audit_logs').select('action').eq('target_id', targetId)).data).toEqual([{ action: 'int.cms' }]);
  });

  it('pages: walk the whole approval path and find the published page by slug', async () => {
    const repo = new CmsPagesRepository(client);
    const page = await repo.create({ campusId: ID.campusA, slug: `walk-${tag}`, title: 'Walk', contentJson: {}, createdBy: ID.userAdminA });
    const step = (toStatus: 'in_review' | 'approved' | 'published', actorField: 'reviewed_by' | 'approved_by' | 'published_by' | null) =>
      repo.transitionStatus({ id: page.id, toStatus, actorField, actorId: ID.userAdminA, campusId: ID.campusA, action: `cms.page.${toStatus}`, metadata: {} });
    await step('in_review', null);
    expect(await repo.findPublishedBySlug(ID.campusA, `walk-${tag}`)).toBeNull();
    await step('approved', 'approved_by');
    const published = await step('published', 'published_by');
    expect(published).toMatchObject({ status: 'published', publishedBy: ID.userAdminA });
    expect(await repo.findPublishedBySlug(ID.campusA, `walk-${tag}`)).toMatchObject({ id: page.id });
  });
});

describe('AuditController (queries the service-role client directly)', () => {
  it('lists the actor’s campus audit entries, newest first, filterable by target type', async () => {
    const controller = new AuditController(client);
    const identity = { campusId: ID.campusA } as ResolvedIdentity;
    await new SupabaseIdentityRepository(client).recordAudit({ actorId: ID.userAdminA, campusId: ID.campusA, action: 'int.audit', targetType: 'int_audit_probe', targetId: `id-${uniq()}`, metadata: { k: 'v' } });

    const all = await controller.list(identity);
    expect(all.length).toBeGreaterThan(0);
    const times = all.map((e) => Date.parse(e.createdAt));
    expect([...times].sort((a, b) => b - a)).toEqual(times);

    const filtered = await controller.list(identity, 'int_audit_probe');
    expect(filtered.length).toBeGreaterThanOrEqual(1);
    expect(filtered.every((e) => e.targetType === 'int_audit_probe')).toBe(true);
    expect(filtered[0]).toMatchObject({ action: 'int.audit', actorId: ID.userAdminA, metadata: { k: 'v' } });
  });
});
