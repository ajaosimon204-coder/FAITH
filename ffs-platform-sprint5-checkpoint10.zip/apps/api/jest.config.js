/** @type {import('jest').Config} */
module.exports = {
  preset: 'ts-jest',
  testEnvironment: 'node',
  rootDir: '.',
  testRegex: '.*\\.spec\\.ts$',
  // Integration specs need a live PostgREST (supabase/local-test-harness/run_integration.sh);
  // they run under jest.integration.config.js, never in the hermetic `npm test`.
  testPathIgnorePatterns: ['/node_modules/', '/test-integration/'],
  collectCoverageFrom: ['src/**/*.(t|j)s', '!src/main.ts'],
  coverageDirectory: '../coverage',
};
