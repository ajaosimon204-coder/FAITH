import { Module } from '@nestjs/common';
import { APP_GUARD } from '@nestjs/core';
import { CoreModule } from './core.module';
import { IdentityModule } from './modules/identity/identity.module';
import { SupabaseAuthGuard } from './modules/identity/supabase-auth.guard';
import { RbacModule } from './modules/rbac/rbac.module';
import { OrganizationsModule } from './modules/organizations/organizations.module';
import { AuditModule } from './modules/audit/audit.module';
import { ConfigModule } from './modules/config/config.module';
import { AcademicModule } from './modules/academic/academic.module';
import { CmsModule } from './modules/cms/cms.module';
import { AdmissionsModule } from './modules/admissions/admissions.module';
import { HealthController } from './health.controller';

@Module({
  imports: [
    CoreModule,
    IdentityModule,
    RbacModule,
    OrganizationsModule,
    AuditModule,
    ConfigModule,
    AcademicModule,
    CmsModule,
    AdmissionsModule,
  ],
  controllers: [HealthController],
  providers: [
    // Every request is authenticated by default (fail closed). The only routes that
    // opt out, via @Public(), are the public CMS reads (Sprint 4) and the public
    // admissions submission (Sprint 5) — each reviewed individually at its controller.
    { provide: APP_GUARD, useClass: SupabaseAuthGuard },
  ],
})
export class AppModule {}
