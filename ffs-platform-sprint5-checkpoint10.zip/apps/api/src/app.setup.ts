import { ValidationPipe } from '@nestjs/common';
import { NestExpressApplication } from '@nestjs/platform-express';
import { parseTrustProxy } from './config/trust-proxy';

/**
 * Everything about the HTTP application that is configuration rather than wiring, in ONE
 * place — used by main.ts and by the boot tests, so the tests exercise exactly what runs
 * in production instead of a hand-copied approximation of it.
 */
export function configureApp(app: NestExpressApplication, env: NodeJS.ProcessEnv = process.env): void {
  app.useGlobalPipes(new ValidationPipe({ whitelist: true, forbidNonWhitelisted: true }));
  app.enableCors({ origin: env.CORS_ORIGIN ?? false, credentials: true });

  // Behind a reverse proxy/load balancer, tell Express how many hops to trust so the
  // per-client rate limit on the public admissions route sees real client addresses.
  const trustProxyHops = parseTrustProxy(env.TRUST_PROXY);
  if (trustProxyHops !== undefined) {
    app.set('trust proxy', trustProxyHops);
  }
}
