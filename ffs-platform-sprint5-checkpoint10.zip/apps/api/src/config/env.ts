/**
 * Centralised environment configuration.
 *
 * Rule: secrets (Supabase service-role/secret key, legacy JWT secret) are read ONLY here,
 * server-side, and never re-exported to any client-facing payload.
 */
export interface AppEnv {
  readonly port: number;
  readonly supabaseUrl: string;
  /** The legacy `service_role` JWT, or a current `sb_secret_...` key. Server-side only. */
  readonly supabaseServiceRoleKey: string;
  /**
   * Legacy HS256 JWT secret. OPTIONAL: only projects still on Supabase's legacy shared secret have one
   * (current projects sign with asymmetric keys, verified through the JWKS endpoint below).
   */
  readonly supabaseJwtSecret: string | undefined;
  /** Where the project publishes its public JWT signing keys. */
  readonly supabaseJwksUrl: string;
  /** Expected `iss` of access tokens. */
  readonly supabaseJwtIssuer: string;
  readonly nodeEnv: 'local' | 'staging' | 'production' | 'test';
}

class MissingEnvError extends Error {
  constructor(key: string) {
    super(
      `Missing required environment variable: ${key}. Refusing to start without it ` +
        `(fail closed, not open, for anything security-relevant).`,
    );
    this.name = 'MissingEnvError';
  }
}

function requireEnv(key: string): string {
  const value = process.env[key];
  if (!value || value.trim().length === 0) {
    throw new MissingEnvError(key);
  }
  return value;
}

function optionalEnv(key: string): string | undefined {
  const value = process.env[key];
  return value && value.trim().length > 0 ? value.trim() : undefined;
}

function requireUrl(key: string, value: string): string {
  try {
    const url = new URL(value);
    if (url.protocol !== 'https:' && url.protocol !== 'http:') throw new Error('not http(s)');
  } catch {
    throw new Error(`Invalid ${key} "${value}": expected an http(s) URL. Refusing to start.`);
  }
  return value.replace(/\/+$/, '');
}

export function loadEnv(): AppEnv {
  const nodeEnv = (process.env.NODE_ENV ?? 'local') as AppEnv['nodeEnv'];
  const supabaseUrl = requireUrl('SUPABASE_URL', requireEnv('SUPABASE_URL'));
  const authBase = `${supabaseUrl}/auth/v1`;

  return {
    port: Number(process.env.PORT ?? 4000),
    supabaseUrl,
    supabaseServiceRoleKey: requireEnv('SUPABASE_SERVICE_ROLE_KEY'),
    supabaseJwtSecret: optionalEnv('SUPABASE_JWT_SECRET'),
    supabaseJwksUrl: requireUrl('SUPABASE_JWKS_URL', optionalEnv('SUPABASE_JWKS_URL') ?? `${authBase}/.well-known/jwks.json`),
    supabaseJwtIssuer: optionalEnv('SUPABASE_JWT_ISSUER') ?? authBase,
    nodeEnv,
  };
}
