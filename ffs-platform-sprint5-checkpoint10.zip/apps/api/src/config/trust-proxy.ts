/**
 * Reads TRUST_PROXY: the number of reverse-proxy hops in front of the API (0 = none).
 *
 * Why it exists: the public admissions route is rate-limited per client address. Behind a
 * load balancer every request arrives from the balancer's address, so without this the
 * limit would be shared by ALL applicants and lock everyone out after a handful of
 * submissions. Setting the hop count lets Express read the real client address from
 * X-Forwarded-For — and ONLY from the trusted hops, so a client cannot spoof its own.
 *
 * Deliberately strict: only a non-negative integer is accepted. `true` (trust every
 * proxy, spoofable) and anything unparseable are refused at startup, in line with the
 * project's fail-closed handling of security-relevant configuration (config/env.ts).
 * Unset means "not behind a proxy": Express's default, the socket address, is used.
 */
export function parseTrustProxy(raw: string | undefined): number | undefined {
  if (raw === undefined || raw.trim() === '') return undefined;
  const hops = raw.trim();
  if (!/^\d+$/.test(hops)) {
    throw new Error(
      `Invalid TRUST_PROXY "${raw}": expected a non-negative integer number of proxy hops (e.g. 1). ` +
        `Refusing to start rather than guess which client addresses to trust.`,
    );
  }
  return Number(hops);
}
