import { Controller, Get } from '@nestjs/common';
import { Public } from './modules/identity/public.decorator';

/**
 * Liveness check for hosting platforms and load balancers ("is the process up and answering?").
 * Deliberately public and deliberately minimal: it touches no database and returns no information about the
 * deployment (no version, no configuration, no dependency status), so it reveals nothing to a stranger.
 * Whether Supabase and the keys are configured correctly is what scripts/smoke-test.mjs is for.
 */
@Controller('health')
export class HealthController {
  @Public()
  @Get()
  check(): { status: 'ok' } {
    return { status: 'ok' };
  }
}
