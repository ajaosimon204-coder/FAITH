import { BadRequestException, ForbiddenException, Injectable } from '@nestjs/common';
import { hasPermission, ResolvedIdentity } from '../identity/identity.types';
import { CmsContentBase, CmsContentStatus } from './cms.types';

/**
 * Every CMS content type (pages, news, gallery, staff profiles) implements
 * this same shape. The four database tables are structurally identical
 * apart from their type-specific fields (Architecture Section B.5 / K) —
 * this interface captures exactly the part that's shared, so the workflow
 * logic below is written ONCE (Governance Rule 2), not duplicated four
 * times.
 */
export interface ICmsContentRepository<TRecord extends CmsContentBase> {
  findById(id: string): Promise<TRecord | null>;
  /**
   * Atomic status transition (write + audit log entry in one Postgres
   * transaction, via app_cms_transition — migration 0019). Replaces the
   * former two-step updateStatus()+recordAudit() pattern, which was not
   * atomic (a failure between the two calls left a status change with no
   * audit trail — see ADR-018) and, more importantly, was never the real
   * fix for the Critical audit findings on its own: the atomicity gap was
   * secondary to the RLS-layer permission-granularity and actor-forgery
   * bypasses, which required removing direct-client write access entirely,
   * not just making the App Backend's own writes atomic.
   */
  transitionStatus(params: {
    id: string;
    toStatus: CmsContentStatus;
    actorField: 'reviewed_by' | 'approved_by' | 'published_by' | null;
    actorId: string;
    campusId: string;
    action: string;
    metadata: Record<string, unknown>;
    extraFields?: Record<string, unknown>;
  }): Promise<TRecord>;
  listByStatus(campusId: string, status?: CmsContentStatus): Promise<TRecord[]>;
}

const REQUIRED_PERMISSION_FOR_TRANSITION: Record<string, string> = {
  'draft->in_review': 'content.create',
  'in_review->approved': 'content.review',
  'in_review->draft': 'content.review',
  'approved->draft': 'content.publish', // a late reject after approval is a publish-tier decision
  'approved->published': 'content.publish',
  'published->archived': 'content.archive',
};

/**
 * Generic workflow engine shared by all four CMS content types. Instantiated
 * once per content type (see cms.module.ts) with that type's repository —
 * the workflow rules themselves (which transitions exist, which permission
 * each one requires) live here exactly once.
 *
 * Mirrors the result-workflow pattern from the approved architecture
 * (Phase 1 Revised, Section F): draft -> submitted/in_review -> reviewed/
 * approved -> locked/published, with an explicit reject-back path — same
 * shape, different domain.
 */
@Injectable()
export class CmsContentWorkflowService<TRecord extends CmsContentBase> {
  constructor(
    private readonly repository: ICmsContentRepository<TRecord>,
    private readonly targetTypeName: string,
  ) {}

  async submitForReview(actor: ResolvedIdentity, id: string): Promise<TRecord> {
    return this.transition(actor, id, 'in_review', null);
  }

  async approve(actor: ResolvedIdentity, id: string): Promise<TRecord> {
    return this.transition(actor, id, 'approved', 'reviewed_by');
  }

  async rejectToDraft(actor: ResolvedIdentity, id: string): Promise<TRecord> {
    const current = await this.requireRecord(actor, id);
    // Which permission applies depends on which state we're rejecting FROM.
    return this.transition(actor, id, 'draft', current.status === 'approved' ? null : 'reviewed_by');
  }

  async publish(actor: ResolvedIdentity, id: string): Promise<TRecord> {
    return this.transition(actor, id, 'published', 'published_by');
  }

  async archive(actor: ResolvedIdentity, id: string): Promise<TRecord> {
    return this.transition(actor, id, 'archived', null);
  }

  async list(actor: ResolvedIdentity, status?: CmsContentStatus): Promise<TRecord[]> {
    // Fixed per the Sprint 4 adversarial audit (High finding): this
    // previously had NO permission check at all — any authenticated user,
    // any role, could list non-published content (draft/in_review/
    // approved/archived) for their own campus. This route is for content
    // authoring/management; public consumption of published content goes
    // through the separate, dedicated public controller/service, which
    // has its own explicit query filter independent of this permission
    // check.
    const hasAnyContentPermission =
      hasPermission(actor, 'content.create') ||
      hasPermission(actor, 'content.review') ||
      hasPermission(actor, 'content.publish') ||
      hasPermission(actor, 'content.archive');
    if (!hasAnyContentPermission) {
      throw new ForbiddenException(
        `Not authorized to list ${this.targetTypeName} — requires at least one content.* permission.`,
      );
    }
    return this.repository.listByStatus(actor.campusId, status);
  }

  private async requireRecord(actor: ResolvedIdentity, id: string): Promise<TRecord> {
    const record = await this.repository.findById(id);
    if (!record) {
      throw new BadRequestException(`${this.targetTypeName} ${id} not found.`);
    }
    // Cross-campus check (same class of gap found and fixed in the Sprint 3
    // re-audit, ADR-014 — applied here proactively per that finding's own
    // recommendation: every service-role-backed read/write path must
    // re-derive campus scoping explicitly, since RLS does not run here).
    if (record.campusId !== actor.campusId) {
      throw new BadRequestException(`${this.targetTypeName} ${id} not found.`);
    }
    return record;
  }

  private async transition(
    actor: ResolvedIdentity,
    id: string,
    to: CmsContentStatus,
    actorField: 'reviewed_by' | 'approved_by' | 'published_by' | null,
  ): Promise<TRecord> {
    const current = await this.requireRecord(actor, id);

    const transitionKey = `${current.status}->${to}`;
    const requiredPermission = REQUIRED_PERMISSION_FOR_TRANSITION[transitionKey];
    if (!requiredPermission) {
      throw new BadRequestException(
        `Invalid transition for ${this.targetTypeName}: ${current.status} -> ${to}.`,
      );
    }
    if (!hasPermission(actor, requiredPermission)) {
      throw new ForbiddenException(
        `Not authorized to move ${this.targetTypeName} from ${current.status} to ${to} ` +
          `(requires ${requiredPermission}).`,
      );
    }

    const updated = await this.repository.transitionStatus({
      id,
      toStatus: to,
      actorField,
      actorId: actor.appUserId,
      campusId: actor.campusId,
      action: `${this.targetTypeName}.${transitionKey.replace('->', '_to_')}`,
      metadata: { from: current.status, to },
    });

    return updated;
  }
}
