import { Body, Controller, Get, Param, Post, Query } from '@nestjs/common';
import { CurrentIdentity } from '../identity/current-identity.decorator';
import { ResolvedIdentity } from '../identity/identity.types';
import { Public } from '../identity/public.decorator';
import { CmsPagesService } from './cms-pages.service';
import { CmsContentStatus } from './cms.types';

interface CreatePageBody {
  slug: string;
  title: string;
  contentJson: unknown;
}

/**
 * Sprint 4 exposes the full workflow only for cms_pages (the reference
 * implementation) — news/gallery/staff-profiles have complete repositories
 * and share the same CmsContentWorkflowService, but their own controller
 * routes are deferred (see Sprint 4 Completion Report, "Architecture
 * Deviations") to keep this sprint's surface area reviewable. Wiring their
 * routes is a small, mechanical follow-up, not a redesign.
 */
@Controller('api/v1/cms')
export class CmsController {
  constructor(private readonly pagesService: CmsPagesService) {}

  @Post('pages')
  createPage(@CurrentIdentity() identity: ResolvedIdentity, @Body() body: CreatePageBody) {
    return this.pagesService.create(identity, body);
  }

  @Post('pages/:id/submit-for-review')
  submitForReview(@CurrentIdentity() identity: ResolvedIdentity, @Param('id') id: string) {
    return this.pagesService.submitForReview(identity, id);
  }

  @Post('pages/:id/approve')
  approve(@CurrentIdentity() identity: ResolvedIdentity, @Param('id') id: string) {
    return this.pagesService.approve(identity, id);
  }

  @Post('pages/:id/reject')
  reject(@CurrentIdentity() identity: ResolvedIdentity, @Param('id') id: string) {
    return this.pagesService.rejectToDraft(identity, id);
  }

  @Post('pages/:id/publish')
  publish(@CurrentIdentity() identity: ResolvedIdentity, @Param('id') id: string) {
    return this.pagesService.publish(identity, id);
  }

  @Post('pages/:id/archive')
  archive(@CurrentIdentity() identity: ResolvedIdentity, @Param('id') id: string) {
    return this.pagesService.archive(identity, id);
  }

  @Get('pages')
  list(@CurrentIdentity() identity: ResolvedIdentity, @Query('status') status?: CmsContentStatus) {
    return this.pagesService.list(identity, status);
  }
}

/**
 * Genuinely public: no authentication required, opted out of the global
 * SupabaseAuthGuard via @Public() (see identity/public.decorator.ts). This
 * reads only `published` content, which the repository/RLS already scope
 * to public-safe data — the guard exception is safe specifically because
 * the underlying query has its own independent restriction.
 */
@Controller('api/v1/public/cms')
export class PublicCmsController {
  constructor(private readonly pagesService: CmsPagesService) {}

  @Public()
  @Get('pages/:slug')
  getPublishedPage(@Param('slug') slug: string, @Query('campusId') campusId: string) {
    return this.pagesService.getPublishedBySlug(campusId, slug);
  }
}
