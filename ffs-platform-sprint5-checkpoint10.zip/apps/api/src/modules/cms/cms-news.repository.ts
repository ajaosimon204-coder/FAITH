import { Injectable } from '@nestjs/common';
import { SupabaseClient } from '@supabase/supabase-js';
import { ICmsContentRepository } from './cms-workflow.service';
import { CmsContentStatus, CmsNews } from './cms.types';

function toCmsNews(row: Record<string, unknown>): CmsNews {
  return {
    id: row.id as string,
    campusId: row.campus_id as string,
    title: row.title as string,
    bodyJson: row.body_json,
    coverImageUrl: (row.cover_image_url as string | null) ?? null,
    publishedAt: (row.published_at as string | null) ?? null,
    status: row.status as CmsContentStatus,
    createdBy: row.created_by as string,
    reviewedBy: (row.reviewed_by as string | null) ?? null,
    approvedBy: (row.approved_by as string | null) ?? null,
    publishedBy: (row.published_by as string | null) ?? null,
    createdAt: row.created_at as string,
    updatedAt: row.updated_at as string,
  };
}

@Injectable()
export class CmsNewsRepository implements ICmsContentRepository<CmsNews> {
  constructor(private readonly client: SupabaseClient) {}

  async create(input: {
    campusId: string;
    title: string;
    bodyJson: unknown;
    coverImageUrl: string | null;
    createdBy: string;
  }): Promise<CmsNews> {
    const { data, error } = await this.client
      .from('cms_news')
      .insert({
        campus_id: input.campusId,
        title: input.title,
        body_json: input.bodyJson,
        cover_image_url: input.coverImageUrl,
        created_by: input.createdBy,
      })
      .select()
      .single();
    if (error) throw new Error(`Failed to create CMS news item: ${error.message}`);
    return toCmsNews(data);
  }

  async findById(id: string): Promise<CmsNews | null> {
    const { data, error } = await this.client.from('cms_news').select('*').eq('id', id).maybeSingle();
    if (error) throw new Error(`Failed to load CMS news item: ${error.message}`);
    return data ? toCmsNews(data) : null;
  }

  async transitionStatus(params: {
    id: string;
    toStatus: CmsContentStatus;
    actorField: 'reviewed_by' | 'approved_by' | 'published_by' | null;
    actorId: string;
    campusId: string;
    action: string;
    metadata: Record<string, unknown>;
    extraFields?: Record<string, unknown>;
  }): Promise<CmsNews> {
    // cms_news has a type-specific side effect (published_at) that must
    // land atomically with the status change — passed via extraFields
    // rather than hardcoded here, so the caller (CmsNewsService, once
    // wired) decides when to set it, e.g. only on the ->published
    // transition specifically.
    const { error } = await this.client.rpc('app_cms_transition', {
      p_table_name: 'cms_news',
      p_id: params.id,
      p_to_status: params.toStatus,
      p_actor_field: params.actorField,
      p_actor_id: params.actorId,
      p_action: params.action,
      p_campus_id: params.campusId,
      p_metadata: params.metadata,
      p_extra_fields: params.extraFields ?? {},
    });
    if (error) throw new Error(`Failed to transition CMS news status: ${error.message}`);

    const updated = await this.findById(params.id);
    if (!updated) throw new Error(`CMS news item ${params.id} not found after transition.`);
    return updated;
  }

  async listByStatus(campusId: string, status?: CmsContentStatus): Promise<CmsNews[]> {
    let query = this.client.from('cms_news').select('*').eq('campus_id', campusId);
    if (status) query = query.eq('status', status);
    const { data, error } = await query;
    if (error) throw new Error(`Failed to list CMS news: ${error.message}`);
    return (data ?? []).map(toCmsNews);
  }

  async recordAudit(entry: {
    actorId: string;
    campusId: string;
    action: string;
    targetType: string;
    targetId: string;
    metadata: Record<string, unknown>;
  }): Promise<void> {
    const { error } = await this.client.from('audit_logs').insert({
      actor_id: entry.actorId,
      campus_id: entry.campusId,
      action: entry.action,
      target_type: entry.targetType,
      target_id: entry.targetId,
      metadata_json: entry.metadata,
    });
    if (error) throw new Error(`Failed to write audit log: ${error.message}`);
  }
}
