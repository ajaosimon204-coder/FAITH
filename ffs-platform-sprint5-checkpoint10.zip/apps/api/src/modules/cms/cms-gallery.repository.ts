import { Injectable } from '@nestjs/common';
import { SupabaseClient } from '@supabase/supabase-js';
import { ICmsContentRepository } from './cms-workflow.service';
import { CmsContentStatus, CmsGalleryItem } from './cms.types';

function toCmsGalleryItem(row: Record<string, unknown>): CmsGalleryItem {
  return {
    id: row.id as string,
    campusId: row.campus_id as string,
    title: row.title as string,
    imageUrl: row.image_url as string,
    category: (row.category as string | null) ?? null,
    status: row.status as CmsContentStatus,
    createdBy: row.created_by as string,
    reviewedBy: (row.reviewed_by as string | null) ?? null,
    approvedBy: (row.approved_by as string | null) ?? null,
    publishedBy: (row.published_by as string | null) ?? null,
    createdAt: row.created_at as string,
    updatedAt: row.updated_at as string,
  };
}

@Injectable()
export class CmsGalleryRepository implements ICmsContentRepository<CmsGalleryItem> {
  constructor(private readonly client: SupabaseClient) {}

  async create(input: {
    campusId: string;
    title: string;
    imageUrl: string;
    category: string | null;
    createdBy: string;
  }): Promise<CmsGalleryItem> {
    const { data, error } = await this.client
      .from('cms_gallery')
      .insert({
        campus_id: input.campusId,
        title: input.title,
        image_url: input.imageUrl,
        category: input.category,
        created_by: input.createdBy,
      })
      .select()
      .single();
    if (error) throw new Error(`Failed to create CMS gallery item: ${error.message}`);
    return toCmsGalleryItem(data);
  }

  async findById(id: string): Promise<CmsGalleryItem | null> {
    const { data, error } = await this.client
      .from('cms_gallery')
      .select('*')
      .eq('id', id)
      .maybeSingle();
    if (error) throw new Error(`Failed to load CMS gallery item: ${error.message}`);
    return data ? toCmsGalleryItem(data) : null;
  }

  async transitionStatus(params: {
    id: string;
    toStatus: CmsContentStatus;
    actorField: 'reviewed_by' | 'approved_by' | 'published_by' | null;
    actorId: string;
    campusId: string;
    action: string;
    metadata: Record<string, unknown>;
    extraFields?: Record<string, unknown>;
  }): Promise<CmsGalleryItem> {
    const { error } = await this.client.rpc('app_cms_transition', {
      p_table_name: 'cms_gallery',
      p_id: params.id,
      p_to_status: params.toStatus,
      p_actor_field: params.actorField,
      p_actor_id: params.actorId,
      p_action: params.action,
      p_campus_id: params.campusId,
      p_metadata: params.metadata,
      p_extra_fields: params.extraFields ?? {},
    });
    if (error) throw new Error(`Failed to transition CMS gallery item status: ${error.message}`);

    const updated = await this.findById(params.id);
    if (!updated) throw new Error(`CMS gallery item ${params.id} not found after transition.`);
    return updated;
  }

  async listByStatus(campusId: string, status?: CmsContentStatus): Promise<CmsGalleryItem[]> {
    let query = this.client.from('cms_gallery').select('*').eq('campus_id', campusId);
    if (status) query = query.eq('status', status);
    const { data, error } = await query;
    if (error) throw new Error(`Failed to list CMS gallery items: ${error.message}`);
    return (data ?? []).map(toCmsGalleryItem);
  }

  async recordAudit(entry: {
    actorId: string;
    campusId: string;
    action: string;
    targetType: string;
    targetId: string;
    metadata: Record<string, unknown>;
  }): Promise<void> {
    const { error } = await this.client.from('audit_logs').insert({
      actor_id: entry.actorId,
      campus_id: entry.campusId,
      action: entry.action,
      target_type: entry.targetType,
      target_id: entry.targetId,
      metadata_json: entry.metadata,
    });
    if (error) throw new Error(`Failed to write audit log: ${error.message}`);
  }
}
