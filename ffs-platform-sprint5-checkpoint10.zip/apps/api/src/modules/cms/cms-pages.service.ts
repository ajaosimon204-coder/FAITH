import { ForbiddenException, Injectable } from '@nestjs/common';
import { hasPermission, ResolvedIdentity } from '../identity/identity.types';
import { CmsContentWorkflowService } from './cms-workflow.service';
import { CmsPagesRepository } from './cms-pages.repository';
import { CmsPage } from './cms.types';

@Injectable()
export class CmsPagesService {
  constructor(
    private readonly repository: CmsPagesRepository,
    private readonly workflow: CmsContentWorkflowService<CmsPage>,
  ) {}

  async create(
    actor: ResolvedIdentity,
    input: { slug: string; title: string; contentJson: unknown },
  ): Promise<CmsPage> {
    if (!hasPermission(actor, 'content.create')) {
      throw new ForbiddenException('Not authorized to create CMS content.');
    }

    const page = await this.repository.create({
      campusId: actor.campusId,
      slug: input.slug,
      title: input.title,
      contentJson: input.contentJson,
      createdBy: actor.appUserId,
    });

    await this.repository.recordAudit({
      actorId: actor.appUserId,
      campusId: actor.campusId,
      action: 'cms_pages.created',
      targetType: 'cms_pages',
      targetId: page.id,
      metadata: { slug: input.slug },
    });

    return page;
  }

  // Workflow transitions delegate entirely to the shared engine — no
  // business logic is re-implemented here (Governance Rule 2).
  submitForReview(actor: ResolvedIdentity, id: string) {
    return this.workflow.submitForReview(actor, id);
  }
  approve(actor: ResolvedIdentity, id: string) {
    return this.workflow.approve(actor, id);
  }
  rejectToDraft(actor: ResolvedIdentity, id: string) {
    return this.workflow.rejectToDraft(actor, id);
  }
  publish(actor: ResolvedIdentity, id: string) {
    return this.workflow.publish(actor, id);
  }
  archive(actor: ResolvedIdentity, id: string) {
    return this.workflow.archive(actor, id);
  }
  list(actor: ResolvedIdentity, status?: CmsPage['status']) {
    return this.workflow.list(actor, status);
  }

  /** Public, unauthenticated read — the whole reason this content exists. */
  getPublishedBySlug(campusId: string, slug: string): Promise<CmsPage | null> {
    return this.repository.findPublishedBySlug(campusId, slug);
  }
}
