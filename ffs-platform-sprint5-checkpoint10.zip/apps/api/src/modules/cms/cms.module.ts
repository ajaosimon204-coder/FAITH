import { Module } from '@nestjs/common';
import { SupabaseClient } from '@supabase/supabase-js';
import { SUPABASE_CLIENT } from '../identity/identity.module';
import { CmsController, PublicCmsController } from './cms.controller';
import { CmsContentWorkflowService } from './cms-workflow.service';
import { CmsPagesRepository } from './cms-pages.repository';
import { CmsPagesService } from './cms-pages.service';
import { CmsNewsRepository } from './cms-news.repository';
import { CmsGalleryRepository } from './cms-gallery.repository';
import { CmsStaffProfilesRepository } from './cms-staff-profiles.repository';

const CMS_PAGES_WORKFLOW = 'CMS_PAGES_WORKFLOW';

@Module({
  controllers: [CmsController, PublicCmsController],
  providers: [
    {
      provide: CmsPagesRepository,
      useFactory: (client: SupabaseClient) => new CmsPagesRepository(client),
      inject: [SUPABASE_CLIENT],
    },
    {
      provide: CMS_PAGES_WORKFLOW,
      useFactory: (repo: CmsPagesRepository) =>
        new CmsContentWorkflowService(repo, 'cms_pages'),
      inject: [CmsPagesRepository],
    },
    {
      provide: CmsPagesService,
      useFactory: (repo: CmsPagesRepository, workflow: CmsContentWorkflowService<never>) =>
        new CmsPagesService(repo, workflow),
      inject: [CmsPagesRepository, CMS_PAGES_WORKFLOW],
    },
    // News/gallery/staff-profiles repositories are fully implemented and
    // ready to wire the same way (see Sprint 4 Completion Report,
    // "Architecture Deviations") — registered here as providers so a
    // follow-up only needs to add their services/controller routes, not
    // rebuild the data layer.
    {
      provide: CmsNewsRepository,
      useFactory: (client: SupabaseClient) => new CmsNewsRepository(client),
      inject: [SUPABASE_CLIENT],
    },
    {
      provide: CmsGalleryRepository,
      useFactory: (client: SupabaseClient) => new CmsGalleryRepository(client),
      inject: [SUPABASE_CLIENT],
    },
    {
      provide: CmsStaffProfilesRepository,
      useFactory: (client: SupabaseClient) => new CmsStaffProfilesRepository(client),
      inject: [SUPABASE_CLIENT],
    },
  ],
})
export class CmsModule {}
