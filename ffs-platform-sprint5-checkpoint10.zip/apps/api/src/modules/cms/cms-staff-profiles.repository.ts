import { Injectable } from '@nestjs/common';
import { SupabaseClient } from '@supabase/supabase-js';
import { ICmsContentRepository } from './cms-workflow.service';
import { CmsContentStatus, CmsStaffProfile } from './cms.types';

function toCmsStaffProfile(row: Record<string, unknown>): CmsStaffProfile {
  return {
    id: row.id as string,
    campusId: row.campus_id as string,
    staffId: (row.staff_id as string | null) ?? null,
    displayName: row.display_name as string,
    bio: (row.bio as string | null) ?? null,
    photoUrl: (row.photo_url as string | null) ?? null,
    displayOrder: row.display_order as number,
    status: row.status as CmsContentStatus,
    createdBy: row.created_by as string,
    reviewedBy: (row.reviewed_by as string | null) ?? null,
    approvedBy: (row.approved_by as string | null) ?? null,
    publishedBy: (row.published_by as string | null) ?? null,
    createdAt: row.created_at as string,
    updatedAt: row.updated_at as string,
  };
}

@Injectable()
export class CmsStaffProfilesRepository implements ICmsContentRepository<CmsStaffProfile> {
  constructor(private readonly client: SupabaseClient) {}

  async create(input: {
    campusId: string;
    staffId: string | null;
    displayName: string;
    bio: string | null;
    photoUrl: string | null;
    displayOrder: number;
    createdBy: string;
  }): Promise<CmsStaffProfile> {
    const { data, error } = await this.client
      .from('cms_staff_profiles')
      .insert({
        campus_id: input.campusId,
        staff_id: input.staffId,
        display_name: input.displayName,
        bio: input.bio,
        photo_url: input.photoUrl,
        display_order: input.displayOrder,
        created_by: input.createdBy,
      })
      .select()
      .single();
    if (error) throw new Error(`Failed to create CMS staff profile: ${error.message}`);
    return toCmsStaffProfile(data);
  }

  async findById(id: string): Promise<CmsStaffProfile | null> {
    const { data, error } = await this.client
      .from('cms_staff_profiles')
      .select('*')
      .eq('id', id)
      .maybeSingle();
    if (error) throw new Error(`Failed to load CMS staff profile: ${error.message}`);
    return data ? toCmsStaffProfile(data) : null;
  }

  async transitionStatus(params: {
    id: string;
    toStatus: CmsContentStatus;
    actorField: 'reviewed_by' | 'approved_by' | 'published_by' | null;
    actorId: string;
    campusId: string;
    action: string;
    metadata: Record<string, unknown>;
    extraFields?: Record<string, unknown>;
  }): Promise<CmsStaffProfile> {
    const { error } = await this.client.rpc('app_cms_transition', {
      p_table_name: 'cms_staff_profiles',
      p_id: params.id,
      p_to_status: params.toStatus,
      p_actor_field: params.actorField,
      p_actor_id: params.actorId,
      p_action: params.action,
      p_campus_id: params.campusId,
      p_metadata: params.metadata,
      p_extra_fields: params.extraFields ?? {},
    });
    if (error) throw new Error(`Failed to transition CMS staff profile status: ${error.message}`);

    const updated = await this.findById(params.id);
    if (!updated) throw new Error(`CMS staff profile ${params.id} not found after transition.`);
    return updated;
  }

  async listByStatus(campusId: string, status?: CmsContentStatus): Promise<CmsStaffProfile[]> {
    let query = this.client.from('cms_staff_profiles').select('*').eq('campus_id', campusId);
    if (status) query = query.eq('status', status);
    const { data, error } = await query.order('display_order', { ascending: true });
    if (error) throw new Error(`Failed to list CMS staff profiles: ${error.message}`);
    return (data ?? []).map(toCmsStaffProfile);
  }

  async recordAudit(entry: {
    actorId: string;
    campusId: string;
    action: string;
    targetType: string;
    targetId: string;
    metadata: Record<string, unknown>;
  }): Promise<void> {
    const { error } = await this.client.from('audit_logs').insert({
      actor_id: entry.actorId,
      campus_id: entry.campusId,
      action: entry.action,
      target_type: entry.targetType,
      target_id: entry.targetId,
      metadata_json: entry.metadata,
    });
    if (error) throw new Error(`Failed to write audit log: ${error.message}`);
  }
}
