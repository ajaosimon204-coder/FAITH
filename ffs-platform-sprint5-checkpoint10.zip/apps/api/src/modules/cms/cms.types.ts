export const CMS_CONTENT_STATUSES = [
  'draft',
  'in_review',
  'approved',
  'published',
  'archived',
] as const;
export type CmsContentStatus = (typeof CMS_CONTENT_STATUSES)[number];

export interface CmsContentBase {
  readonly id: string;
  readonly campusId: string;
  readonly status: CmsContentStatus;
  readonly createdBy: string;
  readonly reviewedBy: string | null;
  readonly approvedBy: string | null;
  readonly publishedBy: string | null;
  readonly createdAt: string;
  readonly updatedAt: string;
}

export interface CmsPage extends CmsContentBase {
  readonly slug: string;
  readonly title: string;
  readonly contentJson: unknown;
}

export interface CmsNews extends CmsContentBase {
  readonly title: string;
  readonly bodyJson: unknown;
  readonly coverImageUrl: string | null;
  readonly publishedAt: string | null;
}

export interface CmsGalleryItem extends CmsContentBase {
  readonly title: string;
  readonly imageUrl: string;
  readonly category: string | null;
}

export interface CmsStaffProfile extends CmsContentBase {
  readonly staffId: string | null;
  readonly displayName: string;
  readonly bio: string | null;
  readonly photoUrl: string | null;
  readonly displayOrder: number;
}
