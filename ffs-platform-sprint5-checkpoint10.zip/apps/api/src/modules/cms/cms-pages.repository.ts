import { Injectable } from '@nestjs/common';
import { SupabaseClient } from '@supabase/supabase-js';
import { ICmsContentRepository } from './cms-workflow.service';
import { CmsContentStatus, CmsPage } from './cms.types';

function toCmsPage(row: Record<string, unknown>): CmsPage {
  return {
    id: row.id as string,
    campusId: row.campus_id as string,
    slug: row.slug as string,
    title: row.title as string,
    contentJson: row.content_json,
    status: row.status as CmsContentStatus,
    createdBy: row.created_by as string,
    reviewedBy: (row.reviewed_by as string | null) ?? null,
    approvedBy: (row.approved_by as string | null) ?? null,
    publishedBy: (row.published_by as string | null) ?? null,
    createdAt: row.created_at as string,
    updatedAt: row.updated_at as string,
  };
}

@Injectable()
export class CmsPagesRepository implements ICmsContentRepository<CmsPage> {
  constructor(private readonly client: SupabaseClient) {}

  async create(input: {
    campusId: string;
    slug: string;
    title: string;
    contentJson: unknown;
    createdBy: string;
  }): Promise<CmsPage> {
    const { data, error } = await this.client
      .from('cms_pages')
      .insert({
        campus_id: input.campusId,
        slug: input.slug,
        title: input.title,
        content_json: input.contentJson,
        created_by: input.createdBy,
      })
      .select()
      .single();

    if (error) throw new Error(`Failed to create CMS page: ${error.message}`);
    return toCmsPage(data);
  }

  async findById(id: string): Promise<CmsPage | null> {
    const { data, error } = await this.client
      .from('cms_pages')
      .select('*')
      .eq('id', id)
      .maybeSingle();

    if (error) throw new Error(`Failed to load CMS page: ${error.message}`);
    return data ? toCmsPage(data) : null;
  }

  async findPublishedBySlug(campusId: string, slug: string): Promise<CmsPage | null> {
    const { data, error } = await this.client
      .from('cms_pages')
      .select('*')
      .eq('campus_id', campusId)
      .eq('slug', slug)
      .eq('status', 'published')
      .maybeSingle();

    if (error) throw new Error(`Failed to load published CMS page: ${error.message}`);
    return data ? toCmsPage(data) : null;
  }

  async transitionStatus(params: {
    id: string;
    toStatus: CmsContentStatus;
    actorField: 'reviewed_by' | 'approved_by' | 'published_by' | null;
    actorId: string;
    campusId: string;
    action: string;
    metadata: Record<string, unknown>;
    extraFields?: Record<string, unknown>;
  }): Promise<CmsPage> {
    const { error } = await this.client.rpc('app_cms_transition', {
      p_table_name: 'cms_pages',
      p_id: params.id,
      p_to_status: params.toStatus,
      p_actor_field: params.actorField,
      p_actor_id: params.actorId,
      p_action: params.action,
      p_campus_id: params.campusId,
      p_metadata: params.metadata,
      p_extra_fields: params.extraFields ?? {},
    });
    if (error) throw new Error(`Failed to transition CMS page status: ${error.message}`);

    const updated = await this.findById(params.id);
    if (!updated) throw new Error(`CMS page ${params.id} not found after transition.`);
    return updated;
  }

  async listByStatus(campusId: string, status?: CmsContentStatus): Promise<CmsPage[]> {
    let query = this.client.from('cms_pages').select('*').eq('campus_id', campusId);
    if (status) {
      query = query.eq('status', status);
    }
    const { data, error } = await query;
    if (error) throw new Error(`Failed to list CMS pages: ${error.message}`);
    return (data ?? []).map(toCmsPage);
  }

  async recordAudit(entry: {
    actorId: string;
    campusId: string;
    action: string;
    targetType: string;
    targetId: string;
    metadata: Record<string, unknown>;
  }): Promise<void> {
    const { error } = await this.client.from('audit_logs').insert({
      actor_id: entry.actorId,
      campus_id: entry.campusId,
      action: entry.action,
      target_type: entry.targetType,
      target_id: entry.targetId,
      metadata_json: entry.metadata,
    });
    if (error) throw new Error(`Failed to write audit log: ${error.message}`);
  }
}
