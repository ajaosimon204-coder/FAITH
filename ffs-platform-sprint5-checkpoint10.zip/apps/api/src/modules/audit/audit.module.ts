import { Module } from '@nestjs/common';
import { AuditController } from './audit.controller';

// The controller receives the (global) SUPABASE_CLIENT directly via @Inject — Nest builds
// controllers from `controllers`, so a separate provider for the same class has no effect.
@Module({
  controllers: [AuditController],
})
export class AuditModule {}
