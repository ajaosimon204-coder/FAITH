import { Controller, Get, Inject, Query, UseGuards } from '@nestjs/common';
import { SupabaseClient } from '@supabase/supabase-js';
import { PermissionGuard, RequirePermissions } from '../rbac/permission.guard';
import { PERMISSIONS } from '../rbac/permissions';
import { CurrentIdentity } from '../identity/current-identity.decorator';
import { SUPABASE_CLIENT } from '../identity/identity.module';
import { ResolvedIdentity } from '../identity/identity.types';

export interface AuditLogEntry {
  readonly id: string;
  readonly actorId: string;
  readonly action: string;
  readonly targetType: string;
  readonly targetId: string;
  readonly metadata: Record<string, unknown>;
  readonly createdAt: string;
}

/**
 * Audit log is append-only and readable only by admin-tier roles holding
 * `audit.read` (Architecture Section 17 / Governance Rule 8: every module
 * documents its audit requirements — this module's audit requirement is
 * "everything RBAC does", already satisfied by RbacService).
 */
@Controller('api/v1/audit-logs')
@UseGuards(PermissionGuard)
export class AuditController {
  constructor(@Inject(SUPABASE_CLIENT) private readonly client: SupabaseClient) {}

  @Get()
  @RequirePermissions(PERMISSIONS.AUDIT_READ)
  async list(
    @CurrentIdentity() identity: ResolvedIdentity,
    @Query('targetType') targetType?: string,
  ): Promise<AuditLogEntry[]> {
    // This controller uses the service-role client, which bypasses RLS by
    // design (Architecture Section 4). Because of that, tenant scoping MUST
    // be applied explicitly here — this is not optional defense in depth,
    // it is the only gate for this particular query path.
    let query = this.client
      .from('audit_logs')
      .select('id, actor_id, action, target_type, target_id, metadata_json, created_at')
      .eq('campus_id', identity.campusId)
      .order('created_at', { ascending: false })
      .limit(100);

    if (targetType) {
      query = query.eq('target_type', targetType);
    }

    const { data, error } = await query;
    if (error) {
      throw new Error(`Failed to load audit logs: ${error.message}`);
    }

    return (data ?? []).map((row) => ({
      id: row.id as string,
      actorId: row.actor_id as string,
      action: row.action as string,
      targetType: row.target_type as string,
      targetId: row.target_id as string,
      metadata: (row.metadata_json as Record<string, unknown>) ?? {},
      createdAt: row.created_at as string,
    }));
  }
}
