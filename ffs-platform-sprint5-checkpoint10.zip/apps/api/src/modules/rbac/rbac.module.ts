import { Module } from '@nestjs/common';
import { IdentityModule, IDENTITY_REPOSITORY } from '../identity/identity.module';
import { IIdentityRepository } from '../identity/identity.repository';
import { PermissionGuard } from './permission.guard';
import { RbacController } from './rbac.controller';
import { RbacService } from './rbac.service';

@Module({
  imports: [IdentityModule],
  controllers: [RbacController],
  providers: [
    {
      provide: RbacService,
      useFactory: (repo: IIdentityRepository) => new RbacService(repo),
      inject: [IDENTITY_REPOSITORY],
    },
    PermissionGuard,
  ],
  exports: [RbacService, PermissionGuard],
})
export class RbacModule {}
