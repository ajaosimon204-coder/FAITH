/**
 * Sprint 1 permission set. Additional permissions are introduced module by
 * module in later sprints (Governance Rule: no future-sprint functionality
 * implemented merely because it's convenient) — this file is intentionally
 * limited to what Identity/RBAC/Organizations/Audit actually need now.
 */
export const PERMISSIONS = {
  RBAC_MANAGE: 'rbac.manage', // assign/revoke roles
  RBAC_READ: 'rbac.read', // view role assignments
  ORGANIZATIONS_READ: 'organizations.read',
  ORGANIZATIONS_MANAGE: 'organizations.manage',
  AUDIT_READ: 'audit.read',
} as const;

export type PermissionKey = (typeof PERMISSIONS)[keyof typeof PERMISSIONS];
