import { BadRequestException, Injectable } from '@nestjs/common';
import { IIdentityRepository } from '../identity/identity.repository';
import { ResolvedIdentity } from '../identity/identity.types';

const ASSIGNABLE_ROLE_KEYS = [
  'super_admin',
  'proprietor',
  'school_administrator',
  'principal',
  'vice_principal',
  'head_teacher',
  'accountant',
  'teacher',
  'class_teacher',
  'exam_officer',
  'librarian',
  'content_editor',
  'student',
  'parent_guardian',
] as const;

export type AssignableRoleKey = (typeof ASSIGNABLE_ROLE_KEYS)[number];

/**
 * Role assignment is the one piece of genuine business logic Sprint 1 owns.
 * It lives here, once — no controller and no other module re-implements it
 * (Governance Rule 2: no duplicate business logic).
 */
@Injectable()
export class RbacService {
  constructor(private readonly repository: IIdentityRepository) {}

  async assignRole(params: {
    actor: ResolvedIdentity;
    targetAppUserId: string;
    roleKey: string;
  }): Promise<void> {
    if (!ASSIGNABLE_ROLE_KEYS.includes(params.roleKey as AssignableRoleKey)) {
      throw new BadRequestException(`Unknown or unassignable role: ${params.roleKey}`);
    }

    // A role assignment is always scoped to the actor's own campus — an
    // admin cannot assign a role in a campus they don't belong to, even if
    // they somehow guessed a target user's ID that belongs elsewhere. This
    // is enforced here AND by RLS on the underlying insert.
    await this.repository.assignRole({
      appUserId: params.targetAppUserId,
      roleKey: params.roleKey,
      campusId: params.actor.campusId,
      assignedBy: params.actor.appUserId,
    });

    await this.repository.recordAudit({
      actorId: params.actor.appUserId,
      campusId: params.actor.campusId,
      action: 'rbac.role_assigned',
      targetType: 'user',
      targetId: params.targetAppUserId,
      metadata: { roleKey: params.roleKey },
    });
  }
}
