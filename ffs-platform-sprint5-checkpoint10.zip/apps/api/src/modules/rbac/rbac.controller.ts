import { Body, Controller, Get, Param, Post, UseGuards } from '@nestjs/common';
import { PermissionGuard, RequirePermissions } from './permission.guard';
import { CurrentIdentity } from '../identity/current-identity.decorator';
import { ResolvedIdentity } from '../identity/identity.types';
import { PERMISSIONS } from './permissions';
import { RbacService } from './rbac.service';

interface AssignRoleBody {
  roleKey: string;
}

/**
 * Sprint 1 acceptance-check surface:
 *  - GET /api/v1/me proves the whole auth+RBAC resolution pipeline works
 *    end-to-end for any authenticated caller.
 *  - POST /api/v1/admin/users/:userId/roles proves permission-gated,
 *    audited, tenant-scoped write actually functions.
 */
@Controller('api/v1')
export class RbacController {
  constructor(private readonly rbacService: RbacService) {}

  @Get('me')
  getSelf(@CurrentIdentity() identity: ResolvedIdentity): ResolvedIdentity {
    return identity;
  }

  @Post('admin/users/:userId/roles')
  @UseGuards(PermissionGuard)
  @RequirePermissions(PERMISSIONS.RBAC_MANAGE)
  async assignRole(
    @CurrentIdentity() identity: ResolvedIdentity,
    @Param('userId') userId: string,
    @Body() body: AssignRoleBody,
  ): Promise<{ status: 'assigned' }> {
    await this.rbacService.assignRole({
      actor: identity,
      targetAppUserId: userId,
      roleKey: body.roleKey,
    });
    return { status: 'assigned' };
  }
}
