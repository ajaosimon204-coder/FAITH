import {
  CanActivate,
  ExecutionContext,
  ForbiddenException,
  Injectable,
  SetMetadata,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { AuthenticatedRequest } from '../identity/supabase-auth.guard';
import { hasPermission } from '../identity/identity.types';
import { PermissionKey } from './permissions';

export const REQUIRED_PERMISSIONS_KEY = 'required_permissions';

/**
 * Declares which permission(s) a handler requires. Applied in addition to,
 * never instead of, SupabaseAuthGuard — this guard assumes `request.identity`
 * already exists.
 */
export const RequirePermissions = (...permissions: PermissionKey[]) =>
  SetMetadata(REQUIRED_PERMISSIONS_KEY, permissions);

/**
 * Enforces:
 *   1. Permission check — does the caller's resolved permission set include
 *      every permission this handler requires?
 *   2. Tenant-scope check — for any handler that resolves a :campusId route
 *      param, does it match the caller's own campus? (IDOR / cross-tenant
 *      guard — Architecture Section D / M).
 *
 * This is a second, independent gate on top of RLS (Architecture Section E) —
 * defense in depth, not a replacement for RLS.
 */
@Injectable()
export class PermissionGuard implements CanActivate {
  constructor(private readonly reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const required = this.reflector.getAllAndOverride<PermissionKey[]>(
      REQUIRED_PERMISSIONS_KEY,
      [context.getHandler(), context.getClass()],
    );

    if (!required || required.length === 0) {
      return true;
    }

    const request = context.switchToHttp().getRequest<AuthenticatedRequest>();
    const identity = request.identity;

    if (!identity) {
      throw new ForbiddenException('No resolved identity on request.');
    }

    const missing = required.filter((p) => !hasPermission(identity, p));
    if (missing.length > 0) {
      throw new ForbiddenException(
        `Missing required permission(s): ${missing.join(', ')}.`,
      );
    }

    const routeCampusId = request.params?.['campusId'];
    if (routeCampusId && routeCampusId !== identity.campusId) {
      // Deliberately the same generic message as a missing permission —
      // do not reveal that the resource exists in a different tenant.
      throw new ForbiddenException('Not authorized for this resource.');
    }

    return true;
  }
}
