import { ForbiddenException, Injectable } from '@nestjs/common';
import { hasPermission, ResolvedIdentity } from '../identity/identity.types';
import { IAcademicRepository } from './academic.repository';
import { SchoolClass, SchoolLevelCategory } from './academic.types';

@Injectable()
export class ClassesService {
  constructor(private readonly repository: IAcademicRepository) {}

  async createClassDefinition(
    actor: ResolvedIdentity,
    input: { name: string; level: SchoolLevelCategory },
  ) {
    this.assertCanWrite(actor);
    const definition = await this.repository.createClassDefinition({
      campusId: actor.campusId,
      name: input.name,
      level: input.level,
    });

    await this.repository.recordAudit({
      actorId: actor.appUserId,
      campusId: actor.campusId,
      action: 'class_definition.created',
      targetType: 'class_definition',
      targetId: definition.id,
      metadata: { name: input.name, level: input.level },
    });

    return definition;
  }

  async createClass(
    actor: ResolvedIdentity,
    input: { classDefinitionId: string; academicSessionId: string; name: string; section: string | null },
  ): Promise<SchoolClass> {
    this.assertCanWrite(actor);
    const schoolClass = await this.repository.createClass({
      classDefinitionId: input.classDefinitionId,
      academicSessionId: input.academicSessionId,
      campusId: actor.campusId,
      name: input.name,
      section: input.section,
    });

    await this.repository.recordAudit({
      actorId: actor.appUserId,
      campusId: actor.campusId,
      action: 'class.created',
      targetType: 'class',
      targetId: schoolClass.id,
      metadata: { name: input.name, academicSessionId: input.academicSessionId },
    });

    return schoolClass;
  }

  async createSubject(actor: ResolvedIdentity, input: { name: string; code: string }) {
    this.assertCanWrite(actor);
    const subject = await this.repository.createSubject({
      campusId: actor.campusId,
      name: input.name,
      code: input.code,
    });

    await this.repository.recordAudit({
      actorId: actor.appUserId,
      campusId: actor.campusId,
      action: 'subject.created',
      targetType: 'subject',
      targetId: subject.id,
      metadata: { name: input.name, code: input.code },
    });

    return subject;
  }

  async linkSubjectToClass(
    actor: ResolvedIdentity,
    input: { classId: string; subjectId: string },
  ): Promise<void> {
    this.assertCanWrite(actor);

    // Cross-campus check (added during Sprint 3 re-audit — see ADR-014):
    // this repository call runs under the service-role connection, which
    // bypasses RLS entirely. Without this explicit check, an actor with
    // academic.classes.write could link a class and subject from two
    // DIFFERENT campuses together, or link resources belonging to a
    // campus other than their own — neither the permission check above
    // nor the database's primary-key constraint on class_subjects catches
    // this on its own. A database-level trigger (migration 0015) provides
    // a second, independent backstop for the same property.
    const schoolClass = await this.repository.findClassById(input.classId);
    if (!schoolClass || schoolClass.campusId !== actor.campusId) {
      throw new ForbiddenException('Not authorized to modify this class.');
    }
    const subject = await this.repository.getSubjectById(input.subjectId);
    if (!subject || subject.campusId !== actor.campusId) {
      throw new ForbiddenException('Not authorized to use this subject.');
    }

    await this.repository.linkSubjectToClass(input.classId, input.subjectId);

    await this.repository.recordAudit({
      actorId: actor.appUserId,
      campusId: actor.campusId,
      action: 'class_subject.linked',
      targetType: 'class',
      targetId: input.classId,
      metadata: { subjectId: input.subjectId },
    });
  }

  private assertCanWrite(actor: ResolvedIdentity): void {
    if (!hasPermission(actor, 'academic.classes.write')) {
      throw new ForbiddenException('Not authorized to manage class definitions, classes, or subjects.');
    }
  }
}
