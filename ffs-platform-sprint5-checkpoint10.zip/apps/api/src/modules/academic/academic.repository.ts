import { Injectable } from '@nestjs/common';
import { SupabaseClient } from '@supabase/supabase-js';
import {
  AcademicSession,
  Enrollment,
  SchoolClass,
  Subject,
  TeacherAssignment,
  Term,
} from './academic.types';

export interface IAcademicRepository {
  // Sessions & terms
  createSession(input: {
    campusId: string;
    name: string;
    startDate: string;
    endDate: string;
  }): Promise<AcademicSession>;
  setCurrentSession(campusId: string, sessionId: string): Promise<AcademicSession>;
  createTerm(input: {
    academicSessionId: string;
    campusId: string;
    name: string;
    startDate: string;
    endDate: string;
  }): Promise<Term>;
  setCurrentTerm(academicSessionId: string, termId: string): Promise<Term>;

  // Enrollment
  findActiveEnrollment(studentId: string, academicSessionId: string): Promise<Enrollment | null>;
  findCurrentEnrollment(studentId: string): Promise<Enrollment | null>;
  closeEnrollment(
    enrollmentId: string,
    status: 'completed' | 'withdrawn' | 'transferred',
    reason: string | null,
  ): Promise<Enrollment>;
  createEnrollment(input: {
    studentId: string;
    classId: string;
    academicSessionId: string;
    termId: string | null;
    campusId: string;
  }): Promise<Enrollment>;
  transferEnrollment(input: {
    studentId: string;
    fromEnrollmentId: string;
    newClassId: string;
    reason: string | null;
  }): Promise<Enrollment>;
  listEnrollmentHistory(studentId: string): Promise<Enrollment[]>;
  findClassById(classId: string): Promise<SchoolClass | null>;
  getStudentUsersId(studentId: string): Promise<string | null>;
  getStudentCampusId(studentId: string): Promise<string | null>;
  getStaffIdForUser(actorAppUserId: string): Promise<string | null>;

  // Teacher assignments
  isAssignedToClass(staffId: string, classId: string): Promise<boolean>;
  createTeacherAssignment(input: {
    staffId: string;
    classId: string;
    subjectId: string | null;
    academicSessionId: string;
    campusId: string;
    role: 'subject_teacher' | 'class_teacher';
    assignedBy: string;
  }): Promise<TeacherAssignment>;
  removeTeacherAssignment(assignmentId: string): Promise<void>;
  listAssignmentsForStaff(staffId: string): Promise<TeacherAssignment[]>;

  recordAudit(entry: {
    actorId: string;
    campusId: string;
    action: string;
    targetType: string;
    targetId: string;
    metadata: Record<string, unknown>;
  }): Promise<void>;

  // Class definitions, session-specific classes, subjects
  createClassDefinition(input: {
    campusId: string;
    name: string;
    level: string;
  }): Promise<{ id: string; campusId: string; name: string; level: string }>;
  createClass(input: {
    classDefinitionId: string;
    academicSessionId: string;
    campusId: string;
    name: string;
    section: string | null;
  }): Promise<SchoolClass>;
  createSubject(input: {
    campusId: string;
    name: string;
    code: string;
  }): Promise<{ id: string; campusId: string; name: string; code: string }>;
  linkSubjectToClass(classId: string, subjectId: string): Promise<void>;
  getSubjectById(subjectId: string): Promise<Subject | null>;
}

function toSession(row: Record<string, unknown>): AcademicSession {
  return {
    id: row.id as string,
    campusId: row.campus_id as string,
    name: row.name as string,
    startDate: row.start_date as string,
    endDate: row.end_date as string,
    isCurrent: row.is_current as boolean,
  };
}

function toTerm(row: Record<string, unknown>): Term {
  return {
    id: row.id as string,
    academicSessionId: row.academic_session_id as string,
    campusId: row.campus_id as string,
    name: row.name as string,
    startDate: row.start_date as string,
    endDate: row.end_date as string,
    isCurrent: row.is_current as boolean,
  };
}

function toEnrollment(row: Record<string, unknown>): Enrollment {
  return {
    id: row.id as string,
    studentId: row.student_id as string,
    classId: row.class_id as string,
    academicSessionId: row.academic_session_id as string,
    termId: (row.term_id as string | null) ?? null,
    campusId: row.campus_id as string,
    status: row.status as Enrollment['status'],
    enrolledAt: row.enrolled_at as string,
    exitedAt: (row.exited_at as string | null) ?? null,
    exitReason: (row.exit_reason as string | null) ?? null,
  };
}

function toClass(row: Record<string, unknown>): SchoolClass {
  return {
    id: row.id as string,
    classDefinitionId: row.class_definition_id as string,
    academicSessionId: row.academic_session_id as string,
    campusId: row.campus_id as string,
    name: row.name as string,
    section: (row.section as string | null) ?? null,
  };
}

function toTeacherAssignment(row: Record<string, unknown>): TeacherAssignment {
  return {
    id: row.id as string,
    staffId: row.staff_id as string,
    classId: row.class_id as string,
    subjectId: (row.subject_id as string | null) ?? null,
    academicSessionId: row.academic_session_id as string,
    campusId: row.campus_id as string,
    role: row.role as TeacherAssignment['role'],
    assignedBy: row.assigned_by as string,
    assignedAt: row.assigned_at as string,
  };
}

@Injectable()
export class SupabaseAcademicRepository implements IAcademicRepository {
  constructor(private readonly client: SupabaseClient) {}

  async createSession(input: {
    campusId: string;
    name: string;
    startDate: string;
    endDate: string;
  }): Promise<AcademicSession> {
    const { data, error } = await this.client
      .from('academic_sessions')
      .insert({
        campus_id: input.campusId,
        name: input.name,
        start_date: input.startDate,
        end_date: input.endDate,
      })
      .select()
      .single();

    if (error) throw new Error(`Failed to create academic session: ${error.message}`);
    return toSession(data);
  }

  async setCurrentSession(campusId: string, sessionId: string): Promise<AcademicSession> {
    const { data, error } = await this.client.rpc('app_set_current_academic_session', {
      p_campus_id: campusId,
      p_session_id: sessionId,
    });
    if (error) throw new Error(`Failed to set current session: ${error.message}`);
    return toSession(Array.isArray(data) ? data[0] : data);
  }

  async createTerm(input: {
    academicSessionId: string;
    campusId: string;
    name: string;
    startDate: string;
    endDate: string;
  }): Promise<Term> {
    const { data, error } = await this.client
      .from('terms')
      .insert({
        academic_session_id: input.academicSessionId,
        campus_id: input.campusId,
        name: input.name,
        start_date: input.startDate,
        end_date: input.endDate,
      })
      .select()
      .single();

    if (error) throw new Error(`Failed to create term: ${error.message}`);
    return toTerm(data);
  }

  async setCurrentTerm(academicSessionId: string, termId: string): Promise<Term> {
    const { data, error } = await this.client.rpc('app_set_current_term', {
      p_academic_session_id: academicSessionId,
      p_term_id: termId,
    });
    if (error) throw new Error(`Failed to set current term: ${error.message}`);
    return toTerm(Array.isArray(data) ? data[0] : data);
  }

  async findActiveEnrollment(
    studentId: string,
    academicSessionId: string,
  ): Promise<Enrollment | null> {
    const { data, error } = await this.client
      .from('enrollments')
      .select('*')
      .eq('student_id', studentId)
      .eq('academic_session_id', academicSessionId)
      .eq('status', 'active')
      .maybeSingle();

    if (error) throw new Error(`Failed to look up active enrollment: ${error.message}`);
    return data ? toEnrollment(data) : null;
  }

  async findCurrentEnrollment(studentId: string): Promise<Enrollment | null> {
    const { data, error } = await this.client
      .from('student_current_enrollments')
      .select('*')
      .eq('student_id', studentId)
      .maybeSingle();

    if (error) throw new Error(`Failed to look up current enrollment: ${error.message}`);
    return data ? toEnrollment(data) : null;
  }

  async closeEnrollment(
    enrollmentId: string,
    status: 'completed' | 'withdrawn' | 'transferred',
    reason: string | null,
  ): Promise<Enrollment> {
    const { data, error } = await this.client
      .from('enrollments')
      .update({ status, exited_at: new Date().toISOString(), exit_reason: reason })
      .eq('id', enrollmentId)
      .select()
      .single();

    if (error) throw new Error(`Failed to close enrollment: ${error.message}`);
    return toEnrollment(data);
  }

  async createEnrollment(input: {
    studentId: string;
    classId: string;
    academicSessionId: string;
    termId: string | null;
    campusId: string;
  }): Promise<Enrollment> {
    const { data, error } = await this.client
      .from('enrollments')
      .insert({
        student_id: input.studentId,
        class_id: input.classId,
        academic_session_id: input.academicSessionId,
        term_id: input.termId,
        campus_id: input.campusId,
      })
      .select()
      .single();

    if (error) throw new Error(`Failed to create enrollment: ${error.message}`);
    return toEnrollment(data);
  }

  async listEnrollmentHistory(studentId: string): Promise<Enrollment[]> {
    const { data, error } = await this.client
      .from('enrollments')
      .select('*')
      .eq('student_id', studentId)
      .order('enrolled_at', { ascending: false });

    if (error) throw new Error(`Failed to list enrollment history: ${error.message}`);
    return (data ?? []).map(toEnrollment);
  }

  async transferEnrollment(input: {
    studentId: string;
    fromEnrollmentId: string;
    newClassId: string;
    reason: string | null;
  }): Promise<Enrollment> {
    const { data, error } = await this.client.rpc('app_transfer_enrollment', {
      p_student_id: input.studentId,
      p_from_enrollment_id: input.fromEnrollmentId,
      p_new_class_id: input.newClassId,
      p_reason: input.reason,
    });
    if (error) throw new Error(`Failed to transfer enrollment: ${error.message}`);
    return toEnrollment(Array.isArray(data) ? data[0] : data);
  }

  async findClassById(classId: string): Promise<SchoolClass | null> {
    const { data, error } = await this.client
      .from('classes')
      .select('*')
      .eq('id', classId)
      .maybeSingle();

    if (error) throw new Error(`Failed to load class: ${error.message}`);
    return data ? toClass(data) : null;
  }

  async getStudentUsersId(studentId: string): Promise<string | null> {
    const { data, error } = await this.client
      .from('students')
      .select('users_id')
      .eq('id', studentId)
      .maybeSingle();

    if (error) throw new Error(`Failed to load student: ${error.message}`);
    return (data?.users_id as string | null) ?? null;
  }

  async getStudentCampusId(studentId: string): Promise<string | null> {
    const { data, error } = await this.client
      .from('students')
      .select('campus_id')
      .eq('id', studentId)
      .maybeSingle();

    if (error) throw new Error(`Failed to load student: ${error.message}`);
    return (data?.campus_id as string | null) ?? null;
  }

  async getStaffIdForUser(actorAppUserId: string): Promise<string | null> {
    const { data, error } = await this.client
      .from('staff')
      .select('id')
      .eq('users_id', actorAppUserId)
      .maybeSingle();

    if (error) throw new Error(`Failed to resolve staff record: ${error.message}`);
    return (data?.id as string | null) ?? null;
  }

  async isAssignedToClass(staffId: string, classId: string): Promise<boolean> {
    const { data, error } = await this.client
      .from('teacher_assignments')
      .select('id')
      .eq('staff_id', staffId)
      .eq('class_id', classId)
      .maybeSingle();

    if (error) throw new Error(`Failed to check teacher assignment: ${error.message}`);
    return data !== null;
  }

  async createTeacherAssignment(input: {
    staffId: string;
    classId: string;
    subjectId: string | null;
    academicSessionId: string;
    campusId: string;
    role: 'subject_teacher' | 'class_teacher';
    assignedBy: string;
  }): Promise<TeacherAssignment> {
    const { data, error } = await this.client
      .from('teacher_assignments')
      .insert({
        staff_id: input.staffId,
        class_id: input.classId,
        subject_id: input.subjectId,
        academic_session_id: input.academicSessionId,
        campus_id: input.campusId,
        role: input.role,
        assigned_by: input.assignedBy,
      })
      .select()
      .single();

    if (error) throw new Error(`Failed to create teacher assignment: ${error.message}`);
    return toTeacherAssignment(data);
  }

  async removeTeacherAssignment(assignmentId: string): Promise<void> {
    const { error } = await this.client.from('teacher_assignments').delete().eq('id', assignmentId);
    if (error) throw new Error(`Failed to remove teacher assignment: ${error.message}`);
  }

  async listAssignmentsForStaff(staffId: string): Promise<TeacherAssignment[]> {
    const { data, error } = await this.client
      .from('teacher_assignments')
      .select('*')
      .eq('staff_id', staffId);

    if (error) throw new Error(`Failed to list teacher assignments: ${error.message}`);
    return (data ?? []).map(toTeacherAssignment);
  }

  async recordAudit(entry: {
    actorId: string;
    campusId: string;
    action: string;
    targetType: string;
    targetId: string;
    metadata: Record<string, unknown>;
  }): Promise<void> {
    const { error } = await this.client.from('audit_logs').insert({
      actor_id: entry.actorId,
      campus_id: entry.campusId,
      action: entry.action,
      target_type: entry.targetType,
      target_id: entry.targetId,
      metadata_json: entry.metadata,
    });
    if (error) throw new Error(`Failed to write audit log: ${error.message}`);
  }

  async createClassDefinition(input: {
    campusId: string;
    name: string;
    level: string;
  }): Promise<{ id: string; campusId: string; name: string; level: string }> {
    const { data, error } = await this.client
      .from('class_definitions')
      .insert({ campus_id: input.campusId, name: input.name, level: input.level })
      .select()
      .single();
    if (error) throw new Error(`Failed to create class definition: ${error.message}`);
    return {
      id: data.id as string,
      campusId: data.campus_id as string,
      name: data.name as string,
      level: data.level as string,
    };
  }

  async createClass(input: {
    classDefinitionId: string;
    academicSessionId: string;
    campusId: string;
    name: string;
    section: string | null;
  }): Promise<SchoolClass> {
    const { data, error } = await this.client
      .from('classes')
      .insert({
        class_definition_id: input.classDefinitionId,
        academic_session_id: input.academicSessionId,
        campus_id: input.campusId,
        name: input.name,
        section: input.section,
      })
      .select()
      .single();
    if (error) throw new Error(`Failed to create class: ${error.message}`);
    return toClass(data);
  }

  async createSubject(input: {
    campusId: string;
    name: string;
    code: string;
  }): Promise<{ id: string; campusId: string; name: string; code: string }> {
    const { data, error } = await this.client
      .from('subjects')
      .insert({ campus_id: input.campusId, name: input.name, code: input.code })
      .select()
      .single();
    if (error) throw new Error(`Failed to create subject: ${error.message}`);
    return {
      id: data.id as string,
      campusId: data.campus_id as string,
      name: data.name as string,
      code: data.code as string,
    };
  }

  async linkSubjectToClass(classId: string, subjectId: string): Promise<void> {
    const { error } = await this.client
      .from('class_subjects')
      .insert({ class_id: classId, subject_id: subjectId });
    if (error) throw new Error(`Failed to link subject to class: ${error.message}`);
  }

  async getSubjectById(subjectId: string): Promise<Subject | null> {
    const { data, error } = await this.client
      .from('subjects')
      .select('*')
      .eq('id', subjectId)
      .maybeSingle();
    if (error) throw new Error(`Failed to load subject: ${error.message}`);
    if (!data) return null;
    return {
      id: data.id as string,
      campusId: data.campus_id as string,
      name: data.name as string,
      code: data.code as string,
    };
  }
}
