import { Module } from '@nestjs/common';
import { SupabaseClient } from '@supabase/supabase-js';
import { SUPABASE_CLIENT } from '../identity/identity.module';
import { AcademicController } from './academic.controller';
import { IAcademicRepository, SupabaseAcademicRepository } from './academic.repository';
import { ClassesService } from './classes.service';
import { EnrollmentService } from './enrollment.service';
import { SessionsService } from './sessions.service';
import { TeacherAssignmentService } from './teacher-assignment.service';

const ACADEMIC_REPOSITORY = 'ACADEMIC_REPOSITORY';

@Module({
  controllers: [AcademicController],
  providers: [
    {
      provide: ACADEMIC_REPOSITORY,
      useFactory: (client: SupabaseClient): IAcademicRepository =>
        new SupabaseAcademicRepository(client),
      inject: [SUPABASE_CLIENT],
    },
    {
      provide: SessionsService,
      useFactory: (repo: IAcademicRepository) => new SessionsService(repo),
      inject: [ACADEMIC_REPOSITORY],
    },
    {
      provide: ClassesService,
      useFactory: (repo: IAcademicRepository) => new ClassesService(repo),
      inject: [ACADEMIC_REPOSITORY],
    },
    {
      provide: EnrollmentService,
      useFactory: (repo: IAcademicRepository) => new EnrollmentService(repo),
      inject: [ACADEMIC_REPOSITORY],
    },
    {
      provide: TeacherAssignmentService,
      useFactory: (repo: IAcademicRepository) => new TeacherAssignmentService(repo),
      inject: [ACADEMIC_REPOSITORY],
    },
  ],
  exports: [EnrollmentService, TeacherAssignmentService],
})
export class AcademicModule {}
