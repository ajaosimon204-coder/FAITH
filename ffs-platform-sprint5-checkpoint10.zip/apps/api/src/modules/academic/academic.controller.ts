import { Body, Controller, Delete, Get, Param, Post } from '@nestjs/common';
import { CurrentIdentity } from '../identity/current-identity.decorator';
import { ResolvedIdentity } from '../identity/identity.types';
import { ClassesService } from './classes.service';
import { EnrollmentService } from './enrollment.service';
import { SessionsService } from './sessions.service';
import { TeacherAssignmentService } from './teacher-assignment.service';
import { SchoolLevelCategory, TeacherAssignmentRole } from './academic.types';

interface CreateSessionBody {
  name: string;
  startDate: string;
  endDate: string;
}

interface CreateTermBody {
  academicSessionId: string;
  name: string;
  startDate: string;
  endDate: string;
}

interface CreateClassDefinitionBody {
  name: string;
  level: SchoolLevelCategory;
}

interface CreateClassBody {
  classDefinitionId: string;
  academicSessionId: string;
  name: string;
  section: string | null;
}

interface CreateSubjectBody {
  name: string;
  code: string;
}

interface LinkSubjectBody {
  subjectId: string;
}

interface EnrollBody {
  studentId: string;
  classId: string;
  academicSessionId: string;
  termId: string | null;
}

interface TransferBody {
  studentId: string;
  academicSessionId: string;
  newClassId: string;
  reason: string | null;
}

interface WithdrawBody {
  studentId: string;
  academicSessionId: string;
  reason: string | null;
}

interface AssignTeacherBody {
  staffId: string;
  classId: string;
  subjectId: string | null;
  academicSessionId: string;
  role: TeacherAssignmentRole;
}

@Controller('api/v1/academic')
export class AcademicController {
  constructor(
    private readonly sessionsService: SessionsService,
    private readonly classesService: ClassesService,
    private readonly enrollmentService: EnrollmentService,
    private readonly teacherAssignmentService: TeacherAssignmentService,
  ) {}

  // --- Sessions & terms ---

  @Post('sessions')
  createSession(@CurrentIdentity() identity: ResolvedIdentity, @Body() body: CreateSessionBody) {
    return this.sessionsService.createSession(identity, body);
  }

  @Post('sessions/:sessionId/set-current')
  setCurrentSession(
    @CurrentIdentity() identity: ResolvedIdentity,
    @Param('sessionId') sessionId: string,
  ) {
    return this.sessionsService.setCurrentSession(identity, sessionId);
  }

  @Post('terms')
  createTerm(@CurrentIdentity() identity: ResolvedIdentity, @Body() body: CreateTermBody) {
    return this.sessionsService.createTerm(identity, body);
  }

  @Post('sessions/:sessionId/terms/:termId/set-current')
  setCurrentTerm(
    @CurrentIdentity() identity: ResolvedIdentity,
    @Param('sessionId') sessionId: string,
    @Param('termId') termId: string,
  ) {
    return this.sessionsService.setCurrentTerm(identity, sessionId, termId);
  }

  // --- Class definitions, classes, subjects ---

  @Post('class-definitions')
  createClassDefinition(
    @CurrentIdentity() identity: ResolvedIdentity,
    @Body() body: CreateClassDefinitionBody,
  ) {
    return this.classesService.createClassDefinition(identity, body);
  }

  @Post('classes')
  createClass(@CurrentIdentity() identity: ResolvedIdentity, @Body() body: CreateClassBody) {
    return this.classesService.createClass(identity, body);
  }

  @Post('subjects')
  createSubject(@CurrentIdentity() identity: ResolvedIdentity, @Body() body: CreateSubjectBody) {
    return this.classesService.createSubject(identity, body);
  }

  @Post('classes/:classId/subjects')
  linkSubject(
    @CurrentIdentity() identity: ResolvedIdentity,
    @Param('classId') classId: string,
    @Body() body: LinkSubjectBody,
  ) {
    return this.classesService.linkSubjectToClass(identity, { classId, subjectId: body.subjectId });
  }

  // --- Enrollment ---

  @Post('enrollments')
  enroll(@CurrentIdentity() identity: ResolvedIdentity, @Body() body: EnrollBody) {
    return this.enrollmentService.enrollStudent(identity, body);
  }

  @Post('enrollments/transfer')
  transfer(@CurrentIdentity() identity: ResolvedIdentity, @Body() body: TransferBody) {
    return this.enrollmentService.transferStudent(identity, body);
  }

  @Post('enrollments/withdraw')
  withdraw(@CurrentIdentity() identity: ResolvedIdentity, @Body() body: WithdrawBody) {
    return this.enrollmentService.withdrawStudent(identity, body);
  }

  @Get('students/:studentId/current-class')
  getCurrentClass(
    @CurrentIdentity() identity: ResolvedIdentity,
    @Param('studentId') studentId: string,
  ) {
    return this.enrollmentService.getCurrentEnrollment(identity, studentId);
  }

  @Get('students/:studentId/enrollments')
  getEnrollmentHistory(
    @CurrentIdentity() identity: ResolvedIdentity,
    @Param('studentId') studentId: string,
  ) {
    return this.enrollmentService.getEnrollmentHistory(identity, studentId);
  }

  // --- Teacher assignments ---

  @Post('teacher-assignments')
  assignTeacher(@CurrentIdentity() identity: ResolvedIdentity, @Body() body: AssignTeacherBody) {
    return this.teacherAssignmentService.assignTeacher(identity, body);
  }

  @Delete('teacher-assignments/:assignmentId')
  removeAssignment(
    @CurrentIdentity() identity: ResolvedIdentity,
    @Param('assignmentId') assignmentId: string,
  ) {
    return this.teacherAssignmentService.removeAssignment(identity, assignmentId);
  }

  @Get('staff/:staffId/assignments')
  getAssignmentsForStaff(
    @CurrentIdentity() identity: ResolvedIdentity,
    @Param('staffId') staffId: string,
  ) {
    return this.teacherAssignmentService.getAssignmentsForStaff(identity, staffId);
  }
}
