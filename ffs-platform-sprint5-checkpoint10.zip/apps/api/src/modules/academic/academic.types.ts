export const SCHOOL_LEVEL_CATEGORIES = [
  'preparatory',
  'kg',
  'nursery',
  'basic',
  'junior_secondary',
  'senior_secondary',
] as const;
export type SchoolLevelCategory = (typeof SCHOOL_LEVEL_CATEGORIES)[number];

export const ENROLLMENT_STATUSES = ['active', 'completed', 'withdrawn', 'transferred'] as const;
export type EnrollmentStatus = (typeof ENROLLMENT_STATUSES)[number];

export const TEACHER_ASSIGNMENT_ROLES = ['subject_teacher', 'class_teacher'] as const;
export type TeacherAssignmentRole = (typeof TEACHER_ASSIGNMENT_ROLES)[number];

export interface AcademicSession {
  readonly id: string;
  readonly campusId: string;
  readonly name: string;
  readonly startDate: string;
  readonly endDate: string;
  readonly isCurrent: boolean;
}

export interface Term {
  readonly id: string;
  readonly academicSessionId: string;
  readonly campusId: string;
  readonly name: string;
  readonly startDate: string;
  readonly endDate: string;
  readonly isCurrent: boolean;
}

export interface ClassDefinition {
  readonly id: string;
  readonly campusId: string;
  readonly name: string;
  readonly level: SchoolLevelCategory;
}

export interface SchoolClass {
  readonly id: string;
  readonly classDefinitionId: string;
  readonly academicSessionId: string;
  readonly campusId: string;
  readonly name: string;
  readonly section: string | null;
}

export interface Subject {
  readonly id: string;
  readonly campusId: string;
  readonly name: string;
  readonly code: string;
}

export interface Enrollment {
  readonly id: string;
  readonly studentId: string;
  readonly classId: string;
  readonly academicSessionId: string;
  readonly termId: string | null;
  readonly campusId: string;
  readonly status: EnrollmentStatus;
  readonly enrolledAt: string;
  readonly exitedAt: string | null;
  readonly exitReason: string | null;
}

export interface TeacherAssignment {
  readonly id: string;
  readonly staffId: string;
  readonly classId: string;
  readonly subjectId: string | null;
  readonly academicSessionId: string;
  readonly campusId: string;
  readonly role: TeacherAssignmentRole;
  readonly assignedBy: string;
  readonly assignedAt: string;
}
