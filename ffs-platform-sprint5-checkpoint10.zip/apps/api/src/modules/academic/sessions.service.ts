import { ForbiddenException, Injectable } from '@nestjs/common';
import { hasPermission, ResolvedIdentity } from '../identity/identity.types';
import { IAcademicRepository } from './academic.repository';
import { AcademicSession, Term } from './academic.types';

@Injectable()
export class SessionsService {
  constructor(private readonly repository: IAcademicRepository) {}

  async createSession(
    actor: ResolvedIdentity,
    input: { name: string; startDate: string; endDate: string },
  ): Promise<AcademicSession> {
    this.assertCanWrite(actor);
    const session = await this.repository.createSession({
      campusId: actor.campusId,
      name: input.name,
      startDate: input.startDate,
      endDate: input.endDate,
    });

    await this.repository.recordAudit({
      actorId: actor.appUserId,
      campusId: actor.campusId,
      action: 'academic_session.created',
      targetType: 'academic_session',
      targetId: session.id,
      metadata: { name: input.name },
    });

    return session;
  }

  async setCurrentSession(actor: ResolvedIdentity, sessionId: string): Promise<AcademicSession> {
    this.assertCanWrite(actor);
    const session = await this.repository.setCurrentSession(actor.campusId, sessionId);

    await this.repository.recordAudit({
      actorId: actor.appUserId,
      campusId: actor.campusId,
      action: 'academic_session.set_current',
      targetType: 'academic_session',
      targetId: sessionId,
      metadata: {},
    });

    return session;
  }

  async createTerm(
    actor: ResolvedIdentity,
    input: { academicSessionId: string; name: string; startDate: string; endDate: string },
  ): Promise<Term> {
    this.assertCanWrite(actor);
    const term = await this.repository.createTerm({
      academicSessionId: input.academicSessionId,
      campusId: actor.campusId,
      name: input.name,
      startDate: input.startDate,
      endDate: input.endDate,
    });

    await this.repository.recordAudit({
      actorId: actor.appUserId,
      campusId: actor.campusId,
      action: 'term.created',
      targetType: 'term',
      targetId: term.id,
      metadata: { name: input.name, academicSessionId: input.academicSessionId },
    });

    return term;
  }

  async setCurrentTerm(
    actor: ResolvedIdentity,
    academicSessionId: string,
    termId: string,
  ): Promise<Term> {
    this.assertCanWrite(actor);
    const term = await this.repository.setCurrentTerm(academicSessionId, termId);

    await this.repository.recordAudit({
      actorId: actor.appUserId,
      campusId: actor.campusId,
      action: 'term.set_current',
      targetType: 'term',
      targetId: termId,
      metadata: { academicSessionId },
    });

    return term;
  }

  private assertCanWrite(actor: ResolvedIdentity): void {
    if (!hasPermission(actor, 'academic.sessions.write')) {
      throw new ForbiddenException('Not authorized to manage academic sessions or terms.');
    }
  }
}
