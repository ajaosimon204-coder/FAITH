import { ConflictException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { hasPermission, ResolvedIdentity } from '../identity/identity.types';
import { IAcademicRepository } from './academic.repository';
import { Enrollment } from './academic.types';

/**
 * Owns the ONE rule this whole sprint exists to protect: a student's class
 * history is append-only. There is no "update the student's class" — there
 * is only "enroll" (first time in a session) and "transfer" (close the old
 * enrollment, open a new one), both of which the database also enforces
 * independently via triggers (migration 0010) and an atomic RPC function
 * (migration 0014). This service is the ONLY code path that calls those
 * primitives — no controller and no other module re-implements enrollment
 * logic (Governance Rule 2).
 *
 * IMPORTANT: this service uses the service-role repository, which bypasses
 * RLS entirely (Architecture Section 4). That means the read methods below
 * MUST apply their own authorization check explicitly — RLS is not a
 * backstop here, it protects a different access path (the frontend's
 * direct reads). See `assertCanViewStudent`.
 */
@Injectable()
export class EnrollmentService {
  constructor(private readonly repository: IAcademicRepository) {}

  async enrollStudent(
    actor: ResolvedIdentity,
    input: {
      studentId: string;
      classId: string;
      academicSessionId: string;
      termId: string | null;
    },
  ): Promise<Enrollment> {
    this.assertCanManageEnrollments(actor);

    const existing = await this.repository.findActiveEnrollment(
      input.studentId,
      input.academicSessionId,
    );
    if (existing) {
      throw new ConflictException(
        `Student ${input.studentId} already has an active enrollment for this academic session ` +
          `(enrollment ${existing.id}, class ${existing.classId}). Use transfer instead of enroll.`,
      );
    }

    const enrollment = await this.repository.createEnrollment({
      studentId: input.studentId,
      classId: input.classId,
      academicSessionId: input.academicSessionId,
      termId: input.termId,
      campusId: actor.campusId,
    });

    await this.repository.recordAudit({
      actorId: actor.appUserId,
      campusId: actor.campusId,
      action: 'enrollment.created',
      targetType: 'student',
      targetId: input.studentId,
      metadata: { enrollmentId: enrollment.id, classId: input.classId },
    });

    return enrollment;
  }

  async transferStudent(
    actor: ResolvedIdentity,
    input: { studentId: string; academicSessionId: string; newClassId: string; reason: string | null },
  ): Promise<Enrollment> {
    this.assertCanManageEnrollments(actor);

    const current = await this.repository.findActiveEnrollment(
      input.studentId,
      input.academicSessionId,
    );
    if (!current) {
      throw new NotFoundException(
        `Student ${input.studentId} has no active enrollment for this academic session to transfer. Use enroll instead.`,
      );
    }

    const newEnrollment = await this.repository.transferEnrollment({
      studentId: input.studentId,
      fromEnrollmentId: current.id,
      newClassId: input.newClassId,
      reason: input.reason,
    });

    await this.repository.recordAudit({
      actorId: actor.appUserId,
      campusId: actor.campusId,
      action: 'enrollment.transferred',
      targetType: 'student',
      targetId: input.studentId,
      metadata: {
        fromEnrollmentId: current.id,
        fromClassId: current.classId,
        toEnrollmentId: newEnrollment.id,
        toClassId: input.newClassId,
        reason: input.reason,
      },
    });

    return newEnrollment;
  }

  async withdrawStudent(
    actor: ResolvedIdentity,
    input: { studentId: string; academicSessionId: string; reason: string | null },
  ): Promise<Enrollment> {
    this.assertCanManageEnrollments(actor);

    const current = await this.repository.findActiveEnrollment(
      input.studentId,
      input.academicSessionId,
    );
    if (!current) {
      throw new NotFoundException(
        `Student ${input.studentId} has no active enrollment for this academic session to withdraw.`,
      );
    }

    const closed = await this.repository.closeEnrollment(current.id, 'withdrawn', input.reason);

    await this.repository.recordAudit({
      actorId: actor.appUserId,
      campusId: actor.campusId,
      action: 'enrollment.withdrawn',
      targetType: 'student',
      targetId: input.studentId,
      metadata: { enrollmentId: current.id, reason: input.reason },
    });

    return closed;
  }

  async getCurrentEnrollment(actor: ResolvedIdentity, studentId: string): Promise<Enrollment | null> {
    const current = await this.repository.findCurrentEnrollment(studentId);
    await this.assertCanViewStudent(actor, studentId, current?.classId ?? null);
    return current;
  }

  async getEnrollmentHistory(actor: ResolvedIdentity, studentId: string): Promise<Enrollment[]> {
    // History access is deliberately narrower than "current class" access:
    // a teacher assigned to a student's CURRENT class can see that current
    // enrollment, but not the student's entire multi-year history — that
    // requires admin-tier academic.enrollments.read or being the student
    // themself. This is a service-layer decision, not something the
    // database enforces on its own.
    //
    // CROSS-CAMPUS CHECK (added during Sprint 3 re-audit — see ADR-014):
    // holding academic.enrollments.read does NOT by itself imply the
    // student is even in the actor's own campus. That must be checked
    // explicitly against the database, every time — permission strings
    // alone are never sufficient once more than one campus can exist.
    const studentCampusId = await this.repository.getStudentCampusId(studentId);
    if (studentCampusId === null) {
      throw new NotFoundException(`Student ${studentId} not found.`);
    }
    if (studentCampusId !== actor.campusId) {
      throw new ForbiddenException('Not authorized to view this student\'s academic data.');
    }

    if (!hasPermission(actor, 'academic.enrollments.read')) {
      const studentUsersId = await this.repository.getStudentUsersId(studentId);
      if (studentUsersId !== actor.appUserId) {
        throw new ForbiddenException(
          'Only the student themself or an admin-tier role can view full enrollment history.',
        );
      }
    }

    return this.repository.listEnrollmentHistory(studentId);
  }

  private assertCanManageEnrollments(actor: ResolvedIdentity): void {
    if (!hasPermission(actor, 'academic.enrollments.manage')) {
      throw new ForbiddenException('Not authorized to manage enrollments.');
    }
  }

  /**
   * The relationship-based authorization check for reading a single
   * student's current enrollment — mirrors the RLS policy logic in
   * migration 0011 exactly, because this code path runs under the
   * service-role connection where RLS does not apply at all.
   *
   * Every branch below derives its decision from a database-fetched
   * relationship (student's own campus/users_id, an actual
   * teacher_assignments row) — NEVER from a client-supplied class_id or
   * campus_id. `currentClassId` here is passed in by the caller, but it
   * originates from `repository.findCurrentEnrollment()` (a trusted
   * server-side lookup), not from request input — there is no API
   * endpoint that lets a caller supply an arbitrary class_id to influence
   * this check.
   */
  private async assertCanViewStudent(
    actor: ResolvedIdentity,
    studentId: string,
    currentClassId: string | null,
  ): Promise<void> {
    // CROSS-CAMPUS CHECK (added during Sprint 3 re-audit — see ADR-014):
    // this must run FIRST and unconditionally, before any permission or
    // relationship branch below — none of those branches are campus-aware
    // on their own.
    const studentCampusId = await this.repository.getStudentCampusId(studentId);
    if (studentCampusId === null) {
      throw new NotFoundException(`Student ${studentId} not found.`);
    }
    if (studentCampusId !== actor.campusId) {
      throw new ForbiddenException('Not authorized to view this student\'s academic data.');
    }

    if (hasPermission(actor, 'academic.enrollments.read')) {
      return;
    }

    const studentUsersId = await this.repository.getStudentUsersId(studentId);
    if (studentUsersId === actor.appUserId) {
      return;
    }

    if (currentClassId) {
      const staffId = await this.repository.getStaffIdForUser(actor.appUserId);
      if (staffId) {
        const assigned = await this.repository.isAssignedToClass(staffId, currentClassId);
        if (assigned) {
          return;
        }
      }
    }

    throw new ForbiddenException(
      'Not authorized to view this student\'s academic data — must be the student themself, ' +
        'a teacher assigned to their current class, or hold academic.enrollments.read.',
    );
  }
}
