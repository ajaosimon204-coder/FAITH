import { BadRequestException, ForbiddenException, Injectable } from '@nestjs/common';
import { hasPermission, ResolvedIdentity } from '../identity/identity.types';
import { IAcademicRepository } from './academic.repository';
import { TeacherAssignment, TeacherAssignmentRole } from './academic.types';

/**
 * The other half of "teacher access must be relationship-based": this is
 * the ONLY place a teacher_assignments row is ever created or removed.
 * Every other module that needs to know "can this teacher touch this
 * class" (attendance, results, LMS, CBT — all future sprints) queries
 * THIS table, never a role check.
 */
@Injectable()
export class TeacherAssignmentService {
  constructor(private readonly repository: IAcademicRepository) {}

  async assignTeacher(
    actor: ResolvedIdentity,
    input: {
      staffId: string;
      classId: string;
      subjectId: string | null;
      academicSessionId: string;
      role: TeacherAssignmentRole;
    },
  ): Promise<TeacherAssignment> {
    if (!hasPermission(actor, 'academic.teacher_assignments.manage')) {
      throw new ForbiddenException('Not authorized to manage teacher assignments.');
    }

    this.validateRoleSubjectPairing(input.role, input.subjectId);

    const assignment = await this.repository.createTeacherAssignment({
      staffId: input.staffId,
      classId: input.classId,
      subjectId: input.subjectId,
      academicSessionId: input.academicSessionId,
      campusId: actor.campusId,
      role: input.role,
      assignedBy: actor.appUserId,
    });

    await this.repository.recordAudit({
      actorId: actor.appUserId,
      campusId: actor.campusId,
      action: 'teacher_assignment.created',
      targetType: 'staff',
      targetId: input.staffId,
      metadata: {
        assignmentId: assignment.id,
        classId: input.classId,
        subjectId: input.subjectId,
        role: input.role,
      },
    });

    return assignment;
  }

  async removeAssignment(actor: ResolvedIdentity, assignmentId: string): Promise<void> {
    if (!hasPermission(actor, 'academic.teacher_assignments.manage')) {
      throw new ForbiddenException('Not authorized to manage teacher assignments.');
    }

    await this.repository.removeTeacherAssignment(assignmentId);

    await this.repository.recordAudit({
      actorId: actor.appUserId,
      campusId: actor.campusId,
      action: 'teacher_assignment.removed',
      targetType: 'teacher_assignment',
      targetId: assignmentId,
      metadata: {},
    });
  }

  async getAssignmentsForStaff(
    actor: ResolvedIdentity,
    staffId: string,
  ): Promise<TeacherAssignment[]> {
    if (!hasPermission(actor, 'academic.teacher_assignments.read')) {
      const ownStaffId = await this.repository.getStaffIdForUser(actor.appUserId);
      if (ownStaffId !== staffId) {
        throw new ForbiddenException(
          'Only the assigned staff member themself or an admin-tier role can view these assignments.',
        );
      }
    }

    return this.repository.listAssignmentsForStaff(staffId);
  }

  /**
   * The relationship check other future modules (attendance, results, LMS,
   * CBT) will call — exposed here so this service remains the single
   * source of truth for "is this teacher actually assigned to this class"
   * rather than each future module re-deriving it (Governance Rule 2).
   */
  async isTeacherAssignedToClass(actor: ResolvedIdentity, classId: string): Promise<boolean> {
    const staffId = await this.repository.getStaffIdForUser(actor.appUserId);
    if (!staffId) {
      return false;
    }
    return this.repository.isAssignedToClass(staffId, classId);
  }

  private validateRoleSubjectPairing(
    role: TeacherAssignmentRole,
    subjectId: string | null,
  ): void {
    if (role === 'class_teacher' && subjectId !== null) {
      throw new BadRequestException('A class_teacher assignment must not specify a subject.');
    }
    if (role === 'subject_teacher' && subjectId === null) {
      throw new BadRequestException('A subject_teacher assignment must specify a subject.');
    }
  }
}
