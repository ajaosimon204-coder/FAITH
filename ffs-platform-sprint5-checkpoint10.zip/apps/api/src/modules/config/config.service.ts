import {
  BadRequestException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import Ajv, { ErrorObject } from 'ajv';
import { ResolvedIdentity, hasPermission } from '../identity/identity.types';
import { IConfigRepository } from './config.repository';
import { ConfigCategory, ConfigDefinition, ConfigValue, SchoolConfigValue } from './config.types';

function formatAjvErrors(errors: ErrorObject[] | null | undefined): string {
  if (!errors || errors.length === 0) {
    return 'Value failed schema validation.';
  }
  return errors
    .map((e) => `${e.instancePath || '(root)'} ${e.message ?? 'is invalid'}`)
    .join('; ');
}

/**
 * The one place configuration values are validated and permission-checked.
 * No controller, and no other module, re-implements any part of this
 * (Governance Rule 2). This is also the concrete mechanism behind
 * "JSONB must never become an unrestricted arbitrary-settings mechanism"
 * (Final Architecture, Section 2): a value can only ever be written for a
 * key that already has a registered ConfigDefinition, and only ever after
 * passing that definition's own json_schema.
 */
@Injectable()
export class ConfigService {
  private readonly ajv: Ajv;

  constructor(private readonly repository: IConfigRepository) {
    this.ajv = new Ajv({ allErrors: true, strict: true });
  }

  async listCategory(
    actor: ResolvedIdentity,
    category: ConfigCategory,
  ): Promise<SchoolConfigValue[]> {
    const definitions = await this.repository.listDefinitionsByCategory(category);
    if (definitions.length === 0) {
      return [];
    }

    // A category may mix definitions with different read permissions in
    // principle (it doesn't currently, but the check is per-definition, not
    // per-category, so that possibility is never silently unsafe later).
    const readable = definitions.filter((d) => hasPermission(actor, d.readPermissionKey));
    if (readable.length === 0) {
      throw new ForbiddenException(`Not authorized to read ${category} configuration.`);
    }

    const values = await this.repository.listValuesByCategory(category, actor.campusId);
    const readableKeys = new Set(readable.map((d) => d.key));
    return values.filter((v) => readableKeys.has(v.key));
  }

  async getValue(actor: ResolvedIdentity, key: string): Promise<SchoolConfigValue | null> {
    const definition = await this.requireDefinition(key);
    this.assertPermission(actor, definition.readPermissionKey, 'read');

    return this.repository.findValue(definition.id, actor.campusId);
  }

  async setValue(
    actor: ResolvedIdentity,
    key: string,
    newValue: ConfigValue,
  ): Promise<SchoolConfigValue> {
    const definition = await this.requireDefinition(key);
    this.assertPermission(actor, definition.writePermissionKey, 'write');
    this.validateAgainstSchema(definition, newValue);

    return this.repository.upsertValueWithAudit({
      configDefinitionId: definition.id,
      campusId: actor.campusId,
      newValue,
      actorId: actor.appUserId,
    });
  }

  private async requireDefinition(key: string): Promise<ConfigDefinition> {
    const definition = await this.repository.findDefinitionByKey(key);
    if (!definition) {
      // Deliberately NotFound, not BadRequest: an unregistered key is not
      // "invalid input" so much as "this setting does not exist" — and it
      // never will unless a migration adds it (Governance Rule 5).
      throw new NotFoundException(`Unknown configuration key: ${key}`);
    }
    return definition;
  }

  private assertPermission(
    actor: ResolvedIdentity,
    permissionKey: string,
    mode: 'read' | 'write',
  ): void {
    if (!hasPermission(actor, permissionKey)) {
      throw new ForbiddenException(`Not authorized to ${mode} this configuration key.`);
    }
  }

  private validateAgainstSchema(definition: ConfigDefinition, value: ConfigValue): void {
    const validate = this.ajv.compile(definition.jsonSchema);
    const isValid = validate(value);
    if (!isValid) {
      throw new BadRequestException(
        `Value for '${definition.key}' failed validation: ${formatAjvErrors(validate.errors)}`,
      );
    }
  }
}
