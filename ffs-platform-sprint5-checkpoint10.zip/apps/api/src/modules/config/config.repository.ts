import { Injectable } from '@nestjs/common';
import { SupabaseClient } from '@supabase/supabase-js';
import {
  ConfigCategory,
  ConfigDefinition,
  ConfigValue,
  SchoolConfigValue,
} from './config.types';

export interface IConfigRepository {
  findDefinitionByKey(key: string): Promise<ConfigDefinition | null>;
  listDefinitionsByCategory(category: ConfigCategory): Promise<ConfigDefinition[]>;
  findValue(
    configDefinitionId: string,
    campusId: string,
  ): Promise<SchoolConfigValue | null>;
  listValuesByCategory(
    category: ConfigCategory,
    campusId: string,
  ): Promise<SchoolConfigValue[]>;
  /**
   * Upserts the value AND writes the audit entry as a single atomic
   * operation from the caller's point of view. The Supabase implementation
   * does this via an RPC (Postgres function) so both writes commit or fail
   * together, rather than the repository performing two separate calls
   * that could partially succeed.
   */
  upsertValueWithAudit(params: {
    configDefinitionId: string;
    campusId: string;
    newValue: ConfigValue;
    actorId: string;
  }): Promise<SchoolConfigValue>;
}

function toConfigDefinition(row: Record<string, unknown>): ConfigDefinition {
  return {
    id: row.id as string,
    category: row.category as ConfigCategory,
    key: row.key as string,
    dataType: row.data_type as ConfigDefinition['dataType'],
    jsonSchema: row.json_schema as Record<string, unknown>,
    readPermissionKey: row.read_permission_key as string,
    writePermissionKey: row.write_permission_key as string,
    description: row.description as string,
  };
}

@Injectable()
export class SupabaseConfigRepository implements IConfigRepository {
  constructor(private readonly client: SupabaseClient) {}

  async findDefinitionByKey(key: string): Promise<ConfigDefinition | null> {
    const { data, error } = await this.client
      .from('config_definitions')
      .select('*')
      .eq('key', key)
      .maybeSingle();

    if (error) {
      throw new Error(`Failed to load config definition: ${error.message}`);
    }
    return data ? toConfigDefinition(data) : null;
  }

  async listDefinitionsByCategory(category: ConfigCategory): Promise<ConfigDefinition[]> {
    const { data, error } = await this.client
      .from('config_definitions')
      .select('*')
      .eq('category', category);

    if (error) {
      throw new Error(`Failed to list config definitions: ${error.message}`);
    }
    return (data ?? []).map(toConfigDefinition);
  }

  async findValue(
    configDefinitionId: string,
    campusId: string,
  ): Promise<SchoolConfigValue | null> {
    const { data, error } = await this.client
      .from('school_config')
      .select('*, config_definitions(key, category)')
      .eq('config_definition_id', configDefinitionId)
      .eq('campus_id', campusId)
      .maybeSingle();

    if (error) {
      throw new Error(`Failed to load config value: ${error.message}`);
    }
    if (!data) {
      return null;
    }
    return this.toSchoolConfigValue(data);
  }

  async listValuesByCategory(
    category: ConfigCategory,
    campusId: string,
  ): Promise<SchoolConfigValue[]> {
    const { data, error } = await this.client
      .from('school_config')
      .select('*, config_definitions!inner(key, category)')
      .eq('campus_id', campusId)
      .eq('config_definitions.category', category);

    if (error) {
      throw new Error(`Failed to list config values: ${error.message}`);
    }
    return (data ?? []).map((row) => this.toSchoolConfigValue(row));
  }

  async upsertValueWithAudit(params: {
    configDefinitionId: string;
    campusId: string;
    newValue: ConfigValue;
    actorId: string;
  }): Promise<SchoolConfigValue> {
    // Calls a Postgres function (defined in migration 0008) that performs
    // the upsert + audit insert inside one transaction — see that
    // migration for why this can't safely be two separate client calls.
    const { data, error } = await this.client.rpc('app_write_school_config', {
      p_config_definition_id: params.configDefinitionId,
      p_campus_id: params.campusId,
      p_new_value: params.newValue as object,
      p_actor_id: params.actorId,
    });

    if (error) {
      throw new Error(`Failed to write config value: ${error.message}`);
    }

    // The function returns the bare school_config row, which has no `key` / `category` (those live on the
    // definition). Re-read through the joined query so the caller always receives a complete value, rather
    // than an object whose key and category are silently undefined.
    const written = Array.isArray(data) ? data[0] : data;
    const complete = await this.findValue(params.configDefinitionId, params.campusId);
    if (!complete) {
      throw new Error(
        `Config value ${(written as { id?: string } | null)?.id ?? ''} was written but could not be read back.`,
      );
    }
    return complete;
  }

  private toSchoolConfigValue(row: Record<string, unknown>): SchoolConfigValue {
    const nested = row.config_definitions as
      | { key: string; category: ConfigCategory }
      | undefined;

    return {
      id: row.id as string,
      configDefinitionId: row.config_definition_id as string,
      campusId: row.campus_id as string,
      key: nested?.key ?? (row.key as string),
      category: nested?.category ?? (row.category as ConfigCategory),
      value: row.value_json,
      updatedBy: row.updated_by as string,
      updatedAt: row.updated_at as string,
    };
  }
}
