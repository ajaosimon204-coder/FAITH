import { Body, Controller, Get, Param, Put, BadRequestException } from '@nestjs/common';
import { CurrentIdentity } from '../identity/current-identity.decorator';
import { ResolvedIdentity } from '../identity/identity.types';
import { ConfigService } from './config.service';
import { CONFIG_CATEGORIES, ConfigCategory, ConfigValue, SchoolConfigValue } from './config.types';

interface SetConfigValueBody {
  value: ConfigValue;
}

function assertValidCategory(category: string): asserts category is ConfigCategory {
  if (!CONFIG_CATEGORIES.includes(category as ConfigCategory)) {
    throw new BadRequestException(
      `Unknown config category '${category}'. Expected one of: ${CONFIG_CATEGORIES.join(', ')}.`,
    );
  }
}

/**
 * Permission checks for this controller are intentionally NOT done via the
 * static @RequirePermissions decorator — each config_definition carries its
 * OWN permission key (Architecture: "an authorized role/permission" per
 * key, not per route), so the check has to be resource-aware, done inside
 * ConfigService (see config.service.ts) rather than declared statically
 * here. This is a deliberate, documented exception to the usual pattern.
 */
@Controller('api/v1/config')
export class ConfigController {
  constructor(private readonly configService: ConfigService) {}

  @Get(':category')
  async listCategory(
    @CurrentIdentity() identity: ResolvedIdentity,
    @Param('category') category: string,
  ): Promise<SchoolConfigValue[]> {
    assertValidCategory(category);
    return this.configService.listCategory(identity, category);
  }

  @Get('value/:key')
  getValue(
    @CurrentIdentity() identity: ResolvedIdentity,
    @Param('key') key: string,
  ): Promise<SchoolConfigValue | null> {
    return this.configService.getValue(identity, key);
  }

  @Put('value/:key')
  setValue(
    @CurrentIdentity() identity: ResolvedIdentity,
    @Param('key') key: string,
    @Body() body: SetConfigValueBody,
  ): Promise<SchoolConfigValue> {
    return this.configService.setValue(identity, key, body.value);
  }
}
