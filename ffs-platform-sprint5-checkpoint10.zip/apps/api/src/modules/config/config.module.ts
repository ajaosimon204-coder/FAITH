import { Module } from '@nestjs/common';
import { SupabaseClient } from '@supabase/supabase-js';
import { SUPABASE_CLIENT } from '../identity/identity.module';
import { ConfigController } from './config.controller';
import { IConfigRepository, SupabaseConfigRepository } from './config.repository';
import { ConfigService } from './config.service';

const CONFIG_REPOSITORY = 'CONFIG_REPOSITORY';

@Module({
  controllers: [ConfigController],
  providers: [
    {
      provide: CONFIG_REPOSITORY,
      useFactory: (client: SupabaseClient): IConfigRepository =>
        new SupabaseConfigRepository(client),
      inject: [SUPABASE_CLIENT],
    },
    {
      provide: ConfigService,
      useFactory: (repo: IConfigRepository) => new ConfigService(repo),
      inject: [CONFIG_REPOSITORY],
    },
  ],
  exports: [ConfigService],
})
export class ConfigModule {}
