export const CONFIG_CATEGORIES = ['academic', 'finance', 'school', 'examination'] as const;
export type ConfigCategory = (typeof CONFIG_CATEGORIES)[number];

export const CONFIG_DATA_TYPES = [
  'string',
  'number',
  'integer',
  'boolean',
  'object',
  'array',
] as const;
export type ConfigDataType = (typeof CONFIG_DATA_TYPES)[number];

/**
 * A config value, however it's represented once parsed from JSONB. Kept as
 * `unknown` at the boundary — the whole point of ConfigService is that
 * nothing downstream trusts this shape until ajv has validated it against
 * the definition's json_schema.
 */
export type ConfigValue = unknown;

export interface ConfigDefinition {
  readonly id: string;
  readonly category: ConfigCategory;
  readonly key: string;
  readonly dataType: ConfigDataType;
  readonly jsonSchema: Record<string, unknown>;
  readonly readPermissionKey: string;
  readonly writePermissionKey: string;
  readonly description: string;
}

export interface SchoolConfigValue {
  readonly id: string;
  readonly configDefinitionId: string;
  readonly campusId: string;
  readonly key: string; // denormalized for convenience in API responses
  readonly category: ConfigCategory;
  readonly value: ConfigValue;
  readonly updatedBy: string;
  readonly updatedAt: string;
}

export interface ConfigAuditEntry {
  readonly id: string;
  readonly configDefinitionId: string;
  readonly campusId: string;
  readonly actorId: string;
  readonly oldValue: ConfigValue;
  readonly newValue: ConfigValue;
  readonly createdAt: string;
}
