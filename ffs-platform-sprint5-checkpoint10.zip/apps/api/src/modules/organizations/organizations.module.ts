import { Module } from '@nestjs/common';
import { SupabaseClient } from '@supabase/supabase-js';
import { SUPABASE_CLIENT } from '../identity/identity.module';
import { OrganizationsController } from './organizations.controller';
import {
  IOrganizationsRepository,
  OrganizationsService,
  SupabaseOrganizationsRepository,
} from './organizations.service';

const ORGANIZATIONS_REPOSITORY = 'ORGANIZATIONS_REPOSITORY';

@Module({
  controllers: [OrganizationsController],
  providers: [
    {
      provide: ORGANIZATIONS_REPOSITORY,
      useFactory: (client: SupabaseClient): IOrganizationsRepository =>
        new SupabaseOrganizationsRepository(client),
      inject: [SUPABASE_CLIENT],
    },
    {
      provide: OrganizationsService,
      useFactory: (repo: IOrganizationsRepository) => new OrganizationsService(repo),
      inject: [ORGANIZATIONS_REPOSITORY],
    },
  ],
})
export class OrganizationsModule {}
