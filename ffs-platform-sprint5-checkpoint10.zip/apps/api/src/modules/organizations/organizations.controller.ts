import { Controller, Get } from '@nestjs/common';
import { CurrentIdentity } from '../identity/current-identity.decorator';
import { ResolvedIdentity } from '../identity/identity.types';
import { OrganizationContext, OrganizationsService } from './organizations.service';

@Controller('api/v1/organizations')
export class OrganizationsController {
  constructor(private readonly organizationsService: OrganizationsService) {}

  @Get('mine')
  getMine(@CurrentIdentity() identity: ResolvedIdentity): Promise<OrganizationContext> {
    return this.organizationsService.getMyOrganizationContext(identity.campusId);
  }
}
