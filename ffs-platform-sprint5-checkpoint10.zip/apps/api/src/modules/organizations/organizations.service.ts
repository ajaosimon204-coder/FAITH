import { Injectable } from '@nestjs/common';
import { SupabaseClient } from '@supabase/supabase-js';

export interface OrganizationContext {
  readonly organizationId: string;
  readonly organizationName: string;
  readonly campusId: string;
  readonly campusName: string;
}

export interface IOrganizationsRepository {
  getContextForCampus(campusId: string): Promise<OrganizationContext | null>;
}

@Injectable()
export class SupabaseOrganizationsRepository implements IOrganizationsRepository {
  constructor(private readonly client: SupabaseClient) {}

  async getContextForCampus(campusId: string): Promise<OrganizationContext | null> {
    const { data, error } = await this.client
      .from('campuses')
      .select('id, name, organizations(id, name)')
      .eq('id', campusId)
      .maybeSingle();

    if (error) {
      throw new Error(`Failed to load organization context: ${error.message}`);
    }
    if (!data) {
      return null;
    }

    const org = (data as unknown as { organizations: { id: string; name: string } })
      .organizations;

    return {
      organizationId: org.id,
      organizationName: org.name,
      campusId: data.id as string,
      campusName: data.name as string,
    };
  }
}

@Injectable()
export class OrganizationsService {
  constructor(private readonly repository: IOrganizationsRepository) {}

  async getMyOrganizationContext(campusId: string): Promise<OrganizationContext> {
    const context = await this.repository.getContextForCampus(campusId);
    if (!context) {
      // A resolved identity with a campus_id that doesn't resolve to a real
      // campus is a data-integrity fault, not a normal 404 — surfaced loudly.
      throw new Error(`Campus ${campusId} does not resolve to an organization.`);
    }
    return context;
  }
}
