import { BadRequestException, ConflictException, ForbiddenException, Injectable, NotFoundException } from '@nestjs/common';
import { hasPermission, ResolvedIdentity } from '../identity/identity.types';
import { AdmissionsRuleViolationError, IAdmissionsRepository } from './admissions.repository';
import {
  ADMISSIONS_PERMISSIONS,
  Application,
  APPLICATION_STATUSES,
  ApplicationDetail,
  ApplicationStatus,
  ConversionResult,
  ReviewNotes,
} from './admissions.types';
import { cleanNote, isUuid } from './admissions.validation';

type ReviewAction = 'startReview' | 'requestInfo' | 'resumeReview' | 'approve' | 'reject';

interface WorkflowRule {
  readonly from: ApplicationStatus;
  readonly to: ApplicationStatus;
  /** Free-text the reviewer must (or may) supply with this action. */
  readonly notes: 'none' | 'optional' | 'required';
  readonly reason: 'none' | 'optional' | 'required';
}

/**
 * The review workflow, stated once. It mirrors the database trigger
 * `trg_validate_application_status_transition` (migration 0021), which remains the
 * final authority — this table exists so the service can refuse early with a clear
 * message and decide what each action must carry (e.g. a rejection needs a reason).
 * `converted` is deliberately not here: conversion is its own operation (`convert`).
 */
const WORKFLOW: Record<ReviewAction, WorkflowRule> = {
  startReview: { from: 'submitted', to: 'under_review', notes: 'optional', reason: 'none' },
  requestInfo: { from: 'under_review', to: 'info_requested', notes: 'required', reason: 'none' },
  resumeReview: { from: 'info_requested', to: 'under_review', notes: 'optional', reason: 'none' },
  approve: { from: 'under_review', to: 'approved', notes: 'optional', reason: 'none' },
  reject: { from: 'under_review', to: 'rejected', notes: 'optional', reason: 'required' },
};

/**
 * Staff-facing admissions operations (review, decision, conversion to a student).
 *
 * IMPORTANT: this service uses the service-role repository, which bypasses RLS entirely.
 * Every method therefore authorises explicitly (permission, THEN campus) — RLS is not a
 * backstop on this path, it protects a different one (the frontend's direct reads).
 * Order of refusal: 403 (no permission) -> 400 (bad input) -> 404 (no such application
 * in the actor's campus, same answer for "missing" and "someone else's") -> 409 (wrong state).
 */
@Injectable()
export class AdmissionsReviewService {
  constructor(private readonly repository: IAdmissionsRepository) {}

  async list(actor: ResolvedIdentity, status?: string): Promise<Application[]> {
    this.assertCanRead(actor);
    let filter: ApplicationStatus | undefined;
    if (status !== undefined && status !== '') {
      if (!(APPLICATION_STATUSES as readonly string[]).includes(status)) {
        throw new BadRequestException(`status must be one of: ${APPLICATION_STATUSES.join(', ')}.`);
      }
      filter = status as ApplicationStatus;
    }
    return this.repository.listApplications(actor.campusId, filter);
  }

  async get(actor: ResolvedIdentity, applicationId: string): Promise<ApplicationDetail> {
    this.assertCanRead(actor);
    const application = await this.requireApplication(actor, applicationId);
    const documents = await this.repository.listDocuments(application.id);
    return { application, documents };
  }

  startReview(actor: ResolvedIdentity, applicationId: string, input: ReviewNotes = {}): Promise<Application> {
    return this.review(actor, applicationId, 'startReview', input);
  }

  requestInfo(actor: ResolvedIdentity, applicationId: string, input: ReviewNotes): Promise<Application> {
    return this.review(actor, applicationId, 'requestInfo', input);
  }

  resumeReview(actor: ResolvedIdentity, applicationId: string, input: ReviewNotes = {}): Promise<Application> {
    return this.review(actor, applicationId, 'resumeReview', input);
  }

  approve(actor: ResolvedIdentity, applicationId: string, input: ReviewNotes = {}): Promise<Application> {
    return this.review(actor, applicationId, 'approve', input);
  }

  reject(actor: ResolvedIdentity, applicationId: string, input: ReviewNotes): Promise<Application> {
    return this.review(actor, applicationId, 'reject', input);
  }

  /**
   * Converts an approved application into a student, guardian, link and active enrollment
   * in one database transaction. The class is validated here first (exists in the actor's
   * campus, is a class of the level applied for) so the usual mistakes get a precise
   * message; the database re-checks all of it and stays the final authority.
   */
  async convert(actor: ResolvedIdentity, applicationId: string, classId: string): Promise<ConversionResult> {
    this.assertCanManage(actor);
    if (!isUuid(classId)) {
      throw new BadRequestException('classId must be a valid id.');
    }
    const application = await this.requireApplication(actor, applicationId);
    if (application.status !== 'approved') {
      throw new ConflictException(
        `Application ${application.referenceNo} is ${application.status}; only an approved application can be converted.`,
      );
    }

    const placement = await this.repository.findPlacementClass(classId);
    if (!placement || placement.campusId !== actor.campusId) {
      throw new NotFoundException(`Class ${classId} not found.`);
    }
    if (placement.classDefinitionId !== application.classDefinitionId) {
      throw new BadRequestException(
        `Class ${classId} is not a class of the level this applicant applied for.`,
      );
    }

    try {
      return await this.repository.convertApplication({
        applicationId: application.id,
        campusId: actor.campusId,
        classId,
        actorId: actor.appUserId,
      });
    } catch (error) {
      if (error instanceof AdmissionsRuleViolationError) throw new ConflictException(error.message);
      throw error;
    }
  }

  private async review(
    actor: ResolvedIdentity,
    applicationId: string,
    action: ReviewAction,
    input: ReviewNotes,
  ): Promise<Application> {
    this.assertCanManage(actor);
    const rule = WORKFLOW[action];
    const reviewNotes = rule.notes === 'none' ? null : cleanNote('Review notes', input?.notes, rule.notes === 'required');
    const decisionReason =
      rule.reason === 'none' ? null : cleanNote('A decision reason', input?.reason, rule.reason === 'required');

    const application = await this.requireApplication(actor, applicationId);
    if (application.status !== rule.from) {
      throw new ConflictException(
        `Application ${application.referenceNo} is ${application.status}; this action requires it to be ${rule.from}.`,
      );
    }

    try {
      return await this.repository.transitionApplication({
        id: application.id,
        campusId: actor.campusId,
        toStatus: rule.to,
        actorId: actor.appUserId,
        action: `application.${rule.to}`,
        reviewNotes,
        decisionReason,
      });
    } catch (error) {
      // Someone else moved it between our read and the database write: report the conflict.
      if (error instanceof AdmissionsRuleViolationError) throw new ConflictException(error.message);
      throw error;
    }
  }

  private async requireApplication(actor: ResolvedIdentity, applicationId: string): Promise<Application> {
    const application = isUuid(applicationId) ? await this.repository.findApplicationById(applicationId) : null;
    // Same answer for "no such application" and "an application in another campus": the
    // service-role read bypasses RLS, so the campus scoping must be re-derived here, and
    // must not reveal that the other campus's application exists.
    if (!application || application.campusId !== actor.campusId) {
      throw new NotFoundException(`Application ${applicationId} not found.`);
    }
    return application;
  }

  private assertCanRead(actor: ResolvedIdentity): void {
    if (
      !hasPermission(actor, ADMISSIONS_PERMISSIONS.APPLICATIONS_READ) &&
      !hasPermission(actor, ADMISSIONS_PERMISSIONS.APPLICATIONS_MANAGE)
    ) {
      throw new ForbiddenException(
        `Not authorized to view applications (requires ${ADMISSIONS_PERMISSIONS.APPLICATIONS_READ}).`,
      );
    }
  }

  private assertCanManage(actor: ResolvedIdentity): void {
    if (!hasPermission(actor, ADMISSIONS_PERMISSIONS.APPLICATIONS_MANAGE)) {
      throw new ForbiddenException(
        `Not authorized to act on applications (requires ${ADMISSIONS_PERMISSIONS.APPLICATIONS_MANAGE}).`,
      );
    }
  }
}
