export const APPLICATION_STATUSES = [
  'submitted',
  'under_review',
  'info_requested',
  'approved',
  'rejected',
  'converted',
] as const;
export type ApplicationStatus = (typeof APPLICATION_STATUSES)[number];

/**
 * Permission keys seeded by migration 0023. `manage` covers every state-changing
 * action (review, approve, reject, convert); `read` covers viewing only.
 */
export const ADMISSIONS_PERMISSIONS = {
  APPLICATIONS_READ: 'admissions.applications.read',
  APPLICATIONS_MANAGE: 'admissions.applications.manage',
} as const;

export interface Application {
  readonly id: string;
  readonly campusId: string;
  readonly referenceNo: string;
  readonly applicantFirstName: string;
  readonly applicantLastName: string;
  readonly applicantDateOfBirth: string;
  readonly applicantGender: string | null;
  readonly classDefinitionId: string;
  readonly guardianFirstName: string;
  readonly guardianLastName: string;
  readonly guardianEmail: string | null;
  readonly guardianPhone: string | null;
  readonly status: ApplicationStatus;
  readonly submittedAt: string;
  readonly reviewedBy: string | null;
  readonly reviewNotes: string | null;
  readonly decisionReason: string | null;
  readonly possibleDuplicateOf: string | null;
  readonly convertedStudentId: string | null;
}

/**
 * A supporting document is a URL reference only — the platform stores no file
 * bytes (migration 0021).
 */
export interface ApplicationDocument {
  readonly id: string;
  readonly applicationId: string;
  readonly docType: string;
  readonly fileUrl: string;
  readonly uploadedAt: string;
}

/** What `app_convert_application` returns on success. */
export interface ConversionResult {
  readonly studentId: string;
  readonly guardianId: string;
  readonly admissionNo: string;
}

/** The class a converted student will be placed in, as needed to validate placement. */
export interface PlacementClass {
  readonly id: string;
  readonly campusId: string;
  readonly classDefinitionId: string;
}

/** The level (class_definition) an applicant is applying for, as needed to validate a submission. */
export interface ClassDefinitionRef {
  readonly id: string;
  readonly campusId: string;
}

export interface NewApplicationInput {
  readonly campusId: string;
  readonly applicantFirstName: string;
  readonly applicantLastName: string;
  readonly applicantDateOfBirth: string;
  readonly applicantGender: string | null;
  readonly classDefinitionId: string;
  readonly guardianFirstName: string;
  readonly guardianLastName: string;
  readonly guardianEmail: string | null;
  readonly guardianPhone: string | null;
  readonly possibleDuplicateOf: string | null;
}

export interface TransitionApplicationInput {
  readonly id: string;
  readonly campusId: string;
  readonly toStatus: ApplicationStatus;
  readonly actorId: string;
  readonly action: string;
  readonly reviewNotes: string | null;
  readonly decisionReason: string | null;
}

export interface ConvertApplicationInput {
  readonly applicationId: string;
  readonly campusId: string;
  readonly classId: string;
  readonly actorId: string;
}

export interface DuplicateLookupInput {
  readonly campusId: string;
  readonly applicantFirstName: string;
  readonly applicantLastName: string;
  readonly applicantDateOfBirth: string;
}

/** What a parent/guardian (unauthenticated) sends to apply. Validated and normalised by the submission service. */
export interface SubmitApplicationInput {
  readonly campusId: string;
  readonly applicantFirstName: string;
  readonly applicantLastName: string;
  readonly applicantDateOfBirth: string;
  readonly applicantGender?: string | null;
  readonly classDefinitionId: string;
  readonly guardianFirstName: string;
  readonly guardianLastName: string;
  readonly guardianEmail?: string | null;
  readonly guardianPhone?: string | null;
  readonly documents?: ReadonlyArray<{ readonly docType: string; readonly fileUrl: string }>;
}

/**
 * The only thing an anonymous applicant gets back. Deliberately minimal: it never
 * exposes the duplicate flag (that would reveal another child's application).
 */
export interface SubmissionReceipt {
  readonly applicationId: string;
  readonly referenceNo: string;
  readonly submittedAt: string;
  readonly documentsRequested: number;
  readonly documentsStored: number;
}

export interface ApplicationDetail {
  readonly application: Application;
  readonly documents: ApplicationDocument[];
}

export interface ReviewNotes {
  readonly notes?: string | null;
  readonly reason?: string | null;
}
