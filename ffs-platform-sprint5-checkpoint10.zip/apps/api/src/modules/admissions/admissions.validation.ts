import { BadRequestException } from '@nestjs/common';
import { SubmitApplicationInput } from './admissions.types';

export const APPLICANT_GENDERS = ['female', 'male'] as const;
export const MAX_APPLICANT_AGE_YEARS = 25;
export const MAX_DOCUMENTS_PER_APPLICATION = 10;
export const MAX_NAME_LENGTH = 100;
export const MAX_NOTE_LENGTH = 2000;

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
const ISO_DATE = /^(\d{4})-(\d{2})-(\d{2})$/;
const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PHONE = /^\+?\d{7,15}$/;

/** The normalised, safe-to-store form of a validated submission (documents are validated separately). */
export interface ValidatedSubmission {
  campusId: string;
  applicantFirstName: string;
  applicantLastName: string;
  applicantDateOfBirth: string;
  applicantGender: string | null;
  classDefinitionId: string;
  guardianFirstName: string;
  guardianLastName: string;
  guardianEmail: string | null;
  guardianPhone: string | null;
  documents: Array<{ docType: string; fileUrl: string }>;
}

function asText(value: unknown): string {
  return typeof value === 'string' ? value : '';
}

/** Trims and collapses internal whitespace. */
function cleanText(value: unknown): string {
  return asText(value).trim().replace(/\s+/g, ' ');
}

function validName(label: string, value: unknown, errors: string[]): string {
  const name = cleanText(value);
  if (name.length === 0) {
    errors.push(`${label} is required.`);
  } else if (name.length > MAX_NAME_LENGTH) {
    errors.push(`${label} must be at most ${MAX_NAME_LENGTH} characters.`);
  } else if (!/\p{L}/u.test(name)) {
    errors.push(`${label} must contain at least one letter.`);
  }
  return name;
}

function validDateOfBirth(value: unknown, now: Date, errors: string[]): string {
  const raw = asText(value).trim();
  const match = ISO_DATE.exec(raw);
  if (!match) {
    errors.push('Applicant date of birth must be a date in YYYY-MM-DD form.');
    return raw;
  }
  const [year, month, day] = [Number(match[1]), Number(match[2]), Number(match[3])];
  const date = new Date(Date.UTC(year, month - 1, day));
  const isRealDate =
    date.getUTCFullYear() === year && date.getUTCMonth() === month - 1 && date.getUTCDate() === day;
  if (!isRealDate) {
    errors.push('Applicant date of birth is not a real calendar date.');
    return raw;
  }
  const today = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate());
  if (date.getTime() > today) {
    errors.push('Applicant date of birth cannot be in the future.');
  } else {
    const oldest = Date.UTC(now.getUTCFullYear() - MAX_APPLICANT_AGE_YEARS, now.getUTCMonth(), now.getUTCDate());
    if (date.getTime() < oldest) {
      errors.push(`Applicant must be at most ${MAX_APPLICANT_AGE_YEARS} years old.`);
    }
  }
  return raw;
}

function validDocument(
  doc: { docType?: unknown; fileUrl?: unknown },
  index: number,
  errors: string[],
): { docType: string; fileUrl: string } {
  const label = `Document ${index + 1}`;
  const docType = cleanText(doc?.docType);
  if (docType.length === 0 || docType.length > 50) {
    errors.push(`${label}: type is required (at most 50 characters).`);
  }
  const fileUrl = asText(doc?.fileUrl).trim();
  let acceptable = false;
  if (fileUrl.length > 0 && fileUrl.length <= 2048) {
    try {
      const url = new URL(fileUrl);
      acceptable = url.protocol === 'https:' && url.username === '' && url.password === '';
    } catch {
      acceptable = false;
    }
  }
  if (!acceptable) {
    errors.push(`${label}: file URL must be a valid https URL (at most 2048 characters) without credentials.`);
  }
  return { docType, fileUrl };
}

/**
 * Validates and normalises an application submission, collecting EVERY problem so the
 * applicant can fix the form in one pass. Throws a single 400 listing them all.
 * `now` is injected so the date rules are testable.
 */
export function validateSubmission(input: SubmitApplicationInput, now: Date): ValidatedSubmission {
  const errors: string[] = [];

  const campusId = asText(input?.campusId).trim();
  if (!UUID.test(campusId)) errors.push('campusId must be a valid id.');
  const classDefinitionId = asText(input?.classDefinitionId).trim();
  if (!UUID.test(classDefinitionId)) errors.push('classDefinitionId must be a valid id.');

  const applicantFirstName = validName('Applicant first name', input?.applicantFirstName, errors);
  const applicantLastName = validName('Applicant last name', input?.applicantLastName, errors);
  const applicantDateOfBirth = validDateOfBirth(input?.applicantDateOfBirth, now, errors);

  let applicantGender: string | null = null;
  const genderRaw = cleanText(input?.applicantGender).toLowerCase();
  if (genderRaw.length > 0) {
    if ((APPLICANT_GENDERS as readonly string[]).includes(genderRaw)) {
      applicantGender = genderRaw;
    } else {
      errors.push(`Applicant gender must be one of: ${APPLICANT_GENDERS.join(', ')}.`);
    }
  }

  const guardianFirstName = validName('Guardian first name', input?.guardianFirstName, errors);
  const guardianLastName = validName('Guardian last name', input?.guardianLastName, errors);

  // Stored lower-cased: the database matches siblings' guardians by e-mail case-insensitively,
  // and a single canonical form keeps the data clean.
  let guardianEmail: string | null = null;
  const emailRaw = asText(input?.guardianEmail).trim();
  if (emailRaw.length > 0) {
    if (emailRaw.length <= 254 && EMAIL.test(emailRaw)) {
      guardianEmail = emailRaw.toLowerCase();
    } else {
      errors.push('Guardian email is not a valid email address.');
    }
  }

  let guardianPhone: string | null = null;
  const phoneRaw = asText(input?.guardianPhone).trim();
  if (phoneRaw.length > 0) {
    const stripped = phoneRaw.replace(/[\s()-]/g, '');
    if (PHONE.test(stripped)) {
      guardianPhone = stripped;
    } else {
      errors.push('Guardian phone must be 7 to 15 digits, optionally starting with +.');
    }
  }

  if (emailRaw.length === 0 && phoneRaw.length === 0) {
    errors.push('A guardian email or phone number is required so the school can reach the family.');
  }

  const documents: Array<{ docType: string; fileUrl: string }> = [];
  const rawDocs = input?.documents ?? [];
  if (!Array.isArray(rawDocs)) {
    errors.push('documents must be a list.');
  } else if (rawDocs.length > MAX_DOCUMENTS_PER_APPLICATION) {
    errors.push(`At most ${MAX_DOCUMENTS_PER_APPLICATION} documents may be attached.`);
  } else {
    rawDocs.forEach((doc, i) => documents.push(validDocument(doc, i, errors)));
  }

  if (errors.length > 0) {
    throw new BadRequestException({ statusCode: 400, error: 'Bad Request', message: errors });
  }

  return {
    campusId,
    applicantFirstName,
    applicantLastName,
    applicantDateOfBirth,
    applicantGender,
    classDefinitionId,
    guardianFirstName,
    guardianLastName,
    guardianEmail,
    guardianPhone,
    documents,
  };
}

/** Optional free text (review notes, decision reason): trimmed, empty -> null, bounded. */
export function cleanNote(label: string, value: unknown, required: boolean): string | null {
  const text = asText(value).trim();
  if (text.length === 0) {
    if (required) throw new BadRequestException(`${label} is required.`);
    return null;
  }
  if (text.length > MAX_NOTE_LENGTH) {
    throw new BadRequestException(`${label} must be at most ${MAX_NOTE_LENGTH} characters.`);
  }
  return text;
}

export function isUuid(value: unknown): value is string {
  return typeof value === 'string' && UUID.test(value);
}
