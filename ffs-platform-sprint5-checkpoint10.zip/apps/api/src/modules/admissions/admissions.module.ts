import { Module } from '@nestjs/common';
import { SupabaseClient } from '@supabase/supabase-js';
import { ThrottlerModule } from '@nestjs/throttler';
import { SUPABASE_CLIENT } from '../identity/identity.module';
import { AdmissionsController, PublicAdmissionsController } from './admissions.controller';
import { AdmissionsReviewService } from './admissions-review.service';
import { AdmissionsSubmissionService } from './admissions-submission.service';
import { IAdmissionsRepository, SupabaseAdmissionsRepository } from './admissions.repository';

export const ADMISSIONS_REPOSITORY = 'ADMISSIONS_REPOSITORY';

/**
 * Public submissions per client address per window. Generous for a family (or a school
 * office submitting on several families' behalf from one connection) and far too low to
 * flood the review queue. Counted in process memory, so with N API instances the effective
 * ceiling is N times this; move to a shared store if instances are scaled out.
 */
export const ADMISSIONS_SUBMISSION_RATE_LIMIT = { limit: 10, ttlMs: 60 * 60 * 1000 } as const;

@Module({
  imports: [
    ThrottlerModule.forRoot([
      {
        limit: ADMISSIONS_SUBMISSION_RATE_LIMIT.limit,
        ttl: ADMISSIONS_SUBMISSION_RATE_LIMIT.ttlMs,
      },
    ]),
  ],
  controllers: [AdmissionsController, PublicAdmissionsController],
  providers: [
    {
      provide: ADMISSIONS_REPOSITORY,
      useFactory: (client: SupabaseClient): IAdmissionsRepository =>
        new SupabaseAdmissionsRepository(client),
      inject: [SUPABASE_CLIENT],
    },
    {
      provide: AdmissionsSubmissionService,
      useFactory: (repo: IAdmissionsRepository) => new AdmissionsSubmissionService(repo),
      inject: [ADMISSIONS_REPOSITORY],
    },
    {
      provide: AdmissionsReviewService,
      useFactory: (repo: IAdmissionsRepository) => new AdmissionsReviewService(repo),
      inject: [ADMISSIONS_REPOSITORY],
    },
  ],
})
export class AdmissionsModule {}
