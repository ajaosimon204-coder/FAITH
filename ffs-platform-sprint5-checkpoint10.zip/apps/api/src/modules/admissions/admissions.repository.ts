import { Injectable } from '@nestjs/common';
import { SupabaseClient } from '@supabase/supabase-js';
import {
  Application,
  ApplicationDocument,
  ApplicationStatus,
  ClassDefinitionRef,
  ConversionResult,
  ConvertApplicationInput,
  DuplicateLookupInput,
  NewApplicationInput,
  PlacementClass,
  TransitionApplicationInput,
} from './admissions.types';

/**
 * Raised when the database itself rejects an admissions write on a business
 * rule (an illegal status transition, converting a non-approved application,
 * a class that does not fit, and so on). These are `RAISE EXCEPTION` errors
 * from the atomic functions and triggers (SQLSTATE P0001) — an expected
 * outcome of a race or a stale view, not a server fault — so the service layer
 * can answer 409 rather than 500. The database remains the final authority;
 * the service pre-checks only to give friendlier, earlier errors.
 */
export class AdmissionsRuleViolationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'AdmissionsRuleViolationError';
  }
}

export interface IAdmissionsRepository {
  createApplication(input: NewApplicationInput): Promise<Application>;
  addDocument(input: {
    applicationId: string;
    docType: string;
    fileUrl: string;
  }): Promise<ApplicationDocument>;
  findApplicationById(id: string): Promise<Application | null>;
  listApplications(campusId: string, status?: ApplicationStatus): Promise<Application[]>;
  listDocuments(applicationId: string): Promise<ApplicationDocument[]>;
  /** Most recent earlier application for the same child (name + date of birth) in the campus. */
  findPossibleDuplicate(input: DuplicateLookupInput): Promise<Application | null>;
  /**
   * Atomic status change + audit entry in one database transaction
   * (`app_application_transition`, migration 0024).
   */
  transitionApplication(input: TransitionApplicationInput): Promise<Application>;
  /**
   * Atomic conversion of an approved application into a student, guardian,
   * guardian link and active enrollment (`app_convert_application`, migration 0024).
   */
  convertApplication(input: ConvertApplicationInput): Promise<ConversionResult>;
  findPlacementClass(classId: string): Promise<PlacementClass | null>;
  findClassDefinition(id: string): Promise<ClassDefinitionRef | null>;
}

type Row = Record<string, unknown>;

export function toApplication(row: Row): Application {
  return {
    id: row.id as string,
    campusId: row.campus_id as string,
    referenceNo: row.reference_no as string,
    applicantFirstName: row.applicant_first_name as string,
    applicantLastName: row.applicant_last_name as string,
    applicantDateOfBirth: row.applicant_date_of_birth as string,
    applicantGender: (row.applicant_gender as string | null) ?? null,
    classDefinitionId: row.class_definition_id as string,
    guardianFirstName: row.guardian_first_name as string,
    guardianLastName: row.guardian_last_name as string,
    guardianEmail: (row.guardian_email as string | null) ?? null,
    guardianPhone: (row.guardian_phone as string | null) ?? null,
    status: row.status as ApplicationStatus,
    submittedAt: row.submitted_at as string,
    reviewedBy: (row.reviewed_by as string | null) ?? null,
    reviewNotes: (row.review_notes as string | null) ?? null,
    decisionReason: (row.decision_reason as string | null) ?? null,
    possibleDuplicateOf: (row.possible_duplicate_of as string | null) ?? null,
    convertedStudentId: (row.converted_student_id as string | null) ?? null,
  };
}

export function toApplicationDocument(row: Row): ApplicationDocument {
  return {
    id: row.id as string,
    applicationId: row.application_id as string,
    docType: row.doc_type as string,
    fileUrl: row.file_url as string,
    uploadedAt: row.uploaded_at as string,
  };
}

export function toConversionResult(value: unknown): ConversionResult {
  const v = (Array.isArray(value) ? value[0] : value) as Row | null | undefined;
  if (
    !v ||
    typeof v.studentId !== 'string' ||
    typeof v.guardianId !== 'string' ||
    typeof v.admissionNo !== 'string'
  ) {
    throw new Error('Application conversion returned an unexpected result shape.');
  }
  return { studentId: v.studentId, guardianId: v.guardianId, admissionNo: v.admissionNo };
}

/**
 * Escapes `\`, `%` and `_` so a value can be used as an exact, case-insensitive
 * match in an ILIKE pattern (a name such as "Mary_Ann" must not act as a wildcard).
 */
export function escapeIlike(value: string): string {
  return value.replace(/[\\%_]/g, (c) => `\\${c}`);
}

/** SQLSTATE raised by `RAISE EXCEPTION` in the admissions functions and triggers. */
const BUSINESS_RULE_SQLSTATE = 'P0001';

function failure(context: string, error: { message: string; code?: string }): Error {
  if (error.code === BUSINESS_RULE_SQLSTATE) {
    return new AdmissionsRuleViolationError(error.message);
  }
  return new Error(`${context}: ${error.message}`);
}

@Injectable()
export class SupabaseAdmissionsRepository implements IAdmissionsRepository {
  constructor(private readonly client: SupabaseClient) {}

  async createApplication(input: NewApplicationInput): Promise<Application> {
    const { data, error } = await this.client
      .from('applications')
      .insert({
        campus_id: input.campusId,
        applicant_first_name: input.applicantFirstName,
        applicant_last_name: input.applicantLastName,
        applicant_date_of_birth: input.applicantDateOfBirth,
        applicant_gender: input.applicantGender,
        class_definition_id: input.classDefinitionId,
        guardian_first_name: input.guardianFirstName,
        guardian_last_name: input.guardianLastName,
        guardian_email: input.guardianEmail,
        guardian_phone: input.guardianPhone,
        possible_duplicate_of: input.possibleDuplicateOf,
      })
      .select()
      .single();
    if (error) throw failure('Failed to create application', error);
    return toApplication(data);
  }

  async addDocument(input: {
    applicationId: string;
    docType: string;
    fileUrl: string;
  }): Promise<ApplicationDocument> {
    const { data, error } = await this.client
      .from('application_documents')
      .insert({
        application_id: input.applicationId,
        doc_type: input.docType,
        file_url: input.fileUrl,
      })
      .select()
      .single();
    if (error) throw failure('Failed to add application document', error);
    return toApplicationDocument(data);
  }

  async findApplicationById(id: string): Promise<Application | null> {
    const { data, error } = await this.client
      .from('applications')
      .select('*')
      .eq('id', id)
      .maybeSingle();
    if (error) throw new Error(`Failed to load application: ${error.message}`);
    return data ? toApplication(data) : null;
  }

  async listApplications(campusId: string, status?: ApplicationStatus): Promise<Application[]> {
    let query = this.client.from('applications').select('*').eq('campus_id', campusId);
    if (status) query = query.eq('status', status);
    const { data, error } = await query.order('submitted_at', { ascending: false });
    if (error) throw new Error(`Failed to list applications: ${error.message}`);
    return (data ?? []).map(toApplication);
  }

  async listDocuments(applicationId: string): Promise<ApplicationDocument[]> {
    const { data, error } = await this.client
      .from('application_documents')
      .select('*')
      .eq('application_id', applicationId)
      .order('uploaded_at', { ascending: true });
    if (error) throw new Error(`Failed to list application documents: ${error.message}`);
    return (data ?? []).map(toApplicationDocument);
  }

  async findPossibleDuplicate(input: DuplicateLookupInput): Promise<Application | null> {
    const { data, error } = await this.client
      .from('applications')
      .select('*')
      .eq('campus_id', input.campusId)
      .eq('applicant_date_of_birth', input.applicantDateOfBirth)
      .ilike('applicant_first_name', escapeIlike(input.applicantFirstName.trim()))
      .ilike('applicant_last_name', escapeIlike(input.applicantLastName.trim()))
      .order('submitted_at', { ascending: false })
      .limit(1);
    if (error) throw new Error(`Failed to look up duplicate applications: ${error.message}`);
    const row = (data ?? [])[0];
    return row ? toApplication(row) : null;
  }

  async transitionApplication(input: TransitionApplicationInput): Promise<Application> {
    const { data, error } = await this.client.rpc('app_application_transition', {
      p_id: input.id,
      p_campus_id: input.campusId,
      p_to_status: input.toStatus,
      p_actor_id: input.actorId,
      p_action: input.action,
      p_review_notes: input.reviewNotes,
      p_decision_reason: input.decisionReason,
    });
    if (error) throw failure('Failed to transition application', error);
    return toApplication(Array.isArray(data) ? data[0] : data);
  }

  async convertApplication(input: ConvertApplicationInput): Promise<ConversionResult> {
    const { data, error } = await this.client.rpc('app_convert_application', {
      p_application_id: input.applicationId,
      p_campus_id: input.campusId,
      p_class_id: input.classId,
      p_actor_id: input.actorId,
    });
    if (error) throw failure('Failed to convert application', error);
    return toConversionResult(data);
  }

  async findPlacementClass(classId: string): Promise<PlacementClass | null> {
    const { data, error } = await this.client
      .from('classes')
      .select('id, campus_id, class_definition_id')
      .eq('id', classId)
      .maybeSingle();
    if (error) throw new Error(`Failed to load class: ${error.message}`);
    return data
      ? {
          id: data.id as string,
          campusId: data.campus_id as string,
          classDefinitionId: data.class_definition_id as string,
        }
      : null;
  }

  async findClassDefinition(id: string): Promise<ClassDefinitionRef | null> {
    const { data, error } = await this.client
      .from('class_definitions')
      .select('id, campus_id')
      .eq('id', id)
      .maybeSingle();
    if (error) throw new Error(`Failed to load class definition: ${error.message}`);
    return data ? { id: data.id as string, campusId: data.campus_id as string } : null;
  }
}
