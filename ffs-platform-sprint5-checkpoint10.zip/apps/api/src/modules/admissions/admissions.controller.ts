import { Body, Controller, Get, Param, Post, Query, UseGuards } from '@nestjs/common';
import { ThrottlerGuard } from '@nestjs/throttler';
import { CurrentIdentity } from '../identity/current-identity.decorator';
import { ResolvedIdentity } from '../identity/identity.types';
import { Public } from '../identity/public.decorator';
import { AdmissionsReviewService } from './admissions-review.service';
import { AdmissionsSubmissionService } from './admissions-submission.service';
import { ReviewNotes, SubmitApplicationInput } from './admissions.types';

/**
 * Staff-facing admissions routes. Authenticated by the global SupabaseAuthGuard; every
 * rule (permission, campus scope, workflow state, input) lives in AdmissionsReviewService —
 * the controller only maps HTTP to service calls (Governance Rule 2: written once).
 */
@Controller('api/v1/admissions')
export class AdmissionsController {
  constructor(private readonly reviewService: AdmissionsReviewService) {}

  @Get('applications')
  list(@CurrentIdentity() identity: ResolvedIdentity, @Query('status') status?: string) {
    return this.reviewService.list(identity, status);
  }

  @Get('applications/:id')
  get(@CurrentIdentity() identity: ResolvedIdentity, @Param('id') id: string) {
    return this.reviewService.get(identity, id);
  }

  @Post('applications/:id/start-review')
  startReview(
    @CurrentIdentity() identity: ResolvedIdentity,
    @Param('id') id: string,
    @Body() body: ReviewNotes,
  ) {
    return this.reviewService.startReview(identity, id, body);
  }

  @Post('applications/:id/request-info')
  requestInfo(
    @CurrentIdentity() identity: ResolvedIdentity,
    @Param('id') id: string,
    @Body() body: ReviewNotes,
  ) {
    return this.reviewService.requestInfo(identity, id, body);
  }

  @Post('applications/:id/resume-review')
  resumeReview(
    @CurrentIdentity() identity: ResolvedIdentity,
    @Param('id') id: string,
    @Body() body: ReviewNotes,
  ) {
    return this.reviewService.resumeReview(identity, id, body);
  }

  @Post('applications/:id/approve')
  approve(
    @CurrentIdentity() identity: ResolvedIdentity,
    @Param('id') id: string,
    @Body() body: ReviewNotes,
  ) {
    return this.reviewService.approve(identity, id, body);
  }

  @Post('applications/:id/reject')
  reject(
    @CurrentIdentity() identity: ResolvedIdentity,
    @Param('id') id: string,
    @Body() body: ReviewNotes,
  ) {
    return this.reviewService.reject(identity, id, body);
  }

  @Post('applications/:id/convert')
  convert(
    @CurrentIdentity() identity: ResolvedIdentity,
    @Param('id') id: string,
    @Body() body: { classId: string },
  ) {
    return this.reviewService.convert(identity, id, body?.classId);
  }
}

/**
 * Genuinely public: a parent or guardian applies with no account, so this route opts out
 * of the global auth guard via @Public(). That exception is safe only because of what
 * stands behind it: AdmissionsSubmissionService validates and normalises every field,
 * the database owns status and reference number and refuses a level from another campus,
 * the response is a minimal receipt, and this route is rate-limited per client address
 * (ThrottlerGuard, configured in AdmissionsModule). It is write-only: nothing under
 * /public/admissions reads application data back.
 */
@Controller('api/v1/public/admissions')
export class PublicAdmissionsController {
  constructor(private readonly submissionService: AdmissionsSubmissionService) {}

  @Public()
  @UseGuards(ThrottlerGuard)
  @Post('applications')
  submit(@Body() body: SubmitApplicationInput) {
    return this.submissionService.submit(body);
  }
}
