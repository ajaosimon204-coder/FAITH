import { BadRequestException, Injectable, Logger } from '@nestjs/common';
import { AdmissionsRuleViolationError, IAdmissionsRepository } from './admissions.repository';
import { SubmissionReceipt, SubmitApplicationInput } from './admissions.types';
import { validateSubmission } from './admissions.validation';

/**
 * Public application intake. There is NO authenticated actor here — the caller is a
 * parent or guardian — so this service is the entire trust boundary for that input:
 * it validates and normalises everything, checks the applied-for level really belongs
 * to the named campus, flags a possible duplicate, and returns a deliberately minimal
 * receipt. (The database independently refuses a level from another campus —
 * migration 0027 — and owns the status and reference number.)
 *
 * Documents are URL references, attached after the application is created. That is not
 * a single database transaction, so a failure attaching one document must not lose the
 * application the family has just submitted: the receipt reports how many were stored,
 * and the school can request the rest through the `info_requested` step.
 */
@Injectable()
export class AdmissionsSubmissionService {
  private readonly logger = new Logger(AdmissionsSubmissionService.name);

  constructor(
    private readonly repository: IAdmissionsRepository,
    private readonly clock: () => Date = () => new Date(),
  ) {}

  async submit(input: SubmitApplicationInput): Promise<SubmissionReceipt> {
    const data = validateSubmission(input, this.clock());

    // Same message whether the level does not exist or belongs to another campus,
    // so a public caller cannot probe which ids exist in other campuses.
    const definition = await this.repository.findClassDefinition(data.classDefinitionId);
    if (!definition || definition.campusId !== data.campusId) {
      throw new BadRequestException('The selected class level is not available for this campus.');
    }

    // Flag, never block: siblings with the same name are rare but twins and re-applications
    // are real, and a school decides what a duplicate means, not the form.
    const duplicate = await this.repository.findPossibleDuplicate({
      campusId: data.campusId,
      applicantFirstName: data.applicantFirstName,
      applicantLastName: data.applicantLastName,
      applicantDateOfBirth: data.applicantDateOfBirth,
    });

    let application;
    try {
      application = await this.repository.createApplication({
        campusId: data.campusId,
        applicantFirstName: data.applicantFirstName,
        applicantLastName: data.applicantLastName,
        applicantDateOfBirth: data.applicantDateOfBirth,
        applicantGender: data.applicantGender,
        classDefinitionId: data.classDefinitionId,
        guardianFirstName: data.guardianFirstName,
        guardianLastName: data.guardianLastName,
        guardianEmail: data.guardianEmail,
        guardianPhone: data.guardianPhone,
        possibleDuplicateOf: duplicate?.id ?? null,
      });
    } catch (error) {
      // The database refused on a business rule we had already pre-checked: a race
      // (e.g. the level was removed in between). Still the applicant's 400, not a 500.
      if (error instanceof AdmissionsRuleViolationError) {
        throw new BadRequestException('The application could not be accepted. Please check the form and try again.');
      }
      throw error;
    }

    let documentsStored = 0;
    for (const doc of data.documents) {
      try {
        await this.repository.addDocument({
          applicationId: application.id,
          docType: doc.docType,
          fileUrl: doc.fileUrl,
        });
        documentsStored += 1;
      } catch (error) {
        this.logger.warn(
          `Application ${application.referenceNo}: could not attach a "${doc.docType}" document ` +
            `(${error instanceof Error ? error.message : 'unknown error'})`,
        );
      }
    }

    return {
      applicationId: application.id,
      referenceNo: application.referenceNo,
      submittedAt: application.submittedAt,
      documentsRequested: data.documents.length,
      documentsStored,
    };
  }
}
