/**
 * The verified token claims we trust from Supabase Auth, and nothing more.
 * Supabase Auth is the ONLY holder of credentials (Architecture Section A/B.1).
 */
export interface VerifiedAuthClaims {
  readonly authUserId: string; // Supabase auth.users.id (sub claim)
  readonly email: string | null;
}

/**
 * The fully-resolved application identity for a request: who they are,
 * what campus they're scoped to, and what they're permitted to do.
 *
 * This object is built ONCE per request, server-side, from the database —
 * never trusted from the client, never cached across requests beyond the
 * request lifecycle (Governance Rule 6: no frontend-owned business truth).
 */
export interface ResolvedIdentity {
  readonly authUserId: string;
  readonly appUserId: string;
  readonly email: string | null;
  readonly status: 'active' | 'suspended';
  readonly campusId: string;
  readonly organizationId: string;
  readonly roles: readonly string[]; // role keys, e.g. 'super_admin'
  readonly permissions: readonly string[]; // permission keys, e.g. 'rbac.manage'
}

export function hasPermission(
  identity: ResolvedIdentity,
  permission: string,
): boolean {
  return identity.permissions.includes(permission);
}

export function hasAnyRole(
  identity: ResolvedIdentity,
  roles: readonly string[],
): boolean {
  return identity.roles.some((r) => roles.includes(r));
}
