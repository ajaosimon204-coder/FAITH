import { Injectable, Logger, ServiceUnavailableException, UnauthorizedException } from '@nestjs/common';
import {
  createRemoteJWKSet,
  decodeProtectedHeader,
  errors,
  jwtVerify,
  JWTPayload,
  JWTVerifyGetKey,
} from 'jose';
import { VerifiedAuthClaims } from './identity.types';

/** Signature algorithms accepted for tokens signed with Supabase's asymmetric JWT signing keys. */
export const ASYMMETRIC_ALGORITHMS = ['ES256', 'RS256', 'EdDSA'] as const;

export interface JwtVerificationOptions {
  /**
   * HS256 shared secret. Only for projects still on Supabase's LEGACY JWT secret. Current projects sign
   * with asymmetric keys and have no secret to configure (Supabase no longer lets one be extracted).
   */
  readonly legacySecret?: string;
  /** JWKS endpoint publishing the public signing keys (`<project>/auth/v1/.well-known/jwks.json`). */
  readonly jwksUrl?: string;
  /** Expected `iss`, e.g. `https://<ref>.supabase.co/auth/v1`. Enforced when set. */
  readonly issuer?: string;
  /** Expected `aud`; Supabase uses `authenticated` for signed-in users. Enforced when set. */
  readonly audience?: string;
  /** Minimum seconds between JWKS refetches when a token names an unknown key (rotation). Default 30. */
  readonly jwksCooldownSeconds?: number;
  /** Clock skew tolerated on exp/nbf, in seconds. Default 5. */
  readonly clockToleranceSeconds?: number;
}

/** A token we have no configured way to verify (e.g. an HS256 token but no legacy secret). */
class UnverifiableTokenError extends Error {}

/**
 * Verifies Supabase Auth-issued JWTs, whichever way the project signs them:
 *   - asymmetric (ES256 / RS256 / EdDSA): verified against the project's published JWKS — current projects;
 *   - HS256 with the legacy shared secret — older projects, only if a secret is configured.
 *
 * The signing algorithm is read from the token header but only to CHOOSE the verification path; each
 * path then enforces its own fixed algorithm allowlist, so a token cannot talk its way into the wrong
 * one (the classic algorithm-confusion attack — an HS256 token "signed" with a public key — is refused
 * because the HS256 path uses only the configured secret, never a JWKS key).
 *
 * This service does exactly one thing: prove the token was issued by Supabase Auth and hasn't been
 * tampered with or expired. It does NOT decide roles, permissions, or campus scope — that is
 * IdentityResolutionService's job, resolved fresh from our own tables (Architecture Section A).
 */
@Injectable()
export class JwtVerificationService {
  private readonly logger = new Logger(JwtVerificationService.name);
  private readonly legacyKey?: Uint8Array;
  private readonly jwks?: JWTVerifyGetKey;
  private readonly claimOptions: { issuer?: string; audience?: string; clockTolerance: number };

  constructor(options: JwtVerificationOptions) {
    this.legacyKey = options.legacySecret ? new TextEncoder().encode(options.legacySecret) : undefined;
    this.jwks = options.jwksUrl
      ? createRemoteJWKSet(new URL(options.jwksUrl), {
          cooldownDuration: (options.jwksCooldownSeconds ?? 30) * 1000,
          timeoutDuration: 5000,
        })
      : undefined;
    this.claimOptions = {
      ...(options.issuer ? { issuer: options.issuer } : {}),
      ...(options.audience ? { audience: options.audience } : {}),
      clockTolerance: options.clockToleranceSeconds ?? 5,
    };
  }

  async verify(bearerToken: string): Promise<VerifiedAuthClaims> {
    if (!bearerToken) {
      throw new UnauthorizedException('Missing bearer token.');
    }

    let payload: JWTPayload;
    try {
      payload = await this.verifyPayload(bearerToken);
    } catch (err) {
      throw this.translate(err);
    }

    const sub = payload.sub;
    if (!sub || typeof sub !== 'string') {
      throw new UnauthorizedException('Token missing subject claim.');
    }
    const email = typeof payload.email === 'string' ? payload.email : null;
    return { authUserId: sub, email };
  }

  private async verifyPayload(token: string): Promise<JWTPayload> {
    let alg: string | undefined;
    try {
      alg = decodeProtectedHeader(token).alg;
    } catch {
      throw new errors.JWTInvalid('Malformed token.');
    }

    if (alg === 'HS256') {
      if (!this.legacyKey) {
        throw new UnverifiableTokenError(
          'HS256 token received but no legacy JWT secret is configured (SUPABASE_JWT_SECRET).',
        );
      }
      const { payload } = await jwtVerify(token, this.legacyKey, { ...this.claimOptions, algorithms: ['HS256'] });
      return payload;
    }

    if (alg && (ASYMMETRIC_ALGORITHMS as readonly string[]).includes(alg)) {
      if (!this.jwks) {
        throw new UnverifiableTokenError(`${alg} token received but no JWKS endpoint is configured.`);
      }
      const { payload } = await jwtVerify(token, this.jwks, {
        ...this.claimOptions,
        algorithms: [...ASYMMETRIC_ALGORITHMS],
      });
      return payload;
    }

    // `none`, unknown algorithms, or a missing header.
    throw new errors.JOSEAlgNotAllowed(`Unsupported token algorithm "${alg ?? 'none'}".`);
  }

  /**
   * Token faults answer 401 and are deliberately vague to the client (no probing oracle: expired vs.
   * malformed vs. wrong signature all look alike). The real reason is logged server-side — without the
   * token — so an operator can diagnose, e.g., a wrong issuer or a missing legacy secret.
   * Anything else (the JWKS endpoint unreachable or malformed) is OUR side failing, not the caller's: it
   * answers 503, because telling every signed-in user their session is invalid during a key-fetch outage
   * would be both wrong and impossible to diagnose.
   */
  private translate(err: unknown): Error {
    if (err instanceof errors.JWTExpired) {
      this.logger.debug('Token rejected: expired.');
      return new UnauthorizedException('Invalid or expired session.');
    }
    const isTokenFault =
      err instanceof UnverifiableTokenError ||
      err instanceof errors.JWTClaimValidationFailed ||
      err instanceof errors.JWTInvalid ||
      err instanceof errors.JWSInvalid ||
      err instanceof errors.JWSSignatureVerificationFailed ||
      err instanceof errors.JWKSNoMatchingKey ||
      err instanceof errors.JWKSMultipleMatchingKeys ||
      err instanceof errors.JOSEAlgNotAllowed;

    if (isTokenFault) {
      const detail =
        err instanceof errors.JWTClaimValidationFailed
          ? `claim "${err.claim}" ${err.reason}`
          : err instanceof Error
            ? `${err.name}: ${err.message}`
            : 'unknown';
      this.logger.warn(`Token rejected: ${detail}`);
      return new UnauthorizedException('Invalid or expired session.');
    }

    this.logger.error(
      `Token verification could not complete (key retrieval failing?): ${err instanceof Error ? `${err.name}: ${err.message}` : 'unknown'}`,
    );
    return new ServiceUnavailableException('Authentication is temporarily unavailable. Please try again shortly.');
  }
}
