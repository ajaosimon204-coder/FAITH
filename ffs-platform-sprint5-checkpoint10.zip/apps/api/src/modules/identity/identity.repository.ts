import { Injectable } from '@nestjs/common';
import { SupabaseClient } from '@supabase/supabase-js';

export interface UserRecord {
  readonly appUserId: string;
  readonly authUserId: string;
  readonly email: string | null;
  readonly status: 'active' | 'suspended';
  readonly campusId: string;
  readonly organizationId: string;
}

/**
 * Everything the identity/RBAC layer needs to read or write, behind an
 * interface — so services can be unit-tested against an in-memory fake
 * instead of a live database (Sprint requirement: appropriate testing).
 */
export interface IIdentityRepository {
  findUserByAuthId(authUserId: string): Promise<UserRecord | null>;
  findRolesForUser(appUserId: string): Promise<string[]>;
  findPermissionsForRoles(roleKeys: readonly string[]): Promise<string[]>;
  assignRole(params: {
    appUserId: string;
    roleKey: string;
    campusId: string;
    assignedBy: string;
  }): Promise<void>;
  recordAudit(entry: {
    actorId: string;
    campusId: string;
    action: string;
    targetType: string;
    targetId: string;
    metadata: Record<string, unknown>;
  }): Promise<void>;
}

/**
 * Live Supabase-backed implementation. Uses the service-role client — this
 * class is only ever constructed inside the App Backend, never exposed to
 * the frontend (Architecture Section 4 / Governance Rule 1).
 */
@Injectable()
export class SupabaseIdentityRepository implements IIdentityRepository {
  constructor(private readonly client: SupabaseClient) {}

  async findUserByAuthId(authUserId: string): Promise<UserRecord | null> {
    const { data, error } = await this.client
      .from('users')
      // A user belongs to a campus, and the campus belongs to an organization — there is no
      // organization_id column on users, so it is read through the campus relationship.
      .select('id, auth_user_id, email, status, campus_id, campuses(organization_id)')
      .eq('auth_user_id', authUserId)
      .maybeSingle();

    if (error) {
      throw new Error(`Failed to resolve user identity: ${error.message}`);
    }
    if (!data) {
      return null;
    }

    const campus = data.campuses as unknown as { organization_id: string } | null;
    if (!campus) {
      // users.campus_id is NOT NULL with a foreign key, so this cannot happen on a healthy database;
      // fail loudly rather than build an identity with no organization.
      throw new Error(`Failed to resolve user identity: campus ${data.campus_id as string} not found.`);
    }

    return {
      appUserId: data.id as string,
      authUserId: data.auth_user_id as string,
      email: (data.email as string | null) ?? null,
      status: data.status as 'active' | 'suspended',
      campusId: data.campus_id as string,
      organizationId: campus.organization_id,
    };
  }

  async findRolesForUser(appUserId: string): Promise<string[]> {
    const { data, error } = await this.client
      .from('user_roles')
      .select('roles(key)')
      .eq('user_id', appUserId);

    if (error) {
      throw new Error(`Failed to resolve user roles: ${error.message}`);
    }

    return (data ?? [])
      .map((row) => {
        const roles = row as unknown as { roles: { key: string } | null };
        return roles.roles?.key;
      })
      .filter((key): key is string => Boolean(key));
  }

  async findPermissionsForRoles(roleKeys: readonly string[]): Promise<string[]> {
    if (roleKeys.length === 0) {
      return [];
    }
    const { data, error } = await this.client
      .from('role_permissions')
      .select('permissions(key), roles!inner(key)')
      .in('roles.key', roleKeys as string[]);

    if (error) {
      throw new Error(`Failed to resolve role permissions: ${error.message}`);
    }

    const permissionKeys = (data ?? [])
      .map((row) => {
        const rp = row as unknown as { permissions: { key: string } | null };
        return rp.permissions?.key;
      })
      .filter((key): key is string => Boolean(key));

    return Array.from(new Set(permissionKeys));
  }

  async assignRole(params: {
    appUserId: string;
    roleKey: string;
    campusId: string;
    assignedBy: string;
  }): Promise<void> {
    const { data: role, error: roleError } = await this.client
      .from('roles')
      .select('id')
      .eq('key', params.roleKey)
      .maybeSingle();

    if (roleError || !role) {
      throw new Error(`Unknown role key: ${params.roleKey}`);
    }

    const { error } = await this.client.from('user_roles').insert({
      user_id: params.appUserId,
      role_id: role.id,
      campus_id: params.campusId,
      assigned_by: params.assignedBy,
    });

    if (error) {
      throw new Error(`Failed to assign role: ${error.message}`);
    }
  }

  async recordAudit(entry: {
    actorId: string;
    campusId: string;
    action: string;
    targetType: string;
    targetId: string;
    metadata: Record<string, unknown>;
  }): Promise<void> {
    const { error } = await this.client.from('audit_logs').insert({
      actor_id: entry.actorId,
      campus_id: entry.campusId,
      action: entry.action,
      target_type: entry.targetType,
      target_id: entry.targetId,
      metadata_json: entry.metadata,
    });

    if (error) {
      throw new Error(`Failed to write audit log: ${error.message}`);
    }
  }
}
