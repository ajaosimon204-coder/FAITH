import { Module } from '@nestjs/common';
import { SupabaseClient } from '@supabase/supabase-js';
import { AppEnv } from '../../config/env';
import { IdentityResolutionService } from './identity-resolution.service';
import { IIdentityRepository, SupabaseIdentityRepository } from './identity.repository';
import { JwtVerificationService } from './jwt-verification.service';
import { SupabaseAuthGuard } from './supabase-auth.guard';

export const IDENTITY_REPOSITORY = 'IDENTITY_REPOSITORY';
export const SUPABASE_CLIENT = 'SUPABASE_CLIENT';
export const APP_ENV = 'APP_ENV';

@Module({
  providers: [
    {
      provide: JwtVerificationService,
      useFactory: (env: AppEnv) =>
        new JwtVerificationService({
          legacySecret: env.supabaseJwtSecret,
          jwksUrl: env.supabaseJwksUrl,
          issuer: env.supabaseJwtIssuer,
          audience: 'authenticated',
        }),
      inject: [APP_ENV],
    },
    {
      provide: IDENTITY_REPOSITORY,
      useFactory: (client: SupabaseClient): IIdentityRepository =>
        new SupabaseIdentityRepository(client),
      inject: [SUPABASE_CLIENT],
    },
    {
      provide: IdentityResolutionService,
      useFactory: (jwt: JwtVerificationService, repo: IIdentityRepository) =>
        new IdentityResolutionService(jwt, repo),
      inject: [JwtVerificationService, IDENTITY_REPOSITORY],
    },
    SupabaseAuthGuard,
  ],
  exports: [IdentityResolutionService, SupabaseAuthGuard, IDENTITY_REPOSITORY],
})
export class IdentityModule {}
