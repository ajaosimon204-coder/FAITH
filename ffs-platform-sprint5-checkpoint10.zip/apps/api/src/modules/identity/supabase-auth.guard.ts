import {
  CanActivate,
  ExecutionContext,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { Request } from 'express';
import { IdentityResolutionService } from './identity-resolution.service';
import { ResolvedIdentity } from './identity.types';
import { IS_PUBLIC_KEY } from './public.decorator';

export interface AuthenticatedRequest extends Request {
  identity: ResolvedIdentity;
}

function extractBearerToken(request: Request): string {
  const header = request.headers['authorization'];
  if (!header || Array.isArray(header)) {
    throw new UnauthorizedException('Missing Authorization header.');
  }
  const [scheme, token] = header.split(' ');
  if (scheme !== 'Bearer' || !token) {
    throw new UnauthorizedException('Expected a Bearer token.');
  }
  return token;
}

/**
 * Applied globally (see app.module.ts). Every request — public health check
 * excluded via @Public() — must resolve to a valid ResolvedIdentity before
 * reaching a controller. This is the ONE place authentication happens;
 * no controller re-implements token verification (Governance Rule 1).
 */
@Injectable()
export class SupabaseAuthGuard implements CanActivate {
  constructor(
    private readonly identityResolution: IdentityResolutionService,
    private readonly reflector: Reflector,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const isPublic = this.reflector.getAllAndOverride<boolean>(IS_PUBLIC_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);
    if (isPublic) {
      return true;
    }

    const request = context.switchToHttp().getRequest<AuthenticatedRequest>();
    const token = extractBearerToken(request);
    const identity = await this.identityResolution.resolveFromBearerToken(token);
    request.identity = identity;
    return true;
  }
}
