import { Injectable, UnauthorizedException } from '@nestjs/common';
import { IIdentityRepository } from './identity.repository';
import { JwtVerificationService } from './jwt-verification.service';
import { ResolvedIdentity } from './identity.types';

/**
 * Builds the full, trustworthy ResolvedIdentity for a request:
 *   1. Verify the Supabase Auth token (proves WHO).
 *   2. Look up the corresponding application user (fails closed if none —
 *      an auth.users row existing does not imply platform access exists).
 *   3. Resolve roles, and permissions from roles, fresh from the database.
 *
 * Nothing here is ever read from a client-supplied header or claim beyond
 * the verified `sub` — campus/role/permission are always looked up
 * server-side (Governance Rule 6).
 */
@Injectable()
export class IdentityResolutionService {
  constructor(
    private readonly jwtVerification: JwtVerificationService,
    private readonly repository: IIdentityRepository,
  ) {}

  async resolveFromBearerToken(bearerToken: string): Promise<ResolvedIdentity> {
    const claims = await this.jwtVerification.verify(bearerToken);

    const user = await this.repository.findUserByAuthId(claims.authUserId);
    if (!user) {
      throw new UnauthorizedException(
        'No application account is linked to this identity.',
      );
    }

    if (user.status !== 'active') {
      throw new UnauthorizedException('This account is not active.');
    }

    const roles = await this.repository.findRolesForUser(user.appUserId);
    const permissions = await this.repository.findPermissionsForRoles(roles);

    return {
      authUserId: user.authUserId,
      appUserId: user.appUserId,
      email: user.email,
      status: user.status,
      campusId: user.campusId,
      organizationId: user.organizationId,
      roles,
      permissions,
    };
  }
}
