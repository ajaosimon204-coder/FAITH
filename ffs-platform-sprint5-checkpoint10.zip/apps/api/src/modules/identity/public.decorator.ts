import { SetMetadata } from '@nestjs/common';

export const IS_PUBLIC_KEY = 'is_public_route';

/**
 * Marks a route as not requiring authentication. Used ONLY for genuinely
 * public content — currently just the public CMS read endpoints
 * (published pages/news/gallery/staff-profiles). Every other route in this
 * application is authenticated by default (fail closed) via the global
 * SupabaseAuthGuard; this decorator is the single, explicit, reviewable
 * exception mechanism rather than each route independently deciding
 * whether to check auth.
 */
export const Public = () => SetMetadata(IS_PUBLIC_KEY, true);
