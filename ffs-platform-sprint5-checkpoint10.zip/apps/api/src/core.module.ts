import { Global, Module } from '@nestjs/common';
import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { loadEnv, AppEnv } from './config/env';
import { APP_ENV, SUPABASE_CLIENT } from './modules/identity/identity.module';

/**
 * @Global() so every feature module can inject APP_ENV / SUPABASE_CLIENT
 * without each one re-declaring the provider (Governance Rule 2: no
 * duplicate logic — including no duplicate provider wiring for the same
 * underlying resource).
 */
@Global()
@Module({
  providers: [
    {
      provide: APP_ENV,
      useFactory: (): AppEnv => loadEnv(),
    },
    {
      provide: SUPABASE_CLIENT,
      useFactory: (env: AppEnv): SupabaseClient =>
        createClient(env.supabaseUrl, env.supabaseServiceRoleKey, {
          auth: { persistSession: false },
        }),
      inject: [APP_ENV],
    },
  ],
  exports: [APP_ENV, SUPABASE_CLIENT],
})
export class CoreModule {}
