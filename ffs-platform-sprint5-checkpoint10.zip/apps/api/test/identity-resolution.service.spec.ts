import * as jwt from 'jsonwebtoken';
import { UnauthorizedException } from '@nestjs/common';
import { IdentityResolutionService } from '../src/modules/identity/identity-resolution.service';
import { JwtVerificationService } from '../src/modules/identity/jwt-verification.service';
import { FakeIdentityRepository } from './fakes/fake-identity.repository';

const SECRET = 'test-secret';

function signToken(sub: string): string {
  return jwt.sign({ sub }, SECRET, { algorithm: 'HS256', expiresIn: '1h' });
}

describe('IdentityResolutionService', () => {
  let repository: FakeIdentityRepository;
  let service: IdentityResolutionService;

  beforeEach(() => {
    repository = new FakeIdentityRepository();
    service = new IdentityResolutionService(
      new JwtVerificationService({ legacySecret: SECRET }),
      repository,
    );
  });

  it('resolves a full identity with roles and permissions for a known active user', async () => {
    repository.users.push({
      appUserId: 'user-1',
      authUserId: 'auth-1',
      email: 'teacher@ffs.example',
      status: 'active',
      campusId: 'campus-1',
      organizationId: 'org-1',
    });
    repository.userRoles.push({
      appUserId: 'user-1',
      roleKey: 'teacher',
      campusId: 'campus-1',
    });
    repository.rolePermissions['teacher'] = ['organizations.read'];

    const identity = await service.resolveFromBearerToken(signToken('auth-1'));

    expect(identity.appUserId).toBe('user-1');
    expect(identity.campusId).toBe('campus-1');
    expect(identity.roles).toEqual(['teacher']);
    expect(identity.permissions).toEqual(['organizations.read']);
  });

  it('fails closed when a Supabase Auth identity has no linked application user', async () => {
    // Deliberately no repository.users entry — proves auth.users existing
    // does not imply platform access (Architecture Section A).
    await expect(
      service.resolveFromBearerToken(signToken('auth-orphan')),
    ).rejects.toThrow(UnauthorizedException);
  });

  it('fails closed for a suspended user even with a valid token', async () => {
    repository.users.push({
      appUserId: 'user-2',
      authUserId: 'auth-2',
      email: null,
      status: 'suspended',
      campusId: 'campus-1',
      organizationId: 'org-1',
    });

    await expect(
      service.resolveFromBearerToken(signToken('auth-2')),
    ).rejects.toThrow(UnauthorizedException);
  });

  it('resolves an empty permission set for a user with no role assignments', async () => {
    repository.users.push({
      appUserId: 'user-3',
      authUserId: 'auth-3',
      email: null,
      status: 'active',
      campusId: 'campus-1',
      organizationId: 'org-1',
    });

    const identity = await service.resolveFromBearerToken(signToken('auth-3'));

    expect(identity.roles).toEqual([]);
    expect(identity.permissions).toEqual([]);
  });

  it('rejects a forged token that was never issued by Supabase Auth', async () => {
    const forged = jwt.sign({ sub: 'auth-1' }, 'not-the-real-secret', {
      algorithm: 'HS256',
    });

    await expect(service.resolveFromBearerToken(forged)).rejects.toThrow(
      UnauthorizedException,
    );
  });
});
