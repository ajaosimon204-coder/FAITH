import { BadRequestException, ForbiddenException } from '@nestjs/common';
import { TeacherAssignmentService } from '../src/modules/academic/teacher-assignment.service';
import { ResolvedIdentity } from '../src/modules/identity/identity.types';
import { FakeAcademicRepository } from './fakes/fake-academic.repository';

function buildIdentity(overrides: Partial<ResolvedIdentity> = {}): ResolvedIdentity {
  return {
    authUserId: 'auth-admin',
    appUserId: 'user-admin',
    email: 'admin@ffs.example',
    status: 'active',
    campusId: 'campus-1',
    organizationId: 'org-1',
    roles: ['school_administrator'],
    permissions: ['academic.teacher_assignments.manage', 'academic.teacher_assignments.read'],
    ...overrides,
  };
}

describe('TeacherAssignmentService', () => {
  let repository: FakeAcademicRepository;
  let service: TeacherAssignmentService;

  beforeEach(() => {
    repository = new FakeAcademicRepository();
    service = new TeacherAssignmentService(repository);
  });

  it('creates a subject_teacher assignment with a subject and writes an audit entry', async () => {
    const actor = buildIdentity();

    const assignment = await service.assignTeacher(actor, {
      staffId: 'staff-1',
      classId: 'class-1',
      subjectId: 'subject-1',
      academicSessionId: 'session-1',
      role: 'subject_teacher',
    });

    expect(assignment.role).toBe('subject_teacher');
    expect(repository.auditEntries).toHaveLength(1);
  });

  it('creates a class_teacher assignment with no subject', async () => {
    const actor = buildIdentity();

    const assignment = await service.assignTeacher(actor, {
      staffId: 'staff-1',
      classId: 'class-1',
      subjectId: null,
      academicSessionId: 'session-1',
      role: 'class_teacher',
    });

    expect(assignment.subjectId).toBeNull();
  });

  it('rejects a class_teacher assignment that specifies a subject', async () => {
    const actor = buildIdentity();

    await expect(
      service.assignTeacher(actor, {
        staffId: 'staff-1',
        classId: 'class-1',
        subjectId: 'subject-1',
        academicSessionId: 'session-1',
        role: 'class_teacher',
      }),
    ).rejects.toThrow(BadRequestException);
  });

  it('rejects a subject_teacher assignment with no subject specified', async () => {
    const actor = buildIdentity();

    await expect(
      service.assignTeacher(actor, {
        staffId: 'staff-1',
        classId: 'class-1',
        subjectId: null,
        academicSessionId: 'session-1',
        role: 'subject_teacher',
      }),
    ).rejects.toThrow(BadRequestException);
  });

  it('denies assignment creation for an actor without academic.teacher_assignments.manage', async () => {
    const actor = buildIdentity({ permissions: ['academic.teacher_assignments.read'] });

    await expect(
      service.assignTeacher(actor, {
        staffId: 'staff-1',
        classId: 'class-1',
        subjectId: null,
        academicSessionId: 'session-1',
        role: 'class_teacher',
      }),
    ).rejects.toThrow(ForbiddenException);
  });

  it('prevents a second class_teacher assignment for the same class/session (repository-level guard)', async () => {
    const actor = buildIdentity();
    await service.assignTeacher(actor, {
      staffId: 'staff-1',
      classId: 'class-1',
      subjectId: null,
      academicSessionId: 'session-1',
      role: 'class_teacher',
    });

    await expect(
      service.assignTeacher(actor, {
        staffId: 'staff-2',
        classId: 'class-1',
        subjectId: null,
        academicSessionId: 'session-1',
        role: 'class_teacher',
      }),
    ).rejects.toThrow();
  });

  it('a teacher can view their own assignments without any admin permission', async () => {
    const actor = buildIdentity();
    await service.assignTeacher(actor, {
      staffId: 'staff-1',
      classId: 'class-1',
      subjectId: null,
      academicSessionId: 'session-1',
      role: 'class_teacher',
    });

    repository.staffIdForUserMap['user-teacher-1'] = 'staff-1';
    const teacher = buildIdentity({
      appUserId: 'user-teacher-1',
      roles: ['teacher'],
      permissions: [],
    });

    const assignments = await service.getAssignmentsForStaff(teacher, 'staff-1');
    expect(assignments).toHaveLength(1);
  });

  it('denies a teacher viewing a different teacher\'s assignments without admin permission', async () => {
    const actor = buildIdentity();
    await service.assignTeacher(actor, {
      staffId: 'staff-1',
      classId: 'class-1',
      subjectId: null,
      academicSessionId: 'session-1',
      role: 'class_teacher',
    });

    repository.staffIdForUserMap['user-teacher-2'] = 'staff-2'; // different staff record
    const otherTeacher = buildIdentity({
      appUserId: 'user-teacher-2',
      roles: ['teacher'],
      permissions: [],
    });

    await expect(service.getAssignmentsForStaff(otherTeacher, 'staff-1')).rejects.toThrow(
      ForbiddenException,
    );
  });

  it('isTeacherAssignedToClass correctly reflects relationship state (used by future modules)', async () => {
    const actor = buildIdentity();
    await service.assignTeacher(actor, {
      staffId: 'staff-1',
      classId: 'class-1',
      subjectId: null,
      academicSessionId: 'session-1',
      role: 'class_teacher',
    });
    repository.staffIdForUserMap['user-teacher-1'] = 'staff-1';
    const teacher = buildIdentity({ appUserId: 'user-teacher-1', permissions: [] });

    expect(await service.isTeacherAssignedToClass(teacher, 'class-1')).toBe(true);
    expect(await service.isTeacherAssignedToClass(teacher, 'class-999')).toBe(false);
  });

  it('removes an assignment and writes an audit entry', async () => {
    const actor = buildIdentity();
    const assignment = await service.assignTeacher(actor, {
      staffId: 'staff-1',
      classId: 'class-1',
      subjectId: null,
      academicSessionId: 'session-1',
      role: 'class_teacher',
    });

    await service.removeAssignment(actor, assignment.id);

    expect(repository.teacherAssignments).toHaveLength(0);
    expect(repository.auditEntries.map((a) => a.action)).toContain('teacher_assignment.removed');
  });
});
