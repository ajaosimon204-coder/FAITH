import { IAcademicRepository } from '../../src/modules/academic/academic.repository';
import {
  AcademicSession,
  Enrollment,
  SchoolClass,
  TeacherAssignment,
  Term,
} from '../../src/modules/academic/academic.types';

let counter = 0;
function nextId(prefix: string): string {
  counter += 1;
  return `${prefix}-${counter}`;
}

export class FakeAcademicRepository implements IAcademicRepository {
  public sessions: AcademicSession[] = [];
  public terms: Term[] = [];
  public classes: SchoolClass[] = [];
  public subjects: { id: string; campusId: string; name: string; code: string }[] = [];
  public classSubjectLinks: Array<{ classId: string; subjectId: string }> = [];
  public enrollments: Enrollment[] = [];
  public teacherAssignments: TeacherAssignment[] = [];
  public studentUsersIdMap: Record<string, string | null> = {};
  public studentCampusIdMap: Record<string, string | null> = {};
  public staffIdForUserMap: Record<string, string | null> = {};
  public auditEntries: Array<{
    actorId: string;
    campusId: string;
    action: string;
    targetType: string;
    targetId: string;
    metadata: Record<string, unknown>;
  }> = [];

  async createSession(input: {
    campusId: string;
    name: string;
    startDate: string;
    endDate: string;
  }): Promise<AcademicSession> {
    const session: AcademicSession = {
      id: nextId('session'),
      campusId: input.campusId,
      name: input.name,
      startDate: input.startDate,
      endDate: input.endDate,
      isCurrent: false,
    };
    this.sessions.push(session);
    return session;
  }

  async setCurrentSession(campusId: string, sessionId: string): Promise<AcademicSession> {
    this.sessions = this.sessions.map((s) =>
      s.campusId === campusId ? { ...s, isCurrent: s.id === sessionId } : s,
    );
    const found = this.sessions.find((s) => s.id === sessionId);
    if (!found) throw new Error(`Session ${sessionId} not found`);
    return found;
  }

  async createTerm(input: {
    academicSessionId: string;
    campusId: string;
    name: string;
    startDate: string;
    endDate: string;
  }): Promise<Term> {
    const term: Term = {
      id: nextId('term'),
      academicSessionId: input.academicSessionId,
      campusId: input.campusId,
      name: input.name,
      startDate: input.startDate,
      endDate: input.endDate,
      isCurrent: false,
    };
    this.terms.push(term);
    return term;
  }

  async setCurrentTerm(academicSessionId: string, termId: string): Promise<Term> {
    this.terms = this.terms.map((t) =>
      t.academicSessionId === academicSessionId ? { ...t, isCurrent: t.id === termId } : t,
    );
    const found = this.terms.find((t) => t.id === termId);
    if (!found) throw new Error(`Term ${termId} not found`);
    return found;
  }

  async findActiveEnrollment(
    studentId: string,
    academicSessionId: string,
  ): Promise<Enrollment | null> {
    return (
      this.enrollments.find(
        (e) =>
          e.studentId === studentId &&
          e.academicSessionId === academicSessionId &&
          e.status === 'active',
      ) ?? null
    );
  }

  async findCurrentEnrollment(studentId: string): Promise<Enrollment | null> {
    const currentSession = this.sessions.find((s) => s.isCurrent);
    if (!currentSession) return null;
    return this.findActiveEnrollment(studentId, currentSession.id);
  }

  async closeEnrollment(
    enrollmentId: string,
    status: 'completed' | 'withdrawn' | 'transferred',
    reason: string | null,
  ): Promise<Enrollment> {
    const idx = this.enrollments.findIndex((e) => e.id === enrollmentId);
    if (idx === -1) throw new Error(`Enrollment ${enrollmentId} not found`);
    const updated: Enrollment = {
      ...this.enrollments[idx],
      status,
      exitedAt: new Date().toISOString(),
      exitReason: reason,
    };
    this.enrollments[idx] = updated;
    return updated;
  }

  async createEnrollment(input: {
    studentId: string;
    classId: string;
    academicSessionId: string;
    termId: string | null;
    campusId: string;
  }): Promise<Enrollment> {
    const enrollment: Enrollment = {
      id: nextId('enrollment'),
      studentId: input.studentId,
      classId: input.classId,
      academicSessionId: input.academicSessionId,
      termId: input.termId,
      campusId: input.campusId,
      status: 'active',
      enrolledAt: new Date().toISOString(),
      exitedAt: null,
      exitReason: null,
    };
    this.enrollments.push(enrollment);
    return enrollment;
  }

  async transferEnrollment(input: {
    studentId: string;
    fromEnrollmentId: string;
    newClassId: string;
    reason: string | null;
  }): Promise<Enrollment> {
    const from = this.enrollments.find((e) => e.id === input.fromEnrollmentId);
    if (!from || from.status !== 'active') {
      throw new Error(`No active enrollment ${input.fromEnrollmentId} found to transfer`);
    }
    await this.closeEnrollment(input.fromEnrollmentId, 'transferred', input.reason);
    return this.createEnrollment({
      studentId: input.studentId,
      classId: input.newClassId,
      academicSessionId: from.academicSessionId,
      termId: from.termId,
      campusId: from.campusId,
    });
  }

  async listEnrollmentHistory(studentId: string): Promise<Enrollment[]> {
    return this.enrollments
      .filter((e) => e.studentId === studentId)
      .sort((a, b) => (a.enrolledAt < b.enrolledAt ? 1 : -1));
  }

  async findClassById(classId: string): Promise<SchoolClass | null> {
    return this.classes.find((c) => c.id === classId) ?? null;
  }

  async getStudentUsersId(studentId: string): Promise<string | null> {
    return this.studentUsersIdMap[studentId] ?? null;
  }

  async getStudentCampusId(studentId: string): Promise<string | null> {
    return this.studentCampusIdMap[studentId] ?? null;
  }

  async getStaffIdForUser(actorAppUserId: string): Promise<string | null> {
    return this.staffIdForUserMap[actorAppUserId] ?? null;
  }

  async isAssignedToClass(staffId: string, classId: string): Promise<boolean> {
    return this.teacherAssignments.some((a) => a.staffId === staffId && a.classId === classId);
  }

  async createTeacherAssignment(input: {
    staffId: string;
    classId: string;
    subjectId: string | null;
    academicSessionId: string;
    campusId: string;
    role: 'subject_teacher' | 'class_teacher';
    assignedBy: string;
  }): Promise<TeacherAssignment> {
    const existingClassTeacher = this.teacherAssignments.find(
      (a) =>
        a.classId === input.classId &&
        a.academicSessionId === input.academicSessionId &&
        a.role === 'class_teacher',
    );
    if (input.role === 'class_teacher' && existingClassTeacher) {
      throw new Error(`Class ${input.classId} already has a class_teacher for this session`);
    }

    const assignment: TeacherAssignment = {
      id: nextId('assignment'),
      staffId: input.staffId,
      classId: input.classId,
      subjectId: input.subjectId,
      academicSessionId: input.academicSessionId,
      campusId: input.campusId,
      role: input.role,
      assignedBy: input.assignedBy,
      assignedAt: new Date().toISOString(),
    };
    this.teacherAssignments.push(assignment);
    return assignment;
  }

  async removeTeacherAssignment(assignmentId: string): Promise<void> {
    this.teacherAssignments = this.teacherAssignments.filter((a) => a.id !== assignmentId);
  }

  async listAssignmentsForStaff(staffId: string): Promise<TeacherAssignment[]> {
    return this.teacherAssignments.filter((a) => a.staffId === staffId);
  }

  async recordAudit(entry: {
    actorId: string;
    campusId: string;
    action: string;
    targetType: string;
    targetId: string;
    metadata: Record<string, unknown>;
  }): Promise<void> {
    this.auditEntries.push(entry);
  }

  async createClassDefinition(input: {
    campusId: string;
    name: string;
    level: string;
  }): Promise<{ id: string; campusId: string; name: string; level: string }> {
    return { id: nextId('classdef'), ...input };
  }

  async createClass(input: {
    classDefinitionId: string;
    academicSessionId: string;
    campusId: string;
    name: string;
    section: string | null;
  }): Promise<SchoolClass> {
    const schoolClass: SchoolClass = {
      id: nextId('class'),
      classDefinitionId: input.classDefinitionId,
      academicSessionId: input.academicSessionId,
      campusId: input.campusId,
      name: input.name,
      section: input.section,
    };
    this.classes.push(schoolClass);
    return schoolClass;
  }

  async createSubject(input: {
    campusId: string;
    name: string;
    code: string;
  }): Promise<{ id: string; campusId: string; name: string; code: string }> {
    const subject = { id: nextId('subject'), ...input };
    this.subjects.push(subject);
    return subject;
  }

  async linkSubjectToClass(classId: string, subjectId: string): Promise<void> {
    // Models the real database's primary-key constraint on
    // class_subjects(class_id, subject_id) — a duplicate link is rejected,
    // not silently accepted.
    const alreadyLinked = this.classSubjectLinks.some(
      (l) => l.classId === classId && l.subjectId === subjectId,
    );
    if (alreadyLinked) {
      throw new Error(
        `duplicate key value violates unique constraint "class_subjects_pkey" (class_id=${classId}, subject_id=${subjectId})`,
      );
    }
    this.classSubjectLinks.push({ classId, subjectId });
  }

  async getSubjectById(subjectId: string): Promise<{ id: string; campusId: string; name: string; code: string } | null> {
    return this.subjects.find((s) => s.id === subjectId) ?? null;
  }
}
