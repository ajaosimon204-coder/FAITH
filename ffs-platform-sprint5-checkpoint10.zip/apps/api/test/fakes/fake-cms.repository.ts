import { ICmsContentRepository } from '../../src/modules/cms/cms-workflow.service';
import { CmsContentStatus, CmsPage } from '../../src/modules/cms/cms.types';

let counter = 0;
function nextId(): string {
  counter += 1;
  return `page-${counter}`;
}

export class FakeCmsPagesRepository implements ICmsContentRepository<CmsPage> {
  public pages: CmsPage[] = [];
  public auditEntries: Array<{
    actorId: string;
    campusId: string;
    action: string;
    targetType: string;
    targetId: string;
    metadata: Record<string, unknown>;
  }> = [];

  create(input: {
    campusId: string;
    slug: string;
    title: string;
    contentJson: unknown;
    createdBy: string;
  }): CmsPage {
    const page: CmsPage = {
      id: nextId(),
      campusId: input.campusId,
      slug: input.slug,
      title: input.title,
      contentJson: input.contentJson,
      status: 'draft',
      createdBy: input.createdBy,
      reviewedBy: null,
      approvedBy: null,
      publishedBy: null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.pages.push(page);
    return page;
  }

  async findById(id: string): Promise<CmsPage | null> {
    return this.pages.find((p) => p.id === id) ?? null;
  }

  async transitionStatus(params: {
    id: string;
    toStatus: CmsContentStatus;
    actorField: 'reviewed_by' | 'approved_by' | 'published_by' | null;
    actorId: string;
    campusId: string;
    action: string;
    metadata: Record<string, unknown>;
    extraFields?: Record<string, unknown>;
  }): Promise<CmsPage> {
    const idx = this.pages.findIndex((p) => p.id === params.id);
    if (idx === -1) throw new Error(`Page ${params.id} not found`);

    const fieldMap: Record<string, keyof CmsPage> = {
      reviewed_by: 'reviewedBy',
      approved_by: 'approvedBy',
      published_by: 'publishedBy',
    };

    // Models the atomic write+audit behavior of app_cms_transition
    // (migration 0019) — both happen together in this fake, same as the
    // real RPC function, so tests exercise the real atomicity contract.
    const updated: CmsPage = {
      ...this.pages[idx],
      status: params.toStatus,
      ...(params.actorField ? { [fieldMap[params.actorField]]: params.actorId } : {}),
    };
    this.pages[idx] = updated;

    this.auditEntries.push({
      actorId: params.actorId,
      campusId: params.campusId,
      action: params.action,
      targetType: 'cms_pages',
      targetId: params.id,
      metadata: params.metadata,
    });

    return updated;
  }

  async listByStatus(campusId: string, status?: CmsContentStatus): Promise<CmsPage[]> {
    return this.pages.filter(
      (p) => p.campusId === campusId && (status === undefined || p.status === status),
    );
  }

  async recordAudit(entry: {
    actorId: string;
    campusId: string;
    action: string;
    targetType: string;
    targetId: string;
    metadata: Record<string, unknown>;
  }): Promise<void> {
    this.auditEntries.push(entry);
  }

  findPublishedBySlug(campusId: string, slug: string): CmsPage | null {
    return (
      this.pages.find((p) => p.campusId === campusId && p.slug === slug && p.status === 'published') ??
      null
    );
  }
}
