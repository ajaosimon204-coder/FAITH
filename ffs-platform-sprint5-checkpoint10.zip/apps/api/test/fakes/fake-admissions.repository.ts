import {
  AdmissionsRuleViolationError,
  IAdmissionsRepository,
} from '../../src/modules/admissions/admissions.repository';
import {
  Application,
  ApplicationDocument,
  ApplicationStatus,
  ClassDefinitionRef,
  ConversionResult,
  ConvertApplicationInput,
  DuplicateLookupInput,
  NewApplicationInput,
  PlacementClass,
  TransitionApplicationInput,
} from '../../src/modules/admissions/admissions.types';

/**
 * In-memory stand-in for the admissions database. It reproduces the rules the
 * real database enforces (migrations 0021 and 0024) — the same status-transition
 * table, the same rejection messages, per-campus sequential admission numbers,
 * case-insensitive guardian reuse — so service tests run against realistic
 * behavior. Those rules are verified against real PostgreSQL by the pgTAP suite
 * `rls_admissions_tests.sql`; test/fake-admissions.repository.spec.ts pins this
 * fake to the same scenarios so the two cannot drift apart unnoticed.
 */
const ALLOWED_TRANSITIONS: ReadonlyArray<readonly [ApplicationStatus, ApplicationStatus]> = [
  ['submitted', 'under_review'],
  ['under_review', 'info_requested'],
  ['info_requested', 'under_review'],
  ['under_review', 'approved'],
  ['under_review', 'rejected'],
  ['approved', 'converted'],
];

export interface FakeStudent {
  id: string;
  campusId: string;
  displayName: string;
  lifecycleStatus: 'admitted';
  admissionNo: string;
  dateOfBirth: string;
  gender: string | null;
}

export interface FakeGuardian {
  id: string;
  campusId: string;
  firstName: string;
  lastName: string;
  phone: string | null;
  email: string | null;
}

export interface FakeEnrollment {
  studentId: string;
  classId: string;
  campusId: string;
  status: 'active';
}

export interface FakeAuditEntry {
  actorId: string;
  campusId: string;
  action: string;
  targetType: string;
  targetId: string;
  metadata: Record<string, unknown>;
}

export class FakeAdmissionsRepository implements IAdmissionsRepository {
  public applications: Application[] = [];
  public documents: ApplicationDocument[] = [];
  public classes: PlacementClass[] = [];
  public classDefinitions: ClassDefinitionRef[] = [];
  public students: FakeStudent[] = [];
  public guardians: FakeGuardian[] = [];
  public guardianLinks: Array<{ guardianId: string; studentId: string; relationship: string }> = [];
  public enrollments: FakeEnrollment[] = [];
  public auditEntries: FakeAuditEntry[] = [];

  private sequence = 0;
  private clock = Date.parse('2026-01-01T09:00:00.000Z');

  /**
   * The real database generates UUIDs (gen_random_uuid()), and the services validate ids as
   * UUIDs, so the fake must too. Deterministic: the entity kind picks the first segment, a
   * counter fills the last, which keeps ids unique and readable in failure output.
   */
  private nextId(kind: 'app' | 'doc' | 'guardian' | 'student'): string {
    const segment = { app: 'a0000000', doc: 'd0000000', guardian: 'e0000000', student: 'f0000000' }[kind];
    this.sequence += 1;
    return `${segment}-0000-4000-8000-${String(this.sequence).padStart(12, '0')}`;
  }

  /** Strictly increasing timestamps keep "most recent first" ordering deterministic. */
  private nextTimestamp(): string {
    this.clock += 1000;
    return new Date(this.clock).toISOString();
  }

  async createApplication(input: NewApplicationInput): Promise<Application> {
    // Mirrors trg_validate_application_class_definition_campus (migration 0027).
    const definition = this.classDefinitions.find((d) => d.id === input.classDefinitionId);
    if (!definition) {
      throw new AdmissionsRuleViolationError(
        `application: class_definition ${input.classDefinitionId} does not exist`,
      );
    }
    if (definition.campusId !== input.campusId) {
      throw new AdmissionsRuleViolationError(
        `application: class_definition ${input.classDefinitionId} (campus ${definition.campusId}) ` +
          `does not belong to the application's campus ${input.campusId}`,
      );
    }
    const application: Application = {
      id: this.nextId('app'),
      campusId: input.campusId,
      referenceNo: `APP-${new Date(this.clock).getUTCFullYear()}-${String(
        this.applications.length + 1,
      ).padStart(6, '0')}`,
      applicantFirstName: input.applicantFirstName,
      applicantLastName: input.applicantLastName,
      applicantDateOfBirth: input.applicantDateOfBirth,
      applicantGender: input.applicantGender,
      classDefinitionId: input.classDefinitionId,
      guardianFirstName: input.guardianFirstName,
      guardianLastName: input.guardianLastName,
      guardianEmail: input.guardianEmail,
      guardianPhone: input.guardianPhone,
      status: 'submitted',
      submittedAt: this.nextTimestamp(),
      reviewedBy: null,
      reviewNotes: null,
      decisionReason: null,
      possibleDuplicateOf: input.possibleDuplicateOf,
      convertedStudentId: null,
    };
    this.applications.push(application);
    return application;
  }

  async addDocument(input: {
    applicationId: string;
    docType: string;
    fileUrl: string;
  }): Promise<ApplicationDocument> {
    if (!this.applications.some((a) => a.id === input.applicationId)) {
      throw new Error(`Failed to add application document: unknown application ${input.applicationId}`);
    }
    const document: ApplicationDocument = {
      id: this.nextId('doc'),
      applicationId: input.applicationId,
      docType: input.docType,
      fileUrl: input.fileUrl,
      uploadedAt: this.nextTimestamp(),
    };
    this.documents.push(document);
    return document;
  }

  async findApplicationById(id: string): Promise<Application | null> {
    return this.applications.find((a) => a.id === id) ?? null;
  }

  async listApplications(campusId: string, status?: ApplicationStatus): Promise<Application[]> {
    return this.applications
      .filter((a) => a.campusId === campusId && (status === undefined || a.status === status))
      .sort((a, b) => b.submittedAt.localeCompare(a.submittedAt));
  }

  async listDocuments(applicationId: string): Promise<ApplicationDocument[]> {
    return this.documents
      .filter((d) => d.applicationId === applicationId)
      .sort((a, b) => a.uploadedAt.localeCompare(b.uploadedAt));
  }

  async findPossibleDuplicate(input: DuplicateLookupInput): Promise<Application | null> {
    const first = input.applicantFirstName.trim().toLowerCase();
    const last = input.applicantLastName.trim().toLowerCase();
    const matches = this.applications
      .filter(
        (a) =>
          a.campusId === input.campusId &&
          a.applicantDateOfBirth === input.applicantDateOfBirth &&
          a.applicantFirstName.toLowerCase() === first &&
          a.applicantLastName.toLowerCase() === last,
      )
      .sort((a, b) => b.submittedAt.localeCompare(a.submittedAt));
    return matches[0] ?? null;
  }

  async transitionApplication(input: TransitionApplicationInput): Promise<Application> {
    const current = this.applications.find((a) => a.id === input.id);
    if (!current || current.campusId !== input.campusId) {
      throw new AdmissionsRuleViolationError(`application ${input.id} not found`);
    }
    const legal =
      current.status === input.toStatus ||
      ALLOWED_TRANSITIONS.some(([from, to]) => from === current.status && to === input.toStatus);
    if (!legal) {
      throw new AdmissionsRuleViolationError(
        `Invalid application status transition: ${current.status} -> ${input.toStatus}`,
      );
    }
    const updated: Application = {
      ...current,
      status: input.toStatus,
      reviewedBy: input.actorId,
      reviewNotes: input.reviewNotes ?? current.reviewNotes,
      decisionReason: input.decisionReason ?? current.decisionReason,
    };
    this.replace(updated);
    this.auditEntries.push({
      actorId: input.actorId,
      campusId: input.campusId,
      action: input.action,
      targetType: 'application',
      targetId: input.id,
      metadata: { from: current.status, to: input.toStatus },
    });
    return updated;
  }

  async convertApplication(input: ConvertApplicationInput): Promise<ConversionResult> {
    const app = this.applications.find((a) => a.id === input.applicationId);
    if (!app || app.campusId !== input.campusId) {
      throw new AdmissionsRuleViolationError(`application ${input.applicationId} not found`);
    }
    if (app.status !== 'approved') {
      throw new AdmissionsRuleViolationError(
        `application ${input.applicationId} must be approved before conversion (current status: ${app.status})`,
      );
    }
    const cls = this.classes.find((c) => c.id === input.classId);
    if (!cls || cls.campusId !== input.campusId) {
      throw new AdmissionsRuleViolationError(`class ${input.classId} does not belong to this campus`);
    }
    if (cls.classDefinitionId !== app.classDefinitionId) {
      throw new AdmissionsRuleViolationError(
        `class ${input.classId} is not a class of the level applied for ` +
          `(application ${input.applicationId} applied for class_definition ${app.classDefinitionId})`,
      );
    }

    const numbered = this.students.filter((s) => s.campusId === input.campusId).length;
    const admissionNo = `FFS-${new Date(this.clock).getUTCFullYear()}-${String(numbered + 1).padStart(5, '0')}`;

    let guardian = app.guardianEmail
      ? this.guardians.find(
          (g) =>
            g.campusId === input.campusId &&
            g.email !== null &&
            g.email.toLowerCase() === app.guardianEmail?.toLowerCase(),
        )
      : undefined;
    if (!guardian) {
      guardian = {
        id: this.nextId('guardian'),
        campusId: input.campusId,
        firstName: app.guardianFirstName,
        lastName: app.guardianLastName,
        phone: app.guardianPhone,
        email: app.guardianEmail,
      };
      this.guardians.push(guardian);
    }

    const student: FakeStudent = {
      id: this.nextId('student'),
      campusId: input.campusId,
      displayName: `${app.applicantFirstName} ${app.applicantLastName}`,
      lifecycleStatus: 'admitted',
      admissionNo,
      dateOfBirth: app.applicantDateOfBirth,
      gender: app.applicantGender,
    };
    this.students.push(student);
    this.guardianLinks.push({ guardianId: guardian.id, studentId: student.id, relationship: 'guardian' });
    this.enrollments.push({
      studentId: student.id,
      classId: input.classId,
      campusId: input.campusId,
      status: 'active',
    });
    this.replace({
      ...app,
      status: 'converted',
      convertedStudentId: student.id,
      reviewedBy: input.actorId,
    });
    this.auditEntries.push({
      actorId: input.actorId,
      campusId: input.campusId,
      action: 'application.converted',
      targetType: 'application',
      targetId: input.applicationId,
      metadata: { student_id: student.id, guardian_id: guardian.id, admission_no: admissionNo },
    });
    return { studentId: student.id, guardianId: guardian.id, admissionNo };
  }

  async findClassDefinition(id: string): Promise<ClassDefinitionRef | null> {
    return this.classDefinitions.find((d) => d.id === id) ?? null;
  }

  async findPlacementClass(classId: string): Promise<PlacementClass | null> {
    return this.classes.find((c) => c.id === classId) ?? null;
  }

  private replace(updated: Application): void {
    this.applications = this.applications.map((a) => (a.id === updated.id ? updated : a));
  }
}
