import { IConfigRepository } from '../../src/modules/config/config.repository';
import {
  ConfigCategory,
  ConfigDefinition,
  ConfigValue,
  SchoolConfigValue,
} from '../../src/modules/config/config.types';

export class FakeConfigRepository implements IConfigRepository {
  public definitions: ConfigDefinition[] = [];
  public values: SchoolConfigValue[] = [];
  public auditWrites: Array<{
    configDefinitionId: string;
    campusId: string;
    oldValue: ConfigValue;
    newValue: ConfigValue;
    actorId: string;
  }> = [];

  async findDefinitionByKey(key: string): Promise<ConfigDefinition | null> {
    return this.definitions.find((d) => d.key === key) ?? null;
  }

  async listDefinitionsByCategory(category: ConfigCategory): Promise<ConfigDefinition[]> {
    return this.definitions.filter((d) => d.category === category);
  }

  async findValue(
    configDefinitionId: string,
    campusId: string,
  ): Promise<SchoolConfigValue | null> {
    return (
      this.values.find(
        (v) => v.configDefinitionId === configDefinitionId && v.campusId === campusId,
      ) ?? null
    );
  }

  async listValuesByCategory(
    category: ConfigCategory,
    campusId: string,
  ): Promise<SchoolConfigValue[]> {
    return this.values.filter((v) => v.category === category && v.campusId === campusId);
  }

  async upsertValueWithAudit(params: {
    configDefinitionId: string;
    campusId: string;
    newValue: ConfigValue;
    actorId: string;
  }): Promise<SchoolConfigValue> {
    const definition = this.definitions.find((d) => d.id === params.configDefinitionId);
    if (!definition) {
      throw new Error(`Unknown config_definition_id: ${params.configDefinitionId}`);
    }

    const existing = this.values.find(
      (v) =>
        v.configDefinitionId === params.configDefinitionId && v.campusId === params.campusId,
    );

    this.auditWrites.push({
      configDefinitionId: params.configDefinitionId,
      campusId: params.campusId,
      oldValue: existing?.value ?? null,
      newValue: params.newValue,
      actorId: params.actorId,
    });

    const updated: SchoolConfigValue = {
      id: existing?.id ?? `sc-${this.values.length + 1}`,
      configDefinitionId: params.configDefinitionId,
      campusId: params.campusId,
      key: definition.key,
      category: definition.category,
      value: params.newValue,
      updatedBy: params.actorId,
      updatedAt: new Date().toISOString(),
    };

    this.values = this.values.filter(
      (v) =>
        !(v.configDefinitionId === params.configDefinitionId && v.campusId === params.campusId),
    );
    this.values.push(updated);

    return updated;
  }
}
