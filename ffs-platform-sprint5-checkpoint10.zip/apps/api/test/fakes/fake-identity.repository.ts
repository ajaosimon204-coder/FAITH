import { IIdentityRepository, UserRecord } from '../../src/modules/identity/identity.repository';

interface FakeUserRoleAssignment {
  appUserId: string;
  roleKey: string;
  campusId: string;
}

interface RecordedAuditEntry {
  actorId: string;
  campusId: string;
  action: string;
  targetType: string;
  targetId: string;
  metadata: Record<string, unknown>;
}

/**
 * A fully in-memory fake for the identity repository, so identity/RBAC
 * business logic can be unit-tested without a live Postgres instance.
 */
export class FakeIdentityRepository implements IIdentityRepository {
  public users: UserRecord[] = [];
  public rolePermissions: Record<string, string[]> = {};
  public userRoles: FakeUserRoleAssignment[] = [];
  public auditEntries: RecordedAuditEntry[] = [];
  public knownRoleKeys: Set<string> = new Set();

  async findUserByAuthId(authUserId: string): Promise<UserRecord | null> {
    return this.users.find((u) => u.authUserId === authUserId) ?? null;
  }

  async findRolesForUser(appUserId: string): Promise<string[]> {
    return this.userRoles
      .filter((r) => r.appUserId === appUserId)
      .map((r) => r.roleKey);
  }

  async findPermissionsForRoles(roleKeys: readonly string[]): Promise<string[]> {
    const permissions = new Set<string>();
    for (const roleKey of roleKeys) {
      for (const permission of this.rolePermissions[roleKey] ?? []) {
        permissions.add(permission);
      }
    }
    return Array.from(permissions);
  }

  async assignRole(params: {
    appUserId: string;
    roleKey: string;
    campusId: string;
    assignedBy: string;
  }): Promise<void> {
    if (!this.knownRoleKeys.has(params.roleKey)) {
      throw new Error(`Unknown role key: ${params.roleKey}`);
    }
    this.userRoles.push({
      appUserId: params.appUserId,
      roleKey: params.roleKey,
      campusId: params.campusId,
    });
  }

  async recordAudit(entry: RecordedAuditEntry): Promise<void> {
    this.auditEntries.push(entry);
  }
}
