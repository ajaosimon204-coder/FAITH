import { SupabaseClient } from '@supabase/supabase-js';
import {
  AdmissionsRuleViolationError,
  escapeIlike,
  SupabaseAdmissionsRepository,
  toApplication,
  toApplicationDocument,
  toConversionResult,
} from '../src/modules/admissions/admissions.repository';

type Result = { data: unknown; error: { message: string; code?: string } | null };
interface Call {
  method: string;
  args: unknown[];
}

/**
 * Minimal recording stand-in for the Supabase client: every chained call is
 * recorded, and the final awaited value (or .single()/.maybeSingle()) resolves
 * to the configured result. Enough to assert exactly what the repository sends.
 */
function makeClient(result: Result) {
  const calls: Call[] = [];
  const builder: Record<string, unknown> = {};
  const record =
    (method: string) =>
    (...args: unknown[]) => {
      calls.push({ method, args });
      return builder;
    };
  for (const m of ['select', 'insert', 'eq', 'ilike', 'order', 'limit']) builder[m] = record(m);
  builder.single = (...args: unknown[]) => {
    calls.push({ method: 'single', args });
    return Promise.resolve(result);
  };
  builder.maybeSingle = (...args: unknown[]) => {
    calls.push({ method: 'maybeSingle', args });
    return Promise.resolve(result);
  };
  builder.then = (resolve: (r: Result) => unknown) => Promise.resolve(result).then(resolve);

  const client = {
    from: (table: string) => {
      calls.push({ method: 'from', args: [table] });
      return builder;
    },
    rpc: (fn: string, params: unknown) => {
      calls.push({ method: 'rpc', args: [fn, params] });
      return Promise.resolve(result);
    },
  };
  return { client: client as unknown as SupabaseClient, calls };
}

const applicationRow = {
  id: 'app-1',
  campus_id: 'campus-1',
  reference_no: 'APP-2026-000001',
  applicant_first_name: 'Ada',
  applicant_last_name: 'Obi',
  applicant_date_of_birth: '2014-05-05',
  applicant_gender: 'female',
  class_definition_id: 'def-1',
  guardian_first_name: 'Ngozi',
  guardian_last_name: 'Obi',
  guardian_email: 'parent@example.test',
  guardian_phone: '08000000001',
  status: 'submitted',
  submitted_at: '2026-01-01T09:00:00Z',
  reviewed_by: null,
  review_notes: null,
  decision_reason: null,
  possible_duplicate_of: null,
  converted_student_id: null,
};

describe('row mappers', () => {
  it('maps every application column to its camelCase field', () => {
    expect(toApplication(applicationRow)).toEqual({
      id: 'app-1',
      campusId: 'campus-1',
      referenceNo: 'APP-2026-000001',
      applicantFirstName: 'Ada',
      applicantLastName: 'Obi',
      applicantDateOfBirth: '2014-05-05',
      applicantGender: 'female',
      classDefinitionId: 'def-1',
      guardianFirstName: 'Ngozi',
      guardianLastName: 'Obi',
      guardianEmail: 'parent@example.test',
      guardianPhone: '08000000001',
      status: 'submitted',
      submittedAt: '2026-01-01T09:00:00Z',
      reviewedBy: null,
      reviewNotes: null,
      decisionReason: null,
      possibleDuplicateOf: null,
      convertedStudentId: null,
    });
  });

  it('normalises missing optional columns to null, never undefined', () => {
    const mapped = toApplication({
      ...applicationRow,
      applicant_gender: undefined,
      guardian_email: undefined,
      guardian_phone: undefined,
      reviewed_by: undefined,
    });
    expect(mapped.applicantGender).toBeNull();
    expect(mapped.guardianEmail).toBeNull();
    expect(mapped.guardianPhone).toBeNull();
    expect(mapped.reviewedBy).toBeNull();
  });

  it('maps a document row', () => {
    expect(
      toApplicationDocument({
        id: 'doc-1',
        application_id: 'app-1',
        doc_type: 'birth_certificate',
        file_url: 'https://example.invalid/x',
        uploaded_at: '2026-01-01T09:00:00Z',
      }),
    ).toEqual({
      id: 'doc-1',
      applicationId: 'app-1',
      docType: 'birth_certificate',
      fileUrl: 'https://example.invalid/x',
      uploadedAt: '2026-01-01T09:00:00Z',
    });
  });
});

describe('toConversionResult', () => {
  it('accepts the function’s jsonb object', () => {
    expect(toConversionResult({ studentId: 's', guardianId: 'g', admissionNo: 'FFS-2026-00001' })).toEqual({
      studentId: 's',
      guardianId: 'g',
      admissionNo: 'FFS-2026-00001',
    });
  });

  it('accepts the same object wrapped in a one-element array', () => {
    expect(toConversionResult([{ studentId: 's', guardianId: 'g', admissionNo: 'n' }]).studentId).toBe('s');
  });

  it.each([null, undefined, {}, { studentId: 's' }, { studentId: 's', guardianId: 'g', admissionNo: 5 }])(
    'rejects a malformed result (%p) instead of returning half a conversion',
    (bad) => {
      expect(() => toConversionResult(bad)).toThrow('unexpected result shape');
    },
  );
});

describe('escapeIlike', () => {
  it('escapes the ILIKE wildcards and the escape character', () => {
    expect(escapeIlike('Mary_Ann')).toBe('Mary\\_Ann');
    expect(escapeIlike('100%')).toBe('100\\%');
    expect(escapeIlike('a\\b')).toBe('a\\\\b');
  });

  it('leaves ordinary names untouched', () => {
    expect(escapeIlike("O'Brien-Smith")).toBe("O'Brien-Smith");
  });
});

describe('SupabaseAdmissionsRepository — contract with the SQL functions', () => {
  // These argument names are asserted against the live function definitions by the pgTAP
  // suite (rls_admissions_tests.sql, "RPC contract"). Change one side and the other fails.
  it('calls app_application_transition with exactly the function’s parameter names', async () => {
    const { client, calls } = makeClient({ data: applicationRow, error: null });
    await new SupabaseAdmissionsRepository(client).transitionApplication({
      id: 'app-1',
      campusId: 'campus-1',
      toStatus: 'under_review',
      actorId: 'user-1',
      action: 'application.under_review',
      reviewNotes: 'ok',
      decisionReason: null,
    });
    expect(calls).toEqual([
      {
        method: 'rpc',
        args: [
          'app_application_transition',
          {
            p_id: 'app-1',
            p_campus_id: 'campus-1',
            p_to_status: 'under_review',
            p_actor_id: 'user-1',
            p_action: 'application.under_review',
            p_review_notes: 'ok',
            p_decision_reason: null,
          },
        ],
      },
    ]);
  });

  it('calls app_convert_application with exactly the function’s parameter names', async () => {
    const { client, calls } = makeClient({
      data: { studentId: 's', guardianId: 'g', admissionNo: 'n' },
      error: null,
    });
    await new SupabaseAdmissionsRepository(client).convertApplication({
      applicationId: 'app-1',
      campusId: 'campus-1',
      classId: 'class-1',
      actorId: 'user-1',
    });
    expect(calls).toEqual([
      {
        method: 'rpc',
        args: [
          'app_convert_application',
          {
            p_application_id: 'app-1',
            p_campus_id: 'campus-1',
            p_class_id: 'class-1',
            p_actor_id: 'user-1',
          },
        ],
      },
    ]);
  });

  it('returns the mapped application whether PostgREST sends the composite as an object or an array', async () => {
    const asObject = makeClient({ data: applicationRow, error: null });
    const asArray = makeClient({ data: [applicationRow], error: null });
    const input = {
      id: 'app-1',
      campusId: 'campus-1',
      toStatus: 'under_review' as const,
      actorId: 'u',
      action: 'a',
      reviewNotes: null,
      decisionReason: null,
    };
    expect((await new SupabaseAdmissionsRepository(asObject.client).transitionApplication(input)).id).toBe('app-1');
    expect((await new SupabaseAdmissionsRepository(asArray.client).transitionApplication(input)).id).toBe('app-1');
  });
});

describe('SupabaseAdmissionsRepository — error classification', () => {
  const transitionInput = {
    id: 'app-1',
    campusId: 'campus-1',
    toStatus: 'approved' as const,
    actorId: 'u',
    action: 'a',
    reviewNotes: null,
    decisionReason: null,
  };

  it('turns a database business-rule rejection (P0001) into AdmissionsRuleViolationError', async () => {
    const { client } = makeClient({
      data: null,
      error: { message: 'Invalid application status transition: submitted -> approved', code: 'P0001' },
    });
    const promise = new SupabaseAdmissionsRepository(client).transitionApplication(transitionInput);
    await expect(promise).rejects.toBeInstanceOf(AdmissionsRuleViolationError);
    await expect(promise).rejects.toThrow('Invalid application status transition: submitted -> approved');
  });

  it('keeps any other database failure a plain Error with context (a server fault, not a rule violation)', async () => {
    const { client } = makeClient({ data: null, error: { message: 'connection reset', code: '08006' } });
    const promise = new SupabaseAdmissionsRepository(client).transitionApplication(transitionInput);
    await expect(promise).rejects.toThrow('Failed to transition application: connection reset');
    await expect(promise).rejects.not.toBeInstanceOf(AdmissionsRuleViolationError);
  });

  it('classifies conversion rejections the same way', async () => {
    const { client } = makeClient({
      data: null,
      error: { message: 'application app-1 must be approved before conversion (current status: submitted)', code: 'P0001' },
    });
    await expect(
      new SupabaseAdmissionsRepository(client).convertApplication({
        applicationId: 'app-1',
        campusId: 'campus-1',
        classId: 'class-1',
        actorId: 'u',
      }),
    ).rejects.toBeInstanceOf(AdmissionsRuleViolationError);
  });
});

describe('SupabaseAdmissionsRepository — queries', () => {
  it('inserts an application with the snake_case columns and returns the mapped row', async () => {
    const { client, calls } = makeClient({ data: applicationRow, error: null });
    const created = await new SupabaseAdmissionsRepository(client).createApplication({
      campusId: 'campus-1',
      applicantFirstName: 'Ada',
      applicantLastName: 'Obi',
      applicantDateOfBirth: '2014-05-05',
      applicantGender: 'female',
      classDefinitionId: 'def-1',
      guardianFirstName: 'Ngozi',
      guardianLastName: 'Obi',
      guardianEmail: 'parent@example.test',
      guardianPhone: '08000000001',
      possibleDuplicateOf: null,
    });
    expect(created.referenceNo).toBe('APP-2026-000001');
    expect(calls[0]).toEqual({ method: 'from', args: ['applications'] });
    expect(calls[1]).toEqual({
      method: 'insert',
      args: [
        {
          campus_id: 'campus-1',
          applicant_first_name: 'Ada',
          applicant_last_name: 'Obi',
          applicant_date_of_birth: '2014-05-05',
          applicant_gender: 'female',
          class_definition_id: 'def-1',
          guardian_first_name: 'Ngozi',
          guardian_last_name: 'Obi',
          guardian_email: 'parent@example.test',
          guardian_phone: '08000000001',
          possible_duplicate_of: null,
        },
      ],
    });
  });

  it('never sets status or reference_no on insert — the database owns both', async () => {
    const { client, calls } = makeClient({ data: applicationRow, error: null });
    await new SupabaseAdmissionsRepository(client).createApplication({
      campusId: 'c',
      applicantFirstName: 'A',
      applicantLastName: 'B',
      applicantDateOfBirth: '2014-01-01',
      applicantGender: null,
      classDefinitionId: 'd',
      guardianFirstName: 'G',
      guardianLastName: 'H',
      guardianEmail: null,
      guardianPhone: null,
      possibleDuplicateOf: null,
    });
    const payload = calls.find((c) => c.method === 'insert')?.args[0] as Record<string, unknown>;
    expect(payload).not.toHaveProperty('status');
    expect(payload).not.toHaveProperty('reference_no');
  });

  it('lists a campus’s applications newest first, filtered by status only when asked', async () => {
    const all = makeClient({ data: [applicationRow], error: null });
    await new SupabaseAdmissionsRepository(all.client).listApplications('campus-1');
    expect(all.calls.map((c) => c.method)).toEqual(['from', 'select', 'eq', 'order']);
    expect(all.calls[3].args).toEqual(['submitted_at', { ascending: false }]);

    const filtered = makeClient({ data: [applicationRow], error: null });
    await new SupabaseAdmissionsRepository(filtered.client).listApplications('campus-1', 'approved');
    expect(filtered.calls.filter((c) => c.method === 'eq').map((c) => c.args)).toEqual([
      ['campus_id', 'campus-1'],
      ['status', 'approved'],
    ]);
  });

  it('looks up a possible duplicate by campus, date of birth and escaped, trimmed names', async () => {
    const { client, calls } = makeClient({ data: [applicationRow], error: null });
    const found = await new SupabaseAdmissionsRepository(client).findPossibleDuplicate({
      campusId: 'campus-1',
      applicantFirstName: '  Mary_Ann ',
      applicantLastName: 'O%Brien',
      applicantDateOfBirth: '2014-05-05',
    });
    expect(found?.id).toBe('app-1');
    expect(calls.filter((c) => c.method === 'eq').map((c) => c.args)).toEqual([
      ['campus_id', 'campus-1'],
      ['applicant_date_of_birth', '2014-05-05'],
    ]);
    expect(calls.filter((c) => c.method === 'ilike').map((c) => c.args)).toEqual([
      ['applicant_first_name', 'Mary\\_Ann'],
      ['applicant_last_name', 'O\\%Brien'],
    ]);
  });

  it('returns null when no duplicate exists', async () => {
    const { client } = makeClient({ data: [], error: null });
    expect(
      await new SupabaseAdmissionsRepository(client).findPossibleDuplicate({
        campusId: 'c',
        applicantFirstName: 'X',
        applicantLastName: 'Y',
        applicantDateOfBirth: '2014-01-01',
      }),
    ).toBeNull();
  });

  it('returns null for an unknown application and an unknown class', async () => {
    const none = makeClient({ data: null, error: null });
    expect(await new SupabaseAdmissionsRepository(none.client).findApplicationById('x')).toBeNull();
    expect(await new SupabaseAdmissionsRepository(none.client).findPlacementClass('x')).toBeNull();
  });

  it('maps a placement class', async () => {
    const { client } = makeClient({
      data: { id: 'class-1', campus_id: 'campus-1', class_definition_id: 'def-1' },
      error: null,
    });
    expect(await new SupabaseAdmissionsRepository(client).findPlacementClass('class-1')).toEqual({
      id: 'class-1',
      campusId: 'campus-1',
      classDefinitionId: 'def-1',
    });
  });

  it('maps a class definition, and returns null when it does not exist', async () => {
    const found = makeClient({ data: { id: 'def-1', campus_id: 'campus-1' }, error: null });
    expect(await new SupabaseAdmissionsRepository(found.client).findClassDefinition('def-1')).toEqual({
      id: 'def-1',
      campusId: 'campus-1',
    });
    expect(found.calls[0]).toEqual({ method: 'from', args: ['class_definitions'] });
    const none = makeClient({ data: null, error: null });
    expect(await new SupabaseAdmissionsRepository(none.client).findClassDefinition('x')).toBeNull();
  });

  it('throws a contextual Error when a read fails', async () => {
    const { client } = makeClient({ data: null, error: { message: 'boom' } });
    await expect(new SupabaseAdmissionsRepository(client).findApplicationById('x')).rejects.toThrow(
      'Failed to load application: boom',
    );
  });
});
