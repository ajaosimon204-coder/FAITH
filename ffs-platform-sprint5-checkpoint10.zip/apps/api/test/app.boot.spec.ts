import { INestApplication } from '@nestjs/common';
import { NestExpressApplication } from '@nestjs/platform-express';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { AppModule } from '../src/app.module';
import { configureApp } from '../src/app.setup';

/**
 * Boots the REAL AppModule — every module, provider and the global auth guard, wired
 * exactly as in production — through the SAME configureApp() that main.ts uses. Only the
 * environment is faked (a Supabase client is created lazily and never contacts a server
 * here). This is the test that catches what unit tests cannot: a missing dependency, a
 * provider that cannot be resolved, a startup crash.
 *
 * (It exists because the API once shipped unable to start: main.ts used ValidationPipe
 * without class-validator installed, and nothing ever booted the application to notice.)
 */
describe('application boot', () => {
  let app: INestApplication;
  const saved = { ...process.env };

  beforeAll(async () => {
    process.env.SUPABASE_URL = 'http://127.0.0.1:1'; // nothing listens here; never queried
    process.env.SUPABASE_SERVICE_ROLE_KEY = 'service-role-key-for-boot-test';
    process.env.SUPABASE_JWT_SECRET = 'jwt-secret-for-boot-test';

    const moduleRef = await Test.createTestingModule({ imports: [AppModule] }).compile();
    const nestApp = moduleRef.createNestApplication<NestExpressApplication>();
    configureApp(nestApp, process.env);
    await nestApp.init();
    app = nestApp;
  });

  afterAll(async () => {
    await app.close();
    process.env = saved;
  });

  it('starts, and fails closed: an authenticated route without a token is a 401', async () => {
    await request(app.getHttpServer()).get('/api/v1/admissions/applications').expect(401);
    await request(app.getHttpServer()).get('/api/v1/cms/pages').expect(401);
  });

  it('serves the public admissions route without credentials (validation runs before any database access)', async () => {
    const res = await request(app.getHttpServer()).post('/api/v1/public/admissions/applications').send({}).expect(400);
    expect(res.body.message).toEqual(expect.arrayContaining(['Applicant first name is required.']));
  });

  it('answers the hosting platform liveness check without credentials, and reveals nothing', async () => {
    const res = await request(app.getHttpServer()).get('/health').expect(200);
    expect(res.body).toEqual({ status: 'ok' });
  });

  it('does not expose any admissions read route publicly', async () => {
    await request(app.getHttpServer()).get('/api/v1/public/admissions/applications').expect(404);
  });
});
