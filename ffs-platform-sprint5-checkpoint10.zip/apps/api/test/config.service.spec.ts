import { BadRequestException, ForbiddenException, NotFoundException } from '@nestjs/common';
import { ConfigService } from '../src/modules/config/config.service';
import { ResolvedIdentity } from '../src/modules/identity/identity.types';
import { ConfigDefinition } from '../src/modules/config/config.types';
import { FakeConfigRepository } from './fakes/fake-config.repository';

function buildIdentity(overrides: Partial<ResolvedIdentity> = {}): ResolvedIdentity {
  return {
    authUserId: 'auth-1',
    appUserId: 'user-1',
    email: 'accountant@ffs.example',
    status: 'active',
    campusId: 'campus-1',
    organizationId: 'org-1',
    roles: ['accountant'],
    permissions: ['config.finance.read', 'config.finance.write'],
    ...overrides,
  };
}

const CURRENCY_DEFINITION: ConfigDefinition = {
  id: 'def-currency',
  category: 'finance',
  key: 'finance.default_currency',
  dataType: 'string',
  jsonSchema: { type: 'string', enum: ['NGN'] },
  readPermissionKey: 'config.finance.read',
  writePermissionKey: 'config.finance.write',
  description: 'ISO currency code.',
};

const CLASS_SIZE_DEFINITION: ConfigDefinition = {
  id: 'def-class-size',
  category: 'academic',
  key: 'academic.max_class_size',
  dataType: 'integer',
  jsonSchema: { type: 'integer', minimum: 1, maximum: 200 },
  readPermissionKey: 'config.academic.read',
  writePermissionKey: 'config.academic.write',
  description: 'Soft class-size cap.',
};

describe('ConfigService', () => {
  let repository: FakeConfigRepository;
  let service: ConfigService;

  beforeEach(() => {
    repository = new FakeConfigRepository();
    repository.definitions = [CURRENCY_DEFINITION, CLASS_SIZE_DEFINITION];
    service = new ConfigService(repository);
  });

  describe('setValue', () => {
    it('accepts a schema-valid value from an authorized actor and writes an audit entry', async () => {
      const actor = buildIdentity();

      const result = await service.setValue(actor, 'finance.default_currency', 'NGN');

      expect(result.value).toBe('NGN');
      expect(repository.auditWrites).toHaveLength(1);
      expect(repository.auditWrites[0]).toMatchObject({
        configDefinitionId: 'def-currency',
        campusId: 'campus-1',
        oldValue: null,
        newValue: 'NGN',
        actorId: 'user-1',
      });
    });

    it('rejects a value that violates the schema enum constraint', async () => {
      const actor = buildIdentity();

      await expect(
        service.setValue(actor, 'finance.default_currency', 'USD'),
      ).rejects.toThrow(BadRequestException);

      // No partial write on validation failure — repository never touched.
      expect(repository.values).toHaveLength(0);
      expect(repository.auditWrites).toHaveLength(0);
    });

    it('rejects a value that violates a numeric range constraint', async () => {
      const actor = buildIdentity({
        permissions: ['config.academic.read', 'config.academic.write'],
      });

      await expect(
        service.setValue(actor, 'academic.max_class_size', 500),
      ).rejects.toThrow(BadRequestException);
    });

    it('rejects a wrong-type value even if it would satisfy other constraints', async () => {
      const actor = buildIdentity({
        permissions: ['config.academic.read', 'config.academic.write'],
      });

      await expect(
        service.setValue(actor, 'academic.max_class_size', '40'), // string, not integer
      ).rejects.toThrow(BadRequestException);
    });

    it('denies a write from an actor lacking the write permission, even with read', async () => {
      const actor = buildIdentity({ permissions: ['config.finance.read'] });

      await expect(
        service.setValue(actor, 'finance.default_currency', 'NGN'),
      ).rejects.toThrow(ForbiddenException);

      expect(repository.values).toHaveLength(0);
    });

    it('denies a write for a permission the actor holds in the wrong category', async () => {
      // Holds academic write, tries to write a finance key — proves
      // permission checks are per-definition, not "any config permission".
      const actor = buildIdentity({
        permissions: ['config.academic.read', 'config.academic.write'],
      });

      await expect(
        service.setValue(actor, 'finance.default_currency', 'NGN'),
      ).rejects.toThrow(ForbiddenException);
    });

    it('rejects a write for a key that has no registered ConfigDefinition', async () => {
      const actor = buildIdentity({ roles: ['super_admin'], permissions: [] });

      await expect(
        service.setValue(actor, 'finance.nonexistent_key', 'anything'),
      ).rejects.toThrow(NotFoundException);
    });

    it('captures the correct old value on a second write (update, not just insert)', async () => {
      const actor = buildIdentity();

      await service.setValue(actor, 'finance.default_currency', 'NGN');
      await service.setValue(actor, 'finance.default_currency', 'NGN'); // same value, still audited

      expect(repository.auditWrites).toHaveLength(2);
      expect(repository.auditWrites[1].oldValue).toBe('NGN');
      expect(repository.auditWrites[1].newValue).toBe('NGN');
    });
  });

  describe('getValue', () => {
    it('returns null when no value has been set yet for an authorized reader', async () => {
      const actor = buildIdentity();
      const value = await service.getValue(actor, 'finance.default_currency');
      expect(value).toBeNull();
    });

    it('denies read access to an actor without the read permission', async () => {
      const actor = buildIdentity({ permissions: [] });
      await expect(service.getValue(actor, 'finance.default_currency')).rejects.toThrow(
        ForbiddenException,
      );
    });
  });

  describe('listCategory', () => {
    it('returns only values the actor is permitted to read within that category', async () => {
      const actor = buildIdentity();
      await service.setValue(actor, 'finance.default_currency', 'NGN');

      const results = await service.listCategory(actor, 'finance');

      expect(results).toHaveLength(1);
      expect(results[0].key).toBe('finance.default_currency');
    });

    it('denies listing a category the actor has no read permission for at all', async () => {
      const actor = buildIdentity({ permissions: [] });
      await expect(service.listCategory(actor, 'finance')).rejects.toThrow(ForbiddenException);
    });
  });
});
