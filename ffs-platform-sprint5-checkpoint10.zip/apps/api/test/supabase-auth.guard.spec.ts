import { ExecutionContext, UnauthorizedException } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import * as jwt from 'jsonwebtoken';
import { SupabaseAuthGuard } from '../src/modules/identity/supabase-auth.guard';
import { IdentityResolutionService } from '../src/modules/identity/identity-resolution.service';
import { JwtVerificationService } from '../src/modules/identity/jwt-verification.service';
import { FakeIdentityRepository } from './fakes/fake-identity.repository';
import { IS_PUBLIC_KEY } from '../src/modules/identity/public.decorator';

const SECRET = 'test-secret';

function buildContext(params: {
  headers?: Record<string, string>;
  isPublic?: boolean;
}): ExecutionContext {
  const request = { headers: params.headers ?? {}, identity: undefined as unknown };

  return {
    switchToHttp: () => ({ getRequest: () => request }),
    getHandler: () => ({}),
    getClass: () => ({}),
  } as unknown as ExecutionContext;
}

function makeReflector(isPublic: boolean | undefined): Reflector {
  return {
    getAllAndOverride: (key: string) => (key === IS_PUBLIC_KEY ? isPublic : undefined),
  } as unknown as Reflector;
}

describe('SupabaseAuthGuard', () => {
  let repository: FakeIdentityRepository;
  let identityResolution: IdentityResolutionService;

  beforeEach(() => {
    repository = new FakeIdentityRepository();
    identityResolution = new IdentityResolutionService(
      new JwtVerificationService({ legacySecret: SECRET }),
      repository,
    );
  });

  it('allows a request through WITHOUT any token when the route is marked @Public()', async () => {
    const guard = new SupabaseAuthGuard(identityResolution, makeReflector(true));
    const context = buildContext({ headers: {}, isPublic: true });

    await expect(guard.canActivate(context)).resolves.toBe(true);
  });

  it('rejects a non-public request with no Authorization header at all', async () => {
    const guard = new SupabaseAuthGuard(identityResolution, makeReflector(false));
    const context = buildContext({ headers: {}, isPublic: false });

    await expect(guard.canActivate(context)).rejects.toThrow(UnauthorizedException);
  });

  it('rejects a non-public request with a malformed Authorization header (no Bearer scheme)', async () => {
    const guard = new SupabaseAuthGuard(identityResolution, makeReflector(false));
    const context = buildContext({
      headers: { authorization: 'NotBearer sometoken' },
      isPublic: false,
    });

    await expect(guard.canActivate(context)).rejects.toThrow(UnauthorizedException);
  });

  it('resolves and attaches identity for a non-public request with a valid token', async () => {
    repository.users.push({
      appUserId: 'user-1',
      authUserId: 'auth-1',
      email: 'a@b.com',
      status: 'active',
      campusId: 'campus-1',
      organizationId: 'org-1',
    });
    const token = jwt.sign({ sub: 'auth-1' }, SECRET, { algorithm: 'HS256', expiresIn: '1h' });
    const guard = new SupabaseAuthGuard(identityResolution, makeReflector(false));
    const context = buildContext({
      headers: { authorization: `Bearer ${token}` },
      isPublic: false,
    });

    await expect(guard.canActivate(context)).resolves.toBe(true);
  });

  it('a @Public() route does NOT require a valid token even if one is malformed or absent — the check short-circuits entirely', async () => {
    // This is the specific property that makes @Public() safe to use only
    // for routes whose underlying query is independently scoped (e.g. the
    // published-CMS-content repository method) — the guard performs ZERO
    // token inspection when isPublic is true, by design.
    const guard = new SupabaseAuthGuard(identityResolution, makeReflector(true));
    const context = buildContext({
      headers: { authorization: 'Bearer totally-garbage-not-a-jwt' },
      isPublic: true,
    });

    await expect(guard.canActivate(context)).resolves.toBe(true);
  });
});
