import { AdmissionsRuleViolationError } from '../src/modules/admissions/admissions.repository';
import { NewApplicationInput } from '../src/modules/admissions/admissions.types';
import { FakeAdmissionsRepository } from './fakes/fake-admissions.repository';

/**
 * Pins the fake to the behavior of the real database. Each scenario here mirrors
 * one the pgTAP suite (supabase/tests/rls_admissions_tests.sql) verified against
 * PostgreSQL — if the SQL rules change, that suite and this one are updated together.
 */
const CAMPUS_A = 'campus-a';
const CAMPUS_B = 'campus-b';
const ACTOR = 'user-admin';

function newApp(overrides: Partial<NewApplicationInput> = {}): NewApplicationInput {
  return {
    campusId: CAMPUS_A,
    applicantFirstName: 'Ada',
    applicantLastName: 'Obi',
    applicantDateOfBirth: '2014-05-05',
    applicantGender: 'female',
    classDefinitionId: 'def-jss1',
    guardianFirstName: 'Ngozi',
    guardianLastName: 'Obi',
    guardianEmail: 'Parent@Example.test',
    guardianPhone: '08000000001',
    possibleDuplicateOf: null,
    ...overrides,
  };
}

async function approve(repo: FakeAdmissionsRepository, id: string, campusId = CAMPUS_A) {
  for (const toStatus of ['under_review', 'approved'] as const) {
    await repo.transitionApplication({
      id,
      campusId,
      toStatus,
      actorId: ACTOR,
      action: `application.${toStatus}`,
      reviewNotes: null,
      decisionReason: null,
    });
  }
}

describe('FakeAdmissionsRepository', () => {
  let repo: FakeAdmissionsRepository;

  beforeEach(() => {
    repo = new FakeAdmissionsRepository();
    repo.classDefinitions.push(
      { id: 'def-jss1', campusId: CAMPUS_A },
      { id: 'def-ss1', campusId: CAMPUS_A },
      { id: 'def-jss1-b', campusId: CAMPUS_B },
    );
    repo.classes.push(
      { id: 'class-jss1a', campusId: CAMPUS_A, classDefinitionId: 'def-jss1' },
      { id: 'class-ss1a', campusId: CAMPUS_A, classDefinitionId: 'def-ss1' },
      { id: 'class-b', campusId: CAMPUS_B, classDefinitionId: 'def-jss1-b' },
    );
  });

  describe('creating and reading applications', () => {
    it('starts every application in submitted status with a generated reference number', async () => {
      const app = await repo.createApplication(newApp());
      expect(app.status).toBe('submitted');
      expect(app.referenceNo).toMatch(/^APP-\d{4}-\d{6}$/);
    });

    it('refuses a level that belongs to a different campus, or does not exist (mirrors migration 0027)', async () => {
      await expect(repo.createApplication(newApp({ classDefinitionId: 'def-jss1-b' }))).rejects.toThrow(
        'does not belong to the application\'s campus',
      );
      await expect(repo.createApplication(newApp({ classDefinitionId: 'nope' }))).rejects.toBeInstanceOf(
        AdmissionsRuleViolationError,
      );
      expect(repo.applications).toHaveLength(0);
    });

    it('lists a campus’s applications newest first and filters by status', async () => {
      const first = await repo.createApplication(newApp({ applicantFirstName: 'One' }));
      const second = await repo.createApplication(newApp({ applicantFirstName: 'Two' }));
      await repo.createApplication(newApp({ campusId: CAMPUS_B, classDefinitionId: 'def-jss1-b' }));
      await repo.transitionApplication({
        id: first.id,
        campusId: CAMPUS_A,
        toStatus: 'under_review',
        actorId: ACTOR,
        action: 'a',
        reviewNotes: null,
        decisionReason: null,
      });

      expect((await repo.listApplications(CAMPUS_A)).map((a) => a.id)).toEqual([second.id, first.id]);
      expect((await repo.listApplications(CAMPUS_A, 'under_review')).map((a) => a.id)).toEqual([first.id]);
      expect(await repo.listApplications(CAMPUS_B)).toHaveLength(1);
    });

    it('lists documents oldest first and rejects a document for an unknown application', async () => {
      const app = await repo.createApplication(newApp());
      const d1 = await repo.addDocument({ applicationId: app.id, docType: 'birth_certificate', fileUrl: 'u1' });
      const d2 = await repo.addDocument({ applicationId: app.id, docType: 'report_card', fileUrl: 'u2' });
      expect((await repo.listDocuments(app.id)).map((d) => d.id)).toEqual([d1.id, d2.id]);
      await expect(
        repo.addDocument({ applicationId: 'nope', docType: 'x', fileUrl: 'u' }),
      ).rejects.toThrow('unknown application');
    });

    it('finds the most recent duplicate case-insensitively, within the campus only', async () => {
      await repo.createApplication(newApp());
      const latest = await repo.createApplication(newApp());
      await repo.createApplication(newApp({ campusId: CAMPUS_B, classDefinitionId: 'def-jss1-b' }));

      const found = await repo.findPossibleDuplicate({
        campusId: CAMPUS_A,
        applicantFirstName: ' ADA ',
        applicantLastName: 'obi',
        applicantDateOfBirth: '2014-05-05',
      });
      expect(found?.id).toBe(latest.id);
      expect(
        await repo.findPossibleDuplicate({
          campusId: CAMPUS_A,
          applicantFirstName: 'Ada',
          applicantLastName: 'Obi',
          applicantDateOfBirth: '2014-05-06',
        }),
      ).toBeNull();
    });
  });

  describe('transitionApplication (mirrors app_application_transition)', () => {
    it('applies a legal transition, records the reviewer and writes a matching audit entry', async () => {
      const app = await repo.createApplication(newApp());
      const updated = await repo.transitionApplication({
        id: app.id,
        campusId: CAMPUS_A,
        toStatus: 'under_review',
        actorId: ACTOR,
        action: 'application.under_review',
        reviewNotes: 'looks complete',
        decisionReason: null,
      });
      expect(updated.status).toBe('under_review');
      expect(updated.reviewedBy).toBe(ACTOR);
      expect(updated.reviewNotes).toBe('looks complete');
      expect(repo.auditEntries).toEqual([
        {
          actorId: ACTOR,
          campusId: CAMPUS_A,
          action: 'application.under_review',
          targetType: 'application',
          targetId: app.id,
          metadata: { from: 'submitted', to: 'under_review' },
        },
      ]);
    });

    it('rejects an illegal transition and leaves neither a status change nor an audit entry', async () => {
      const app = await repo.createApplication(newApp());
      await expect(
        repo.transitionApplication({
          id: app.id,
          campusId: CAMPUS_A,
          toStatus: 'approved',
          actorId: ACTOR,
          action: 'application.approved',
          reviewNotes: null,
          decisionReason: null,
        }),
      ).rejects.toThrow('Invalid application status transition: submitted -> approved');
      expect((await repo.findApplicationById(app.id))?.status).toBe('submitted');
      expect(repo.auditEntries).toHaveLength(0);
    });

    it('treats a campus mismatch exactly like a missing application', async () => {
      const app = await repo.createApplication(newApp());
      const attempt = repo.transitionApplication({
        id: app.id,
        campusId: CAMPUS_B,
        toStatus: 'under_review',
        actorId: ACTOR,
        action: 'a',
        reviewNotes: null,
        decisionReason: null,
      });
      await expect(attempt).rejects.toBeInstanceOf(AdmissionsRuleViolationError);
      await expect(attempt).rejects.toThrow(`application ${app.id} not found`);
    });

    it('stores a decision reason and keeps earlier notes when the new ones are null', async () => {
      const app = await repo.createApplication(newApp());
      await repo.transitionApplication({
        id: app.id, campusId: CAMPUS_A, toStatus: 'under_review', actorId: ACTOR,
        action: 'a', reviewNotes: 'first pass', decisionReason: null,
      });
      const rejected = await repo.transitionApplication({
        id: app.id, campusId: CAMPUS_A, toStatus: 'rejected', actorId: ACTOR,
        action: 'b', reviewNotes: null, decisionReason: 'Incomplete documents',
      });
      expect(rejected.decisionReason).toBe('Incomplete documents');
      expect(rejected.reviewNotes).toBe('first pass');
    });

    it('allows the info_requested loop (under_review <-> info_requested)', async () => {
      const app = await repo.createApplication(newApp());
      for (const toStatus of ['under_review', 'info_requested', 'under_review'] as const) {
        const next = await repo.transitionApplication({
          id: app.id, campusId: CAMPUS_A, toStatus, actorId: ACTOR,
          action: 'a', reviewNotes: null, decisionReason: null,
        });
        expect(next.status).toBe(toStatus);
      }
    });
  });

  describe('convertApplication (mirrors app_convert_application)', () => {
    async function approvedApp(overrides: Partial<NewApplicationInput> = {}) {
      const app = await repo.createApplication(newApp(overrides));
      await approve(repo, app.id, overrides.campusId ?? CAMPUS_A);
      return app;
    }
    const convert = (applicationId: string, classId = 'class-jss1a', campusId = CAMPUS_A) =>
      repo.convertApplication({ applicationId, campusId, classId, actorId: ACTOR });

    it('creates the student, guardian, link and active enrollment and marks the application converted', async () => {
      const app = await approvedApp();
      const result = await convert(app.id);

      expect(result.admissionNo).toMatch(/^FFS-\d{4}-00001$/);
      expect(repo.students[0]).toMatchObject({
        id: result.studentId,
        displayName: 'Ada Obi',
        lifecycleStatus: 'admitted',
        dateOfBirth: '2014-05-05',
      });
      expect(repo.guardianLinks).toEqual([
        { guardianId: result.guardianId, studentId: result.studentId, relationship: 'guardian' },
      ]);
      expect(repo.enrollments).toEqual([
        { studentId: result.studentId, classId: 'class-jss1a', campusId: CAMPUS_A, status: 'active' },
      ]);
      const converted = await repo.findApplicationById(app.id);
      expect(converted?.status).toBe('converted');
      expect(converted?.convertedStudentId).toBe(result.studentId);
      expect(repo.auditEntries.at(-1)).toMatchObject({
        action: 'application.converted',
        metadata: { student_id: result.studentId, admission_no: result.admissionNo },
      });
    });

    it('reuses one guardian across siblings (email match is case-insensitive) and numbers sequentially', async () => {
      const first = await approvedApp({ guardianEmail: 'Parent@Example.test' });
      const second = await approvedApp({ applicantFirstName: 'Bola', guardianEmail: 'parent@example.test' });
      const r1 = await convert(first.id);
      const r2 = await convert(second.id);

      expect(r2.guardianId).toBe(r1.guardianId);
      expect(repo.guardians).toHaveLength(1);
      expect(repo.guardianLinks.filter((l) => l.guardianId === r1.guardianId)).toHaveLength(2);
      expect(r1.admissionNo.endsWith('-00001')).toBe(true);
      expect(r2.admissionNo.endsWith('-00002')).toBe(true);
    });

    it('creates a new guardian when the application has no guardian email', async () => {
      const a = await approvedApp({ guardianEmail: null });
      const b = await approvedApp({ applicantFirstName: 'Bola', guardianEmail: null });
      const r1 = await convert(a.id);
      const r2 = await convert(b.id);
      expect(r2.guardianId).not.toBe(r1.guardianId);
    });

    it('rejects an application that is not approved', async () => {
      const app = await repo.createApplication(newApp());
      await expect(convert(app.id)).rejects.toThrow('must be approved before conversion');
    });

    it('rejects converting the same application twice', async () => {
      const app = await approvedApp();
      await convert(app.id);
      await expect(convert(app.id)).rejects.toThrow('must be approved before conversion (current status: converted)');
    });

    it('rejects a campus mismatch on the application, a class from another campus, and a class of the wrong level', async () => {
      const app = await approvedApp();
      await expect(convert(app.id, 'class-jss1a', CAMPUS_B)).rejects.toThrow(`application ${app.id} not found`);
      await expect(convert(app.id, 'class-b')).rejects.toThrow('does not belong to this campus');
      await expect(convert(app.id, 'class-ss1a')).rejects.toThrow('not a class of the level applied for');
      await expect(convert(app.id, 'no-such-class')).rejects.toThrow('does not belong to this campus');
    });

    it('is atomic: a rejected conversion creates no student, guardian, enrollment or audit entry', async () => {
      const app = await approvedApp({ guardianEmail: 'eze@example.test' });
      const auditBefore = repo.auditEntries.length;
      await expect(convert(app.id, 'class-ss1a')).rejects.toBeInstanceOf(AdmissionsRuleViolationError);
      expect(repo.students).toHaveLength(0);
      expect(repo.guardians).toHaveLength(0);
      expect(repo.enrollments).toHaveLength(0);
      expect(repo.auditEntries).toHaveLength(auditBefore);
      expect((await repo.findApplicationById(app.id))?.status).toBe('approved');
    });
  });
});
