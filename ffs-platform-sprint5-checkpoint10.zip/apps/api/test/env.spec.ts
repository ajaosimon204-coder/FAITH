import { loadEnv } from '../src/config/env';

describe('loadEnv', () => {
  const saved = { ...process.env };
  const KEYS = ['SUPABASE_URL', 'SUPABASE_SERVICE_ROLE_KEY', 'SUPABASE_JWT_SECRET', 'SUPABASE_JWKS_URL', 'SUPABASE_JWT_ISSUER'];

  beforeEach(() => {
    for (const k of KEYS) delete process.env[k];
    process.env.SUPABASE_URL = 'https://abcdefgh.supabase.co';
    process.env.SUPABASE_SERVICE_ROLE_KEY = 'sb_secret_example';
  });
  afterAll(() => {
    process.env = saved;
  });

  it('needs only the URL and the service key: a current project has no JWT secret to configure', () => {
    const env = loadEnv();
    expect(env.supabaseJwtSecret).toBeUndefined();
    expect(env.supabaseJwksUrl).toBe('https://abcdefgh.supabase.co/auth/v1/.well-known/jwks.json');
    expect(env.supabaseJwtIssuer).toBe('https://abcdefgh.supabase.co/auth/v1');
  });

  it('tolerates a trailing slash on the project URL', () => {
    process.env.SUPABASE_URL = 'https://abcdefgh.supabase.co/';
    expect(loadEnv().supabaseUrl).toBe('https://abcdefgh.supabase.co');
    expect(loadEnv().supabaseJwtIssuer).toBe('https://abcdefgh.supabase.co/auth/v1');
  });

  it('reads the legacy JWT secret when present, treating blank as absent', () => {
    process.env.SUPABASE_JWT_SECRET = 'legacy-secret';
    expect(loadEnv().supabaseJwtSecret).toBe('legacy-secret');
    process.env.SUPABASE_JWT_SECRET = '   ';
    expect(loadEnv().supabaseJwtSecret).toBeUndefined();
  });

  it('lets the JWKS endpoint and issuer be overridden (custom auth domain)', () => {
    process.env.SUPABASE_JWKS_URL = 'https://auth.school.example/keys.json';
    process.env.SUPABASE_JWT_ISSUER = 'https://auth.school.example/auth/v1';
    const env = loadEnv();
    expect(env.supabaseJwksUrl).toBe('https://auth.school.example/keys.json');
    expect(env.supabaseJwtIssuer).toBe('https://auth.school.example/auth/v1');
  });

  it.each(['SUPABASE_URL', 'SUPABASE_SERVICE_ROLE_KEY'])('refuses to start without %s', (key) => {
    delete process.env[key];
    expect(() => loadEnv()).toThrow(`Missing required environment variable: ${key}`);
  });

  it.each([
    ['SUPABASE_URL', 'not a url'],
    ['SUPABASE_URL', 'ftp://abcdefgh.supabase.co'],
    ['SUPABASE_JWKS_URL', 'javascript:alert(1)'],
  ])('refuses to start when %s is %p', (key, value) => {
    process.env[key] = value;
    expect(() => loadEnv()).toThrow(`Invalid ${key}`);
  });
});
