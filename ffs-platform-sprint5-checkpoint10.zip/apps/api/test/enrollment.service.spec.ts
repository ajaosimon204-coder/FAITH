import { ConflictException, ForbiddenException, NotFoundException } from '@nestjs/common';
import { EnrollmentService } from '../src/modules/academic/enrollment.service';
import { ResolvedIdentity } from '../src/modules/identity/identity.types';
import { FakeAcademicRepository } from './fakes/fake-academic.repository';

function buildIdentity(overrides: Partial<ResolvedIdentity> = {}): ResolvedIdentity {
  return {
    authUserId: 'auth-admin',
    appUserId: 'user-admin',
    email: 'admin@ffs.example',
    status: 'active',
    campusId: 'campus-1',
    organizationId: 'org-1',
    roles: ['school_administrator'],
    permissions: ['academic.enrollments.manage', 'academic.enrollments.read'],
    ...overrides,
  };
}

describe('EnrollmentService', () => {
  let repository: FakeAcademicRepository;
  let service: EnrollmentService;

  beforeEach(() => {
    repository = new FakeAcademicRepository();
    service = new EnrollmentService(repository);
    // All existing tests operate on students within campus-1 (the actor's
    // own campus). Explicit cross-campus scenarios (added during the
    // Sprint 3 re-audit) set a DIFFERENT campus deliberately per-test —
    // see the "cross-campus" describe block below.
    repository.studentCampusIdMap['student-1'] = 'campus-1';
    repository.studentCampusIdMap['student-2'] = 'campus-1';
  });

  describe('enrollStudent', () => {
    it('creates a new active enrollment and an audit entry when none exists yet', async () => {
      const actor = buildIdentity();

      const enrollment = await service.enrollStudent(actor, {
        studentId: 'student-1',
        classId: 'class-1',
        academicSessionId: 'session-1',
        termId: null,
      });

      expect(enrollment.status).toBe('active');
      expect(repository.auditEntries).toHaveLength(1);
      expect(repository.auditEntries[0].action).toBe('enrollment.created');
    });

    it('refuses to double-enroll a student already active in the same session', async () => {
      const actor = buildIdentity();
      await service.enrollStudent(actor, {
        studentId: 'student-1',
        classId: 'class-1',
        academicSessionId: 'session-1',
        termId: null,
      });

      await expect(
        service.enrollStudent(actor, {
          studentId: 'student-1',
          classId: 'class-2',
          academicSessionId: 'session-1',
          termId: null,
        }),
      ).rejects.toThrow(ConflictException);

      // Still only one enrollment row exists — no partial/duplicate write.
      expect(repository.enrollments).toHaveLength(1);
    });

    it('denies enrollment for an actor without academic.enrollments.manage', async () => {
      const actor = buildIdentity({ permissions: ['academic.enrollments.read'] });

      await expect(
        service.enrollStudent(actor, {
          studentId: 'student-1',
          classId: 'class-1',
          academicSessionId: 'session-1',
          termId: null,
        }),
      ).rejects.toThrow(ForbiddenException);

      expect(repository.enrollments).toHaveLength(0);
    });
  });

  describe('transferStudent', () => {
    it('closes the old enrollment as transferred and opens a new active one, preserving history', async () => {
      const actor = buildIdentity();
      const original = await service.enrollStudent(actor, {
        studentId: 'student-1',
        classId: 'class-1',
        academicSessionId: 'session-1',
        termId: null,
      });

      const transferred = await service.transferStudent(actor, {
        studentId: 'student-1',
        academicSessionId: 'session-1',
        newClassId: 'class-2',
        reason: 'Sibling schedule alignment',
      });

      const original_after = repository.enrollments.find((e) => e.id === original.id);
      expect(original_after?.status).toBe('transferred');
      expect(original_after?.exitedAt).not.toBeNull();
      expect(transferred.status).toBe('active');
      expect(transferred.classId).toBe('class-2');

      // BOTH rows still exist — this is the historical-integrity guarantee.
      const history = await service.getEnrollmentHistory(actor, 'student-1');
      expect(history).toHaveLength(2);

      expect(repository.auditEntries.map((a) => a.action)).toContain('enrollment.transferred');
    });

    it('refuses to transfer a student with no active enrollment in that session', async () => {
      const actor = buildIdentity();

      await expect(
        service.transferStudent(actor, {
          studentId: 'student-never-enrolled',
          academicSessionId: 'session-1',
          newClassId: 'class-2',
          reason: null,
        }),
      ).rejects.toThrow(NotFoundException);
    });
  });

  describe('withdrawStudent', () => {
    it('closes the active enrollment as withdrawn', async () => {
      const actor = buildIdentity();
      await service.enrollStudent(actor, {
        studentId: 'student-1',
        classId: 'class-1',
        academicSessionId: 'session-1',
        termId: null,
      });

      const withdrawn = await service.withdrawStudent(actor, {
        studentId: 'student-1',
        academicSessionId: 'session-1',
        reason: 'Relocated',
      });

      expect(withdrawn.status).toBe('withdrawn');
      expect(withdrawn.exitedAt).not.toBeNull();
    });
  });

  describe('getCurrentEnrollment — relationship-based authorization', () => {
    beforeEach(async () => {
      const admin = buildIdentity();
      repository.sessions.push({
        id: 'session-1',
        campusId: 'campus-1',
        name: '2025/2026',
        startDate: '2025-09-01',
        endDate: '2026-07-31',
        isCurrent: true,
      });
      await service.enrollStudent(admin, {
        studentId: 'student-1',
        classId: 'class-1',
        academicSessionId: 'session-1',
        termId: null,
      });
    });

    it('allows an admin-tier actor (academic.enrollments.read) to view any student', async () => {
      const admin = buildIdentity({ permissions: ['academic.enrollments.read'] });
      const enrollment = await service.getCurrentEnrollment(admin, 'student-1');
      expect(enrollment?.classId).toBe('class-1');
    });

    it('allows the student themself to view their own current enrollment', async () => {
      repository.studentUsersIdMap['student-1'] = 'user-student-1';
      const student = buildIdentity({
        appUserId: 'user-student-1',
        roles: ['student'],
        permissions: [],
      });

      const enrollment = await service.getCurrentEnrollment(student, 'student-1');
      expect(enrollment?.classId).toBe('class-1');
    });

    it("allows a teacher actually assigned to the student's current class", async () => {
      repository.staffIdForUserMap['user-teacher-1'] = 'staff-1';
      repository.teacherAssignments.push({
        id: 'assignment-1',
        staffId: 'staff-1',
        classId: 'class-1',
        subjectId: null,
        academicSessionId: 'session-1',
        campusId: 'campus-1',
        role: 'class_teacher',
        assignedBy: 'user-admin',
        assignedAt: new Date().toISOString(),
      });
      const teacher = buildIdentity({
        appUserId: 'user-teacher-1',
        roles: ['teacher'],
        permissions: [],
      });

      const enrollment = await service.getCurrentEnrollment(teacher, 'student-1');
      expect(enrollment?.classId).toBe('class-1');
    });

    it('denies a teacher who holds the Teacher role but has NO assignment to this class', async () => {
      // This is the single most important negative test in this sprint:
      // proving role name alone grants nothing.
      repository.staffIdForUserMap['user-teacher-2'] = 'staff-2';
      // Deliberately no teacher_assignments row for staff-2.
      const unassignedTeacher = buildIdentity({
        appUserId: 'user-teacher-2',
        roles: ['teacher'],
        permissions: [],
      });

      await expect(
        service.getCurrentEnrollment(unassignedTeacher, 'student-1'),
      ).rejects.toThrow(ForbiddenException);
    });

    it("denies an unrelated student trying to view another student's enrollment (IDOR guard)", async () => {
      repository.studentUsersIdMap['student-2'] = 'user-student-2';
      const otherStudent = buildIdentity({
        appUserId: 'user-student-2',
        roles: ['student'],
        permissions: [],
      });

      await expect(
        service.getCurrentEnrollment(otherStudent, 'student-1'),
      ).rejects.toThrow(ForbiddenException);
    });
  });

  describe('getEnrollmentHistory — narrower than current-class access', () => {
    it('denies a correctly-assigned teacher full history access (current-class only, not history)', async () => {
      const admin = buildIdentity();
      await service.enrollStudent(admin, {
        studentId: 'student-1',
        classId: 'class-1',
        academicSessionId: 'session-1',
        termId: null,
      });
      repository.staffIdForUserMap['user-teacher-1'] = 'staff-1';
      repository.teacherAssignments.push({
        id: 'assignment-1',
        staffId: 'staff-1',
        classId: 'class-1',
        subjectId: null,
        academicSessionId: 'session-1',
        campusId: 'campus-1',
        role: 'class_teacher',
        assignedBy: 'user-admin',
        assignedAt: new Date().toISOString(),
      });
      const teacher = buildIdentity({
        appUserId: 'user-teacher-1',
        roles: ['teacher'],
        permissions: [],
      });

      // Same teacher who CAN see current-class (per the earlier describe
      // block) is deliberately still denied full history here.
      await expect(service.getEnrollmentHistory(teacher, 'student-1')).rejects.toThrow(
        ForbiddenException,
      );
    });

    it('denies an admin-tier read for a staff member holding academic.enrollments.read but on unrelated grounds otherwise unauthorized (sanity: permission alone still required)', async () => {
      // A teacher with no admin permission and no assignment at all —
      // confirms the "unauthorized staff attempting to access enrollment
      // history" case from the re-audit is covered.
      const unauthorizedStaff = buildIdentity({
        appUserId: 'user-random-staff',
        roles: ['librarian'],
        permissions: [],
      });

      await expect(
        service.getEnrollmentHistory(unauthorizedStaff, 'student-1'),
      ).rejects.toThrow(ForbiddenException);
    });
  });

  describe('IDOR — cross-campus and cross-teacher (Sprint 3 re-audit)', () => {
    beforeEach(() => {
      repository.sessions.push({
        id: 'session-1',
        campusId: 'campus-1',
        name: '2025/2026',
        startDate: '2025-09-01',
        endDate: '2026-07-31',
        isCurrent: true,
      });
    });

    it('denies access to a student in a DIFFERENT campus, even for an actor holding academic.enrollments.read — this was NOT previously checked', async () => {
      // Prior to the re-audit fix, assertCanViewStudent returned early on
      // `hasPermission(actor, 'academic.enrollments.read')` with NO campus
      // check at all. This test would have passed incorrectly before the
      // fix in enrollment.service.ts (ADR-014).
      repository.studentCampusIdMap['student-in-campus-2'] = 'campus-2';
      const admin = buildIdentity({ campusId: 'campus-1', permissions: ['academic.enrollments.read'] });

      await expect(
        service.getCurrentEnrollment(admin, 'student-in-campus-2'),
      ).rejects.toThrow(ForbiddenException);

      await expect(
        service.getEnrollmentHistory(admin, 'student-in-campus-2'),
      ).rejects.toThrow(ForbiddenException);
    });

    it('denies Teacher B access to a student assigned only to Teacher A\'s class', async () => {
      const admin = buildIdentity();
      await service.enrollStudent(admin, {
        studentId: 'student-1',
        classId: 'class-1',
        academicSessionId: 'session-1',
        termId: null,
      });

      repository.staffIdForUserMap['user-teacher-a'] = 'staff-a';
      repository.teacherAssignments.push({
        id: 'assignment-a',
        staffId: 'staff-a',
        classId: 'class-1',
        subjectId: null,
        academicSessionId: 'session-1',
        campusId: 'campus-1',
        role: 'class_teacher',
        assignedBy: 'user-admin',
        assignedAt: new Date().toISOString(),
      });

      // Teacher B is assigned to a DIFFERENT class, not class-1.
      repository.staffIdForUserMap['user-teacher-b'] = 'staff-b';
      repository.teacherAssignments.push({
        id: 'assignment-b',
        staffId: 'staff-b',
        classId: 'class-2',
        subjectId: null,
        academicSessionId: 'session-1',
        campusId: 'campus-1',
        role: 'class_teacher',
        assignedBy: 'user-admin',
        assignedAt: new Date().toISOString(),
      });

      const teacherB = buildIdentity({
        appUserId: 'user-teacher-b',
        roles: ['teacher'],
        permissions: [],
      });

      await expect(service.getCurrentEnrollment(teacherB, 'student-1')).rejects.toThrow(
        ForbiddenException,
      );
    });

    it('confirms class_id used for authorization is always server-derived, never client-supplied — structurally not exploitable', () => {
      // getCurrentEnrollment/getEnrollmentHistory take only (actor, studentId).
      // There is no API surface, in this service or its controller, that
      // accepts a class_id parameter influencing a READ authorization
      // decision — the class_id used internally always comes from
      // repository.findCurrentEnrollment(), a trusted server-side lookup.
      // This test exists to document that the "teacher supplying an
      // unrelated class_id" attack vector from the re-audit request does
      // not apply to this service's actual API shape, rather than silently
      // omitting that requirement.
      expect(service.getCurrentEnrollment.length).toBe(2); // (actor, studentId)
      expect(service.getEnrollmentHistory.length).toBe(2); // (actor, studentId)
    });
  });
});
