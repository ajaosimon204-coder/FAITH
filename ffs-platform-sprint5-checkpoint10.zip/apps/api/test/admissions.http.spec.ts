import { INestApplication } from '@nestjs/common';
import { NestExpressApplication } from '@nestjs/platform-express';
import { APP_GUARD } from '@nestjs/core';
import { Test } from '@nestjs/testing';
import * as jwt from 'jsonwebtoken';
import request from 'supertest';
import {
  ADMISSIONS_REPOSITORY,
  ADMISSIONS_SUBMISSION_RATE_LIMIT,
  AdmissionsModule,
} from '../src/modules/admissions/admissions.module';
import { configureApp } from '../src/app.setup';
import { ADMISSIONS_PERMISSIONS } from '../src/modules/admissions/admissions.types';
import { IdentityResolutionService } from '../src/modules/identity/identity-resolution.service';
import { JwtVerificationService } from '../src/modules/identity/jwt-verification.service';
import { SupabaseAuthGuard } from '../src/modules/identity/supabase-auth.guard';
import { FakeAdmissionsRepository } from './fakes/fake-admissions.repository';
import { FakeIdentityRepository } from './fakes/fake-identity.repository';

/**
 * HTTP-level tests: a real Nest application with the REAL global auth guard, JWT
 * verification, identity resolution, validation pipe and throttler. Only the database
 * is replaced (in-memory fakes). These prove the wiring — routes, guards, the @Public()
 * opt-out, status codes, rate limiting — which the service specs cannot.
 */
const SECRET = 'test-secret';
const CAMPUS_A = '11111111-1111-4111-8111-111111111111';
const CAMPUS_B = '99999999-9999-4999-8999-999999999999';
const DEF_A = '22222222-2222-4222-8222-222222222222';
const DEF_B = '88888888-8888-4888-8888-888888888888';
const CLASS_A = 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa1';

const { APPLICATIONS_READ: READ, APPLICATIONS_MANAGE: MANAGE } = ADMISSIONS_PERMISSIONS;

function tokenFor(authUserId: string): string {
  return jwt.sign({ sub: authUserId, email: `${authUserId}@ffs.example` }, SECRET, {
    algorithm: 'HS256',
    expiresIn: '1h',
  });
}

const validForm = {
  campusId: CAMPUS_A,
  applicantFirstName: 'Ada',
  applicantLastName: 'Obi',
  applicantDateOfBirth: '2014-05-05',
  applicantGender: 'female',
  classDefinitionId: DEF_A,
  guardianFirstName: 'Ngozi',
  guardianLastName: 'Obi',
  guardianEmail: 'parent@example.test',
  documents: [{ docType: 'birth_certificate', fileUrl: 'https://files.example.test/a.pdf' }],
};

describe('Admissions HTTP surface', () => {
  let app: INestApplication;
  let repo: FakeAdmissionsRepository;

  beforeEach(async () => {
    repo = new FakeAdmissionsRepository();
    repo.classDefinitions.push({ id: DEF_A, campusId: CAMPUS_A }, { id: DEF_B, campusId: CAMPUS_B });
    repo.classes.push({ id: CLASS_A, campusId: CAMPUS_A, classDefinitionId: DEF_A });

    const identityRepo = new FakeIdentityRepository();
    identityRepo.rolePermissions = {
      school_administrator: [READ, MANAGE],
      vice_principal: [READ],
      accountant: [],
    };
    const addUser = (id: string, roleKey: string, campusId: string) => {
      identityRepo.users.push({
        appUserId: `user-${id}`,
        authUserId: `auth-${id}`,
        email: `${id}@ffs.example`,
        status: 'active',
        campusId,
        organizationId: 'org-1',
      });
      identityRepo.userRoles.push({ appUserId: `user-${id}`, roleKey, campusId });
    };
    addUser('manager', 'school_administrator', CAMPUS_A);
    addUser('reader', 'vice_principal', CAMPUS_A);
    addUser('nobody', 'accountant', CAMPUS_A);
    addUser('foreign', 'school_administrator', CAMPUS_B);

    const moduleRef = await Test.createTestingModule({
      imports: [AdmissionsModule],
      providers: [
        {
          provide: IdentityResolutionService,
          useValue: new IdentityResolutionService(new JwtVerificationService({ legacySecret: SECRET }), identityRepo),
        },
        { provide: APP_GUARD, useClass: SupabaseAuthGuard },
      ],
    })
      .overrideProvider(ADMISSIONS_REPOSITORY)
      .useValue(repo)
      .compile();

    const nestApp = moduleRef.createNestApplication<NestExpressApplication>();
    configureApp(nestApp, {}); // the production configuration (pipes, CORS, proxy handling)
    await nestApp.init();
    app = nestApp;
  });

  afterEach(async () => {
    await app.close();
  });

  const http = () => request(app.getHttpServer());
  const asManager = () => `Bearer ${tokenFor('auth-manager')}`;

  describe('public submission', () => {
    it('accepts an application with no credentials and returns only the receipt', async () => {
      const res = await http().post('/api/v1/public/admissions/applications').send(validForm).expect(201);

      expect(Object.keys(res.body).sort()).toEqual(
        ['applicationId', 'documentsRequested', 'documentsStored', 'referenceNo', 'submittedAt'],
      );
      expect(res.body).toMatchObject({ documentsRequested: 1, documentsStored: 1 });
      expect(repo.applications).toHaveLength(1);
      expect(repo.applications[0].status).toBe('submitted');
    });

    it('answers invalid input with a 400 listing every problem', async () => {
      const res = await http()
        .post('/api/v1/public/admissions/applications')
        .send({ ...validForm, applicantFirstName: '', guardianEmail: 'nope' })
        .expect(400);
      expect(res.body.message).toEqual(
        expect.arrayContaining(['Applicant first name is required.', 'Guardian email is not a valid email address.']),
      );
      expect(repo.applications).toHaveLength(0);
    });

    it('ignores fields a client should not control (status, reference number, reviewer)', async () => {
      await http()
        .post('/api/v1/public/admissions/applications')
        .send({ ...validForm, status: 'approved', referenceNo: 'APP-HACK', reviewedBy: 'someone', possibleDuplicateOf: 'x' })
        .expect(201);
      expect(repo.applications[0]).toMatchObject({ status: 'submitted', reviewedBy: null, possibleDuplicateOf: null });
      expect(repo.applications[0].referenceNo).not.toBe('APP-HACK');
    });

    it('exposes nothing readable: GET on the public route does not exist', async () => {
      await http().get('/api/v1/public/admissions/applications').expect(404);
      await http().get('/api/v1/public/admissions/applications/anything').expect(404);
    });

    it('rate-limits a single client: the request after the limit is a 429, and stores nothing more', async () => {
      const { limit } = ADMISSIONS_SUBMISSION_RATE_LIMIT;
      for (let i = 0; i < limit; i += 1) {
        await http().post('/api/v1/public/admissions/applications').send({ ...validForm, applicantFirstName: `Child${i}x` }).expect(201);
      }
      await http().post('/api/v1/public/admissions/applications').send(validForm).expect(429);
      expect(repo.applications).toHaveLength(limit);
    });
  });

  describe('staff routes require authentication', () => {
    const routes: Array<['get' | 'post', string]> = [
      ['get', '/api/v1/admissions/applications'],
      ['get', '/api/v1/admissions/applications/a0000000-0000-4000-8000-000000000001'],
      ['post', '/api/v1/admissions/applications/a0000000-0000-4000-8000-000000000001/start-review'],
      ['post', '/api/v1/admissions/applications/a0000000-0000-4000-8000-000000000001/request-info'],
      ['post', '/api/v1/admissions/applications/a0000000-0000-4000-8000-000000000001/resume-review'],
      ['post', '/api/v1/admissions/applications/a0000000-0000-4000-8000-000000000001/approve'],
      ['post', '/api/v1/admissions/applications/a0000000-0000-4000-8000-000000000001/reject'],
      ['post', '/api/v1/admissions/applications/a0000000-0000-4000-8000-000000000001/convert'],
    ];

    it.each(routes)('%s %s → 401 with no token', async (method, path) => {
      await http()[method](path).expect(401);
    });

    it.each(routes)('%s %s → 401 with a forged token', async (method, path) => {
      const forged = jwt.sign({ sub: 'auth-manager' }, 'not-the-secret', { algorithm: 'HS256' });
      await http()[method](path).set('Authorization', `Bearer ${forged}`).expect(401);
    });

    it('→ 401 for a valid token whose user has no application account', async () => {
      await http().get('/api/v1/admissions/applications').set('Authorization', `Bearer ${tokenFor('auth-stranger')}`).expect(401);
    });
  });

  describe('staff permissions over HTTP', () => {
    it('lets a reader list and view but forbids every state change', async () => {
      const receipt = await http().post('/api/v1/public/admissions/applications').send(validForm);
      const id = receipt.body.applicationId;
      const reader = `Bearer ${tokenFor('auth-reader')}`;

      await http().get('/api/v1/admissions/applications').set('Authorization', reader).expect(200);
      await http().get(`/api/v1/admissions/applications/${id}`).set('Authorization', reader).expect(200);
      await http().post(`/api/v1/admissions/applications/${id}/start-review`).set('Authorization', reader).send({}).expect(403);
      expect(repo.applications[0].status).toBe('submitted');
    });

    it('forbids a user with no admissions permission everything', async () => {
      await http().get('/api/v1/admissions/applications').set('Authorization', `Bearer ${tokenFor('auth-nobody')}`).expect(403);
    });
  });

  describe('the full journey over HTTP', () => {
    it('submit → list → view → review → approve → convert', async () => {
      const receipt = await http().post('/api/v1/public/admissions/applications').send(validForm).expect(201);
      const id = receipt.body.applicationId;
      const auth = asManager();

      const listed = await http().get('/api/v1/admissions/applications?status=submitted').set('Authorization', auth).expect(200);
      expect(listed.body).toHaveLength(1);

      const detail = await http().get(`/api/v1/admissions/applications/${id}`).set('Authorization', auth).expect(200);
      expect(detail.body.documents).toHaveLength(1);

      await http().post(`/api/v1/admissions/applications/${id}/start-review`).set('Authorization', auth).send({ notes: 'looks fine' }).expect(201);
      await http().post(`/api/v1/admissions/applications/${id}/approve`).set('Authorization', auth).send({}).expect(201);
      const converted = await http()
        .post(`/api/v1/admissions/applications/${id}/convert`)
        .set('Authorization', auth)
        .send({ classId: CLASS_A })
        .expect(201);

      expect(converted.body.admissionNo).toMatch(/^FFS-\d{4}-00001$/);
      expect(repo.applications[0].status).toBe('converted');
      expect(repo.students).toHaveLength(1);
      expect(repo.auditEntries.map((e) => e.action)).toEqual([
        'application.under_review',
        'application.approved',
        'application.converted',
      ]);
    });

    it('maps service errors to the right status codes', async () => {
      const receipt = await http().post('/api/v1/public/admissions/applications').send(validForm);
      const id = receipt.body.applicationId;
      const auth = asManager();

      await http().get('/api/v1/admissions/applications?status=bogus').set('Authorization', auth).expect(400);
      await http().post(`/api/v1/admissions/applications/${id}/reject`).set('Authorization', auth).send({}).expect(400); // reason required
      await http().post(`/api/v1/admissions/applications/${id}/approve`).set('Authorization', auth).send({}).expect(409); // still "submitted"
      await http().post(`/api/v1/admissions/applications/${id}/convert`).set('Authorization', auth).send({ classId: CLASS_A }).expect(409);
      await http().get('/api/v1/admissions/applications/not-a-uuid').set('Authorization', auth).expect(404);
    });

    it('treats a missing convert body as a 400, not a server error', async () => {
      const receipt = await http().post('/api/v1/public/admissions/applications').send(validForm);
      const id = receipt.body.applicationId;
      const auth = asManager();
      await http().post(`/api/v1/admissions/applications/${id}/start-review`).set('Authorization', auth).send({});
      await http().post(`/api/v1/admissions/applications/${id}/approve`).set('Authorization', auth).send({});
      await http().post(`/api/v1/admissions/applications/${id}/convert`).set('Authorization', auth).expect(400);
    });
  });

  describe('campus isolation over HTTP', () => {
    it('a manager in another campus sees none of it and cannot act on it', async () => {
      const receipt = await http().post('/api/v1/public/admissions/applications').send(validForm);
      const id = receipt.body.applicationId;
      const foreign = `Bearer ${tokenFor('auth-foreign')}`;

      const list = await http().get('/api/v1/admissions/applications').set('Authorization', foreign).expect(200);
      expect(list.body).toEqual([]);
      await http().get(`/api/v1/admissions/applications/${id}`).set('Authorization', foreign).expect(404);
      await http().post(`/api/v1/admissions/applications/${id}/start-review`).set('Authorization', foreign).send({}).expect(404);
      expect(repo.applications[0].status).toBe('submitted');
    });
  });
});
