import { parseTrustProxy } from '../src/config/trust-proxy';

describe('parseTrustProxy', () => {
  it.each([undefined, '', '   '])('treats %p as "not behind a proxy" (undefined)', (raw) => {
    expect(parseTrustProxy(raw)).toBeUndefined();
  });

  it.each([
    ['0', 0],
    ['1', 1],
    [' 2 ', 2],
  ])('accepts a hop count %p', (raw, expected) => {
    expect(parseTrustProxy(raw)).toBe(expected);
  });

  it.each(['true', 'false', '-1', '1.5', 'loopback', '10.0.0.1', '1,2', 'one'])(
    'refuses %p rather than guessing which addresses to trust',
    (raw) => {
      expect(() => parseTrustProxy(raw)).toThrow('Invalid TRUST_PROXY');
    },
  );
});
