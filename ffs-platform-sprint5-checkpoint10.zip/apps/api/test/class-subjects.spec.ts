import { ForbiddenException } from '@nestjs/common';
import { ClassesService } from '../src/modules/academic/classes.service';
import { ResolvedIdentity } from '../src/modules/identity/identity.types';
import { FakeAcademicRepository } from './fakes/fake-academic.repository';

function buildIdentity(overrides: Partial<ResolvedIdentity> = {}): ResolvedIdentity {
  return {
    authUserId: 'auth-admin',
    appUserId: 'user-admin',
    email: 'admin@ffs.example',
    status: 'active',
    campusId: 'campus-1',
    organizationId: 'org-1',
    roles: ['school_administrator'],
    permissions: ['academic.classes.write'],
    ...overrides,
  };
}

/**
 * Focused test coverage for class_subjects linking, added during the
 * Sprint 3 re-audit. Two of these four cases (unauthorized, cross-campus)
 * were NOT safe before this audit — see ADR-014 for the fix applied to
 * ClassesService.linkSubjectToClass alongside these tests.
 */
describe('ClassesService.linkSubjectToClass', () => {
  let repository: FakeAcademicRepository;
  let service: ClassesService;

  beforeEach(() => {
    repository = new FakeAcademicRepository();
    service = new ClassesService(repository);
  });

  it('links a subject to a class when both belong to the actor\'s own campus', async () => {
    const actor = buildIdentity({ campusId: 'campus-1' });
    repository.classes.push({
      id: 'class-1',
      classDefinitionId: 'def-1',
      academicSessionId: 'session-1',
      campusId: 'campus-1',
      name: 'JSS 1A',
      section: 'A',
    });
    repository.subjects.push({ id: 'subject-1', campusId: 'campus-1', name: 'Math', code: 'MTH' });

    await service.linkSubjectToClass(actor, { classId: 'class-1', subjectId: 'subject-1' });

    expect(repository.classSubjectLinks).toEqual([{ classId: 'class-1', subjectId: 'subject-1' }]);
    expect(repository.auditEntries.map((a) => a.action)).toContain('class_subject.linked');
  });

  it('rejects a duplicate link (mirrors the database primary-key constraint)', async () => {
    const actor = buildIdentity({ campusId: 'campus-1' });
    repository.classes.push({
      id: 'class-1',
      classDefinitionId: 'def-1',
      academicSessionId: 'session-1',
      campusId: 'campus-1',
      name: 'JSS 1A',
      section: 'A',
    });
    repository.subjects.push({ id: 'subject-1', campusId: 'campus-1', name: 'Math', code: 'MTH' });

    await service.linkSubjectToClass(actor, { classId: 'class-1', subjectId: 'subject-1' });

    await expect(
      service.linkSubjectToClass(actor, { classId: 'class-1', subjectId: 'subject-1' }),
    ).rejects.toThrow(/duplicate key/);

    expect(repository.classSubjectLinks).toHaveLength(1);
  });

  it('rejects linking for an actor without academic.classes.write', async () => {
    const actor = buildIdentity({ campusId: 'campus-1', permissions: [] });
    repository.classes.push({
      id: 'class-1',
      classDefinitionId: 'def-1',
      academicSessionId: 'session-1',
      campusId: 'campus-1',
      name: 'JSS 1A',
      section: 'A',
    });
    repository.subjects.push({ id: 'subject-1', campusId: 'campus-1', name: 'Math', code: 'MTH' });

    await expect(
      service.linkSubjectToClass(actor, { classId: 'class-1', subjectId: 'subject-1' }),
    ).rejects.toThrow(ForbiddenException);

    expect(repository.classSubjectLinks).toHaveLength(0);
  });

  it('rejects linking a class from a DIFFERENT campus than the actor\'s own (cross-campus IDOR)', async () => {
    const actor = buildIdentity({ campusId: 'campus-1' });
    repository.classes.push({
      id: 'class-in-campus-2',
      classDefinitionId: 'def-1',
      academicSessionId: 'session-1',
      campusId: 'campus-2', // different campus than the actor
      name: 'JSS 1A',
      section: 'A',
    });
    repository.subjects.push({ id: 'subject-1', campusId: 'campus-1', name: 'Math', code: 'MTH' });

    await expect(
      service.linkSubjectToClass(actor, { classId: 'class-in-campus-2', subjectId: 'subject-1' }),
    ).rejects.toThrow(ForbiddenException);

    expect(repository.classSubjectLinks).toHaveLength(0);
  });

  it('rejects linking a subject from a DIFFERENT campus than the class (cross-campus resource mixing)', async () => {
    const actor = buildIdentity({ campusId: 'campus-1' });
    repository.classes.push({
      id: 'class-1',
      classDefinitionId: 'def-1',
      academicSessionId: 'session-1',
      campusId: 'campus-1',
      name: 'JSS 1A',
      section: 'A',
    });
    repository.subjects.push({
      id: 'subject-in-campus-2',
      campusId: 'campus-2', // different campus than both the class and the actor
      name: 'Math',
      code: 'MTH',
    });

    await expect(
      service.linkSubjectToClass(actor, { classId: 'class-1', subjectId: 'subject-in-campus-2' }),
    ).rejects.toThrow(ForbiddenException);

    expect(repository.classSubjectLinks).toHaveLength(0);
  });
});
