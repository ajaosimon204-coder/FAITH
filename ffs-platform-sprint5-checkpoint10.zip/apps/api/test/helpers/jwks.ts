import * as http from 'http';
import { AddressInfo } from 'net';
import { exportJWK, generateKeyPair, JWK, KeyLike, SignJWT } from 'jose';

export const ISSUER = 'https://project.example.test/auth/v1';
export const AUDIENCE = 'authenticated';

/** A real local JWKS endpoint, so key fetching, caching and rotation run for real (nothing mocked). */
export class JwksServer {
  private server!: http.Server;
  public keys: JWK[] = [];
  public requests = 0;
  public status = 200;
  url = '';

  async start(): Promise<void> {
    this.server = http.createServer((_req, res) => {
      this.requests += 1;
      res.writeHead(this.status, { 'content-type': 'application/json' });
      res.end(JSON.stringify({ keys: this.keys }));
    });
    await new Promise<void>((resolve) => this.server.listen(0, '127.0.0.1', resolve));
    this.url = `http://127.0.0.1:${(this.server.address() as AddressInfo).port}/auth/v1/.well-known/jwks.json`;
  }
  async stop(): Promise<void> {
    await new Promise<void>((resolve) => this.server.close(() => resolve()));
  }
}

export interface Signer {
  kid: string;
  alg: 'ES256' | 'RS256';
  privateKey: KeyLike;
  publicJwk: JWK;
}
export async function makeSigner(kid: string, alg: 'ES256' | 'RS256'): Promise<Signer> {
  const { publicKey, privateKey } = await generateKeyPair(alg, { extractable: true });
  const publicJwk = { ...(await exportJWK(publicKey)), kid, alg, use: 'sig' };
  return { kid, alg, privateKey, publicJwk };
}
export async function sign(
  signer: Signer,
  claims: Record<string, unknown> = {},
  opts: { iss?: string | null; aud?: string | null; exp?: string | number } = {},
): Promise<string> {
  let jwt = new SignJWT({ email: 'parent@example.com', ...claims })
    .setProtectedHeader({ alg: signer.alg, kid: signer.kid })
    .setSubject('auth-user-123')
    .setIssuedAt()
    .setExpirationTime(opts.exp ?? '1h');
  if (opts.iss !== null) jwt = jwt.setIssuer(opts.iss ?? ISSUER);
  if (opts.aud !== null) jwt = jwt.setAudience(opts.aud ?? AUDIENCE);
  return jwt.sign(signer.privateKey);
}

