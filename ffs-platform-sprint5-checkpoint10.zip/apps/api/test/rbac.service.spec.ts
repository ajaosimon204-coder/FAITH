import { BadRequestException } from '@nestjs/common';
import { RbacService } from '../src/modules/rbac/rbac.service';
import { ResolvedIdentity } from '../src/modules/identity/identity.types';
import { FakeIdentityRepository } from './fakes/fake-identity.repository';

function buildActor(overrides: Partial<ResolvedIdentity> = {}): ResolvedIdentity {
  return {
    authUserId: 'auth-admin',
    appUserId: 'user-admin',
    email: 'admin@ffs.example',
    status: 'active',
    campusId: 'campus-1',
    organizationId: 'org-1',
    roles: ['super_admin'],
    permissions: ['rbac.manage'],
    ...overrides,
  };
}

describe('RbacService', () => {
  let repository: FakeIdentityRepository;
  let service: RbacService;

  beforeEach(() => {
    repository = new FakeIdentityRepository();
    repository.knownRoleKeys = new Set(['teacher', 'school_administrator']);
    service = new RbacService(repository);
  });

  it('assigns a valid role, scoped to the actor campus, and writes an audit entry', async () => {
    const actor = buildActor({ campusId: 'campus-1' });

    await service.assignRole({
      actor,
      targetAppUserId: 'user-target',
      roleKey: 'teacher',
    });

    expect(repository.userRoles).toEqual([
      { appUserId: 'user-target', roleKey: 'teacher', campusId: 'campus-1' },
    ]);
    expect(repository.auditEntries).toHaveLength(1);
    expect(repository.auditEntries[0]).toMatchObject({
      actorId: 'user-admin',
      campusId: 'campus-1',
      action: 'rbac.role_assigned',
      targetType: 'user',
      targetId: 'user-target',
    });
  });

  it('rejects an unknown or unassignable role before touching the repository', async () => {
    const actor = buildActor();

    await expect(
      service.assignRole({
        actor,
        targetAppUserId: 'user-target',
        roleKey: 'nonexistent_role',
      }),
    ).rejects.toThrow(BadRequestException);

    expect(repository.userRoles).toHaveLength(0);
    expect(repository.auditEntries).toHaveLength(0);
  });

  it('never assigns a role to a campus other than the actor own campus', async () => {
    const actor = buildActor({ campusId: 'campus-1' });

    await service.assignRole({
      actor,
      targetAppUserId: 'user-target',
      roleKey: 'school_administrator',
    });

    // Even though nothing in the call explicitly said "campus-1", the
    // assignment is always scoped to the actor's own campus — proving a
    // caller cannot smuggle in a different campus via the target user id.
    expect(repository.userRoles[0].campusId).toBe('campus-1');
  });
});
