import * as jsonwebtoken from 'jsonwebtoken';
import { Logger, ServiceUnavailableException, UnauthorizedException } from '@nestjs/common';
import { JwtVerificationService } from '../src/modules/identity/jwt-verification.service';

const SECRET = 'test-secret-do-not-use-in-real-environments';
import { AUDIENCE, ISSUER, JwksServer, makeSigner, sign, Signer } from './helpers/jwks';

describe('JwtVerificationService — legacy HS256 shared secret', () => {
  const service = new JwtVerificationService({ legacySecret: SECRET });
  const hs = (claims: object, options: jsonwebtoken.SignOptions = {}) =>
    jsonwebtoken.sign(claims, SECRET, { algorithm: 'HS256', ...options });

  it('accepts a validly signed, non-expired token and extracts claims', async () => {
    const claims = await service.verify(hs({ sub: 'auth-user-123', email: 'parent@example.com' }, { expiresIn: '1h' }));
    expect(claims).toEqual({ authUserId: 'auth-user-123', email: 'parent@example.com' });
  });

  it('returns a null email when the token has none', async () => {
    expect((await service.verify(hs({ sub: 'u' }))).email).toBeNull();
  });

  it.each([
    ['signed with the wrong secret', () => jsonwebtoken.sign({ sub: 'u' }, 'wrong-secret', { algorithm: 'HS256' })],
    ['expired', () => hs({ sub: 'u' }, { expiresIn: '-1h' })],
    ['without a subject', () => hs({ email: 'a@b.com' })],
    ['signed with an unexpected algorithm (HS384)', () => jsonwebtoken.sign({ sub: 'u' }, SECRET, { algorithm: 'HS384' })],
    ['an unsigned "alg: none" token', () => `${Buffer.from('{"alg":"none"}').toString('base64url')}.${Buffer.from('{"sub":"u"}').toString('base64url')}.`],
    ['not a JWT at all', () => 'definitely-not-a-jwt'],
  ])('rejects a token %s', async (_label, make) => {
    await expect(service.verify(make())).rejects.toBeInstanceOf(UnauthorizedException);
  });

  it('rejects an empty token', async () => {
    await expect(service.verify('')).rejects.toBeInstanceOf(UnauthorizedException);
  });

  it('answers every kind of failure identically (no probing oracle)', async () => {
    const messages = await Promise.all(
      [hs({ sub: 'u' }, { expiresIn: '-1h' }), jsonwebtoken.sign({ sub: 'u' }, 'wrong', { algorithm: 'HS256' }), 'garbage'].map((t) =>
        service.verify(t).catch((e) => e.message),
      ),
    );
    expect(new Set(messages).size).toBe(1);
  });

  it('refuses an HS256 token when NO legacy secret is configured (a current project has none)', async () => {
    jest.spyOn(Logger.prototype, 'warn').mockImplementation(() => undefined);
    const noSecret = new JwtVerificationService({ jwksUrl: 'http://127.0.0.1:1/x' });
    await expect(noSecret.verify(hs({ sub: 'u' }))).rejects.toBeInstanceOf(UnauthorizedException);
    jest.restoreAllMocks();
  });
});

describe('JwtVerificationService — asymmetric signing keys via JWKS', () => {
  const jwks = new JwksServer();
  let es: Signer;
  let rs: Signer;
  let service: JwtVerificationService;

  beforeAll(async () => {
    await jwks.start();
    es = await makeSigner('key-es-1', 'ES256');
    rs = await makeSigner('key-rs-1', 'RS256');
    jwks.keys = [es.publicJwk, rs.publicJwk];
  });
  afterAll(() => jwks.stop());

  beforeEach(() => {
    jest.spyOn(Logger.prototype, 'warn').mockImplementation(() => undefined);
    jest.spyOn(Logger.prototype, 'error').mockImplementation(() => undefined);
    jwks.status = 200;
    service = new JwtVerificationService({ jwksUrl: jwks.url, issuer: ISSUER, audience: AUDIENCE, jwksCooldownSeconds: 0 });
  });
  afterEach(() => jest.restoreAllMocks());

  it.each([
    ['ES256', () => es],
    ['RS256', () => rs],
  ])('accepts a validly signed %s token', async (_alg, signer) => {
    expect(await service.verify(await sign(signer()))).toEqual({ authUserId: 'auth-user-123', email: 'parent@example.com' });
  });

  it('caches the key set: many verifications, one fetch', async () => {
    const before = jwks.requests;
    for (let i = 0; i < 5; i += 1) await service.verify(await sign(es));
    expect(jwks.requests - before).toBe(1);
  });

  it('picks up a rotated-in key when a token names a key it has not seen', async () => {
    const rotated = await makeSigner('key-es-2', 'ES256');
    const token = await sign(rotated);
    await expect(service.verify(token)).rejects.toBeInstanceOf(UnauthorizedException); // not published yet
    jwks.keys = [es.publicJwk, rs.publicJwk, rotated.publicJwk]; // Supabase publishes the new key
    await expect(service.verify(token)).resolves.toMatchObject({ authUserId: 'auth-user-123' });
    jwks.keys = [es.publicJwk, rs.publicJwk];
  });

  it('keeps accepting tokens from the old key while both are published (graceful rotation)', async () => {
    const newer = await makeSigner('key-es-3', 'ES256');
    jwks.keys = [es.publicJwk, newer.publicJwk];
    await expect(service.verify(await sign(es))).resolves.toBeDefined();
    await expect(service.verify(await sign(newer))).resolves.toBeDefined();
    jwks.keys = [es.publicJwk, rs.publicJwk];
  });

  it.each([
    ['signed by a key that is not published', async () => sign(await makeSigner('key-es-1', 'ES256'))], // same kid, different key
    ['expired', async () => sign(es, {}, { exp: Math.floor(Date.now() / 1000) - 3600 })],
    ['from a different issuer', async () => sign(es, {}, { iss: 'https://attacker.example.test/auth/v1' })],
    ['with no issuer', async () => sign(es, {}, { iss: null })],
    ['for a different audience (e.g. an anon/service token)', async () => sign(es, {}, { aud: 'anon' })],
    ['with no audience', async () => sign(es, {}, { aud: null })],
    ['tampered after signing', async () => { const [h, , s] = (await sign(es)).split('.'); return `${h}.${Buffer.from('{"sub":"admin"}').toString('base64url')}.${s}`; }],
  ])('rejects a token %s', async (_label, make) => {
    await expect(service.verify(await make())).rejects.toBeInstanceOf(UnauthorizedException);
  });

  it('is not fooled by algorithm confusion: an HS256 token "signed" with the PUBLIC key is refused', async () => {
    // Classic attack: take the published public key, use its bytes as an HMAC secret, claim HS256.
    const publicKeyAsSecret = JSON.stringify(es.publicJwk);
    const forged = jsonwebtoken.sign({ sub: 'admin', iss: ISSUER, aud: AUDIENCE }, publicKeyAsSecret, { algorithm: 'HS256' });
    await expect(service.verify(forged)).rejects.toBeInstanceOf(UnauthorizedException);
    // Even if a legacy secret IS configured, the forged token must not pass: it is verified with the
    // secret only, never with a JWKS key.
    const both = new JwtVerificationService({ jwksUrl: jwks.url, legacySecret: SECRET, issuer: ISSUER, audience: AUDIENCE });
    await expect(both.verify(forged)).rejects.toBeInstanceOf(UnauthorizedException);
  });

  it('refuses an asymmetric token when no JWKS endpoint is configured', async () => {
    const onlyLegacy = new JwtVerificationService({ legacySecret: SECRET });
    await expect(onlyLegacy.verify(await sign(es))).rejects.toBeInstanceOf(UnauthorizedException);
  });

  it('serves legacy and asymmetric tokens side by side (a project mid-migration)', async () => {
    const both = new JwtVerificationService({ jwksUrl: jwks.url, legacySecret: SECRET, issuer: ISSUER, audience: AUDIENCE });
    const legacy = jsonwebtoken.sign({ sub: 'legacy-user', iss: ISSUER, aud: AUDIENCE }, SECRET, { algorithm: 'HS256', expiresIn: '1h' });
    await expect(both.verify(legacy)).resolves.toMatchObject({ authUserId: 'legacy-user' });
    await expect(both.verify(await sign(es))).resolves.toMatchObject({ authUserId: 'auth-user-123' });
  });

  describe('when OUR side fails (key retrieval), the answer is 503 — not a false "your session is invalid"', () => {
    it('answers 503 when the JWKS endpoint returns an error', async () => {
      const fresh = new JwtVerificationService({ jwksUrl: jwks.url, issuer: ISSUER, audience: AUDIENCE });
      jwks.status = 500;
      await expect(fresh.verify(await sign(es))).rejects.toBeInstanceOf(ServiceUnavailableException);
    });

    it('answers 503 when the JWKS endpoint is unreachable', async () => {
      const unreachable = new JwtVerificationService({ jwksUrl: 'http://127.0.0.1:1/jwks.json', issuer: ISSUER, audience: AUDIENCE });
      await expect(unreachable.verify(await sign(es))).rejects.toBeInstanceOf(ServiceUnavailableException);
    });

    it('recovers by itself once the endpoint is healthy again', async () => {
      const fresh = new JwtVerificationService({ jwksUrl: jwks.url, issuer: ISSUER, audience: AUDIENCE });
      jwks.status = 500;
      await expect(fresh.verify(await sign(es))).rejects.toBeInstanceOf(ServiceUnavailableException);
      jwks.status = 200;
      await expect(fresh.verify(await sign(es))).resolves.toBeDefined();
    });
  });

  it('logs WHY a token was rejected (for operators) without ever logging the token', async () => {
    const warn = Logger.prototype.warn as jest.Mock;
    const token = await sign(es, {}, { iss: 'https://attacker.example.test/auth/v1' });
    await service.verify(token).catch(() => undefined);
    const logged = warn.mock.calls.map((c) => String(c[0])).join('\n');
    expect(logged).toContain('claim "iss"');
    expect(logged).not.toContain(token);
    expect(logged).not.toContain(token.split('.')[1]);
  });
});
