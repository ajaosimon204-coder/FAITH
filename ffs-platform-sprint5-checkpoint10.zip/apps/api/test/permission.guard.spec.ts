import { ExecutionContext, ForbiddenException } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { PermissionGuard } from '../src/modules/rbac/permission.guard';
import { ResolvedIdentity } from '../src/modules/identity/identity.types';

function buildIdentity(overrides: Partial<ResolvedIdentity> = {}): ResolvedIdentity {
  return {
    authUserId: 'auth-1',
    appUserId: 'user-1',
    email: 'admin@ffs.example',
    status: 'active',
    campusId: 'campus-1',
    organizationId: 'org-1',
    roles: ['school_administrator'],
    permissions: ['rbac.manage'],
    ...overrides,
  };
}

function buildContext(params: {
  identity: ResolvedIdentity | undefined;
  routeParams?: Record<string, string>;
  required?: string[];
}): ExecutionContext {
  const request = { identity: params.identity, params: params.routeParams ?? {} };

  return {
    switchToHttp: () => ({ getRequest: () => request }),
    getHandler: () => ({}),
    getClass: () => ({}),
  } as unknown as ExecutionContext;
}

describe('PermissionGuard', () => {
  function makeReflector(required?: string[]): Reflector {
    return {
      getAllAndOverride: () => required,
    } as unknown as Reflector;
  }

  it('allows a request when no permissions are required', () => {
    const guard = new PermissionGuard(makeReflector(undefined));
    const context = buildContext({ identity: buildIdentity() });
    expect(guard.canActivate(context)).toBe(true);
  });

  it('allows a request when the caller holds the required permission', () => {
    const guard = new PermissionGuard(makeReflector(['rbac.manage']));
    const context = buildContext({ identity: buildIdentity() });
    expect(guard.canActivate(context)).toBe(true);
  });

  it('denies a request when the caller lacks the required permission', () => {
    const guard = new PermissionGuard(makeReflector(['audit.read']));
    const context = buildContext({
      identity: buildIdentity({ permissions: ['organizations.read'] }),
    });
    expect(() => guard.canActivate(context)).toThrow(ForbiddenException);
  });

  it('denies a request with no resolved identity at all (defense in depth)', () => {
    const guard = new PermissionGuard(makeReflector(['rbac.manage']));
    const context = buildContext({ identity: undefined });
    expect(() => guard.canActivate(context)).toThrow(ForbiddenException);
  });

  it('denies cross-tenant access when a route campusId does not match the caller campus (IDOR guard)', () => {
    const guard = new PermissionGuard(makeReflector(['rbac.manage']));
    const context = buildContext({
      identity: buildIdentity({ campusId: 'campus-1' }),
      routeParams: { campusId: 'campus-2' },
    });
    expect(() => guard.canActivate(context)).toThrow(ForbiddenException);
  });

  it('allows access when the route campusId matches the caller campus', () => {
    const guard = new PermissionGuard(makeReflector(['rbac.manage']));
    const context = buildContext({
      identity: buildIdentity({ campusId: 'campus-1' }),
      routeParams: { campusId: 'campus-1' },
    });
    expect(guard.canActivate(context)).toBe(true);
  });
});
