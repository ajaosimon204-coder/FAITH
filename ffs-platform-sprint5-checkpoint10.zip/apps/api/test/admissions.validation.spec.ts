import { BadRequestException } from '@nestjs/common';
import { SubmitApplicationInput } from '../src/modules/admissions/admissions.types';
import {
  cleanNote,
  isUuid,
  MAX_DOCUMENTS_PER_APPLICATION,
  MAX_NOTE_LENGTH,
  validateSubmission,
} from '../src/modules/admissions/admissions.validation';

const NOW = new Date('2026-11-17T12:00:00Z');
const CAMPUS = '11111111-1111-4111-8111-111111111111';
const DEFINITION = '22222222-2222-4222-8222-222222222222';

function input(overrides: Partial<SubmitApplicationInput> = {}): SubmitApplicationInput {
  return {
    campusId: CAMPUS,
    applicantFirstName: 'Ada',
    applicantLastName: 'Obi',
    applicantDateOfBirth: '2014-05-05',
    applicantGender: 'female',
    classDefinitionId: DEFINITION,
    guardianFirstName: 'Ngozi',
    guardianLastName: 'Obi',
    guardianEmail: 'parent@example.test',
    guardianPhone: '08031234567',
    documents: [],
    ...overrides,
  };
}

function errorsOf(overrides: Partial<SubmitApplicationInput>): string[] {
  try {
    validateSubmission(input(overrides), NOW);
  } catch (e) {
    expect(e).toBeInstanceOf(BadRequestException);
    return ((e as BadRequestException).getResponse() as { message: string[] }).message;
  }
  throw new Error('expected validation to fail');
}

describe('validateSubmission — normalisation', () => {
  it('trims, collapses whitespace, lower-cases the email and gender, and strips phone formatting', () => {
    const result = validateSubmission(
      input({
        applicantFirstName: '  Ada   Grace ',
        applicantLastName: ' Obi ',
        applicantGender: ' FEMALE ',
        guardianEmail: '  Parent@Example.TEST ',
        guardianPhone: '+234 (803) 123-4567',
      }),
      NOW,
    );
    expect(result).toMatchObject({
      applicantFirstName: 'Ada Grace',
      applicantLastName: 'Obi',
      applicantGender: 'female',
      guardianEmail: 'parent@example.test',
      guardianPhone: '+2348031234567',
    });
  });

  it('accepts non-ASCII names', () => {
    expect(() => validateSubmission(input({ applicantFirstName: 'Chukwuemeka', applicantLastName: 'Ọkọ-Eze' }), NOW)).not.toThrow();
  });

  it('treats gender, email or phone as optional individually, but needs one guardian contact', () => {
    const result = validateSubmission(input({ applicantGender: null, guardianEmail: null }), NOW);
    expect(result.applicantGender).toBeNull();
    expect(result.guardianEmail).toBeNull();
    expect(result.guardianPhone).toBe('08031234567');
  });

  it('accepts an applicant born today and one exactly at the age limit', () => {
    expect(() => validateSubmission(input({ applicantDateOfBirth: '2026-11-17' }), NOW)).not.toThrow();
    expect(() => validateSubmission(input({ applicantDateOfBirth: '2001-11-17' }), NOW)).not.toThrow();
  });
});

describe('validateSubmission — rejections', () => {
  it.each<[string, Partial<SubmitApplicationInput>, string]>([
    ['a malformed campus id', { campusId: 'not-an-id' }, 'campusId must be a valid id.'],
    ['a malformed class level id', { classDefinitionId: '123' }, 'classDefinitionId must be a valid id.'],
    ['an empty applicant first name', { applicantFirstName: '   ' }, 'Applicant first name is required.'],
    ['an over-long applicant last name', { applicantLastName: 'x'.repeat(101) }, 'Applicant last name must be at most 100 characters.'],
    ['a name with no letters', { guardianFirstName: '12345' }, 'Guardian first name must contain at least one letter.'],
    ['a non-ISO date of birth', { applicantDateOfBirth: '05/05/2014' }, 'Applicant date of birth must be a date in YYYY-MM-DD form.'],
    ['an impossible calendar date', { applicantDateOfBirth: '2014-02-30' }, 'Applicant date of birth is not a real calendar date.'],
    ['a date of birth in the future', { applicantDateOfBirth: '2026-11-18' }, 'Applicant date of birth cannot be in the future.'],
    ['an applicant older than the limit', { applicantDateOfBirth: '2001-11-16' }, 'Applicant must be at most 25 years old.'],
    ['an unknown gender', { applicantGender: 'robot' }, 'Applicant gender must be one of: female, male.'],
    ['an invalid email', { guardianEmail: 'not-an-email' }, 'Guardian email is not a valid email address.'],
    ['an invalid phone number', { guardianPhone: '12-ab' }, 'Guardian phone must be 7 to 15 digits, optionally starting with +.'],
    [
      'no guardian contact at all',
      { guardianEmail: null, guardianPhone: null },
      'A guardian email or phone number is required so the school can reach the family.',
    ],
  ])('rejects %s', (_label, overrides, expected) => {
    expect(errorsOf(overrides)).toContain(expected);
  });

  it('reports every problem in one pass, not just the first', () => {
    const messages = errorsOf({ applicantFirstName: '', applicantDateOfBirth: 'nope', guardianEmail: 'x', guardianPhone: null });
    expect(messages.length).toBeGreaterThanOrEqual(3);
  });
});

describe('validateSubmission — documents', () => {
  const good = { docType: 'birth_certificate', fileUrl: 'https://files.example.test/a.pdf' };

  it('accepts up to the maximum number of https documents', () => {
    const docs = Array.from({ length: MAX_DOCUMENTS_PER_APPLICATION }, () => good);
    expect(validateSubmission(input({ documents: docs }), NOW).documents).toHaveLength(MAX_DOCUMENTS_PER_APPLICATION);
  });

  it('rejects too many documents', () => {
    const docs = Array.from({ length: MAX_DOCUMENTS_PER_APPLICATION + 1 }, () => good);
    expect(errorsOf({ documents: docs })).toContain(`At most ${MAX_DOCUMENTS_PER_APPLICATION} documents may be attached.`);
  });

  it.each([
    ['a plain http URL', 'http://files.example.test/a.pdf'],
    ['a javascript: URL', 'javascript:alert(1)'],
    ['a URL with embedded credentials', 'https://user:pass@files.example.test/a.pdf'],
    ['text that is not a URL', 'not a url'],
    ['an empty URL', ''],
    ['an over-long URL', `https://files.example.test/${'a'.repeat(2100)}`],
  ])('rejects %s', (_label, fileUrl) => {
    expect(errorsOf({ documents: [{ docType: 'x', fileUrl }] })).toContain(
      'Document 1: file URL must be a valid https URL (at most 2048 characters) without credentials.',
    );
  });

  it('rejects a document with no type, and numbers the offending document', () => {
    expect(errorsOf({ documents: [good, { docType: '', fileUrl: good.fileUrl }] })).toContain(
      'Document 2: type is required (at most 50 characters).',
    );
  });

  it('rejects documents that are not a list', () => {
    expect(errorsOf({ documents: 'nope' as unknown as SubmitApplicationInput['documents'] })).toContain(
      'documents must be a list.',
    );
  });
});

describe('cleanNote', () => {
  it('trims and returns the text', () => {
    expect(cleanNote('Notes', '  hello ', false)).toBe('hello');
  });
  it('returns null for empty optional text', () => {
    expect(cleanNote('Notes', '   ', false)).toBeNull();
    expect(cleanNote('Notes', undefined, false)).toBeNull();
  });
  it('rejects empty required text', () => {
    expect(() => cleanNote('A decision reason', '  ', true)).toThrow('A decision reason is required.');
  });
  it('rejects over-long text', () => {
    expect(() => cleanNote('Notes', 'x'.repeat(MAX_NOTE_LENGTH + 1), false)).toThrow(BadRequestException);
  });
});

describe('isUuid', () => {
  it('accepts a UUID and rejects everything else', () => {
    expect(isUuid(CAMPUS)).toBe(true);
    expect(isUuid('abc')).toBe(false);
    expect(isUuid(undefined)).toBe(false);
    expect(isUuid(42)).toBe(false);
  });
});
