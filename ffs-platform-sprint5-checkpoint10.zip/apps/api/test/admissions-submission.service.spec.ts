import { BadRequestException, Logger } from '@nestjs/common';
import { AdmissionsRuleViolationError } from '../src/modules/admissions/admissions.repository';
import { AdmissionsSubmissionService } from '../src/modules/admissions/admissions-submission.service';
import { SubmitApplicationInput } from '../src/modules/admissions/admissions.types';
import { FakeAdmissionsRepository } from './fakes/fake-admissions.repository';

const CAMPUS_A = '11111111-1111-4111-8111-111111111111';
const CAMPUS_B = '99999999-9999-4999-8999-999999999999';
const DEF_A = '22222222-2222-4222-8222-222222222222';
const DEF_B = '88888888-8888-4888-8888-888888888888';
const NOW = new Date('2026-11-17T12:00:00Z');

function form(overrides: Partial<SubmitApplicationInput> = {}): SubmitApplicationInput {
  return {
    campusId: CAMPUS_A,
    applicantFirstName: 'Ada',
    applicantLastName: 'Obi',
    applicantDateOfBirth: '2014-05-05',
    applicantGender: 'female',
    classDefinitionId: DEF_A,
    guardianFirstName: 'Ngozi',
    guardianLastName: 'Obi',
    guardianEmail: 'Parent@Example.test',
    guardianPhone: null,
    documents: [],
    ...overrides,
  };
}

describe('AdmissionsSubmissionService', () => {
  let repo: FakeAdmissionsRepository;
  let service: AdmissionsSubmissionService;

  beforeEach(() => {
    repo = new FakeAdmissionsRepository();
    repo.classDefinitions.push({ id: DEF_A, campusId: CAMPUS_A }, { id: DEF_B, campusId: CAMPUS_B });
    service = new AdmissionsSubmissionService(repo, () => NOW);
    jest.spyOn(Logger.prototype, 'warn').mockImplementation(() => undefined);
  });

  afterEach(() => jest.restoreAllMocks());

  it('stores a normalised, submitted application and returns a minimal receipt', async () => {
    const receipt = await service.submit(
      form({ applicantFirstName: '  Ada ', documents: [{ docType: 'birth_certificate', fileUrl: 'https://files.example.test/a.pdf' }] }),
    );

    expect(receipt).toEqual({
      applicationId: repo.applications[0].id,
      referenceNo: repo.applications[0].referenceNo,
      submittedAt: repo.applications[0].submittedAt,
      documentsRequested: 1,
      documentsStored: 1,
    });
    expect(repo.applications[0]).toMatchObject({
      status: 'submitted',
      applicantFirstName: 'Ada',
      guardianEmail: 'parent@example.test',
      possibleDuplicateOf: null,
    });
    expect(repo.documents).toHaveLength(1);
  });

  it('exposes nothing beyond the receipt fields — in particular never the duplicate flag', async () => {
    await service.submit(form());
    const receipt = await service.submit(form());
    expect(Object.keys(receipt).sort()).toEqual(
      ['applicationId', 'documentsRequested', 'documentsStored', 'referenceNo', 'submittedAt'],
    );
    expect(JSON.stringify(receipt)).not.toContain(repo.applications[0].id);
  });

  describe('validation happens before anything is stored', () => {
    it('rejects invalid input with one 400 and writes nothing', async () => {
      await expect(service.submit(form({ applicantFirstName: '', guardianEmail: 'nope' }))).rejects.toBeInstanceOf(
        BadRequestException,
      );
      expect(repo.applications).toHaveLength(0);
    });

    it('uses the injected clock for the date rules', async () => {
      await expect(service.submit(form({ applicantDateOfBirth: '2026-11-18' }))).rejects.toBeInstanceOf(BadRequestException);
      await expect(service.submit(form({ applicantDateOfBirth: '2026-11-17' }))).resolves.toBeDefined();
    });
  });

  describe('class level checks', () => {
    it('rejects a level that belongs to another campus', async () => {
      await expect(service.submit(form({ classDefinitionId: DEF_B }))).rejects.toThrow(
        'The selected class level is not available for this campus.',
      );
      expect(repo.applications).toHaveLength(0);
    });

    it('answers a level that does not exist exactly like one from another campus (no probing)', async () => {
      const missing = service.submit(form({ classDefinitionId: '33333333-3333-4333-8333-333333333333' }));
      const otherCampus = service.submit(form({ classDefinitionId: DEF_B }));
      const [a, b] = await Promise.allSettled([missing, otherCampus]);
      expect(a.status).toBe('rejected');
      expect(b.status).toBe('rejected');
      expect((a as PromiseRejectedResult).reason.message).toBe((b as PromiseRejectedResult).reason.message);
    });
  });

  describe('duplicate detection', () => {
    it('flags a possible duplicate (case-insensitive) but still accepts the application', async () => {
      await service.submit(form());
      await service.submit(form({ applicantFirstName: 'ADA', applicantLastName: 'obi' }));
      expect(repo.applications).toHaveLength(2);
      expect(repo.applications[1].possibleDuplicateOf).toBe(repo.applications[0].id);
    });

    it('does not flag a different date of birth or a different campus', async () => {
      await service.submit(form());
      await service.submit(form({ applicantDateOfBirth: '2014-05-06' }));
      repo.classDefinitions.push({ id: DEF_B, campusId: CAMPUS_B });
      await service.submit(form({ campusId: CAMPUS_B, classDefinitionId: DEF_B }));
      expect(repo.applications.every((a) => a.possibleDuplicateOf === null)).toBe(true);
    });
  });

  describe('documents are attached after the application exists', () => {
    const docs = [
      { docType: 'birth_certificate', fileUrl: 'https://files.example.test/1.pdf' },
      { docType: 'report_card', fileUrl: 'https://files.example.test/2.pdf' },
      { docType: 'photo', fileUrl: 'https://files.example.test/3.jpg' },
    ];

    it('keeps the application and reports honestly when one document fails to attach', async () => {
      const original = repo.addDocument.bind(repo);
      jest.spyOn(repo, 'addDocument').mockImplementation(async (input) => {
        if (input.docType === 'report_card') throw new Error('storage unavailable');
        return original(input);
      });

      const receipt = await service.submit(form({ documents: docs }));

      expect(repo.applications).toHaveLength(1);
      expect(receipt.documentsRequested).toBe(3);
      expect(receipt.documentsStored).toBe(2);
      expect(repo.documents.map((d) => d.docType)).toEqual(['birth_certificate', 'photo']);
      expect(Logger.prototype.warn).toHaveBeenCalledTimes(1);
    });

    it('stores no documents and still succeeds when none were supplied', async () => {
      const receipt = await service.submit(form({ documents: undefined }));
      expect(receipt.documentsRequested).toBe(0);
      expect(receipt.documentsStored).toBe(0);
    });
  });

  describe('failures while creating the application', () => {
    it('turns a database rule rejection (a race on the level) into a 400 for the applicant', async () => {
      jest.spyOn(repo, 'createApplication').mockRejectedValueOnce(new AdmissionsRuleViolationError('class_definition gone'));
      await expect(service.submit(form())).rejects.toThrow(
        'The application could not be accepted. Please check the form and try again.',
      );
    });

    it('lets a genuine server fault propagate (it must be a 500, not a misleading 400)', async () => {
      jest.spyOn(repo, 'createApplication').mockRejectedValueOnce(new Error('connection reset'));
      const attempt = service.submit(form());
      await expect(attempt).rejects.toThrow('connection reset');
      await expect(attempt).rejects.not.toBeInstanceOf(BadRequestException);
    });
  });
});
