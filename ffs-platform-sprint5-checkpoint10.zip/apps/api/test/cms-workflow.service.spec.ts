import { BadRequestException, ForbiddenException } from '@nestjs/common';
import { CmsContentWorkflowService } from '../src/modules/cms/cms-workflow.service';
import { ResolvedIdentity } from '../src/modules/identity/identity.types';
import { CmsPage } from '../src/modules/cms/cms.types';
import { FakeCmsPagesRepository } from './fakes/fake-cms.repository';

function buildIdentity(overrides: Partial<ResolvedIdentity> = {}): ResolvedIdentity {
  return {
    authUserId: 'auth-1',
    appUserId: 'user-1',
    email: 'editor@ffs.example',
    status: 'active',
    campusId: 'campus-1',
    organizationId: 'org-1',
    roles: ['content_editor'],
    permissions: ['content.create'],
    ...overrides,
  };
}

/**
 * This suite exercises CmsContentWorkflowService — the ONE place workflow
 * business logic lives for all four CMS content types (pages, news,
 * gallery, staff profiles). Testing it once here, against a fake
 * satisfying only the shared ICmsContentRepository interface, covers the
 * business logic that would otherwise need re-testing per content type.
 */
describe('CmsContentWorkflowService', () => {
  let repository: FakeCmsPagesRepository;
  let workflow: CmsContentWorkflowService<CmsPage>;

  beforeEach(() => {
    repository = new FakeCmsPagesRepository();
    workflow = new CmsContentWorkflowService(repository, 'cms_pages');
  });

  function createDraft(): CmsPage {
    return repository.create({
      campusId: 'campus-1',
      slug: 'about-us',
      title: 'About Us',
      contentJson: [],
      createdBy: 'user-1',
    });
  }

  describe('the full happy-path workflow', () => {
    it('moves draft -> in_review -> approved -> published -> archived, with the right actor field set at each step', async () => {
      const page = createDraft();
      const editor = buildIdentity({ permissions: ['content.create'] });
      const reviewer = buildIdentity({
        appUserId: 'user-reviewer',
        permissions: ['content.review'],
      });
      const publisher = buildIdentity({
        appUserId: 'user-publisher',
        permissions: ['content.publish'],
      });
      const archiver = buildIdentity({
        appUserId: 'user-archiver',
        permissions: ['content.archive'],
      });

      const submitted = await workflow.submitForReview(editor, page.id);
      expect(submitted.status).toBe('in_review');

      const approved = await workflow.approve(reviewer, page.id);
      expect(approved.status).toBe('approved');
      expect(approved.reviewedBy).toBe('user-reviewer');

      const published = await workflow.publish(publisher, page.id);
      expect(published.status).toBe('published');
      expect(published.publishedBy).toBe('user-publisher');

      const archived = await workflow.archive(archiver, page.id);
      expect(archived.status).toBe('archived');

      expect(repository.auditEntries).toHaveLength(4);
    });
  });

  describe('reject-back paths', () => {
    it('allows content.review to reject in_review back to draft', async () => {
      const page = createDraft();
      const editor = buildIdentity();
      const reviewer = buildIdentity({ permissions: ['content.review'] });

      await workflow.submitForReview(editor, page.id);
      const rejected = await workflow.rejectToDraft(reviewer, page.id);

      expect(rejected.status).toBe('draft');
    });

    it('requires content.publish (not content.review) to reject an already-approved item back to draft', async () => {
      const page = createDraft();
      const editor = buildIdentity();
      const reviewer = buildIdentity({ permissions: ['content.review'] });
      const publisherTier = buildIdentity({ permissions: ['content.publish'] });

      await workflow.submitForReview(editor, page.id);
      await workflow.approve(reviewer, page.id);

      // A reviewer alone cannot reject a late-caught issue post-approval —
      // that's a publish-tier decision (mirrors the approved architecture's
      // "unlock" pattern for locked results being a higher-privilege action).
      await expect(workflow.rejectToDraft(reviewer, page.id)).rejects.toThrow(ForbiddenException);

      const rejected = await workflow.rejectToDraft(publisherTier, page.id);
      expect(rejected.status).toBe('draft');
    });
  });

  describe('permission enforcement per transition', () => {
    it('denies submitForReview for an actor without content.create', async () => {
      const page = createDraft();
      const noPermission = buildIdentity({ permissions: [] });

      await expect(workflow.submitForReview(noPermission, page.id)).rejects.toThrow(
        ForbiddenException,
      );
    });

    it('denies approve for an actor holding only content.create (not content.review)', async () => {
      const page = createDraft();
      const editor = buildIdentity();
      await workflow.submitForReview(editor, page.id);

      await expect(workflow.approve(editor, page.id)).rejects.toThrow(ForbiddenException);
    });

    it('denies publish for an actor holding only content.review (not content.publish) — the narrow-publish requirement', async () => {
      const page = createDraft();
      const editor = buildIdentity();
      const reviewer = buildIdentity({ permissions: ['content.review'] });

      await workflow.submitForReview(editor, page.id);
      await workflow.approve(reviewer, page.id);

      // This is the architecture's explicit requirement: "do not make
      // every administrator automatically capable of publishing
      // public-facing content."
      await expect(workflow.publish(reviewer, page.id)).rejects.toThrow(ForbiddenException);
    });

    it('denies archive for an actor without content.archive', async () => {
      const page = createDraft();
      const editor = buildIdentity();
      const reviewer = buildIdentity({ permissions: ['content.review'] });
      const publisher = buildIdentity({ permissions: ['content.publish'] });

      await workflow.submitForReview(editor, page.id);
      await workflow.approve(reviewer, page.id);
      await workflow.publish(publisher, page.id);

      await expect(workflow.archive(publisher, page.id)).rejects.toThrow(ForbiddenException);
    });
  });

  describe('invalid transitions rejected regardless of permission', () => {
    it('rejects publishing straight from draft (skipping review/approval), even for a super-permissioned actor', async () => {
      const page = createDraft();
      const superUser = buildIdentity({
        permissions: ['content.create', 'content.review', 'content.publish', 'content.archive'],
      });

      await expect(workflow.publish(superUser, page.id)).rejects.toThrow(BadRequestException);
    });

    it('rejects archiving a draft directly', async () => {
      const page = createDraft();
      const superUser = buildIdentity({
        permissions: ['content.create', 'content.review', 'content.publish', 'content.archive'],
      });

      await expect(workflow.archive(superUser, page.id)).rejects.toThrow(BadRequestException);
    });

    it('rejects re-approving an already-published item (archived is the only forward path from published)', async () => {
      const page = createDraft();
      const editor = buildIdentity();
      const reviewer = buildIdentity({ permissions: ['content.review'] });
      const publisher = buildIdentity({ permissions: ['content.publish'] });

      await workflow.submitForReview(editor, page.id);
      await workflow.approve(reviewer, page.id);
      await workflow.publish(publisher, page.id);

      await expect(workflow.approve(reviewer, page.id)).rejects.toThrow(BadRequestException);
    });
  });

  describe('list', () => {
    it('scopes listing to the actor\'s own campus and optional status filter', async () => {
      repository.create({
        campusId: 'campus-1',
        slug: 'a',
        title: 'A',
        contentJson: [],
        createdBy: 'user-1',
      });
      repository.create({
        campusId: 'campus-2',
        slug: 'b',
        title: 'B',
        contentJson: [],
        createdBy: 'user-2',
      });

      const actor = buildIdentity({ campusId: 'campus-1' });
      const results = await workflow.list(actor);

      expect(results).toHaveLength(1);
      expect(results[0].slug).toBe('a');
    });

    it('denies listing entirely for an actor with NO content.* permission at all (Sprint 4 audit, High finding)', async () => {
      // Before this fix, list() had no permission check whatsoever — any
      // authenticated user, any role (student, parent, unrelated staff),
      // could enumerate draft/in_review/approved/archived content for
      // their own campus. This is the authenticated App Backend route,
      // not the separate public route — public consumption goes through
      // getPublishedBySlug's own explicit status filter instead.
      repository.create({
        campusId: 'campus-1',
        slug: 'secret-draft',
        title: 'Secret',
        contentJson: [],
        createdBy: 'user-1',
      });

      const actor = buildIdentity({ campusId: 'campus-1', permissions: [] });

      await expect(workflow.list(actor)).rejects.toThrow(ForbiddenException);
    });

    it('allows listing for an actor holding ANY single content.* permission, not just content.create', async () => {
      repository.create({
        campusId: 'campus-1',
        slug: 'reviewable',
        title: 'Reviewable',
        contentJson: [],
        createdBy: 'user-1',
      });

      const reviewerOnly = buildIdentity({
        campusId: 'campus-1',
        permissions: ['content.review'],
      });

      await expect(workflow.list(reviewerOnly)).resolves.toHaveLength(1);
    });
  });

  describe('cross-campus IDOR protection (Sprint 4, found and fixed proactively per ADR-014)', () => {
    it('refuses to transition a record belonging to a DIFFERENT campus, even for a fully-permissioned actor', async () => {
      // This repository uses the service-role connection and bypasses RLS
      // entirely — before this fix, requireRecord() looked a record up by
      // id alone with no campus check at all, meaning an actor holding
      // content.publish in Campus A could transition a page belonging to
      // Campus B purely by knowing/guessing its id. Same class of gap as
      // the EnrollmentService/ClassesService findings in the Sprint 3
      // re-audit — applied here proactively before it shipped, per that
      // audit's own recommendation.
      const otherCampusPage = repository.create({
        campusId: 'campus-2',
        slug: 'campus-2-page',
        title: 'Campus 2 Page',
        contentJson: [],
        createdBy: 'user-2',
      });

      const actor = buildIdentity({
        campusId: 'campus-1',
        permissions: ['content.create', 'content.review', 'content.publish', 'content.archive'],
      });

      await expect(workflow.submitForReview(actor, otherCampusPage.id)).rejects.toThrow(
        BadRequestException,
      );

      // Confirm it's a true no-op, not a partial state change.
      const unchanged = await repository.findById(otherCampusPage.id);
      expect(unchanged?.status).toBe('draft');
      expect(repository.auditEntries).toHaveLength(0);
    });

    it('does not leak whether a cross-campus record exists vs. does not exist (same error either way)', async () => {
      const otherCampusPage = repository.create({
        campusId: 'campus-2',
        slug: 'campus-2-page',
        title: 'Campus 2 Page',
        contentJson: [],
        createdBy: 'user-2',
      });
      const actor = buildIdentity({ campusId: 'campus-1', permissions: ['content.create'] });

      let crossCampusError: unknown;
      let nonexistentError: unknown;
      try {
        await workflow.submitForReview(actor, otherCampusPage.id);
      } catch (e) {
        crossCampusError = e;
      }
      try {
        await workflow.submitForReview(actor, 'totally-made-up-id');
      } catch (e) {
        nonexistentError = e;
      }

      // Both cases use the identical exception type and generic "not
      // found" phrasing (the id itself is legitimately echoed back in
      // both, which isn't a leak — the caller already knows the id they
      // sent). What matters for IDOR-safety is that there's no DIFFERENT
      // message (e.g. "exists but wrong campus") that would confirm a
      // cross-campus record's existence.
      expect(crossCampusError).toBeInstanceOf(BadRequestException);
      expect(nonexistentError).toBeInstanceOf(BadRequestException);
      expect((crossCampusError as Error).message).toMatch(/not found\.$/);
      expect((nonexistentError as Error).message).toMatch(/not found\.$/);
    });
  });
});
