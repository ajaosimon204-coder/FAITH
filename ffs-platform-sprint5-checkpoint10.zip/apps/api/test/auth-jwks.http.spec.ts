import { INestApplication } from '@nestjs/common';
import { NestExpressApplication } from '@nestjs/platform-express';
import { APP_GUARD } from '@nestjs/core';
import { Test } from '@nestjs/testing';
import * as jsonwebtoken from 'jsonwebtoken';
import request from 'supertest';
import { configureApp } from '../src/app.setup';
import { ADMISSIONS_REPOSITORY, AdmissionsModule } from '../src/modules/admissions/admissions.module';
import { ADMISSIONS_PERMISSIONS } from '../src/modules/admissions/admissions.types';
import { IdentityResolutionService } from '../src/modules/identity/identity-resolution.service';
import { JwtVerificationService } from '../src/modules/identity/jwt-verification.service';
import { SupabaseAuthGuard } from '../src/modules/identity/supabase-auth.guard';
import { FakeAdmissionsRepository } from './fakes/fake-admissions.repository';
import { FakeIdentityRepository } from './fakes/fake-identity.repository';
import { AUDIENCE, ISSUER, JwksServer, makeSigner, sign, Signer } from './helpers/jwks';

/**
 * A CURRENT Supabase project signs login tokens with asymmetric keys. This drives the real global auth
 * guard, identity resolution and a real staff route with such tokens, against a real local JWKS endpoint.
 */
describe('staff routes with asymmetric (JWKS-signed) tokens', () => {
  const jwks = new JwksServer();
  let signer: Signer;
  let app: INestApplication;

  beforeAll(async () => {
    await jwks.start();
    signer = await makeSigner('prod-key-1', 'ES256');
    jwks.keys = [signer.publicJwk];
  });
  afterAll(() => jwks.stop());

  async function boot(options: { legacySecret?: string } = {}) {
    const identityRepo = new FakeIdentityRepository();
    identityRepo.rolePermissions = { school_administrator: [ADMISSIONS_PERMISSIONS.APPLICATIONS_READ] };
    identityRepo.users.push({
      appUserId: 'user-1', authUserId: 'auth-user-123', email: 'parent@example.com', status: 'active',
      campusId: '11111111-1111-4111-8111-111111111111', organizationId: 'org-1',
    });
    identityRepo.userRoles.push({ appUserId: 'user-1', roleKey: 'school_administrator', campusId: '11111111-1111-4111-8111-111111111111' });

    const moduleRef = await Test.createTestingModule({
      imports: [AdmissionsModule],
      providers: [
        {
          provide: IdentityResolutionService,
          useValue: new IdentityResolutionService(
            new JwtVerificationService({ jwksUrl: jwks.url, issuer: ISSUER, audience: AUDIENCE, ...options }),
            identityRepo,
          ),
        },
        { provide: APP_GUARD, useClass: SupabaseAuthGuard },
      ],
    })
      .overrideProvider(ADMISSIONS_REPOSITORY)
      .useValue(new FakeAdmissionsRepository())
      .compile();
    const nest = moduleRef.createNestApplication<NestExpressApplication>();
    configureApp(nest, {});
    await nest.init();
    return nest;
  }

  afterEach(async () => {
    jwks.status = 200;
    await app?.close();
  });

  const list = () => request(app.getHttpServer()).get('/api/v1/admissions/applications');

  it('a staff member signed in with an ES256 token is authenticated, resolved and authorised', async () => {
    app = await boot();
    await list().set('Authorization', `Bearer ${await sign(signer)}`).expect(200);
  });

  it('a token signed by a key the project does not publish is a 401', async () => {
    app = await boot();
    const stranger = await makeSigner('prod-key-1', 'ES256');
    await list().set('Authorization', `Bearer ${await sign(stranger)}`).expect(401);
  });

  it('a token for the wrong audience (e.g. the anonymous key) is a 401', async () => {
    app = await boot();
    await list().set('Authorization', `Bearer ${await sign(signer, {}, { aud: 'anon' })}`).expect(401);
  });

  it('a legacy HS256 token is refused when the project has no legacy secret configured', async () => {
    app = await boot();
    const legacy = jsonwebtoken.sign({ sub: 'auth-user-123', iss: ISSUER, aud: AUDIENCE }, 'old-secret', { algorithm: 'HS256' });
    await list().set('Authorization', `Bearer ${legacy}`).expect(401);
  });

  it('a key-retrieval outage is a 503 (service problem), not a 401 (blaming the user)', async () => {
    app = await boot();
    jwks.status = 500;
    // A key the verifier has never fetched forces a fetch, which now fails.
    const fresh = await makeSigner('brand-new-key', 'ES256');
    await list().set('Authorization', `Bearer ${await sign(fresh)}`).expect(503);
  });
});
