import { BadRequestException, ConflictException, ForbiddenException, NotFoundException } from '@nestjs/common';
import { AdmissionsRuleViolationError } from '../src/modules/admissions/admissions.repository';
import { AdmissionsReviewService } from '../src/modules/admissions/admissions-review.service';
import { ADMISSIONS_PERMISSIONS, Application } from '../src/modules/admissions/admissions.types';
import { ResolvedIdentity } from '../src/modules/identity/identity.types';
import { FakeAdmissionsRepository } from './fakes/fake-admissions.repository';

const CAMPUS_A = '11111111-1111-4111-8111-111111111111';
const CAMPUS_B = '99999999-9999-4999-8999-999999999999';
const DEF_JSS1 = '22222222-2222-4222-8222-222222222222';
const DEF_SS1 = '33333333-3333-4333-8333-333333333333';
const DEF_B = '88888888-8888-4888-8888-888888888888';
const CLASS_JSS1A = 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa1';
const CLASS_SS1A = 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa2';
const CLASS_B = 'aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaa3';

const { APPLICATIONS_READ: READ, APPLICATIONS_MANAGE: MANAGE } = ADMISSIONS_PERMISSIONS;

function identity(permissions: string[], overrides: Partial<ResolvedIdentity> = {}): ResolvedIdentity {
  return {
    authUserId: 'auth-1',
    appUserId: 'user-admin',
    email: 'admin@ffs.example',
    status: 'active',
    campusId: CAMPUS_A,
    organizationId: 'org-1',
    roles: ['school_administrator'],
    permissions,
    ...overrides,
  };
}

const manager = identity([READ, MANAGE]);
const reader = identity([READ], { appUserId: 'user-vp', roles: ['vice_principal'] });
const nobody = identity([], { appUserId: 'user-accountant', roles: ['accountant'] });

describe('AdmissionsReviewService', () => {
  let repo: FakeAdmissionsRepository;
  let service: AdmissionsReviewService;

  async function submit(overrides: Partial<Parameters<FakeAdmissionsRepository['createApplication']>[0]> = {}): Promise<Application> {
    return repo.createApplication({
      campusId: CAMPUS_A,
      applicantFirstName: 'Ada',
      applicantLastName: 'Obi',
      applicantDateOfBirth: '2014-05-05',
      applicantGender: 'female',
      classDefinitionId: DEF_JSS1,
      guardianFirstName: 'Ngozi',
      guardianLastName: 'Obi',
      guardianEmail: 'parent@example.test',
      guardianPhone: null,
      possibleDuplicateOf: null,
      ...overrides,
    });
  }

  async function approved(overrides = {}): Promise<Application> {
    const app = await submit(overrides);
    await service.startReview(manager, app.id);
    return service.approve(manager, app.id);
  }

  beforeEach(() => {
    repo = new FakeAdmissionsRepository();
    repo.classDefinitions.push(
      { id: DEF_JSS1, campusId: CAMPUS_A },
      { id: DEF_SS1, campusId: CAMPUS_A },
      { id: DEF_B, campusId: CAMPUS_B },
    );
    repo.classes.push(
      { id: CLASS_JSS1A, campusId: CAMPUS_A, classDefinitionId: DEF_JSS1 },
      { id: CLASS_SS1A, campusId: CAMPUS_A, classDefinitionId: DEF_SS1 },
      { id: CLASS_B, campusId: CAMPUS_B, classDefinitionId: DEF_B },
    );
    service = new AdmissionsReviewService(repo);
  });

  describe('permissions', () => {
    it('lets a reader view but not act', async () => {
      const app = await submit();
      await expect(service.list(reader)).resolves.toHaveLength(1);
      await expect(service.get(reader, app.id)).resolves.toBeDefined();
      await expect(service.startReview(reader, app.id)).rejects.toBeInstanceOf(ForbiddenException);
      await expect(service.convert(reader, app.id, CLASS_JSS1A)).rejects.toBeInstanceOf(ForbiddenException);
    });

    it('refuses an actor with no admissions permission everything', async () => {
      const app = await submit();
      await expect(service.list(nobody)).rejects.toBeInstanceOf(ForbiddenException);
      await expect(service.get(nobody, app.id)).rejects.toBeInstanceOf(ForbiddenException);
      await expect(service.approve(nobody, app.id)).rejects.toBeInstanceOf(ForbiddenException);
      await expect(service.convert(nobody, app.id, CLASS_JSS1A)).rejects.toBeInstanceOf(ForbiddenException);
    });

    it('treats manage alone as sufficient to view', async () => {
      await submit();
      await expect(service.list(identity([MANAGE]))).resolves.toHaveLength(1);
    });

    it('checks permission before anything else — a forbidden actor learns nothing about the application', async () => {
      await expect(service.get(nobody, 'not-even-an-id')).rejects.toBeInstanceOf(ForbiddenException);
    });

    it('changes nothing when a forbidden action is refused', async () => {
      const app = await submit();
      await expect(service.startReview(reader, app.id)).rejects.toBeInstanceOf(ForbiddenException);
      expect((await repo.findApplicationById(app.id))?.status).toBe('submitted');
      expect(repo.auditEntries).toHaveLength(0);
    });
  });

  describe('campus isolation (the service-role read bypasses RLS, so the service must enforce it)', () => {
    let foreign: Application;
    beforeEach(async () => {
      foreign = await submit({ campusId: CAMPUS_B, classDefinitionId: DEF_B });
    });

    it('lists only the actor’s campus', async () => {
      await submit();
      const listed = await service.list(manager);
      expect(listed).toHaveLength(1);
      expect(listed.every((a) => a.campusId === CAMPUS_A)).toBe(true);
    });

    it('answers "not found" for another campus’s application on every operation', async () => {
      await expect(service.get(manager, foreign.id)).rejects.toBeInstanceOf(NotFoundException);
      await expect(service.startReview(manager, foreign.id)).rejects.toBeInstanceOf(NotFoundException);
      await expect(service.reject(manager, foreign.id, { reason: 'x' })).rejects.toBeInstanceOf(NotFoundException);
      await expect(service.convert(manager, foreign.id, CLASS_JSS1A)).rejects.toBeInstanceOf(NotFoundException);
    });

    it('gives the same answer for a missing application and for another campus’s (no existence leak)', async () => {
      const missing = service.get(manager, '44444444-4444-4444-8444-444444444444');
      await expect(missing).rejects.toBeInstanceOf(NotFoundException);
      await expect(service.get(manager, foreign.id)).rejects.toBeInstanceOf(NotFoundException);
    });

    it('treats a malformed id as not found', async () => {
      await expect(service.get(manager, 'nope')).rejects.toBeInstanceOf(NotFoundException);
    });

    it('leaves the other campus’s application untouched', async () => {
      await expect(service.startReview(manager, foreign.id)).rejects.toBeInstanceOf(NotFoundException);
      expect((await repo.findApplicationById(foreign.id))?.status).toBe('submitted');
    });
  });

  describe('listing and detail', () => {
    it('filters by status and rejects an unknown status', async () => {
      const a = await submit();
      await submit({ applicantFirstName: 'Bola' });
      await service.startReview(manager, a.id);
      expect(await service.list(manager, 'under_review')).toHaveLength(1);
      expect(await service.list(manager, '')).toHaveLength(2);
      await expect(service.list(manager, 'bogus')).rejects.toBeInstanceOf(BadRequestException);
    });

    it('returns the application with its documents', async () => {
      const app = await submit();
      await repo.addDocument({ applicationId: app.id, docType: 'birth_certificate', fileUrl: 'https://files.example.test/a.pdf' });
      const detail = await service.get(reader, app.id);
      expect(detail.application.id).toBe(app.id);
      expect(detail.documents).toHaveLength(1);
    });
  });

  describe('the review workflow', () => {
    it('walks submitted -> under_review -> info_requested -> under_review -> approved -> converted', async () => {
      const app = await submit();
      await service.startReview(manager, app.id, { notes: 'starting' });
      const asked = await service.requestInfo(manager, app.id, { notes: 'Please send the birth certificate.' });
      expect(asked).toMatchObject({ status: 'info_requested', reviewNotes: 'Please send the birth certificate.' });
      await service.resumeReview(manager, app.id);
      await service.approve(manager, app.id, { notes: 'all good' });
      const result = await service.convert(manager, app.id, CLASS_JSS1A);

      expect(result.admissionNo).toMatch(/^FFS-\d{4}-00001$/);
      expect((await repo.findApplicationById(app.id))?.status).toBe('converted');
      expect(repo.auditEntries.map((e) => e.action)).toEqual([
        'application.under_review',
        'application.info_requested',
        'application.under_review',
        'application.approved',
        'application.converted',
      ]);
      expect(repo.auditEntries.every((e) => e.actorId === 'user-admin' && e.campusId === CAMPUS_A)).toBe(true);
    });

    it('records the acting reviewer and trims the notes', async () => {
      const app = await submit();
      const updated = await service.startReview(manager, app.id, { notes: '  checked ' });
      expect(updated.reviewedBy).toBe('user-admin');
      expect(updated.reviewNotes).toBe('checked');
    });

    it('requires a reason to reject and stores it', async () => {
      const app = await submit();
      await service.startReview(manager, app.id);
      await expect(service.reject(manager, app.id, {})).rejects.toThrow('A decision reason is required.');
      await expect(service.reject(manager, app.id, { reason: '   ' })).rejects.toBeInstanceOf(BadRequestException);
      const rejected = await service.reject(manager, app.id, { reason: 'No places available' });
      expect(rejected).toMatchObject({ status: 'rejected', decisionReason: 'No places available' });
    });

    it('requires notes when asking the family for more information', async () => {
      const app = await submit();
      await service.startReview(manager, app.id);
      await expect(service.requestInfo(manager, app.id, {})).rejects.toThrow('Review notes is required.');
    });

    it('refuses an action from the wrong state with a 409 that names both states', async () => {
      const app = await submit();
      await expect(service.approve(manager, app.id)).rejects.toThrow(
        `Application ${app.referenceNo} is submitted; this action requires it to be under_review.`,
      );
      await expect(service.approve(manager, app.id)).rejects.toBeInstanceOf(ConflictException);
    });

    it('does not allow deciding twice', async () => {
      const app = await submit();
      await service.startReview(manager, app.id);
      await service.approve(manager, app.id);
      await expect(service.approve(manager, app.id)).rejects.toBeInstanceOf(ConflictException);
      await expect(service.reject(manager, app.id, { reason: 'changed my mind' })).rejects.toBeInstanceOf(ConflictException);
    });

    it('validates input before checking state, so a malformed request is a 400 wherever the application is', async () => {
      const app = await submit(); // still "submitted": the wrong state for reject
      await expect(service.reject(manager, app.id, {})).rejects.toBeInstanceOf(BadRequestException);
    });
  });

  describe('races with the database', () => {
    it('reports a conflict when the database refuses a transition the service had pre-checked', async () => {
      const app = await submit();
      jest.spyOn(repo, 'transitionApplication').mockRejectedValueOnce(
        new AdmissionsRuleViolationError('Invalid application status transition: under_review -> under_review'),
      );
      const attempt = service.startReview(manager, app.id);
      await expect(attempt).rejects.toBeInstanceOf(ConflictException);
    });

    it('lets a genuine server fault propagate as itself, not as a conflict', async () => {
      const app = await submit();
      jest.spyOn(repo, 'transitionApplication').mockRejectedValueOnce(new Error('connection reset'));
      const attempt = service.startReview(manager, app.id);
      await expect(attempt).rejects.toThrow('connection reset');
      await expect(attempt).rejects.not.toBeInstanceOf(ConflictException);
    });

    it('reports a conflict when conversion loses a race', async () => {
      const app = await approved();
      jest.spyOn(repo, 'convertApplication').mockRejectedValueOnce(
        new AdmissionsRuleViolationError(`application ${app.id} must be approved before conversion (current status: converted)`),
      );
      await expect(service.convert(manager, app.id, CLASS_JSS1A)).rejects.toBeInstanceOf(ConflictException);
    });
  });

  describe('convert', () => {
    it('refuses an application that is not approved', async () => {
      const app = await submit();
      await expect(service.convert(manager, app.id, CLASS_JSS1A)).rejects.toThrow(
        `Application ${app.referenceNo} is submitted; only an approved application can be converted.`,
      );
    });

    it('rejects a malformed class id', async () => {
      const app = await approved();
      await expect(service.convert(manager, app.id, 'nope')).rejects.toThrow('classId must be a valid id.');
    });

    it('answers "not found" for an unknown class and for another campus’s class alike', async () => {
      const app = await approved();
      await expect(service.convert(manager, app.id, 'bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb')).rejects.toBeInstanceOf(NotFoundException);
      await expect(service.convert(manager, app.id, CLASS_B)).rejects.toBeInstanceOf(NotFoundException);
    });

    it('rejects a class of a different level than the one applied for', async () => {
      const app = await approved();
      await expect(service.convert(manager, app.id, CLASS_SS1A)).rejects.toThrow(
        'is not a class of the level this applicant applied for.',
      );
      expect(repo.students).toHaveLength(0);
    });

    it('creates the student, guardian, link and enrollment on success', async () => {
      const app = await approved();
      const result = await service.convert(manager, app.id, CLASS_JSS1A);
      expect(repo.students).toHaveLength(1);
      expect(repo.guardians).toHaveLength(1);
      expect(repo.guardianLinks).toHaveLength(1);
      expect(repo.enrollments).toEqual([
        { studentId: result.studentId, classId: CLASS_JSS1A, campusId: CAMPUS_A, status: 'active' },
      ]);
    });

    it('cannot convert the same application twice', async () => {
      const app = await approved();
      await service.convert(manager, app.id, CLASS_JSS1A);
      await expect(service.convert(manager, app.id, CLASS_JSS1A)).rejects.toBeInstanceOf(ConflictException);
      expect(repo.students).toHaveLength(1);
    });

    it('gives siblings one guardian and consecutive admission numbers', async () => {
      const first = await approved();
      const second = await approved({ applicantFirstName: 'Bola', guardianEmail: 'PARENT@example.test' });
      const r1 = await service.convert(manager, first.id, CLASS_JSS1A);
      const r2 = await service.convert(manager, second.id, CLASS_JSS1A);
      expect(r2.guardianId).toBe(r1.guardianId);
      expect(r1.admissionNo.endsWith('-00001')).toBe(true);
      expect(r2.admissionNo.endsWith('-00002')).toBe(true);
    });
  });
});
