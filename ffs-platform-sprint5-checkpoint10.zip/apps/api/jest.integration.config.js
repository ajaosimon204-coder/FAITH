/** @type {import('jest').Config} */
module.exports = {
  preset: 'ts-jest',
  testEnvironment: 'node',
  rootDir: '.',
  testRegex: 'test-integration/.*\\.int\\.spec\\.ts$',
  testTimeout: 30000,
};
