#!/usr/bin/env node
/**
 * Hosted smoke test — run against a DEPLOYED stack (your Supabase project + the deployed API) before go-live
 * and after any infrastructure change. See docs/HOSTED_SMOKE_TEST.md for the runbook.
 *
 * It checks the things unit tests cannot: that this deployment really fails closed, that the Data API is
 * locked down, that real login tokens are accepted by the API, and that row-level security holds under real
 * tokens. Dependency-free (Node 20+). Never needs your secret/service-role key.
 *
 *   node scripts/smoke-test.mjs [--with-writes]
 *
 * Environment (secrets are read from the environment only — never pass them as arguments):
 *   SMOKE_API_URL            deployed API base URL, e.g. https://api.school.example
 *   SMOKE_SUPABASE_URL       project URL, e.g. https://<ref>.supabase.co
 *   SMOKE_PUBLISHABLE_KEY    publishable key (sb_publishable_...) or legacy anon key. Safe-to-expose key.
 *   SMOKE_STAFF_EMAIL / SMOKE_STAFF_PASSWORD        OPTIONAL: a staff test user holding admissions permissions
 *   SMOKE_LIMITED_EMAIL / SMOKE_LIMITED_PASSWORD    OPTIONAL: a test user with NO admissions permission
 *   SMOKE_CAMPUS_ID / SMOKE_CLASS_DEFINITION_ID     only with --with-writes: where to file the test application
 *
 * Default mode WRITES NOTHING. --with-writes files ONE clearly labelled test application through the public
 * route and then rejects it (it is never converted, so no student or guardian is created).
 *
 * Exit code: 0 if nothing FAILED (skips are reported, not hidden), 1 otherwise.
 */

const args = new Set(process.argv.slice(2));
const WITH_WRITES = args.has('--with-writes');

const env = (k) => (process.env[k] ?? '').trim();
const API = env('SMOKE_API_URL').replace(/\/+$/, '');
const SB = env('SMOKE_SUPABASE_URL').replace(/\/+$/, '');
const PUBLISHABLE = env('SMOKE_PUBLISHABLE_KEY');
const STAFF = { email: env('SMOKE_STAFF_EMAIL'), password: env('SMOKE_STAFF_PASSWORD') };
const LIMITED = { email: env('SMOKE_LIMITED_EMAIL'), password: env('SMOKE_LIMITED_PASSWORD') };

const missing = ['SMOKE_API_URL', 'SMOKE_SUPABASE_URL', 'SMOKE_PUBLISHABLE_KEY'].filter((k) => !env(k));
if (missing.length) {
  console.error(`Missing required environment: ${missing.join(', ')}\nSee the header of scripts/smoke-test.mjs.`);
  process.exit(2);
}

// ---- output (anything secret is redacted from every line we print) ---------------------------------------
const SECRETS = [PUBLISHABLE, STAFF.password, LIMITED.password].filter((s) => s.length >= 6);
const redact = (text) => SECRETS.reduce((t, s) => t.split(s).join('«redacted»'), String(text));
const results = [];
const record = (status, name, detail = '') => {
  results.push({ status, name });
  const mark = { PASS: '✓', FAIL: '✗', SKIP: '–', WARN: '!' }[status];
  console.log(redact(`  ${mark} ${status.padEnd(4)}  ${name}${detail ? `\n          ${detail}` : ''}`));
};
const pass = (name) => record('PASS', name);
const fail = (name, why) => record('FAIL', name, why);
const skip = (name, why) => record('SKIP', name, why);
const warn = (name, why) => record('WARN', name, why);
const section = (title) => console.log(`\n${title}`);

// ---- http -----------------------------------------------------------------------------------------------
async function http(method, url, { headers = {}, body } = {}) {
  try {
    const res = await fetch(url, {
      method,
      headers: { ...(body === undefined ? {} : { 'content-type': 'application/json' }), ...headers },
      body: body === undefined ? undefined : JSON.stringify(body),
      signal: AbortSignal.timeout(20000),
    });
    const text = await res.text();
    let json;
    try { json = JSON.parse(text); } catch { json = undefined; }
    return { status: res.status, json, text };
  } catch (e) {
    return { status: 0, json: undefined, text: `network error: ${e.cause?.code ?? e.message}` };
  }
}
const short = (r) => redact(`HTTP ${r.status} ${(r.text || '').slice(0, 160).replace(/\s+/g, ' ')}`);

// Data API (PostgREST). The publishable/anon key goes in `apikey` only; a user token goes in Authorization.
const rest = (method, path, { token, body } = {}) =>
  http(method, `${SB}/rest/v1/${path}`, {
    headers: { apikey: PUBLISHABLE, ...(token ? { authorization: `Bearer ${token}` } : {}) },
    body,
  });
const api = (method, path, { token, body } = {}) =>
  http(method, `${API}${path}`, { headers: token ? { authorization: `Bearer ${token}` } : {}, body });

const isPermissionDenied = (r) => [401, 403].includes(r.status) && /42501|permission denied/i.test(r.text);
const ZERO = '00000000-0000-4000-8000-000000000000';

function decodeJwt(token) {
  try {
    const part = (i) => JSON.parse(Buffer.from(token.split('.')[i], 'base64url').toString('utf8'));
    return { header: part(0), payload: part(1) };
  } catch {
    return null;
  }
}

async function login({ email, password }) {
  const r = await http('POST', `${SB}/auth/v1/token?grant_type=password`, {
    headers: { apikey: PUBLISHABLE },
    body: { email, password },
  });
  return r.status === 200 && r.json?.access_token ? { token: r.json.access_token } : { error: short(r) };
}

// ===========================================================================================================
console.log(`Hosted smoke test${WITH_WRITES ? ' (with writes)' : ' (read-only)'}\n  API:      ${API}\n  Supabase: ${SB}`);

section('1. The deployed API fails closed');
{
  const r = await api('GET', '/api/v1/admissions/applications');
  if (r.status === 401) pass('A staff route without a token is refused (401)');
  else if (r.status === 0) fail('The API is reachable', `${short(r)} — is SMOKE_API_URL right, and is the service running?`);
  else fail('A staff route without a token is refused (401)', `${short(r)} — the API is not enforcing authentication`);
}
{
  const r = await api('POST', '/api/v1/public/admissions/applications', { body: {} });
  if (r.status === 400 && Array.isArray(r.json?.message)) pass('The public application route validates input (400, nothing written)');
  else fail('The public application route validates input (400, nothing written)', short(r));
}
{
  const r = await api('GET', '/api/v1/public/admissions/applications');
  if (r.status === 404) pass('There is no public read route for applications (404)');
  else fail('There is no public read route for applications (404)', `${short(r)} — application data must never be publicly readable`);
}

section('2. The Data API is locked down for anonymous callers');
{
  const r = await rest('GET', 'cms_pages?select=id&limit=1');
  if (r.status === 200) pass('The publishable key works against this project');
  else fail('The publishable key works against this project', `${short(r)} — wrong SMOKE_SUPABASE_URL / key, or the Data API is disabled`);
}
{
  const r = await rest('GET', 'applications?select=id&limit=1');
  if (r.status === 200 && Array.isArray(r.json) && r.json.length === 0) pass('Anonymous callers see no applications');
  else if (r.status === 200) fail('Anonymous callers see no applications', `returned ${r.json?.length ?? '?'} row(s) — row-level security is not protecting this table`);
  else if (isPermissionDenied(r)) pass('Anonymous callers see no applications (access denied outright)');
  else fail('Anonymous callers see no applications', short(r));
}
{
  const r = await rest('GET', 'student_current_enrollments?select=student_id&limit=1');
  if (isPermissionDenied(r)) pass('Anonymous callers are refused the enrollments view (migration 0029)');
  else if (r.status === 200 && r.json?.length === 0) warn('Enrollments view returned nothing to anonymous callers', 'only because it is empty — it should be refused outright (42501); confirm migration 0029 is applied');
  else if (r.status === 200) fail('Anonymous callers are refused the enrollments view (migration 0029)', `returned ${r.json.length} row(s) to an unauthenticated caller — DATA EXPOSURE: apply migration 0029`);
  else fail('Anonymous callers are refused the enrollments view (migration 0029)', short(r));
}
{
  // Bodies are deliberately invalid, so even if a privilege were wrongly open nothing could be written.
  const probes = [
    ['INSERT into applications', rest('POST', 'applications', { body: { campus_id: ZERO, class_definition_id: ZERO, applicant_first_name: 'x', applicant_last_name: 'x', applicant_date_of_birth: '2014-01-01', guardian_first_name: 'x', guardian_last_name: 'x' } })],
    ['INSERT into guardians', rest('POST', 'guardians', { body: { campus_id: ZERO, first_name: 'x', last_name: 'x' } })],
    ['UPDATE applications', rest('PATCH', `applications?id=eq.${ZERO}`, { body: { review_notes: 'x' } })],
    ['DELETE applications', rest('DELETE', `applications?id=eq.${ZERO}`)],
    ['call app_convert_application()', rest('POST', 'rpc/app_convert_application', { body: { p_application_id: ZERO, p_campus_id: ZERO, p_class_id: ZERO, p_actor_id: ZERO } })],
    ['call app_application_transition()', rest('POST', 'rpc/app_application_transition', { body: { p_id: ZERO, p_campus_id: ZERO, p_to_status: 'under_review', p_actor_id: ZERO, p_action: 'x', p_review_notes: null, p_decision_reason: null } })],
  ];
  for (const [label, promise] of probes) {
    const r = await promise;
    if (isPermissionDenied(r)) pass(`Anonymous callers cannot ${label}`);
    else fail(`Anonymous callers cannot ${label}`, `${short(r)} — expected "permission denied" (42501); a table/function privilege is too open on this project`);
  }
}

section('3. Real sign-in, through the API and the Data API');
let staffToken;
if (!STAFF.email || !STAFF.password) {
  skip('Staff sign-in and the checks that need it', 'set SMOKE_STAFF_EMAIL and SMOKE_STAFF_PASSWORD (a test user holding admissions permissions)');
} else {
  const session = await login(STAFF);
  if (session.error) {
    fail('A staff test user can sign in', `${session.error} — wrong credentials, or the user does not exist/confirm`);
  } else {
    staffToken = session.token;
    pass('A staff test user can sign in');

    const jwt = decodeJwt(staffToken);
    const expectedIssuer = `${SB}/auth/v1`;
    if (jwt) {
      console.log(`          token: alg=${jwt.header.alg} iss=${jwt.payload.iss} aud=${jwt.payload.aud}`);
      if (jwt.payload.iss !== expectedIssuer) {
        warn('Token issuer matches the project URL', `iss is "${jwt.payload.iss}" but the API expects "${expectedIssuer}". If the API rejects this token, set SUPABASE_JWT_ISSUER=${jwt.payload.iss} on the API.`);
      }
      if (jwt.payload.aud !== 'authenticated') warn('Token audience is "authenticated"', `aud is "${jwt.payload.aud}"`);
    }

    const list = await api('GET', '/api/v1/admissions/applications', { token: staffToken });
    if (list.status === 200 && Array.isArray(list.json)) pass('The API accepts a real login token and authorises the staff user');
    else if (list.status === 401) fail('The API accepts a real login token and authorises the staff user', `${short(list)} — the API rejected a valid token. Check: SUPABASE_URL on the API matches this project; the token alg above (ES256/RS256 need the JWKS endpoint reachable; HS256 needs SUPABASE_JWT_SECRET); issuer (see warning above); and that this user exists in the platform's users table with a role. The API logs the exact reason.`);
    else if (list.status === 403) fail('The API accepts a real login token and authorises the staff user', `${short(list)} — signed in, but this user has no admissions permission`);
    else if (list.status === 503) fail('The API accepts a real login token and authorises the staff user', `${short(list)} — the API cannot fetch the project's signing keys (JWKS); check its outbound network access to ${SB}`);
    else fail('The API accepts a real login token and authorises the staff user', short(list));

    const tampered = staffToken.slice(0, -4) + (staffToken.endsWith('AAAA') ? 'BBBB' : 'AAAA');
    const t = await api('GET', '/api/v1/admissions/applications', { token: tampered });
    if (t.status === 401) pass('A tampered token is refused (401)');
    else fail('A tampered token is refused (401)', short(t));

    const apps = await rest('GET', 'applications?select=campus_id', { token: staffToken });
    if (apps.status === 200 && Array.isArray(apps.json)) {
      const campuses = new Set(apps.json.map((a) => a.campus_id));
      if (campuses.size > 1) fail('Row-level security scopes this user to one campus', `rows from ${campuses.size} different campuses are visible to one staff user`);
      else if (apps.json.length === 0) warn('Row-level security scopes this user to one campus', 'no application rows are visible to this user, so campus scoping could not actually be observed (an empty result proves nothing). Re-run once the project holds applications for at least two campuses.');
      else pass(`Row-level security scopes this user to one campus (${apps.json.length} application row(s) visible)`);
    } else fail('The Data API honours the staff token (row-level security)', short(apps));

    const view = await rest('GET', 'student_current_enrollments?select=campus_id', { token: staffToken });
    if (view.status !== 200 || !Array.isArray(view.json)) fail('The enrollments view is scoped to one campus for this user', short(view));
    else if (new Set(view.json.map((r) => r.campus_id)).size > 1) fail('The enrollments view is scoped to one campus for this user', 'enrollments from several campuses are visible to one staff user — DATA EXPOSURE');
    else if (view.json.length === 0) warn('The enrollments view is scoped to one campus for this user', 'no enrollment rows are visible to this user, so scoping could not actually be observed');
    else pass(`The enrollments view is scoped to one campus for this user (${view.json.length} row(s) visible)`);

    const write = await rest('POST', 'applications', { token: staffToken, body: { campus_id: ZERO, class_definition_id: ZERO, applicant_first_name: 'x', applicant_last_name: 'x', applicant_date_of_birth: '2014-01-01', guardian_first_name: 'x', guardian_last_name: 'x' } });
    if (isPermissionDenied(write)) pass('Even a staff user cannot write applications directly (writes go through the API only)');
    else fail('Even a staff user cannot write applications directly', `${short(write)} — expected "permission denied"`);
  }
}

section('4. A user with no admissions permission');
if (!LIMITED.email || !LIMITED.password) {
  skip('Limited-user checks', 'set SMOKE_LIMITED_EMAIL and SMOKE_LIMITED_PASSWORD (a test user with no admissions role)');
} else {
  const session = await login(LIMITED);
  if (session.error) fail('The limited test user can sign in', session.error);
  else {
    const r = await api('GET', '/api/v1/admissions/applications', { token: session.token });
    if (r.status === 403) pass('The API refuses a signed-in user without the permission (403)');
    else fail('The API refuses a signed-in user without the permission (403)', short(r));
    const d = await rest('GET', 'applications?select=id', { token: session.token });
    if (d.status === 200 && d.json?.length === 0) pass('The Data API shows that user no applications');
    else fail('The Data API shows that user no applications', short(d));
  }
}

section('5. End-to-end journey (writes one labelled test application)');
if (!WITH_WRITES) {
  skip('Submit → review → reject', 'run with --with-writes (also set SMOKE_CAMPUS_ID and SMOKE_CLASS_DEFINITION_ID)');
} else if (!staffToken || !env('SMOKE_CAMPUS_ID') || !env('SMOKE_CLASS_DEFINITION_ID')) {
  fail('Submit → review → reject', 'needs a working staff sign-in plus SMOKE_CAMPUS_ID and SMOKE_CLASS_DEFINITION_ID');
} else {
  const stamp = new Date().toISOString();
  const sub = await api('POST', '/api/v1/public/admissions/applications', {
    body: {
      campusId: env('SMOKE_CAMPUS_ID'),
      classDefinitionId: env('SMOKE_CLASS_DEFINITION_ID'),
      applicantFirstName: 'SMOKE',
      applicantLastName: `TEST-${stamp.slice(0, 10)}`,
      applicantDateOfBirth: '2015-01-01',
      guardianFirstName: 'Smoke',
      guardianLastName: 'Test',
      guardianEmail: 'smoke-test@invalid.example',
    },
  });
  if (sub.status === 201 && sub.json?.applicationId) {
    pass(`A public application is accepted (reference ${sub.json.referenceNo})`);
    const id = sub.json.applicationId;
    const detail = await api('GET', `/api/v1/admissions/applications/${id}`, { token: staffToken });
    if (detail.status === 200 && detail.json?.application?.status === 'submitted') pass('Staff can see it, in status "submitted"');
    else fail('Staff can see it, in status "submitted"', short(detail));
    const review = await api('POST', `/api/v1/admissions/applications/${id}/start-review`, { token: staffToken, body: { notes: 'smoke test' } });
    if (review.status === 201) pass('Staff can start the review');
    else fail('Staff can start the review', short(review));
    const rej = await api('POST', `/api/v1/admissions/applications/${id}/reject`, { token: staffToken, body: { reason: 'SMOKE TEST — safe to ignore' } });
    if (rej.status === 201 && rej.json?.status === 'rejected') pass('Staff can reject it (the test application is never converted: no student or guardian is created)');
    else fail('Staff can reject it', short(rej));
    console.log(`          Test application ${sub.json.referenceNo} is left in status "rejected", labelled SMOKE TEST.`);
  } else {
    fail('A public application is accepted', `${short(sub)} — check SMOKE_CAMPUS_ID / SMOKE_CLASS_DEFINITION_ID belong together`);
  }
}

// ===========================================================================================================
const count = (s) => results.filter((r) => r.status === s).length;
console.log(`\n══════════ ${count('PASS')} passed · ${count('FAIL')} failed · ${count('WARN')} warnings · ${count('SKIP')} skipped ══════════`);
if (count('FAIL') > 0) console.log('SMOKE TEST FAILED — do not go live until every failure above is understood.');
else if (count('SKIP') > 0) console.log('No failures, but some checks were skipped — see above. Provide the missing inputs for full coverage.');
else console.log('ALL CHECKS PASSED');
process.exit(count('FAIL') > 0 ? 1 : 0);
