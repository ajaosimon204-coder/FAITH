#!/usr/bin/env bash
# One command that proves the whole repository: database, API, integration against the real API
# layer, and the web app. Runs EVERY step even if an earlier one fails, then prints a summary and
# exits non-zero if anything failed. CI runs exactly this.
#
#   scripts/verify-all.sh                     everything (installs dependencies first)
#   scripts/verify-all.sh --no-install        skip `npm ci` (dependencies already installed)
#   scripts/verify-all.sh --skip-web-build    skip `next build` (it downloads Google Fonts, so it needs internet)
#
# Needs: root (the database harness uses `su postgres`), local PostgreSQL 16 + pgTAP, Node 20+,
# and network access to GitHub once (pinned, checksum-verified PostgREST download).
set -uo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
INSTALL=1; WEB_BUILD=1
for a in "$@"; do
  case "$a" in
    --no-install) INSTALL=0 ;;
    --skip-web-build) WEB_BUILD=0 ;;
    *) echo "unknown flag $a"; exit 2 ;;
  esac
done

NAMES=(); RESULTS=()
step() { # step "<label>" <dir> <command...>
  local label="$1" dir="$2"; shift 2
  echo; echo "━━ $label"
  if (cd "$ROOT/$dir" && "$@"); then NAMES+=("$label"); RESULTS+=("PASS"); else NAMES+=("$label"); RESULTS+=("FAIL"); fi
}
skip() { NAMES+=("$1"); RESULTS+=("skipped ($2)"); }

if [[ $INSTALL == 1 ]]; then
  step "api: npm ci" apps/api npm ci --no-audit --no-fund
  step "web: npm ci" apps/web npm ci --no-audit --no-fund
fi

step "database: pgTAP suites (classic project)"  supabase ./local-test-harness/run_all.sh
step "database: pgTAP suites (current project)"  supabase ./local-test-harness/run_all.sh --modern
step "database: classic = current privileges"    supabase ./local-test-harness/compare_privilege_models.sh
step "database: concurrency check"              supabase ./local-test-harness/concurrency_conversion_check.sh
step "api: typecheck"                           apps/api npm run --silent typecheck
step "api: lint"                                apps/api npm run --silent lint
step "api: unit + HTTP + boot tests"            apps/api npm test --silent
step "api: production build"                    apps/api npm run --silent build
step "integration: real PostgREST (classic)"     supabase ./local-test-harness/run_integration.sh
step "integration: real PostgREST (current)"     supabase ./local-test-harness/run_integration.sh --modern
step "smoke test: self-test (current project)"   supabase ./local-test-harness/run_smoke_selftest.sh --modern
step "web: typecheck"                           apps/web npm run --silent typecheck
step "web: lint"                                apps/web npm run --silent lint
step "web: tests"                               apps/web npm test --silent
if [[ $WEB_BUILD == 1 ]]; then step "web: production build" apps/web npm run --silent build; else skip "web: production build" "--skip-web-build"; fi

echo; echo "══════════ SUMMARY ══════════"
failed=0
for i in "${!NAMES[@]}"; do printf '  %-48s %s\n' "${NAMES[$i]}" "${RESULTS[$i]}"; [[ "${RESULTS[$i]}" == FAIL ]] && failed=1; done
[[ $failed == 0 ]] && echo "ALL CHECKS PASSED" || echo "SOME CHECKS FAILED"
exit $failed
