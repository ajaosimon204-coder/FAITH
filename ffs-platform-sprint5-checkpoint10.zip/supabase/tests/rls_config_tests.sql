-- =============================================================================
-- RLS Test Suite: School Configuration System
-- Sprint 2 — Faith Foundation Schools Digital Platform
--
-- Same status as the Sprint 1 RLS suite: written and reasoned through, not
-- yet executed against a live database in this development environment
-- (see Sprint 2 Completion Report, "Known Limitation"). Ready to run via
-- pg_prove once a Postgres/Supabase instance is available.
-- =============================================================================

begin;
select plan(15);

-- -----------------------------------------------------------------------------
-- Fixtures: two campuses (reusing the Sprint 1 fixture pattern), one
-- accountant (finance only) and one school_administrator (broader read,
-- academic write) in Campus A, one accountant in Campus B.
-- -----------------------------------------------------------------------------

insert into organizations (id, name) values
  ('a1000000-0000-0000-0000-000000000001', '[TEST] Org A'),
  ('a1000000-0000-0000-0000-000000000002', '[TEST] Org B');

insert into campuses (id, organization_id, name) values
  ('b1000000-0000-0000-0000-000000000001', 'a1000000-0000-0000-0000-000000000001', '[TEST] Campus A'),
  ('b1000000-0000-0000-0000-000000000002', 'a1000000-0000-0000-0000-000000000002', '[TEST] Campus B');

insert into auth.users (id, email) values
  ('c1000000-0000-0000-0000-000000000001', 'accountant-a@test.invalid'),
  ('c1000000-0000-0000-0000-000000000002', 'admin-a@test.invalid'),
  ('c1000000-0000-0000-0000-000000000003', 'accountant-b@test.invalid');

insert into users (id, auth_user_id, campus_id, email, status) values
  ('d1000000-0000-0000-0000-000000000001', 'c1000000-0000-0000-0000-000000000001', 'b1000000-0000-0000-0000-000000000001', 'accountant-a@test.invalid', 'active'),
  ('d1000000-0000-0000-0000-000000000002', 'c1000000-0000-0000-0000-000000000002', 'b1000000-0000-0000-0000-000000000001', 'admin-a@test.invalid', 'active'),
  ('d1000000-0000-0000-0000-000000000003', 'c1000000-0000-0000-0000-000000000003', 'b1000000-0000-0000-0000-000000000002', 'accountant-b@test.invalid', 'active');

insert into user_roles (user_id, role_id, campus_id, assigned_by)
select 'd1000000-0000-0000-0000-000000000001', id, 'b1000000-0000-0000-0000-000000000001', 'd1000000-0000-0000-0000-000000000001'
from roles where key = 'accountant';

insert into user_roles (user_id, role_id, campus_id, assigned_by)
select 'd1000000-0000-0000-0000-000000000002', id, 'b1000000-0000-0000-0000-000000000001', 'd1000000-0000-0000-0000-000000000002'
from roles where key = 'school_administrator';

insert into user_roles (user_id, role_id, campus_id, assigned_by)
select 'd1000000-0000-0000-0000-000000000003', id, 'b1000000-0000-0000-0000-000000000002', 'd1000000-0000-0000-0000-000000000003'
from roles where key = 'accountant';

-- Seed one value per campus for finance.default_currency, using the real
-- config_definitions row created by migration 0007.
insert into school_config (config_definition_id, campus_id, value_json, updated_by)
select id, 'b1000000-0000-0000-0000-000000000001', '"NGN"'::jsonb, 'd1000000-0000-0000-0000-000000000001'
from config_definitions where key = 'finance.default_currency';

insert into school_config (config_definition_id, campus_id, value_json, updated_by)
select id, 'b1000000-0000-0000-0000-000000000002', '"NGN"'::jsonb, 'd1000000-0000-0000-0000-000000000003'
from config_definitions where key = 'finance.default_currency';

-- -----------------------------------------------------------------------------
-- 1. config_definitions: readable by anyone authenticated, regardless of
--    campus (it's a catalogue, not tenant data).
-- -----------------------------------------------------------------------------

set local role authenticated;
set local request.jwt.claim.sub = 'c1000000-0000-0000-0000-000000000001';

select is(
  (select count(*) from config_definitions where key = 'finance.default_currency'),
  1::bigint,
  'Any authenticated user can read config_definitions catalogue entries'
);

select throws_ok(
  $$ insert into config_definitions (category, key, data_type, json_schema, read_permission_key, write_permission_key, description)
     values ('school', 'forged.key', 'string', '{"type":"string"}'::jsonb, 'config.school.read', 'config.school.write', 'forged') $$,
  null,
  'No authenticated-role write grant exists on config_definitions at all — an accountant cannot insert one'
);

-- -----------------------------------------------------------------------------
-- 2. school_config: an accountant (finance.read/write) can read/write their
--    own campus's finance config.
-- -----------------------------------------------------------------------------

select is(
  (select count(*) from school_config sc
     join config_definitions cd on cd.id = sc.config_definition_id
     where cd.key = 'finance.default_currency' and sc.campus_id = 'b1000000-0000-0000-0000-000000000001'),
  1::bigint,
  'An accountant can read their own campus''s finance.default_currency value'
);

-- -----------------------------------------------------------------------------
-- 3. school_config: an accountant CANNOT read a different campus's finance
--    config, even though they hold config.finance.read generally.
-- -----------------------------------------------------------------------------

select is(
  (select count(*) from school_config where campus_id = 'b1000000-0000-0000-0000-000000000002'),
  0::bigint,
  'An accountant in Campus A cannot read Campus B''s school_config rows (tenant isolation)'
);

-- -----------------------------------------------------------------------------
-- 4. school_config: a school_administrator has config.finance.read but NOT
--    config.finance.write (per the Sprint 2 seed) — can read, cannot write.
-- -----------------------------------------------------------------------------

set local request.jwt.claim.sub = 'c1000000-0000-0000-0000-000000000002';

select is(
  (select count(*) from school_config sc
     join config_definitions cd on cd.id = sc.config_definition_id
     where cd.key = 'finance.default_currency' and sc.campus_id = 'b1000000-0000-0000-0000-000000000001'),
  1::bigint,
  'A school_administrator (has config.finance.read) can read the finance value'
);

-- Corrected per migration 0009: `authenticated` has no UPDATE privilege on
-- school_config at all (and no applicable policy), so a direct UPDATE is
-- refused. On a real Supabase project that surfaces as `permission denied`
-- (SQLSTATE 42501); on the legacy harness, whose post-migration grants stub
-- re-opens UPDATE, it surfaces as zero matched rows and no exception. Both
-- outcomes mean the write was blocked, and the assertion below — the stored
-- value is unchanged — is what proves it, so the statement tolerates either.
do $block$
begin
  update school_config set value_json = '"USD"'::jsonb
  where campus_id = 'b1000000-0000-0000-0000-000000000001'
    and config_definition_id = (select id from config_definitions where key = 'finance.default_currency');
exception when insufficient_privilege then
  null;
end
$block$;

select is(
  (select value_json from school_config sc
     join config_definitions cd on cd.id = sc.config_definition_id
     where cd.key = 'finance.default_currency' and sc.campus_id = 'b1000000-0000-0000-0000-000000000001'),
  '"NGN"'::jsonb,
  'A school_administrator''s direct UPDATE attempt is blocked — the stored value remains unchanged'
);

-- -----------------------------------------------------------------------------
-- 5. school_config: per migration 0009's correction, an accountant who DOES
--    hold config.finance.write STILL cannot write directly — the
--    write-bypass this migration closed applied even to authorized actors.
--    All writes now go exclusively through app_write_school_config().
-- -----------------------------------------------------------------------------

set local request.jwt.claim.sub = 'c1000000-0000-0000-0000-000000000001';

-- Blocked by privilege (42501 on a real project) or by zero matched rows (legacy
-- harness); the assertion below — value unchanged — is what proves it either way.
do $block$
begin
  update school_config set value_json = '"USD"'::jsonb
  where campus_id = 'b1000000-0000-0000-0000-000000000001'
    and config_definition_id = (select id from config_definitions where key = 'finance.default_currency');
exception when insufficient_privilege then
  null;
end
$block$;

select is(
  (select value_json from school_config sc
     join config_definitions cd on cd.id = sc.config_definition_id
     where cd.key = 'finance.default_currency' and sc.campus_id = 'b1000000-0000-0000-0000-000000000001'),
  '"NGN"'::jsonb,
  'An accountant (holds config.finance.write) STILL cannot write directly post-0009 — the direct-write bypass is closed for everyone, not just unauthorized actors'
);

select throws_ok(
  $$ insert into school_config (config_definition_id, campus_id, value_json, updated_by)
     select id, 'b1000000-0000-0000-0000-000000000001', '"NGN"'::jsonb, 'd1000000-0000-0000-0000-000000000001'
     from config_definitions where key = 'school.timezone' $$,
  null,
  'An accountant cannot INSERT into school_config directly either — the only write path is app_write_school_config(), reachable exclusively via the service-role connection'
);

-- -----------------------------------------------------------------------------
-- 6. The atomic write path DOES work correctly, exercised as service_role
--    (standing in for the App Backend's own connection) — proving the fix
--    didn't just close the bypass, it left the legitimate path intact.
-- -----------------------------------------------------------------------------

reset role;
set local role service_role;

select lives_ok(
  $$ select app_write_school_config(
       (select id from config_definitions where key = 'finance.default_currency'),
       'b1000000-0000-0000-0000-000000000001',
       '"USD"'::jsonb,
       'd1000000-0000-0000-0000-000000000001'
     ) $$,
  'The App Backend (service_role) CAN write via app_write_school_config()'
);

select is(
  (select value_json from school_config sc
     join config_definitions cd on cd.id = sc.config_definition_id
     where cd.key = 'finance.default_currency' and sc.campus_id = 'b1000000-0000-0000-0000-000000000001'),
  '"USD"'::jsonb,
  'The value written via app_write_school_config() is actually persisted'
);

set local role authenticated;
set local request.jwt.claim.sub = 'c1000000-0000-0000-0000-000000000001';

-- -----------------------------------------------------------------------------
-- 6b. Regression test for the PUBLIC EXECUTE grant gap (major finding,
--     Sprint 4 audit / migration 0020): even a FULLY-PERMISSIONED actor
--     (this accountant holds config.finance.write) cannot call
--     app_write_school_config() directly — the only legitimate caller is
--     the service-role connection. This specific negative test did not
--     exist before the audit and would have caught the PUBLIC-grant bug
--     immediately had it existed from migration 0008 onward.
-- -----------------------------------------------------------------------------

select throws_ok(
  $$ select app_write_school_config(
       (select id from config_definitions where key = 'finance.default_currency'),
       'b1000000-0000-0000-0000-000000000001',
       '"XX"'::jsonb,
       'd1000000-0000-0000-0000-000000000001'
     ) $$,
  null,
  'An accountant (config.finance.write) — or any authenticated role — cannot call app_write_school_config() directly, bypassing ConfigService''s ajv validation entirely'
);

-- -----------------------------------------------------------------------------
-- 7. school_config: no DELETE grant at all for the authenticated role.
-- -----------------------------------------------------------------------------

select throws_ok(
  $$ delete from school_config where campus_id = 'b1000000-0000-0000-0000-000000000001' $$,
  null,
  'The authenticated role cannot delete school_config rows at all — corrections happen via a new write, not deletion'
);

-- -----------------------------------------------------------------------------
-- 8. config_audit_log: read gated the same as the underlying value's read
--    permission, and tenant-scoped; no write grant at all. Exactly one
--    entry exists — produced by section 6's single service-role write via
--    app_write_school_config(), NOT by any of the (correctly rejected)
--    direct-write attempts in sections 4-5.
-- -----------------------------------------------------------------------------

select is(
  (select count(*) from config_audit_log
     where campus_id = 'b1000000-0000-0000-0000-000000000001'),
  1::bigint,
  'An accountant can read their own campus''s config_audit_log entries (exactly one — from the single legitimate service-role write in section 6)'
);

select is(
  (select count(*) from config_audit_log
     where campus_id = 'b1000000-0000-0000-0000-000000000002'),
  0::bigint,
  'An accountant in Campus A cannot read Campus B''s config_audit_log entries'
);

select throws_ok(
  $$ insert into config_audit_log (config_definition_id, campus_id, actor_id, new_value_json)
     select id, 'b1000000-0000-0000-0000-000000000001', 'd1000000-0000-0000-0000-000000000001', '"forged"'::jsonb
     from config_definitions where key = 'finance.default_currency' $$,
  null,
  'The authenticated role cannot insert into config_audit_log directly — writes only happen via the service-role RPC function'
);

select * from finish();
rollback;
