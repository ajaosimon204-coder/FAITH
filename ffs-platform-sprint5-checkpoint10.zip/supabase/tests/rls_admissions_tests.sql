-- =============================================================================
-- RLS / Function Test Suite: Admissions
-- Sprint 5A — Faith Foundation Schools Digital Platform
--
-- Covers migrations 0021–0025: privilege layer, permission seeds, database
-- triggers/constraints, RLS reads (tenant isolation + guardian self-access),
-- and the two service-role-only atomic functions (success paths, every
-- rejection path, atomic rollback, sibling-guardian reuse).
--
-- RUN ONLY UNDER THE FAITHFUL HARNESS MODEL:
--   supabase/local-test-harness/run_all.sh --faithful
-- This suite asserts privilege state (has_table_privilege /
-- has_function_privilege). The legacy harness's post-migration grants stub
-- re-opens privileges the migrations revoke (ADR-013 class), so it would
-- report false failures here — and, worse, could mask a missing revoke.
-- =============================================================================

begin;
select plan(68);

-- -----------------------------------------------------------------------------
-- Fixtures (inserted as superuser, before any role switch)
-- -----------------------------------------------------------------------------

insert into organizations (id, name) values
  ('aa000000-0000-0000-0000-000000000001', '[TEST] Admissions Org A'),
  ('aa000000-0000-0000-0000-000000000002', '[TEST] Admissions Org B');
insert into campuses (id, organization_id, name) values
  ('bb000000-0000-0000-0000-000000000001', 'aa000000-0000-0000-0000-000000000001', '[TEST] Campus A'),
  ('bb000000-0000-0000-0000-000000000002', 'aa000000-0000-0000-0000-000000000002', '[TEST] Campus B');

insert into auth.users (id, email) values
  ('cc000000-0000-0000-0000-000000000001', 'admin-a@test.invalid'),
  ('cc000000-0000-0000-0000-000000000002', 'vp-a@test.invalid'),
  ('cc000000-0000-0000-0000-000000000003', 'accountant-a@test.invalid'),
  ('cc000000-0000-0000-0000-000000000004', 'guardian-a@test.invalid'),
  ('cc000000-0000-0000-0000-000000000005', 'admin-b@test.invalid');

insert into users (id, auth_user_id, campus_id, email, status) values
  ('dd000000-0000-0000-0000-000000000001', 'cc000000-0000-0000-0000-000000000001', 'bb000000-0000-0000-0000-000000000001', 'admin-a@test.invalid', 'active'),
  ('dd000000-0000-0000-0000-000000000002', 'cc000000-0000-0000-0000-000000000002', 'bb000000-0000-0000-0000-000000000001', 'vp-a@test.invalid', 'active'),
  ('dd000000-0000-0000-0000-000000000003', 'cc000000-0000-0000-0000-000000000003', 'bb000000-0000-0000-0000-000000000001', 'accountant-a@test.invalid', 'active'),
  ('dd000000-0000-0000-0000-000000000004', 'cc000000-0000-0000-0000-000000000004', 'bb000000-0000-0000-0000-000000000001', 'guardian-a@test.invalid', 'active'),
  ('dd000000-0000-0000-0000-000000000005', 'cc000000-0000-0000-0000-000000000005', 'bb000000-0000-0000-0000-000000000002', 'admin-b@test.invalid', 'active');

insert into user_roles (user_id, role_id, campus_id, assigned_by)
select 'dd000000-0000-0000-0000-000000000001', id, 'bb000000-0000-0000-0000-000000000001', 'dd000000-0000-0000-0000-000000000001' from roles where key = 'school_administrator';
insert into user_roles (user_id, role_id, campus_id, assigned_by)
select 'dd000000-0000-0000-0000-000000000002', id, 'bb000000-0000-0000-0000-000000000001', 'dd000000-0000-0000-0000-000000000001' from roles where key = 'vice_principal';
insert into user_roles (user_id, role_id, campus_id, assigned_by)
select 'dd000000-0000-0000-0000-000000000003', id, 'bb000000-0000-0000-0000-000000000001', 'dd000000-0000-0000-0000-000000000001' from roles where key = 'accountant';
insert into user_roles (user_id, role_id, campus_id, assigned_by)
select 'dd000000-0000-0000-0000-000000000005', id, 'bb000000-0000-0000-0000-000000000002', 'dd000000-0000-0000-0000-000000000005' from roles where key = 'school_administrator';

-- Academic structure. Campus A: two levels (JSS 1, SS 1), one session. Campus B: one of each.
insert into academic_sessions (id, campus_id, name, start_date, end_date, is_current) values
  ('a1000000-0000-0000-0000-000000000001', 'bb000000-0000-0000-0000-000000000001', '[TEST] 2025/2026', '2025-09-01', '2026-07-31', true),
  ('a1000000-0000-0000-0000-000000000003', 'bb000000-0000-0000-0000-000000000002', '[TEST] B 2025/2026', '2025-09-01', '2026-07-31', true);
insert into class_definitions (id, campus_id, name, level) values
  ('a2000000-0000-0000-0000-000000000001', 'bb000000-0000-0000-0000-000000000001', '[TEST] JSS 1', 'junior_secondary'),
  ('a2000000-0000-0000-0000-000000000002', 'bb000000-0000-0000-0000-000000000002', '[TEST] JSS 1', 'junior_secondary'),
  ('a2000000-0000-0000-0000-000000000003', 'bb000000-0000-0000-0000-000000000001', '[TEST] SS 1', 'senior_secondary');
insert into classes (id, class_definition_id, academic_session_id, campus_id, name, section) values
  ('a3000000-0000-0000-0000-000000000001', 'a2000000-0000-0000-0000-000000000001', 'a1000000-0000-0000-0000-000000000001', 'bb000000-0000-0000-0000-000000000001', '[TEST] JSS 1A', 'A'),
  ('a3000000-0000-0000-0000-000000000002', 'a2000000-0000-0000-0000-000000000003', 'a1000000-0000-0000-0000-000000000001', 'bb000000-0000-0000-0000-000000000001', '[TEST] SS 1A', 'A'),
  ('a3000000-0000-0000-0000-000000000003', 'a2000000-0000-0000-0000-000000000002', 'a1000000-0000-0000-0000-000000000003', 'bb000000-0000-0000-0000-000000000002', '[TEST] B JSS 1A', 'A');

-- Applications. Campus A: sub1, sub2, sub3 (submitted); conv1..conv3 (driven to approved below). Campus B: bapp.
insert into applications (id, campus_id, applicant_first_name, applicant_last_name, applicant_date_of_birth, applicant_gender, class_definition_id, guardian_first_name, guardian_last_name, guardian_email, guardian_phone) values
  ('a4000000-0000-0000-0000-000000000001', 'bb000000-0000-0000-0000-000000000001', 'Sub', 'One',   '2014-03-01', null, 'a2000000-0000-0000-0000-000000000001', 'Gu', 'One',   null, null),
  ('a4000000-0000-0000-0000-000000000002', 'bb000000-0000-0000-0000-000000000001', 'Sub', 'Two',   '2014-04-01', null, 'a2000000-0000-0000-0000-000000000001', 'Gu', 'Two',   null, null),
  ('a4000000-0000-0000-0000-000000000003', 'bb000000-0000-0000-0000-000000000001', 'Ada', 'Obi',   '2014-05-05', 'female', 'a2000000-0000-0000-0000-000000000001', 'Ngozi', 'Obi', 'Parent@Example.test', '08000000001'),
  ('a4000000-0000-0000-0000-000000000004', 'bb000000-0000-0000-0000-000000000001', 'Bola', 'Obi',  '2015-06-06', 'male',   'a2000000-0000-0000-0000-000000000001', 'Ngozi', 'Obi', 'parent@example.test', '08000000001'),
  ('a4000000-0000-0000-0000-000000000005', 'bb000000-0000-0000-0000-000000000001', 'Chidi', 'Eze', '2014-07-07', 'male',   'a2000000-0000-0000-0000-000000000001', 'Emeka', 'Eze', 'eze@example.test', null),
  ('a4000000-0000-0000-0000-000000000006', 'bb000000-0000-0000-0000-000000000001', 'Sub', 'Three', '2014-08-08', null, 'a2000000-0000-0000-0000-000000000001', 'Gu', 'Three', null, null),
  ('a4000000-0000-0000-0000-000000000007', 'bb000000-0000-0000-0000-000000000002', 'Bee', 'App',   '2014-09-09', null, 'a2000000-0000-0000-0000-000000000002', 'Gu', 'Bee', null, null);

-- Drive conv1..conv3 through the legal path to 'approved' (the status trigger validates each hop).
update applications set status = 'under_review' where id in ('a4000000-0000-0000-0000-000000000003','a4000000-0000-0000-0000-000000000004','a4000000-0000-0000-0000-000000000005');
update applications set status = 'approved'     where id in ('a4000000-0000-0000-0000-000000000003','a4000000-0000-0000-0000-000000000004','a4000000-0000-0000-0000-000000000005');

insert into application_documents (id, application_id, doc_type, file_url) values
  ('a6000000-0000-0000-0000-000000000001', 'a4000000-0000-0000-0000-000000000001', 'birth_certificate', 'https://example.invalid/doc-a'),
  ('a6000000-0000-0000-0000-000000000002', 'a4000000-0000-0000-0000-000000000007', 'birth_certificate', 'https://example.invalid/doc-b');

-- Guardians / students for RLS + trigger tests. ee..01 is a login-linked guardian (user dd..04) with child ff..01.
insert into guardians (id, campus_id, users_id, first_name, last_name) values
  ('ee000000-0000-0000-0000-000000000001', 'bb000000-0000-0000-0000-000000000001', 'dd000000-0000-0000-0000-000000000004', 'Linked', 'Guardian'),
  ('ee000000-0000-0000-0000-000000000002', 'bb000000-0000-0000-0000-000000000001', null, 'Other', 'GuardianA'),
  ('ee000000-0000-0000-0000-000000000003', 'bb000000-0000-0000-0000-000000000002', null, 'Other', 'GuardianB');
insert into students (id, campus_id, display_name) values
  ('ff000000-0000-0000-0000-000000000001', 'bb000000-0000-0000-0000-000000000001', '[TEST] Linked Child'),
  ('ff000000-0000-0000-0000-000000000002', 'bb000000-0000-0000-0000-000000000001', '[TEST] Unlinked Student'),
  ('ff000000-0000-0000-0000-000000000003', 'bb000000-0000-0000-0000-000000000002', '[TEST] Campus B Student');
insert into guardian_students (guardian_id, student_id, relationship) values
  ('ee000000-0000-0000-0000-000000000001', 'ff000000-0000-0000-0000-000000000001', 'mother');

-- -----------------------------------------------------------------------------
-- 1. Privilege layer — the privilege grants themselves, independent of RLS
-- -----------------------------------------------------------------------------

select is(
  (select count(*) from unnest(array['guardians','guardian_students','applications','application_documents']) t,
          unnest(array['anon','authenticated']) r,
          unnest(array['insert','update','delete']) p
   where has_table_privilege(r, t, p)),
  0::bigint,
  'Neither anon nor authenticated holds INSERT/UPDATE/DELETE on any of the four admissions tables'
);

select is(
  (select count(*) from pg_proc
   where proname in ('app_application_transition', 'app_convert_application')
     and (has_function_privilege('anon', oid, 'execute')
       or has_function_privilege('authenticated', oid, 'execute')
       or has_function_privilege('public', oid, 'execute'))),
  0::bigint,
  'No EXECUTE on the two atomic admissions functions for anon, authenticated or PUBLIC (migration 0020 lesson)'
);

select is(
  (select count(*) from pg_proc
   where proname in ('app_application_transition', 'app_convert_application')
     and has_function_privilege('service_role', oid, 'execute')),
  2::bigint,
  'service_role can execute both atomic admissions functions'
);

-- -----------------------------------------------------------------------------
-- 2. Permission seeds (migration 0023)
-- -----------------------------------------------------------------------------

select is(
  (select count(*) from role_permissions rp
     join roles r on r.id = rp.role_id join permissions p on p.id = rp.permission_id
   where r.key in ('super_admin', 'school_administrator', 'principal')
     and p.key in ('admissions.applications.read', 'admissions.applications.manage')),
  6::bigint,
  'super_admin, school_administrator and principal each hold both read and manage'
);

select is(
  (select array_agg(p.key order by p.key) from role_permissions rp
     join roles r on r.id = rp.role_id join permissions p on p.id = rp.permission_id
   where r.key = 'vice_principal' and p.key like 'admissions.%'),
  array['admissions.applications.read'],
  'vice_principal holds read only — not manage'
);

select is(
  (select array_agg(p.key order by p.key) from role_permissions rp
     join roles r on r.id = rp.role_id join permissions p on p.id = rp.permission_id
   where r.key = 'proprietor' and p.key like 'admissions.%'),
  array['admissions.applications.read'],
  'proprietor holds read only — not manage'
);

select is(
  (select count(*) from role_permissions rp
     join roles r on r.id = rp.role_id join permissions p on p.id = rp.permission_id
   where r.key = 'accountant' and p.key like 'admissions.%'),
  0::bigint,
  'accountant holds no admissions permission'
);

-- -----------------------------------------------------------------------------
-- 3. Database-level triggers and constraints (superuser: proves the DB itself
--    enforces these, independent of RLS or the App Backend)
-- -----------------------------------------------------------------------------

select matches(
  (select reference_no from applications where id = 'a4000000-0000-0000-0000-000000000001'),
  '^APP-[0-9]{4}-[0-9]{6}$',
  'reference_no is generated automatically in APP-YYYY-NNNNNN form'
);

select throws_ok(
  $$ insert into applications (campus_id, applicant_first_name, applicant_last_name, applicant_date_of_birth, class_definition_id, guardian_first_name, guardian_last_name, status)
     values ('bb000000-0000-0000-0000-000000000001', 'X', 'Y', '2014-01-01', 'a2000000-0000-0000-0000-000000000001', 'G', 'H', 'approved') $$,
  'P0001', null,
  'A new application cannot be inserted in any status other than submitted'
);

select throws_ok(
  $$ insert into applications (campus_id, applicant_first_name, applicant_last_name, applicant_date_of_birth, class_definition_id, guardian_first_name, guardian_last_name)
     values ('bb000000-0000-0000-0000-000000000001', 'X', 'Y', '2014-01-01', 'a2000000-0000-0000-0000-000000000002', 'G', 'H') $$,
  'P0001', null,
  'An application cannot name a level (class_definition) that belongs to a different campus (migration 0027)'
);

select throws_ok(
  $$ update applications set applicant_first_name = 'Changed' where id = 'a4000000-0000-0000-0000-000000000002' $$,
  'P0001', null,
  'Application identity fields are immutable once submitted'
);

select throws_ok(
  $$ update applications set status = 'approved' where id = 'a4000000-0000-0000-0000-000000000002' $$,
  'P0001', null,
  'submitted -> approved is rejected by the status-transition trigger (must pass through under_review)'
);

select lives_ok(
  $$ update applications set status = 'under_review' where id = 'a4000000-0000-0000-0000-000000000002' $$,
  'submitted -> under_review is a legal transition'
);

select throws_ok(
  $$ insert into guardian_students (guardian_id, student_id, relationship)
     values ('ee000000-0000-0000-0000-000000000001', 'ff000000-0000-0000-0000-000000000003', 'mother') $$,
  'P0001', null,
  'A guardian (Campus A) cannot be linked to a student in Campus B'
);

select throws_ok(
  $$ update students set lifecycle_status = 'bogus' where id = 'ff000000-0000-0000-0000-000000000001' $$,
  '23514', null,
  'students.lifecycle_status rejects values outside the allowed set'
);

-- RPC contract with the App Backend (apps/api admissions.repository.ts). The backend calls these
-- functions by named parameter; apps/api/test/admissions.repository.spec.ts asserts the same names
-- on the TypeScript side, so renaming a parameter on either side fails a test on the other.
select is(
  (select proargnames from pg_proc where proname = 'app_application_transition'),
  array['p_id', 'p_campus_id', 'p_to_status', 'p_actor_id', 'p_action', 'p_review_notes', 'p_decision_reason'],
  'app_application_transition parameter names match what the App Backend sends'
);

select is(
  (select proargnames from pg_proc where proname = 'app_convert_application'),
  array['p_application_id', 'p_campus_id', 'p_class_id', 'p_actor_id'],
  'app_convert_application parameter names match what the App Backend sends'
);

-- The backend's duplicate-application lookup escapes ILIKE wildcards (escapeIlike) and matches
-- case-insensitively; confirm PostgreSQL treats the escaped pattern as a literal.
select is(
  (select count(*) from applications where applicant_first_name ilike 'S\_b'),
  0::bigint,
  'An escaped underscore in an ILIKE pattern is a literal, not a one-character wildcard'
);

select is(
  (select count(*) from applications where applicant_first_name ilike 'sUB'),
  3::bigint,
  'ILIKE matches names case-insensitively (the duplicate lookup relies on this)'
);

-- -----------------------------------------------------------------------------
-- 4. RLS reads and direct-write denial
-- -----------------------------------------------------------------------------

reset role;
set local role authenticated;
set local request.jwt.claim.sub = 'cc000000-0000-0000-0000-000000000001';  -- school_administrator, Campus A

select is(
  (select count(*) from applications),
  6::bigint,
  'A Campus A administrator sees exactly the six Campus A applications'
);

select is(
  (select count(*) from applications where campus_id = 'bb000000-0000-0000-0000-000000000002'),
  0::bigint,
  'A Campus A administrator cannot see Campus B applications'
);

select is(
  (select count(*) from guardians),
  2::bigint,
  'A Campus A administrator sees the two Campus A guardians, not the Campus B one'
);

select is(
  (select count(*) from guardian_students),
  1::bigint,
  'A Campus A administrator sees Campus A guardian links only'
);

select is(
  (select count(*) from application_documents where application_id = 'a4000000-0000-0000-0000-000000000001'),
  1::bigint,
  'A Campus A administrator sees documents of Campus A applications'
);

select is(
  (select count(*) from application_documents where application_id = 'a4000000-0000-0000-0000-000000000007'),
  0::bigint,
  'A Campus A administrator cannot see a Campus B application''s documents'
);

select throws_ok(
  $$ insert into applications (campus_id, applicant_first_name, applicant_last_name, applicant_date_of_birth, class_definition_id, guardian_first_name, guardian_last_name)
     values ('bb000000-0000-0000-0000-000000000001', 'X', 'Y', '2014-01-01', 'a2000000-0000-0000-0000-000000000001', 'G', 'H') $$,
  '42501', null,
  'Even a manage-permission administrator cannot INSERT applications directly (writes go through the App Backend only)'
);

select throws_ok(
  $$ update applications set review_notes = 'direct write' where id = 'a4000000-0000-0000-0000-000000000001' $$,
  '42501', null,
  'Even a manage-permission administrator cannot UPDATE applications directly'
);

select throws_ok(
  $$ insert into guardians (campus_id, first_name, last_name) values ('bb000000-0000-0000-0000-000000000001', 'X', 'Y') $$,
  '42501', null,
  'An administrator cannot INSERT guardians directly'
);

select throws_ok(
  $$ select app_convert_application('a4000000-0000-0000-0000-000000000003', 'bb000000-0000-0000-0000-000000000001', 'a3000000-0000-0000-0000-000000000001', 'dd000000-0000-0000-0000-000000000001') $$,
  '42501', null,
  'An administrator cannot call app_convert_application() directly — service_role only'
);

-- vice_principal: read-only permission still sees applications (policy accepts read OR manage)
reset role;
set local role authenticated;
set local request.jwt.claim.sub = 'cc000000-0000-0000-0000-000000000002';

select is(
  (select count(*) from applications),
  6::bigint,
  'A vice_principal (read only) can read Campus A applications'
);

-- accountant: no admissions permission
reset role;
set local role authenticated;
set local request.jwt.claim.sub = 'cc000000-0000-0000-0000-000000000003';

select is(
  (select count(*) from applications) + (select count(*) from guardians) + (select count(*) from application_documents),
  0::bigint,
  'An accountant (no admissions permission) sees no applications, guardians or documents'
);

-- Campus B administrator
reset role;
set local role authenticated;
set local request.jwt.claim.sub = 'cc000000-0000-0000-0000-000000000005';

select is(
  (select count(*) from applications),
  1::bigint,
  'A Campus B administrator sees only the one Campus B application'
);

select is(
  (select count(*) from application_documents where application_id = 'a4000000-0000-0000-0000-000000000001'),
  0::bigint,
  'A Campus B administrator cannot see Campus A application documents'
);

-- Guardian (login-linked): sees only their own guardian record and links; no applications
reset role;
set local role authenticated;
set local request.jwt.claim.sub = 'cc000000-0000-0000-0000-000000000004';

select is(
  (select count(*) from guardians),
  1::bigint,
  'A guardian sees only their own guardian record'
);

select is(
  (select count(*) from guardian_students where guardian_id = 'ee000000-0000-0000-0000-000000000001'),
  1::bigint,
  'A guardian sees their own guardian-student link'
);

select is(
  (select count(*) from applications),
  0::bigint,
  'A guardian cannot see applications'
);

select ok(
  app_is_guardian_of_student('ff000000-0000-0000-0000-000000000001'),
  'app_is_guardian_of_student() is true for the guardian''s own linked child'
);

select ok(
  not app_is_guardian_of_student('ff000000-0000-0000-0000-000000000002'),
  'app_is_guardian_of_student() is false for a student the guardian is not linked to'
);

-- Anonymous
reset role;
set local role anon;
set local request.jwt.claim.sub = '';

select is(
  (select count(*) from applications) + (select count(*) from guardians) + (select count(*) from guardian_students) + (select count(*) from application_documents),
  0::bigint,
  'anon sees no admissions data at all'
);

select throws_ok(
  $$ insert into guardians (campus_id, first_name, last_name) values ('bb000000-0000-0000-0000-000000000001', 'X', 'Y') $$,
  '42501', null,
  'anon cannot INSERT guardians (migration 0025 closed the privilege-layer gap)'
);

-- -----------------------------------------------------------------------------
-- 5. app_application_transition() as service_role
-- -----------------------------------------------------------------------------

reset role;
set local role service_role;

select is(
  (select status from app_application_transition(
     'a4000000-0000-0000-0000-000000000001', 'bb000000-0000-0000-0000-000000000001',
     'under_review', 'dd000000-0000-0000-0000-000000000001', 'application.under_review', 'looks complete', null)),
  'under_review'::application_status,
  'service_role can move a submitted application to under_review via the function'
);

select is(
  (select reviewed_by from applications where id = 'a4000000-0000-0000-0000-000000000001'),
  'dd000000-0000-0000-0000-000000000001'::uuid,
  'The transition recorded the acting reviewer'
);

select is(
  (select metadata_json->>'to' from audit_logs
   where target_id = 'a4000000-0000-0000-0000-000000000001' and action = 'application.under_review'),
  'under_review',
  'The transition atomically wrote a matching audit_logs entry (with from/to metadata)'
);

select throws_like(
  $$ select app_application_transition(
       'a4000000-0000-0000-0000-000000000001', 'bb000000-0000-0000-0000-000000000001',
       'converted', 'dd000000-0000-0000-0000-000000000001', 'application.converted_invalid') $$,
  '%Invalid application status transition%',
  'under_review -> converted is rejected (must be approved first)'
);

select is(
  (select count(*) from audit_logs where target_id = 'a4000000-0000-0000-0000-000000000001' and action = 'application.converted_invalid'),
  0::bigint,
  'A rejected transition leaves no audit entry behind (atomic)'
);

select throws_like(
  $$ select app_application_transition(
       'a4000000-0000-0000-0000-000000000001', 'bb000000-0000-0000-0000-000000000002',
       'approved', 'dd000000-0000-0000-0000-000000000005', 'application.approved') $$,
  '%not found%',
  'The function rejects a campus mismatch (Campus B actor cannot transition a Campus A application)'
);

select is(
  (select decision_reason from app_application_transition(
     'a4000000-0000-0000-0000-000000000002', 'bb000000-0000-0000-0000-000000000001',
     'rejected', 'dd000000-0000-0000-0000-000000000001', 'application.rejected', null, 'Incomplete documents')),
  'Incomplete documents',
  'A rejection stores the decision reason'
);

-- -----------------------------------------------------------------------------
-- 6. app_convert_application() as service_role
-- -----------------------------------------------------------------------------

select throws_like(
  $$ select app_convert_application('a4000000-0000-0000-0000-000000000006', 'bb000000-0000-0000-0000-000000000001', 'a3000000-0000-0000-0000-000000000001', 'dd000000-0000-0000-0000-000000000001') $$,
  '%must be approved before conversion%',
  'A submitted (not approved) application cannot be converted'
);

select throws_like(
  $$ select app_convert_application('a4000000-0000-0000-0000-000000000005', 'bb000000-0000-0000-0000-000000000002', 'a3000000-0000-0000-0000-000000000003', 'dd000000-0000-0000-0000-000000000005') $$,
  '%not found%',
  'Conversion rejects a campus mismatch on the application'
);

select throws_like(
  $$ select app_convert_application('a4000000-0000-0000-0000-000000000005', 'bb000000-0000-0000-0000-000000000001', 'a3000000-0000-0000-0000-000000000003', 'dd000000-0000-0000-0000-000000000001') $$,
  '%does not belong to this campus%',
  'Conversion rejects a class from another campus'
);

select throws_like(
  $$ select app_convert_application('a4000000-0000-0000-0000-000000000005', 'bb000000-0000-0000-0000-000000000001', 'a3000000-0000-0000-0000-000000000002', 'dd000000-0000-0000-0000-000000000001') $$,
  '%not a class of the level applied for%',
  'Conversion rejects a class of a different level than the one applied for (SS 1 class for a JSS 1 applicant)'
);

-- Atomicity: force a failure late in the function, after the guardian has already been
-- created, by pre-seeding a student whose admission number is exactly the one the next
-- conversion will compute (one existing number -> next is 00002). The unique index then
-- fails the student insert, and the guardian created earlier in the same call must be
-- rolled back with it.
insert into students (campus_id, display_name, admission_no)
values ('bb000000-0000-0000-0000-000000000001', '[TEST] Collider',
        'FFS-' || to_char(now(), 'YYYY') || '-00002');

select throws_like(
  $$ select app_convert_application('a4000000-0000-0000-0000-000000000005', 'bb000000-0000-0000-0000-000000000001', 'a3000000-0000-0000-0000-000000000001', 'dd000000-0000-0000-0000-000000000001') $$,
  '%uq_students_admission_no_per_campus%',
  'An admission-number collision fails the conversion (unique index is the backstop)'
);

select is(
  (select count(*) from guardians where lower(email) = 'eze@example.test')
  + (select count(*) from students where display_name = 'Chidi Eze')
  + (select count(*) from applications where id = 'a4000000-0000-0000-0000-000000000005' and status <> 'approved'),
  0::bigint,
  'The failed conversion left nothing behind: no guardian, no student, application still approved (atomic)'
);

delete from students where display_name = '[TEST] Collider';

-- Happy path
select lives_ok(
  $$ create temp table conv1 as
     select app_convert_application('a4000000-0000-0000-0000-000000000003', 'bb000000-0000-0000-0000-000000000001', 'a3000000-0000-0000-0000-000000000001', 'dd000000-0000-0000-0000-000000000001') as r $$,
  'An approved application converts successfully'
);

select matches(
  (select r->>'admissionNo' from conv1),
  '^FFS-[0-9]{4}-00001$',
  'The first conversion in a campus gets admission number 00001'
);

select is(
  (select lifecycle_status || '|' || display_name || '|' || date_of_birth::text from students where id = (select (r->>'studentId')::uuid from conv1)),
  'admitted|Ada Obi|2014-05-05',
  'The new student is created as admitted, with the applicant''s name and date of birth'
);

select is(
  (select count(*) from guardian_students
   where student_id = (select (r->>'studentId')::uuid from conv1)
     and guardian_id = (select (r->>'guardianId')::uuid from conv1)
     and relationship = 'guardian'),
  1::bigint,
  'The guardian is created and linked to the student'
);

select is(
  (select count(*) from enrollments
   where student_id = (select (r->>'studentId')::uuid from conv1)
     and class_id = 'a3000000-0000-0000-0000-000000000001' and status = 'active'),
  1::bigint,
  'An active enrollment is created in the requested class'
);

select is(
  (select academic_session_id from enrollments where student_id = (select (r->>'studentId')::uuid from conv1)),
  'a1000000-0000-0000-0000-000000000001'::uuid,
  'The enrollment takes its academic session from the class itself (no caller-supplied session to get wrong)'
);

select is(
  (select converted_student_id from applications where id = 'a4000000-0000-0000-0000-000000000003'),
  (select (r->>'studentId')::uuid from conv1),
  'The application is marked converted and points at the new student'
);

select is(
  (select metadata_json->>'admission_no' from audit_logs
   where target_id = 'a4000000-0000-0000-0000-000000000003' and action = 'application.converted'),
  (select r->>'admissionNo' from conv1),
  'Conversion wrote an audit_logs entry carrying the admission number'
);

select throws_like(
  $$ select app_convert_application('a4000000-0000-0000-0000-000000000003', 'bb000000-0000-0000-0000-000000000001', 'a3000000-0000-0000-0000-000000000001', 'dd000000-0000-0000-0000-000000000001') $$,
  '%must be approved before conversion%',
  'An already-converted application cannot be converted a second time'
);

-- Sibling: same guardian e-mail (different case) in the same campus reuses the existing guardian.
select lives_ok(
  $$ create temp table conv2 as
     select app_convert_application('a4000000-0000-0000-0000-000000000004', 'bb000000-0000-0000-0000-000000000001', 'a3000000-0000-0000-0000-000000000001', 'dd000000-0000-0000-0000-000000000001') as r $$,
  'A sibling application converts successfully'
);

select is(
  (select (r->>'guardianId') from conv2),
  (select (r->>'guardianId') from conv1),
  'The sibling reuses the existing guardian (matched by e-mail, case-insensitively)'
);

select is(
  (select count(*) from guardian_students where guardian_id = (select (r->>'guardianId')::uuid from conv1)),
  2::bigint,
  'The shared guardian is now linked to both children'
);

select matches(
  (select r->>'admissionNo' from conv2),
  '^FFS-[0-9]{4}-00002$',
  'The second conversion in the campus gets admission number 00002'
);

-- -----------------------------------------------------------------------------
-- 7. admission_no uniqueness (superuser). Last on purpose: it adds students with
--    admission numbers, which would shift the sequential numbers asserted above.
-- -----------------------------------------------------------------------------

reset role;

insert into students (campus_id, display_name, admission_no) values
  ('bb000000-0000-0000-0000-000000000002', '[TEST] Adm Dup 1', 'ADM-DUP');

select throws_ok(
  $$ insert into students (campus_id, display_name, admission_no) values ('bb000000-0000-0000-0000-000000000002', '[TEST] Adm Dup 2', 'ADM-DUP') $$,
  '23505', null,
  'admission_no is unique within a campus'
);

select lives_ok(
  $$ insert into students (campus_id, display_name, admission_no) values ('bb000000-0000-0000-0000-000000000001', '[TEST] Adm Dup Other Campus', 'ADM-DUP') $$,
  'The same admission_no is allowed in a different campus'
);

select * from finish();
rollback;
