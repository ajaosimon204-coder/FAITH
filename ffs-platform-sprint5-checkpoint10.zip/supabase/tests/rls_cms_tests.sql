-- =============================================================================
-- RLS Test Suite: CMS
-- Sprint 4 — Faith Foundation Schools Digital Platform
-- Rewritten per migration 0019 (Sprint 4 adversarial audit corrections).
--
-- Central properties tested: published content is genuinely public (works
-- for the `anon` role, no auth at all); non-published content is
-- staff-only, same-campus; the `authenticated` role has NO direct write
-- access at all (not even content.create/publish/archive holders) —
-- ALL writes go exclusively through the service-role-only atomic
-- app_cms_transition() function, which independently re-checks campus
-- scoping and is the only place actor fields can be set (always to the
-- caller's own resolved identity, never client-suppliable).
-- =============================================================================

begin;
select plan(18);

-- -----------------------------------------------------------------------------
-- Fixtures
-- -----------------------------------------------------------------------------

insert into organizations (id, name) values
  ('a9000000-0000-0000-0000-000000000001', '[TEST] Org A');
insert into campuses (id, organization_id, name) values
  ('b9000000-0000-0000-0000-000000000001', 'a9000000-0000-0000-0000-000000000001', '[TEST] Campus A');

insert into auth.users (id, email) values
  ('c9000000-0000-0000-0000-000000000001', 'editor-a@test.invalid'),
  ('c9000000-0000-0000-0000-000000000002', 'random-staff@test.invalid'),
  ('c9000000-0000-0000-0000-000000000009', 'innocent-victim@test.invalid');

insert into users (id, auth_user_id, campus_id, email, status) values
  ('d9000000-0000-0000-0000-000000000001', 'c9000000-0000-0000-0000-000000000001', 'b9000000-0000-0000-0000-000000000001', 'editor-a@test.invalid', 'active'),
  ('d9000000-0000-0000-0000-000000000002', 'c9000000-0000-0000-0000-000000000002', 'b9000000-0000-0000-0000-000000000001', 'random-staff@test.invalid', 'active'),
  ('d9000000-0000-0000-0000-000000000009', 'c9000000-0000-0000-0000-000000000009', 'b9000000-0000-0000-0000-000000000001', 'innocent-victim@test.invalid', 'active');

insert into user_roles (user_id, role_id, campus_id, assigned_by)
select 'd9000000-0000-0000-0000-000000000001', id, 'b9000000-0000-0000-0000-000000000001', 'd9000000-0000-0000-0000-000000000001'
from roles where key = 'content_editor';  -- holds ONLY content.create

-- A published page and a draft page, plus an 'approved' page ready to
-- test the Critical-finding-fix directly. All state reached via superuser
-- writes respecting the trigger's valid sequence.
insert into cms_pages (id, campus_id, slug, title, status, created_by) values
  ('e9000000-0000-0000-0000-000000000001', 'b9000000-0000-0000-0000-000000000001', 'about', '[TEST] About', 'draft', 'd9000000-0000-0000-0000-000000000001');
update cms_pages set status = 'in_review' where id = 'e9000000-0000-0000-0000-000000000001';
update cms_pages set status = 'approved', reviewed_by = 'd9000000-0000-0000-0000-000000000001' where id = 'e9000000-0000-0000-0000-000000000001';
update cms_pages set status = 'published', published_by = 'd9000000-0000-0000-0000-000000000001' where id = 'e9000000-0000-0000-0000-000000000001';

insert into cms_pages (id, campus_id, slug, title, status, created_by) values
  ('e9000000-0000-0000-0000-000000000002', 'b9000000-0000-0000-0000-000000000001', 'draft-page', '[TEST] Draft', 'draft', 'd9000000-0000-0000-0000-000000000001');

insert into cms_pages (id, campus_id, slug, title, status, created_by) values
  ('e9000000-0000-0000-0000-000000000003', 'b9000000-0000-0000-0000-000000000001', 'approved-page', '[TEST] Approved', 'draft', 'd9000000-0000-0000-0000-000000000001');
update cms_pages set status = 'in_review' where id = 'e9000000-0000-0000-0000-000000000003';
update cms_pages set status = 'approved' where id = 'e9000000-0000-0000-0000-000000000003';

-- Second campus, for cross-campus tests.
insert into organizations (id, name) values
  ('a9000000-0000-0000-0000-000000000002', '[TEST] Org B');
insert into campuses (id, organization_id, name) values
  ('b9000000-0000-0000-0000-000000000002', 'a9000000-0000-0000-0000-000000000002', '[TEST] Campus B');
insert into auth.users (id, email) values
  ('c9000000-0000-0000-0000-000000000003', 'editor-b@test.invalid'),
  ('c9000000-0000-0000-0000-000000000004', 'publisher-b@test.invalid');
insert into users (id, auth_user_id, campus_id, email, status) values
  ('d9000000-0000-0000-0000-000000000003', 'c9000000-0000-0000-0000-000000000003', 'b9000000-0000-0000-0000-000000000002', 'editor-b@test.invalid', 'active'),
  ('d9000000-0000-0000-0000-000000000004', 'c9000000-0000-0000-0000-000000000004', 'b9000000-0000-0000-0000-000000000002', 'publisher-b@test.invalid', 'active');
insert into user_roles (user_id, role_id, campus_id, assigned_by)
select 'd9000000-0000-0000-0000-000000000003', id, 'b9000000-0000-0000-0000-000000000002', 'd9000000-0000-0000-0000-000000000003'
from roles where key = 'content_editor';
insert into user_roles (user_id, role_id, campus_id, assigned_by)
select 'd9000000-0000-0000-0000-000000000004', id, 'b9000000-0000-0000-0000-000000000002', 'd9000000-0000-0000-0000-000000000004'
from roles where key = 'school_administrator';  -- holds content.review + content.publish + content.archive

-- -----------------------------------------------------------------------------
-- 1. Published content is readable by a completely anonymous visitor.
-- -----------------------------------------------------------------------------

set local role anon;

select is(
  (select count(*) from cms_pages where slug = 'about' and status = 'published'),
  1::bigint,
  'An anonymous (unauthenticated) visitor can read published CMS content'
);

select is(
  (select count(*) from cms_pages where slug = 'draft-page'),
  0::bigint,
  'An anonymous visitor cannot see draft content at all'
);

-- -----------------------------------------------------------------------------
-- 2. A content_editor (content.create) can see drafts in their own campus.
-- -----------------------------------------------------------------------------

set local role authenticated;
set local request.jwt.claim.sub = 'c9000000-0000-0000-0000-000000000001';

select is(
  (select count(*) from cms_pages where slug = 'draft-page'),
  1::bigint,
  'A content_editor (content.create) can see draft content in their own campus'
);

-- -----------------------------------------------------------------------------
-- 3. Staff WITHOUT any content permission cannot see drafts, even same-campus.
-- -----------------------------------------------------------------------------

set local request.jwt.claim.sub = 'c9000000-0000-0000-0000-000000000002';

select is(
  (select count(*) from cms_pages where slug = 'draft-page'),
  0::bigint,
  'A staff member with no content.* permission cannot see draft content'
);

select is(
  (select count(*) from cms_pages where slug = 'about'),
  1::bigint,
  'Published content remains visible even to a staff member with no content permission'
);

-- -----------------------------------------------------------------------------
-- 4. NO direct write access for `authenticated` at all, regardless of
--    permission level. This is the core fix for Critical findings 1 & 2
--    from the Sprint 4 adversarial audit (migration 0019).
-- -----------------------------------------------------------------------------

set local request.jwt.claim.sub = 'c9000000-0000-0000-0000-000000000001';

select throws_ok(
  $$ insert into cms_pages (campus_id, slug, title, status, created_by)
     values ('b9000000-0000-0000-0000-000000000001', 'direct-insert-attempt', '[TEST] X', 'draft', 'd9000000-0000-0000-0000-000000000001') $$,
  null,
  'A content_editor (content.create) CANNOT insert directly — no INSERT grant for authenticated at all post-0019'
);

select throws_ok(
  $$ update cms_pages set status = 'in_review' where slug = 'draft-page' $$,
  null,
  'A content_editor (content.create) CANNOT update status directly, not even a legitimate draft->in_review transition — must go through the App Backend'
);

-- -----------------------------------------------------------------------------
-- 5. THE Critical-finding-fix verification: an actor holding ONLY
--    content.create cannot move approved->published via direct write,
--    even though they could see the row and even though the OLD RLS
--    policy would have permitted this (confirmed live during the audit,
--    before this migration existed).
-- -----------------------------------------------------------------------------

select throws_ok(
  $$ update cms_pages set status = 'published', published_by = 'd9000000-0000-0000-0000-000000000001'
     where slug = 'approved-page' $$,
  null,
  'A content.create-only actor cannot publish approved content directly (Critical Finding 1, closed)'
);

select is(
  (select status from cms_pages where slug = 'approved-page'),
  'approved'::cms_content_status,
  'approved-page remains approved — the direct-write attempt was fully rejected, not partially applied'
);

-- -----------------------------------------------------------------------------
-- 6. Actor-field forgery is now structurally impossible via direct write
--    (Critical Finding 2, closed) — there is no write path left that
--    would even reach the point of setting published_by/reviewed_by/
--    approved_by to begin with.
-- -----------------------------------------------------------------------------

select throws_ok(
  $$ update cms_pages set published_by = 'd9000000-0000-0000-0000-000000000009'
     where slug = 'about' $$,
  null,
  'published_by cannot be forged to an arbitrary user id via direct write — no UPDATE grant exists at all'
);

-- -----------------------------------------------------------------------------
-- 7. The atomic app_cms_transition() function works correctly when called
--    as service_role (standing in for the App Backend's own connection) —
--    proving the fix closed the bypass without breaking the legitimate path.
-- -----------------------------------------------------------------------------

reset role;
set local role service_role;

select lives_ok(
  $$ select app_cms_transition(
       'cms_pages', 'e9000000-0000-0000-0000-000000000003'::uuid, 'published'::cms_content_status,
       'published_by', 'd9000000-0000-0000-0000-000000000001'::uuid,
       'cms_pages.approved_to_published', 'b9000000-0000-0000-0000-000000000001'::uuid,
       '{"from":"approved","to":"published"}'::jsonb
     ) $$,
  'The App Backend (service_role), via app_cms_transition(), CAN publish approved content'
);

select is(
  (select status from cms_pages where id = 'e9000000-0000-0000-0000-000000000003'),
  'published'::cms_content_status,
  'The transition via app_cms_transition() actually persisted'
);

select is(
  (select count(*) from audit_logs where target_id = 'e9000000-0000-0000-0000-000000000003' and action = 'cms_pages.approved_to_published'),
  1::bigint,
  'app_cms_transition() atomically wrote the corresponding audit_logs entry'
);

-- -----------------------------------------------------------------------------
-- 8. app_cms_transition()'s own campus check — even as service_role, the
--    function itself rejects a mismatched campus_id (defense in depth,
--    independent of the App Backend's own TypeScript check).
-- -----------------------------------------------------------------------------

select throws_ok(
  $$ select app_cms_transition(
       'cms_pages', 'e9000000-0000-0000-0000-000000000002'::uuid, 'in_review'::cms_content_status,
       null, 'd9000000-0000-0000-0000-000000000003'::uuid,
       'cms_pages.draft_to_in_review', 'b9000000-0000-0000-0000-000000000002'::uuid,
       '{}'::jsonb
     ) $$,
  null,
  'app_cms_transition() itself rejects a campus_id mismatch (draft-page is Campus A, function called with Campus B)'
);

-- EXECUTE is not granted to authenticated/anon at all.
set local role authenticated;
set local request.jwt.claim.sub = 'c9000000-0000-0000-0000-000000000001';

select throws_ok(
  $$ select app_cms_transition(
       'cms_pages', 'e9000000-0000-0000-0000-000000000002'::uuid, 'in_review'::cms_content_status,
       null, 'd9000000-0000-0000-0000-000000000001'::uuid,
       'cms_pages.draft_to_in_review', 'b9000000-0000-0000-0000-000000000001'::uuid,
       '{}'::jsonb
     ) $$,
  null,
  'authenticated cannot call app_cms_transition() at all — no EXECUTE grant, so a content_editor cannot reach the atomic function directly either'
);

-- -----------------------------------------------------------------------------
-- 9. No DELETE grant for authenticated at all — unaffected by 0019.
-- -----------------------------------------------------------------------------

select throws_ok(
  $$ delete from cms_pages where slug = 'draft-page' $$,
  null,
  'The authenticated role cannot delete CMS pages at all'
);

-- -----------------------------------------------------------------------------
-- 10. Cross-campus read isolation — unaffected by 0019, re-verified.
-- -----------------------------------------------------------------------------

set local request.jwt.claim.sub = 'c9000000-0000-0000-0000-000000000003';

select is(
  (select count(*) from cms_pages where slug = 'draft-page'),
  0::bigint,
  'A content_editor from Campus B cannot see Campus A''s draft content'
);

-- -----------------------------------------------------------------------------
-- 11. Cross-campus, PUBLISHER-specific (not just author) — the Sprint 4
--     audit specifically asked this be tested as its own case, not
--     inferred from the author case. Using publisher-b, who holds
--     content.publish (not just content.create), attempting to reach
--     Campus A's approved content via the atomic function as service_role
--     would be the App Backend's own equivalent check; here we confirm
--     the function itself independently blocks it regardless of which
--     permission tier the nominal actor holds, since the campus check in
--     app_cms_transition() doesn't look at permissions at all — it
--     structurally cannot be reached without campus_id agreement.
-- -----------------------------------------------------------------------------

reset role;
set local role service_role;

select throws_ok(
  $$ select app_cms_transition(
       'cms_pages', 'e9000000-0000-0000-0000-000000000001'::uuid, 'archived'::cms_content_status,
       null, 'd9000000-0000-0000-0000-000000000004'::uuid,
       'cms_pages.published_to_archived', 'b9000000-0000-0000-0000-000000000002'::uuid,
       '{}'::jsonb
     ) $$,
  null,
  'A Campus B publisher-tier actor cannot archive Campus A''s published content — app_cms_transition() rejects the campus mismatch regardless of the actor''s permission tier'
);

select * from finish();
rollback;
