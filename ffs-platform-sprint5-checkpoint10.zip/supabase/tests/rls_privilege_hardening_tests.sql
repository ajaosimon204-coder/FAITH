-- =============================================================================
-- Privilege Hardening Suite (migration 0026)
-- Faith Foundation Schools Digital Platform
--
-- RLS is the primary access control, but the privilege layer underneath it must
-- not be wider than the access model intends. This suite checks the grants
-- themselves, across EVERY public table (not a hand-kept list), so a table added
-- by any future migration that reintroduces a wide default fails here.
--
-- Run under the faithful harness model (run_all.sh, the default).
-- =============================================================================

begin;
select plan(11);

select is(
  (select count(*) from pg_class c join pg_namespace n on n.oid = c.relnamespace
   where n.nspname = 'public' and c.relkind in ('r', 'p')
     and (has_table_privilege('anon', c.oid, 'insert')
       or has_table_privilege('anon', c.oid, 'update')
       or has_table_privilege('anon', c.oid, 'delete'))),
  0::bigint,
  'anon holds no INSERT/UPDATE/DELETE on any public table'
);

select is(
  (select count(*) from pg_class c join pg_namespace n on n.oid = c.relnamespace, unnest(array['anon','authenticated']) r
   where n.nspname = 'public' and c.relkind in ('r', 'p')
     and (has_table_privilege(r, c.oid, 'truncate')
       or has_table_privilege(r, c.oid, 'references')
       or has_table_privilege(r, c.oid, 'trigger'))),
  0::bigint,
  'Neither anon nor authenticated holds TRUNCATE/REFERENCES/TRIGGER on any public table (TRUNCATE is not subject to RLS)'
);

select ok(
  has_table_privilege('anon', 'cms_pages', 'select'),
  'anon keeps SELECT on cms_pages — the published-content read path is intact'
);

select ok(
  not has_table_privilege('authenticated', 'school_config', 'update'),
  'authenticated cannot UPDATE school_config (migration 0009 holds on a faithful model)'
);

select ok(
  has_table_privilege('service_role', 'applications', 'insert')
  and has_table_privilege('service_role', 'applications', 'update'),
  'service_role is unaffected: it can still write applications (App Backend path)'
);

-- Default privileges: a table created after 0026 starts closed.
create table zz_hardening_probe (id int);

select ok(
  not has_table_privilege('anon', 'zz_hardening_probe', 'insert')
  and not has_table_privilege('anon', 'zz_hardening_probe', 'update')
  and not has_table_privilege('anon', 'zz_hardening_probe', 'delete'),
  'A table created after 0026 gives anon no write privilege by default'
);

select ok(
  not has_table_privilege('authenticated', 'zz_hardening_probe', 'truncate')
  and not has_table_privilege('authenticated', 'zz_hardening_probe', 'references')
  and not has_table_privilege('authenticated', 'zz_hardening_probe', 'trigger'),
  'A table created after 0026 gives authenticated no TRUNCATE/REFERENCES/TRIGGER by default'
);

-- Views: a view runs with its OWNER's rights unless it is security_invoker, which silently bypasses
-- row-level security (the student_current_enrollments exposure, migration 0029). Sweep every view we own.
select is(
  (select count(*) from pg_class c join pg_namespace n on n.oid = c.relnamespace
   where n.nspname = 'public' and c.relkind in ('v', 'm')
     and not exists (select 1 from pg_depend d where d.objid = c.oid and d.deptype = 'e')
     and not coalesce(c.reloptions, '{}') @> array['security_invoker=true']),
  0::bigint,
  'Every view in public is security_invoker (none can bypass row-level security)'
);

select is(
  (select count(*) from pg_class c join pg_namespace n on n.oid = c.relnamespace
   where n.nspname = 'public' and c.relkind in ('v', 'm')
     and not exists (select 1 from pg_depend d where d.objid = c.oid and d.deptype = 'e')
     and (has_table_privilege('anon', c.oid, 'select')
       or has_table_privilege('anon', c.oid, 'insert')
       or has_table_privilege('anon', c.oid, 'update')
       or has_table_privilege('anon', c.oid, 'delete'))),
  0::bigint,
  'anon holds no privilege on any view in public'
);

select is(
  (select count(*) from pg_class c join pg_namespace n on n.oid = c.relnamespace, unnest(array['anon','authenticated']) r
   where n.nspname = 'public' and c.relkind in ('v', 'm')
     and not exists (select 1 from pg_depend d where d.objid = c.oid and d.deptype = 'e')
     and (has_table_privilege(r, c.oid, 'insert')
       or has_table_privilege(r, c.oid, 'update')
       or has_table_privilege(r, c.oid, 'delete')
       or has_table_privilege(r, c.oid, 'truncate'))),
  0::bigint,
  'Neither anon nor authenticated can write through any view in public'
);

-- Forgot-the-grant guard. Current Supabase projects no longer grant on new tables automatically (see
-- migration 0028), so a migration that creates a table without granting it leaves the App Backend
-- unable to touch it. Fails (in the --modern harness model) for any public table service_role cannot use.
select is(
  (select count(*) from pg_class c join pg_namespace n on n.oid = c.relnamespace
   where n.nspname = 'public' and c.relkind in ('r', 'p')
     and c.relname <> 'zz_hardening_probe'  -- this suite's own throwaway table, created above on purpose
     and not exists (select 1 from pg_depend d where d.objid = c.oid and d.deptype = 'e')
     and not (has_table_privilege('service_role', c.oid, 'select')
          and has_table_privilege('service_role', c.oid, 'insert')
          and has_table_privilege('service_role', c.oid, 'update')
          and has_table_privilege('service_role', c.oid, 'delete'))),
  0::bigint,
  'service_role can read and write every table in public (no migration forgot its explicit GRANT)'
);

select * from finish();
rollback;
