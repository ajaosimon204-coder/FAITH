-- =============================================================================
-- student_current_enrollments — must never show more than `enrollments` itself (migration 0029)
--
-- Regression suite for a data exposure found during Sprint 5 hosted-readiness review: the view ran as its
-- owner, bypassing row-level security, so the unauthenticated `anon` role could read every campus's
-- enrollments through it while the table returned nothing. Run under the faithful harness models.
-- =============================================================================

begin;
select plan(9);

insert into organizations (id, name) values
  ('aa000000-0000-0000-0000-000000000001', '[TEST] Org A'), ('aa000000-0000-0000-0000-000000000002', '[TEST] Org B');
insert into campuses (id, organization_id, name) values
  ('bb000000-0000-0000-0000-000000000001', 'aa000000-0000-0000-0000-000000000001', '[TEST] Campus A'),
  ('bb000000-0000-0000-0000-000000000002', 'aa000000-0000-0000-0000-000000000002', '[TEST] Campus B');
insert into auth.users (id, email) values
  ('cc000000-0000-0000-0000-000000000001', 'admin-a@test.invalid'),
  ('cc000000-0000-0000-0000-000000000002', 'admin-b@test.invalid'),
  ('cc000000-0000-0000-0000-000000000003', 'stranger@test.invalid');
insert into users (id, auth_user_id, campus_id, email, status) values
  ('dd000000-0000-0000-0000-000000000001', 'cc000000-0000-0000-0000-000000000001', 'bb000000-0000-0000-0000-000000000001', 'admin-a@test.invalid', 'active'),
  ('dd000000-0000-0000-0000-000000000002', 'cc000000-0000-0000-0000-000000000002', 'bb000000-0000-0000-0000-000000000002', 'admin-b@test.invalid', 'active'),
  ('dd000000-0000-0000-0000-000000000003', 'cc000000-0000-0000-0000-000000000003', 'bb000000-0000-0000-0000-000000000001', 'stranger@test.invalid', 'active');
insert into user_roles (user_id, role_id, campus_id, assigned_by)
select 'dd000000-0000-0000-0000-000000000001', id, 'bb000000-0000-0000-0000-000000000001', 'dd000000-0000-0000-0000-000000000001' from roles where key = 'school_administrator';
insert into user_roles (user_id, role_id, campus_id, assigned_by)
select 'dd000000-0000-0000-0000-000000000002', id, 'bb000000-0000-0000-0000-000000000002', 'dd000000-0000-0000-0000-000000000002' from roles where key = 'school_administrator';

insert into academic_sessions (id, campus_id, name, start_date, end_date, is_current) values
  ('a1000000-0000-0000-0000-000000000001', 'bb000000-0000-0000-0000-000000000001', '[TEST] S', '2025-09-01', '2026-07-31', true),
  ('a1000000-0000-0000-0000-000000000002', 'bb000000-0000-0000-0000-000000000002', '[TEST] S', '2025-09-01', '2026-07-31', true);
insert into class_definitions (id, campus_id, name, level) values
  ('a2000000-0000-0000-0000-000000000001', 'bb000000-0000-0000-0000-000000000001', '[TEST] JSS 1', 'junior_secondary'),
  ('a2000000-0000-0000-0000-000000000002', 'bb000000-0000-0000-0000-000000000002', '[TEST] JSS 1', 'junior_secondary');
insert into classes (id, class_definition_id, academic_session_id, campus_id, name, section) values
  ('a3000000-0000-0000-0000-000000000001', 'a2000000-0000-0000-0000-000000000001', 'a1000000-0000-0000-0000-000000000001', 'bb000000-0000-0000-0000-000000000001', '[TEST] C', 'A'),
  ('a3000000-0000-0000-0000-000000000002', 'a2000000-0000-0000-0000-000000000002', 'a1000000-0000-0000-0000-000000000002', 'bb000000-0000-0000-0000-000000000002', '[TEST] C', 'A');
insert into students (id, campus_id, display_name) values
  ('ff000000-0000-0000-0000-000000000001', 'bb000000-0000-0000-0000-000000000001', '[TEST] Student A'),
  ('ff000000-0000-0000-0000-000000000002', 'bb000000-0000-0000-0000-000000000002', '[TEST] Student B');
insert into enrollments (student_id, class_id, academic_session_id, campus_id, status) values
  ('ff000000-0000-0000-0000-000000000001', 'a3000000-0000-0000-0000-000000000001', 'a1000000-0000-0000-0000-000000000001', 'bb000000-0000-0000-0000-000000000001', 'active'),
  ('ff000000-0000-0000-0000-000000000002', 'a3000000-0000-0000-0000-000000000002', 'a1000000-0000-0000-0000-000000000002', 'bb000000-0000-0000-0000-000000000002', 'active');

select ok(
  (select coalesce(reloptions, '{}') @> array['security_invoker=true'] from pg_class where oid = 'student_current_enrollments'::regclass),
  'The view runs as the caller (security_invoker), so it cannot bypass row-level security'
);

-- The exposure: anonymous callers must get nothing — not a row, and not even a SELECT privilege.
reset role;
set local role anon;
set local request.jwt.claim.sub = '';
select throws_ok(
  $$ select count(*) from student_current_enrollments $$,
  '42501', null,
  'anon cannot read the view at all (it previously returned every campus''s enrollments)'
);

-- An authenticated user with no roles sees nothing, exactly as on the table.
reset role;
set local role authenticated;
set local request.jwt.claim.sub = 'cc000000-0000-0000-0000-000000000003';
select is(
  (select count(*) from student_current_enrollments),
  0::bigint,
  'An authenticated user with no role sees no rows through the view'
);

-- A Campus A administrator sees Campus A only — and exactly what the table shows them.
reset role;
set local role authenticated;
set local request.jwt.claim.sub = 'cc000000-0000-0000-0000-000000000001';
select is(
  (select count(*) from student_current_enrollments where campus_id = 'bb000000-0000-0000-0000-000000000002'),
  0::bigint,
  'A Campus A administrator sees no Campus B enrollment through the view'
);
select is(
  (select count(*) from student_current_enrollments),
  1::bigint,
  'A Campus A administrator sees their own campus''s current enrollment through the view'
);
select is(
  (select count(*) from student_current_enrollments),
  (select count(*) from enrollments),
  'The view shows an administrator exactly what the enrollments table itself shows them'
);

-- Nobody writes through a view. (Asserted on the privilege itself: for a non-updatable view Postgres
-- refuses the statement at rewrite time with 55000, before any privilege check, so an UPDATE attempt
-- would pass for the wrong reason.)
select ok(
  not has_table_privilege('authenticated', 'student_current_enrollments', 'insert')
  and not has_table_privilege('authenticated', 'student_current_enrollments', 'update')
  and not has_table_privilege('authenticated', 'student_current_enrollments', 'delete'),
  'authenticated holds no write privilege on the view'
);

reset role;
set local role authenticated;
set local request.jwt.claim.sub = 'cc000000-0000-0000-0000-000000000002';
select is(
  (select count(*) from student_current_enrollments where campus_id = 'bb000000-0000-0000-0000-000000000001'),
  0::bigint,
  'A Campus B administrator sees no Campus A enrollment through the view'
);

-- The App Backend still can read it.
reset role;
set local role service_role;
select is(
  (select count(*) from student_current_enrollments),
  2::bigint,
  'service_role (the App Backend) still reads the view across campuses'
);

select * from finish();
rollback;
