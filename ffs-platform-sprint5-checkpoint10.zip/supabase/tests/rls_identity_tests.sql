-- =============================================================================
-- RLS Test Suite: Identity, Tenancy & RBAC
-- Sprint 1 — Faith Foundation Schools Digital Platform
--
-- Uses pgTAP (https://pgtap.org/). Requires: `create extension pgtap;` on the
-- target database, and must be run against a real Postgres/Supabase
-- instance — there is no live database available in the development
-- sandbox this file was authored in, so these tests are written and ready
-- but NOT yet executed. They must run in CI/staging before Sprint 1 is
-- considered verified end-to-end (see Sprint Completion Report, "Known
-- Limitations").
--
-- Test philosophy: assert what each role CANNOT see at least as rigorously
-- as what they can (Architecture Section 14/22) — a security suite that
-- only tests happy paths is not a security suite.
-- =============================================================================

begin;
select plan(17);

-- -----------------------------------------------------------------------------
-- Fixtures: two organizations/campuses, two users each with different roles,
-- to prove both permission-based AND tenant-based isolation.
-- -----------------------------------------------------------------------------

insert into organizations (id, name) values
  ('a0000000-0000-0000-0000-000000000001', '[TEST] Org A'),
  ('a0000000-0000-0000-0000-000000000002', '[TEST] Org B');

insert into campuses (id, organization_id, name) values
  ('b0000000-0000-0000-0000-000000000001', 'a0000000-0000-0000-0000-000000000001', '[TEST] Campus A'),
  ('b0000000-0000-0000-0000-000000000002', 'a0000000-0000-0000-0000-000000000002', '[TEST] Campus B');

-- Simulated auth.users rows (in a real Supabase project these are created
-- via the Auth API; inserted directly here only for isolated RLS testing).
insert into auth.users (id, email) values
  ('c0000000-0000-0000-0000-000000000001', 'admin-a@test.invalid'),
  ('c0000000-0000-0000-0000-000000000002', 'teacher-a@test.invalid'),
  ('c0000000-0000-0000-0000-000000000003', 'admin-b@test.invalid'),
  ('c0000000-0000-0000-0000-000000000004', 'superadmin-a@test.invalid');

insert into users (id, auth_user_id, campus_id, email, status) values
  ('d0000000-0000-0000-0000-000000000001', 'c0000000-0000-0000-0000-000000000001', 'b0000000-0000-0000-0000-000000000001', 'admin-a@test.invalid', 'active'),
  ('d0000000-0000-0000-0000-000000000002', 'c0000000-0000-0000-0000-000000000002', 'b0000000-0000-0000-0000-000000000001', 'teacher-a@test.invalid', 'active'),
  ('d0000000-0000-0000-0000-000000000003', 'c0000000-0000-0000-0000-000000000003', 'b0000000-0000-0000-0000-000000000002', 'admin-b@test.invalid', 'active'),
  ('d0000000-0000-0000-0000-000000000004', 'c0000000-0000-0000-0000-000000000004', 'b0000000-0000-0000-0000-000000000001', 'superadmin-a@test.invalid', 'active');

-- A dedicated super_admin fixture user for section 6's write tests, rather
-- than mutating an existing user's role mid-transaction — there is no
-- UPDATE policy on user_roles at all (by design, see migration 0002), so a
-- role reassignment attempted under RLS as `authenticated` would silently
-- no-op. A fresh fixture avoids relying on RLS-bypassing superuser access
-- mid-suite.
insert into user_roles (user_id, role_id, campus_id, assigned_by)
select 'd0000000-0000-0000-0000-000000000004', id, 'b0000000-0000-0000-0000-000000000001', 'd0000000-0000-0000-0000-000000000004'
from roles where key = 'super_admin';

insert into user_roles (user_id, role_id, campus_id, assigned_by)
select 'd0000000-0000-0000-0000-000000000001', id, 'b0000000-0000-0000-0000-000000000001', 'd0000000-0000-0000-0000-000000000001'
from roles where key = 'school_administrator';

insert into user_roles (user_id, role_id, campus_id, assigned_by)
select 'd0000000-0000-0000-0000-000000000002', id, 'b0000000-0000-0000-0000-000000000001', 'd0000000-0000-0000-0000-000000000001'
from roles where key = 'teacher';

insert into user_roles (user_id, role_id, campus_id, assigned_by)
select 'd0000000-0000-0000-0000-000000000003', id, 'b0000000-0000-0000-0000-000000000002', 'd0000000-0000-0000-0000-000000000003'
from roles where key = 'school_administrator';

insert into audit_logs (actor_id, campus_id, action, target_type, target_id) values
  ('d0000000-0000-0000-0000-000000000001', 'b0000000-0000-0000-0000-000000000001', 'test.action', 'user', 'd0000000-0000-0000-0000-000000000002'),
  ('d0000000-0000-0000-0000-000000000003', 'b0000000-0000-0000-0000-000000000002', 'test.action', 'user', 'd0000000-0000-0000-0000-000000000003');

-- -----------------------------------------------------------------------------
-- 1. users: self-read always allowed
-- -----------------------------------------------------------------------------

set local role authenticated;
set local request.jwt.claim.sub = 'c0000000-0000-0000-0000-000000000002';

select is(
  (select count(*) from users where id = 'd0000000-0000-0000-0000-000000000002'),
  1::bigint,
  'A user can read their own users row'
);

-- -----------------------------------------------------------------------------
-- 2. users: cannot read another campus's user without rbac.read, ever
-- -----------------------------------------------------------------------------

select is(
  (select count(*) from users where id = 'd0000000-0000-0000-0000-000000000003'),
  0::bigint,
  'A teacher (no rbac.read) cannot read a user in a different campus'
);

select is(
  (select count(*) from users where id = 'd0000000-0000-0000-0000-000000000001'),
  0::bigint,
  'A teacher (no rbac.read) cannot read a co-campus admin''s row either — permission-gated, not just tenant-gated'
);

-- -----------------------------------------------------------------------------
-- 3. school_administrator (has rbac.read) CAN read same-campus users, but
--    NOT cross-campus users — proves tenant isolation holds even for a
--    privileged role.
-- -----------------------------------------------------------------------------

set local request.jwt.claim.sub = 'c0000000-0000-0000-0000-000000000001';

select is(
  (select count(*) from users where id = 'd0000000-0000-0000-0000-000000000002'),
  1::bigint,
  'A school_administrator (rbac.read) can read a same-campus user'
);

select is(
  (select count(*) from users where id = 'd0000000-0000-0000-0000-000000000003'),
  0::bigint,
  'A school_administrator CANNOT read a user in a different campus (tenant isolation holds even for admin-tier roles)'
);

-- -----------------------------------------------------------------------------
-- 4. user_roles: IDOR check — a teacher cannot read another user's role
--    assignment by id-guessing, even within the same campus.
-- -----------------------------------------------------------------------------

set local request.jwt.claim.sub = 'c0000000-0000-0000-0000-000000000002';

select is(
  (select count(*) from user_roles where user_id = 'd0000000-0000-0000-0000-000000000001'),
  0::bigint,
  'A teacher cannot read another user''s role assignment (no rbac.read, IDOR-safe)'
);

select is(
  (select count(*) from user_roles where user_id = 'd0000000-0000-0000-0000-000000000002'),
  1::bigint,
  'A teacher CAN read their own role assignment'
);

-- -----------------------------------------------------------------------------
-- 5. user_roles: write is denied to a non-rbac.manage role entirely.
-- -----------------------------------------------------------------------------

select throws_ok(
  $$ insert into user_roles (user_id, role_id, campus_id, assigned_by)
     select 'd0000000-0000-0000-0000-000000000002', id, 'b0000000-0000-0000-0000-000000000001', 'd0000000-0000-0000-0000-000000000002'
     from roles where key = 'exam_officer' $$,
  null,
  'A teacher (no rbac.manage) cannot insert a user_roles row for anyone, including themselves'
);

-- -----------------------------------------------------------------------------
-- 6. user_roles: super_admin (holds rbac.manage per the Sprint 1 seed —
--    school_administrator does NOT, only rbac.read) CANNOT write into
--    another campus's scope, even by directly supplying a foreign
--    campus_id (privilege escalation / cross-tenant write guard).
--
--    Corrected from an earlier version of this test that incorrectly
--    assumed school_administrator holds rbac.manage — it does not; only
--    super_admin does, per migration 0003's actual seed data. Using the
--    dedicated superadmin-a fixture user for this section instead.
-- -----------------------------------------------------------------------------

set local request.jwt.claim.sub = 'c0000000-0000-0000-0000-000000000004';

select throws_ok(
  $$ insert into user_roles (user_id, role_id, campus_id, assigned_by)
     select 'd0000000-0000-0000-0000-000000000003', id, 'b0000000-0000-0000-0000-000000000002', 'd0000000-0000-0000-0000-000000000004'
     from roles where key = 'teacher' $$,
  null,
  'A super_admin from Campus A cannot write a user_roles row scoped to Campus B'
);

-- Legitimate same-campus write succeeds, proving the policy isn't simply
-- blocking all writes.
select lives_ok(
  $$ insert into user_roles (user_id, role_id, campus_id, assigned_by)
     select 'd0000000-0000-0000-0000-000000000002', id, 'b0000000-0000-0000-0000-000000000001', 'd0000000-0000-0000-0000-000000000004'
     from roles where key = 'class_teacher' $$,
  'A super_admin CAN write a user_roles row scoped to their own campus'
);

-- -----------------------------------------------------------------------------
-- 7. audit_logs: no INSERT/UPDATE/DELETE privilege at all for `authenticated`
--    — the frontend can never write or tamper with audit history.
-- -----------------------------------------------------------------------------

select throws_ok(
  $$ insert into audit_logs (actor_id, campus_id, action, target_type, target_id)
     values ('d0000000-0000-0000-0000-000000000001', 'b0000000-0000-0000-0000-000000000001', 'forged', 'user', 'x') $$,
  null,
  'The authenticated role cannot insert into audit_logs at all (service-role only, by grant, not just by policy)'
);

select throws_ok(
  $$ delete from audit_logs where campus_id = 'b0000000-0000-0000-0000-000000000001' $$,
  null,
  'The authenticated role cannot delete audit_logs — no grant exists'
);

-- -----------------------------------------------------------------------------
-- 8. audit_logs: read is permission + tenant scoped.
-- -----------------------------------------------------------------------------

set local request.jwt.claim.sub = 'c0000000-0000-0000-0000-000000000001';

select is(
  (select count(*) from audit_logs where campus_id = 'b0000000-0000-0000-0000-000000000001'),
  1::bigint,
  'A school_administrator (holds audit.read per Sprint 1 seed) can read same-campus audit logs'
);

select is(
  (select count(*) from audit_logs where campus_id = 'b0000000-0000-0000-0000-000000000002'),
  0::bigint,
  'A school_administrator from Campus A cannot read Campus B''s audit logs, even holding audit.read'
);

-- -----------------------------------------------------------------------------
-- 9. organizations / campuses: cross-org read denied.
-- -----------------------------------------------------------------------------

select is(
  (select count(*) from organizations where id = 'a0000000-0000-0000-0000-000000000002'),
  0::bigint,
  'A user in Org A cannot read Org B''s organizations row'
);

select is(
  (select count(*) from campuses where id = 'b0000000-0000-0000-0000-000000000002'),
  0::bigint,
  'A user in Org A cannot read Org B''s campuses row'
);

select is(
  (select count(*) from organizations where id = 'a0000000-0000-0000-0000-000000000001'),
  1::bigint,
  'A user CAN read their own organization'
);

select * from finish();
rollback;
