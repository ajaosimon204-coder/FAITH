-- =============================================================================
-- Regression Suite: PUBLIC EXECUTE Grant on Sensitive Functions
-- Faith Foundation Schools Digital Platform
--
-- Dedicated, standalone suite for one specific class of bug, found during
-- the Sprint 4 audit: Postgres grants EXECUTE to the PUBLIC pseudo-role by
-- default when a function is created. Every prior migration's
-- "revoke execute ... from authenticated, anon" was silently ineffective
-- against this, because every role implicitly inherits PUBLIC's grants.
--
-- This was live-confirmed exploitable: an `accountant` role successfully
-- called app_write_school_config() directly, bypassing ConfigService's
-- ajv schema validation entirely.
--
-- This suite checks the grant itself directly (has_function_privilege),
-- which is a MORE explicit and MORE future-proof check than only
-- attempting a call and expecting failure — a grant-table check fails
-- loudly and specifically the moment a future migration accidentally
-- reintroduces this exact class of gap (e.g. by creating a new sensitive
-- function and forgetting the PUBLIC revoke), rather than requiring
-- someone to notice a functional test failure and diagnose why.
-- =============================================================================

begin;
select plan(20);

-- Every sensitive service-role-only function must have EXECUTE revoked
-- from PUBLIC specifically — not just from authenticated/anon — and must
-- still be callable by service_role.

select is(
  has_function_privilege('public', 'app_write_school_config(uuid,uuid,jsonb,uuid)', 'EXECUTE'),
  false,
  'app_write_school_config: PUBLIC does not have EXECUTE'
);
select is(
  has_function_privilege('authenticated', 'app_write_school_config(uuid,uuid,jsonb,uuid)', 'EXECUTE'),
  false,
  'app_write_school_config: authenticated does not have EXECUTE'
);
select is(
  has_function_privilege('service_role', 'app_write_school_config(uuid,uuid,jsonb,uuid)', 'EXECUTE'),
  true,
  'app_write_school_config: service_role STILL has EXECUTE (the fix did not break the legitimate path)'
);

select is(
  has_function_privilege('public', 'app_set_current_academic_session(uuid,uuid)', 'EXECUTE'),
  false,
  'app_set_current_academic_session: PUBLIC does not have EXECUTE'
);
select is(
  has_function_privilege('service_role', 'app_set_current_academic_session(uuid,uuid)', 'EXECUTE'),
  true,
  'app_set_current_academic_session: service_role STILL has EXECUTE'
);

select is(
  has_function_privilege('public', 'app_set_current_term(uuid,uuid)', 'EXECUTE'),
  false,
  'app_set_current_term: PUBLIC does not have EXECUTE'
);
select is(
  has_function_privilege('service_role', 'app_set_current_term(uuid,uuid)', 'EXECUTE'),
  true,
  'app_set_current_term: service_role STILL has EXECUTE'
);

select is(
  has_function_privilege('public', 'app_transfer_enrollment(uuid,uuid,uuid,text)', 'EXECUTE'),
  false,
  'app_transfer_enrollment: PUBLIC does not have EXECUTE'
);
select is(
  has_function_privilege('authenticated', 'app_transfer_enrollment(uuid,uuid,uuid,text)', 'EXECUTE'),
  false,
  'app_transfer_enrollment: authenticated does not have EXECUTE'
);
select is(
  has_function_privilege('service_role', 'app_transfer_enrollment(uuid,uuid,uuid,text)', 'EXECUTE'),
  true,
  'app_transfer_enrollment: service_role STILL has EXECUTE'
);

select is(
  has_function_privilege('public', 'app_cms_transition(text,uuid,cms_content_status,text,uuid,text,uuid,jsonb,jsonb)', 'EXECUTE'),
  false,
  'app_cms_transition: PUBLIC does not have EXECUTE'
);
select is(
  has_function_privilege('authenticated', 'app_cms_transition(text,uuid,cms_content_status,text,uuid,text,uuid,jsonb,jsonb)', 'EXECUTE'),
  false,
  'app_cms_transition: authenticated does not have EXECUTE'
);
select is(
  has_function_privilege('service_role', 'app_cms_transition(text,uuid,cms_content_status,text,uuid,text,uuid,jsonb,jsonb)', 'EXECUTE'),
  true,
  'app_cms_transition: service_role STILL has EXECUTE'
);

select is(
  has_function_privilege('public', 'app_application_transition(uuid,uuid,application_status,uuid,text,text,text)', 'EXECUTE'),
  false,
  'app_application_transition: PUBLIC does not have EXECUTE'
);
select is(
  has_function_privilege('authenticated', 'app_application_transition(uuid,uuid,application_status,uuid,text,text,text)', 'EXECUTE'),
  false,
  'app_application_transition: authenticated does not have EXECUTE'
);
select is(
  has_function_privilege('service_role', 'app_application_transition(uuid,uuid,application_status,uuid,text,text,text)', 'EXECUTE'),
  true,
  'app_application_transition: service_role STILL has EXECUTE'
);

select is(
  has_function_privilege('public', 'app_convert_application(uuid,uuid,uuid,uuid)', 'EXECUTE'),
  false,
  'app_convert_application: PUBLIC does not have EXECUTE'
);
select is(
  has_function_privilege('authenticated', 'app_convert_application(uuid,uuid,uuid,uuid)', 'EXECUTE'),
  false,
  'app_convert_application: authenticated does not have EXECUTE'
);
select is(
  has_function_privilege('service_role', 'app_convert_application(uuid,uuid,uuid,uuid)', 'EXECUTE'),
  true,
  'app_convert_application: service_role STILL has EXECUTE'
);

-- Functional confirmation, not just grant-table inspection: the exact
-- exploit scenario that originally succeeded now fails end to end.
insert into organizations (id, name) values ('a8888888-0000-0000-0000-000000000001', '[REGRESSION] Org');
insert into campuses (id, organization_id, name) values ('a8888888-0000-0000-0000-000000000002', 'a8888888-0000-0000-0000-000000000001', '[REGRESSION] Campus');
insert into auth.users (id, email) values ('a8888888-0000-0000-0000-000000000003', 'regression-accountant@test.invalid');
insert into users (id, auth_user_id, campus_id, email, status) values ('a8888888-0000-0000-0000-000000000004', 'a8888888-0000-0000-0000-000000000003', 'a8888888-0000-0000-0000-000000000002', 'regression-accountant@test.invalid', 'active');
insert into user_roles (user_id, role_id, campus_id, assigned_by)
select 'a8888888-0000-0000-0000-000000000004', id, 'a8888888-0000-0000-0000-000000000002', 'a8888888-0000-0000-0000-000000000004'
from roles where key = 'accountant';
insert into school_config (config_definition_id, campus_id, value_json, updated_by)
select id, 'a8888888-0000-0000-0000-000000000002', '"NGN"'::jsonb, 'a8888888-0000-0000-0000-000000000004'
from config_definitions where key = 'finance.default_currency';

set local role authenticated;
set local request.jwt.claim.sub = 'a8888888-0000-0000-0000-000000000003';

select throws_ok(
  $$ select app_write_school_config(
       (select id from config_definitions where key = 'finance.default_currency'),
       'a8888888-0000-0000-0000-000000000002',
       '"THIS-WOULD-FAIL-AJV-VALIDATION-IN-CONFIGSERVICE"'::jsonb,
       'a8888888-0000-0000-0000-000000000004'
     ) $$,
  null,
  'REGRESSION: an accountant directly calling app_write_school_config() to bypass ConfigService''s ajv validation now fails — this exact call succeeded before migration 0020'
);

select * from finish();
rollback;
