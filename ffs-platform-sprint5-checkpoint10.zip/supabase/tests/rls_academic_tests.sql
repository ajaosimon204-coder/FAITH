-- =============================================================================
-- RLS Test Suite: Academic Core
-- Sprint 3 — Faith Foundation Schools Digital Platform
--
-- The centerpiece: proving a Teacher role by itself grants NOTHING — every
-- teacher-facing policy is checked against an actual teacher_assignments
-- relationship, never a role name. Also covers historical-integrity
-- guarantees (no overwriting closed enrollments, at most one active
-- enrollment per student per session) directly against the live database.
-- =============================================================================

begin;
select plan(23);

-- -----------------------------------------------------------------------------
-- Fixtures
-- -----------------------------------------------------------------------------

insert into organizations (id, name) values
  ('a2000000-0000-0000-0000-000000000001', '[TEST] Org A');
insert into campuses (id, organization_id, name) values
  ('b2000000-0000-0000-0000-000000000001', 'a2000000-0000-0000-0000-000000000001', '[TEST] Campus A');

insert into auth.users (id, email) values
  ('c2000000-0000-0000-0000-000000000001', 'admin-a@test.invalid'),
  ('c2000000-0000-0000-0000-000000000002', 'teacher-assigned@test.invalid'),
  ('c2000000-0000-0000-0000-000000000003', 'teacher-unassigned@test.invalid'),
  ('c2000000-0000-0000-0000-000000000004', 'student-self@test.invalid'),
  ('c2000000-0000-0000-0000-000000000005', 'student-other@test.invalid');

insert into users (id, auth_user_id, campus_id, email, status) values
  ('d2000000-0000-0000-0000-000000000001', 'c2000000-0000-0000-0000-000000000001', 'b2000000-0000-0000-0000-000000000001', 'admin-a@test.invalid', 'active'),
  ('d2000000-0000-0000-0000-000000000002', 'c2000000-0000-0000-0000-000000000002', 'b2000000-0000-0000-0000-000000000001', 'teacher-assigned@test.invalid', 'active'),
  ('d2000000-0000-0000-0000-000000000003', 'c2000000-0000-0000-0000-000000000003', 'b2000000-0000-0000-0000-000000000001', 'teacher-unassigned@test.invalid', 'active'),
  ('d2000000-0000-0000-0000-000000000004', 'c2000000-0000-0000-0000-000000000004', 'b2000000-0000-0000-0000-000000000001', 'student-self@test.invalid', 'active'),
  ('d2000000-0000-0000-0000-000000000005', 'c2000000-0000-0000-0000-000000000005', 'b2000000-0000-0000-0000-000000000001', 'student-other@test.invalid', 'active');

insert into user_roles (user_id, role_id, campus_id, assigned_by)
select 'd2000000-0000-0000-0000-000000000001', id, 'b2000000-0000-0000-0000-000000000001', 'd2000000-0000-0000-0000-000000000001'
from roles where key = 'super_admin';

insert into staff (id, campus_id, users_id, display_name) values
  ('e2000000-0000-0000-0000-000000000001', 'b2000000-0000-0000-0000-000000000001', 'd2000000-0000-0000-0000-000000000002', '[TEST] Assigned Teacher'),
  ('e2000000-0000-0000-0000-000000000002', 'b2000000-0000-0000-0000-000000000001', 'd2000000-0000-0000-0000-000000000003', '[TEST] Unassigned Teacher');

insert into students (id, campus_id, users_id, display_name) values
  ('f2000000-0000-0000-0000-000000000001', 'b2000000-0000-0000-0000-000000000001', 'd2000000-0000-0000-0000-000000000004', '[TEST] Student Self'),
  ('f2000000-0000-0000-0000-000000000002', 'b2000000-0000-0000-0000-000000000001', 'd2000000-0000-0000-0000-000000000005', '[TEST] Student Other');

insert into academic_sessions (id, campus_id, name, start_date, end_date, is_current) values
  ('a3000000-0000-0000-0000-000000000001', 'b2000000-0000-0000-0000-000000000001', '[TEST] 2025/2026', '2025-09-01', '2026-07-31', true);

insert into class_definitions (id, campus_id, name, level) values
  ('a4000000-0000-0000-0000-000000000001', 'b2000000-0000-0000-0000-000000000001', '[TEST] JSS 1', 'junior_secondary');

insert into classes (id, class_definition_id, academic_session_id, campus_id, name, section) values
  ('a5000000-0000-0000-0000-000000000001', 'a4000000-0000-0000-0000-000000000001', 'a3000000-0000-0000-0000-000000000001', 'b2000000-0000-0000-0000-000000000001', '[TEST] JSS 1A', 'A'),
  ('a5000000-0000-0000-0000-000000000002', 'a4000000-0000-0000-0000-000000000001', 'a3000000-0000-0000-0000-000000000001', 'b2000000-0000-0000-0000-000000000001', '[TEST] JSS 1B', 'B');

insert into teacher_assignments (id, staff_id, class_id, subject_id, academic_session_id, campus_id, role, assigned_by) values
  ('a6000000-0000-0000-0000-000000000001', 'e2000000-0000-0000-0000-000000000001', 'a5000000-0000-0000-0000-000000000001', null, 'a3000000-0000-0000-0000-000000000001', 'b2000000-0000-0000-0000-000000000001', 'class_teacher', 'd2000000-0000-0000-0000-000000000001');

insert into enrollments (id, student_id, class_id, academic_session_id, campus_id, status) values
  ('a7000000-0000-0000-0000-000000000001', 'f2000000-0000-0000-0000-000000000001', 'a5000000-0000-0000-0000-000000000001', 'a3000000-0000-0000-0000-000000000001', 'b2000000-0000-0000-0000-000000000001', 'active');

-- Second campus + cross-campus subjects, inserted here (still as superuser,
-- before the first `set local role authenticated` below) for the
-- class_subjects cross-campus test near the end of this file.
insert into organizations (id, name) values
  ('a2000000-0000-0000-0000-000000000002', '[TEST] Org B (re-audit)');
insert into campuses (id, organization_id, name) values
  ('b2000000-0000-0000-0000-000000000002', 'a2000000-0000-0000-0000-000000000002', '[TEST] Campus B (re-audit)');
insert into subjects (id, campus_id, name, code) values
  ('a8000000-0000-0000-0000-000000000001', 'b2000000-0000-0000-0000-000000000001', '[TEST] Math', 'MTH-REAUDIT'),
  ('a8000000-0000-0000-0000-000000000002', 'b2000000-0000-0000-0000-000000000002', '[TEST] Cross-campus Subject', 'XCS-REAUDIT');

-- -----------------------------------------------------------------------------
-- 1. Student self-read.
-- -----------------------------------------------------------------------------

set local role authenticated;
set local request.jwt.claim.sub = 'c2000000-0000-0000-0000-000000000004';

select is(
  (select count(*) from enrollments where student_id = 'f2000000-0000-0000-0000-000000000001'),
  1::bigint,
  'A student can read their own enrollment'
);

select is(
  (select count(*) from students where id = 'f2000000-0000-0000-0000-000000000001'),
  1::bigint,
  'A student can read their own students row'
);

-- -----------------------------------------------------------------------------
-- 2. THE central test: Teacher role alone grants nothing.
-- -----------------------------------------------------------------------------

set local request.jwt.claim.sub = 'c2000000-0000-0000-0000-000000000003';

select is(
  (select count(*) from enrollments where student_id = 'f2000000-0000-0000-0000-000000000001'),
  0::bigint,
  'An UNASSIGNED teacher (holds the Teacher role, but no teacher_assignments row for this class) CANNOT read this student''s enrollment'
);

select is(
  (select count(*) from students where id = 'f2000000-0000-0000-0000-000000000001'),
  0::bigint,
  'An unassigned teacher cannot read this student''s row either'
);

-- -----------------------------------------------------------------------------
-- 3. An ASSIGNED teacher CAN read the same data (proving it''s the
--    relationship, not a blanket denial of the Teacher role).
-- -----------------------------------------------------------------------------

set local request.jwt.claim.sub = 'c2000000-0000-0000-0000-000000000002';

select is(
  (select count(*) from enrollments where student_id = 'f2000000-0000-0000-0000-000000000001'),
  1::bigint,
  'An ASSIGNED teacher (has a teacher_assignments row for this exact class) CAN read the enrollment'
);

select is(
  (select count(*) from students where id = 'f2000000-0000-0000-0000-000000000001'),
  1::bigint,
  'An assigned teacher can read the student row too'
);

-- -----------------------------------------------------------------------------
-- 4. IDOR: an unrelated student cannot read another student''s data.
-- -----------------------------------------------------------------------------

set local request.jwt.claim.sub = 'c2000000-0000-0000-0000-000000000005';

select is(
  (select count(*) from enrollments where student_id = 'f2000000-0000-0000-0000-000000000001'),
  0::bigint,
  'A different student cannot read another student''s enrollment (IDOR)'
);

select is(
  (select count(*) from students where id = 'f2000000-0000-0000-0000-000000000001'),
  0::bigint,
  'A different student cannot read another student''s row (IDOR)'
);

-- -----------------------------------------------------------------------------
-- 5. Teacher cannot write enrollments even for their own assigned class —
--    only academic.enrollments.manage can write.
-- -----------------------------------------------------------------------------

set local request.jwt.claim.sub = 'c2000000-0000-0000-0000-000000000002';

select throws_ok(
  $$ insert into enrollments (student_id, class_id, academic_session_id, campus_id, status)
     values ('f2000000-0000-0000-0000-000000000002', 'a5000000-0000-0000-0000-000000000001', 'a3000000-0000-0000-0000-000000000001', 'b2000000-0000-0000-0000-000000000001', 'active') $$,
  null,
  'An assigned teacher (no academic.enrollments.manage) cannot insert an enrollment, even for their own class'
);

-- -----------------------------------------------------------------------------
-- 6. Admin (super_admin, has academic.enrollments.manage) CAN write.
-- -----------------------------------------------------------------------------

set local request.jwt.claim.sub = 'c2000000-0000-0000-0000-000000000001';

select lives_ok(
  $$ insert into enrollments (student_id, class_id, academic_session_id, campus_id, status)
     values ('f2000000-0000-0000-0000-000000000002', 'a5000000-0000-0000-0000-000000000002', 'a3000000-0000-0000-0000-000000000001', 'b2000000-0000-0000-0000-000000000001', 'active') $$,
  'An admin (academic.enrollments.manage) CAN insert an enrollment'
);

-- -----------------------------------------------------------------------------
-- 7. Historical-integrity: only one ACTIVE enrollment per student per
--    session — a second active insert for the same student/session fails.
-- -----------------------------------------------------------------------------

select throws_ok(
  $$ insert into enrollments (student_id, class_id, academic_session_id, campus_id, status)
     values ('f2000000-0000-0000-0000-000000000002', 'a5000000-0000-0000-0000-000000000001', 'a3000000-0000-0000-0000-000000000001', 'b2000000-0000-0000-0000-000000000001', 'active') $$,
  null,
  'A second ACTIVE enrollment for the same student in the same session is rejected (unique partial index)'
);

-- -----------------------------------------------------------------------------
-- 8. Historical-integrity: a closed enrollment''s identity cannot be
--    mutated — only status/exit fields may still change.
-- -----------------------------------------------------------------------------

update enrollments set status = 'withdrawn', exited_at = now(), exit_reason = 'test'
where student_id = 'f2000000-0000-0000-0000-000000000002' and class_id = 'a5000000-0000-0000-0000-000000000002';

select throws_ok(
  format(
    $$ update enrollments set class_id = %L
       where student_id = 'f2000000-0000-0000-0000-000000000002' and status = 'withdrawn' $$,
    'a5000000-0000-0000-0000-000000000001'
  ),
  null,
  'A closed enrollment''s class_id cannot be changed after the fact — trigger enforces history immutability'
);

-- -----------------------------------------------------------------------------
-- 9. No DELETE grant on enrollments at all.
-- -----------------------------------------------------------------------------

select throws_ok(
  $$ delete from enrollments where id = 'a7000000-0000-0000-0000-000000000001' $$,
  null,
  'The authenticated role cannot delete enrollments at all — history is closed, never deleted'
);

-- -----------------------------------------------------------------------------
-- 9b. Regression test for the PUBLIC EXECUTE grant gap (major finding,
--     Sprint 4 audit / migration 0020): app_transfer_enrollment() and
--     app_set_current_academic_session() must be unreachable to a direct
--     client call, even a fully-permissioned super_admin. This specific
--     negative test did not exist before the audit — see the identical
--     finding for app_write_school_config in rls_config_tests.sql.
-- -----------------------------------------------------------------------------

select throws_ok(
  $$ select app_transfer_enrollment(
       'f2000000-0000-0000-0000-000000000001',
       'a7000000-0000-0000-0000-000000000001',
       'a5000000-0000-0000-0000-000000000002',
       'forged direct call'
     ) $$,
  null,
  'A super_admin — or any authenticated role — cannot call app_transfer_enrollment() directly, bypassing EnrollmentService entirely'
);

select throws_ok(
  $$ select app_set_current_academic_session(
       'b2000000-0000-0000-0000-000000000001',
       'a3000000-0000-0000-0000-000000000001'
     ) $$,
  null,
  'A super_admin cannot call app_set_current_academic_session() directly either'
);

-- -----------------------------------------------------------------------------
-- 10. teacher_assignments — a teacher sees their own assignment but not
--     another teacher''s.
-- -----------------------------------------------------------------------------

set local request.jwt.claim.sub = 'c2000000-0000-0000-0000-000000000002';

select is(
  (select count(*) from teacher_assignments where staff_id = 'e2000000-0000-0000-0000-000000000001'),
  1::bigint,
  'A teacher can read their own teacher_assignments row'
);

set local request.jwt.claim.sub = 'c2000000-0000-0000-0000-000000000003';

select is(
  (select count(*) from teacher_assignments where staff_id = 'e2000000-0000-0000-0000-000000000001'),
  0::bigint,
  'A DIFFERENT teacher cannot read another teacher''s assignment row'
);

-- -----------------------------------------------------------------------------
-- 11. Exactly one class_teacher per class per session — a second insert
--     for the same class fails.
-- -----------------------------------------------------------------------------

set local request.jwt.claim.sub = 'c2000000-0000-0000-0000-000000000001';

select throws_ok(
  $$ insert into teacher_assignments (staff_id, class_id, subject_id, academic_session_id, campus_id, role, assigned_by)
     values ('e2000000-0000-0000-0000-000000000002', 'a5000000-0000-0000-0000-000000000001', null, 'a3000000-0000-0000-0000-000000000001', 'b2000000-0000-0000-0000-000000000001', 'class_teacher', 'd2000000-0000-0000-0000-000000000001') $$,
  null,
  'A second class_teacher for the same class/session is rejected (unique partial index)'
);

-- -----------------------------------------------------------------------------
-- 12. subject_teacher requires a subject_id — CHECK constraint enforced at
--     the database level regardless of what the application sends.
-- -----------------------------------------------------------------------------

select throws_ok(
  $$ insert into teacher_assignments (staff_id, class_id, subject_id, academic_session_id, campus_id, role, assigned_by)
     values ('e2000000-0000-0000-0000-000000000002', 'a5000000-0000-0000-0000-000000000002', null, 'a3000000-0000-0000-0000-000000000001', 'b2000000-0000-0000-0000-000000000001', 'subject_teacher', 'd2000000-0000-0000-0000-000000000001') $$,
  null,
  'A subject_teacher assignment with no subject_id is rejected at the database level (CHECK constraint)'
);

-- -----------------------------------------------------------------------------
-- 13. academic_sessions / classes readable within campus regardless of role
--     (everyone needs to know what session/class exists), but not writable
--     without academic.sessions.write / academic.classes.write.
-- -----------------------------------------------------------------------------

set local request.jwt.claim.sub = 'c2000000-0000-0000-0000-000000000004';

select is(
  (select count(*) from academic_sessions where campus_id = 'b2000000-0000-0000-0000-000000000001'),
  1::bigint,
  'A student can read the campus''s academic_sessions (broadly readable)'
);

select throws_ok(
  $$ insert into academic_sessions (campus_id, name, start_date, end_date)
     values ('b2000000-0000-0000-0000-000000000001', '[TEST] Forged', '2030-01-01', '2030-12-31') $$,
  null,
  'A student cannot create an academic_session (no academic.sessions.write)'
);

-- -----------------------------------------------------------------------------
-- 14. Sprint 3 re-audit: class_subjects cross-campus DATABASE-level guard
--     (migration 0015). Even a service-role-equivalent direct write must
--     be rejected — this is the belt-and-suspenders backstop behind the
--     ClassesService.linkSubjectToClass application-layer check.
-- -----------------------------------------------------------------------------

set local request.jwt.claim.sub = 'c2000000-0000-0000-0000-000000000001';

select throws_ok(
  $$ insert into class_subjects (class_id, subject_id)
     values ('a5000000-0000-0000-0000-000000000001', 'a8000000-0000-0000-0000-000000000002') $$,
  null,
  'A class (Campus A) cannot be linked to a subject from Campus B — rejected by the trigger from migration 0015, independent of RLS/permission checks'
);

select lives_ok(
  $$ insert into class_subjects (class_id, subject_id)
     values ('a5000000-0000-0000-0000-000000000001', 'a8000000-0000-0000-0000-000000000001') $$,
  'A class and subject from the SAME campus link successfully (the trigger only blocks the mismatched case)'
);

select * from finish();
rollback;
