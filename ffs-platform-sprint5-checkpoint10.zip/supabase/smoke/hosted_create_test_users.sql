-- Links the two Supabase Auth test users to the platform: a staff user (school_administrator — holds the
-- admissions permissions) and a limited user (accountant — holds none). Run in the Supabase SQL editor AFTER
-- creating the two users in Authentication → Users (tick "Auto Confirm User").
--
-- 1. Replace the two e-mail addresses below with the ones you created.
-- 2. Run. It is safe to run twice (it skips anything already linked).
-- Change nothing else. The campus used is the platform's (only) campus.

-- Step 1: link the Auth users to the platform.
insert into users (auth_user_id, campus_id, email, status)
select au.id, (select id from campuses order by created_at limit 1), au.email, 'active'
from auth.users au
where au.email in ('smoke-staff@YOURDOMAIN.example', 'smoke-limited@YOURDOMAIN.example')
  and not exists (select 1 from users u where u.auth_user_id = au.id);

-- Step 2: give each a role. (A separate statement on purpose: one statement cannot see rows that another
-- part of itself has just inserted.)
insert into user_roles (user_id, role_id, campus_id, assigned_by)
select u.id, r.id, u.campus_id, u.id
from users u
join (values ('smoke-staff@YOURDOMAIN.example',   'school_administrator'),
             ('smoke-limited@YOURDOMAIN.example', 'accountant')) as wanted(email, role_key) on wanted.email = u.email
join roles r on r.key = wanted.role_key
where not exists (select 1 from user_roles ur where ur.user_id = u.id and ur.role_id = r.id);

-- Check: should list both users with their role.
select u.email, string_agg(r.key, ', ') as role
from users u join user_roles ur on ur.user_id = u.id join roles r on r.id = ur.role_id
where u.email in ('smoke-staff@YOURDOMAIN.example', 'smoke-limited@YOURDOMAIN.example')
group by u.email order by 1;
