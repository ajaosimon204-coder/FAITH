-- Hosted database audit — READ-ONLY. Paste into the Supabase SQL editor (or run with psql) against the project
-- you are about to take live. It only reads catalog information; it changes nothing.
--
-- Every row should say OK. A FAIL row names exactly which objects are wrong. See docs/HOSTED_SMOKE_TEST.md.

with
tbl as (  -- ordinary tables we own in public
  select c.oid, c.relname from pg_class c join pg_namespace n on n.oid = c.relnamespace
  where n.nspname = 'public' and c.relkind in ('r', 'p')
    and not exists (select 1 from pg_depend d where d.objid = c.oid and d.deptype = 'e')
),
vw as (   -- views we own in public
  select c.oid, c.relname, c.reloptions from pg_class c join pg_namespace n on n.oid = c.relnamespace
  where n.nspname = 'public' and c.relkind in ('v', 'm')
    and not exists (select 1 from pg_depend d where d.objid = c.oid and d.deptype = 'e')
),
checks(ord, name, offenders) as (

  select 1, 'Row-level security is enabled on every table',
    (select string_agg(t.relname, ', ' order by t.relname) from tbl t join pg_class c on c.oid = t.oid where not c.relrowsecurity)

  union all select 2, 'anon holds no INSERT/UPDATE/DELETE on any table',
    (select string_agg(t.relname, ', ' order by t.relname) from tbl t
      where has_table_privilege('anon', t.oid, 'insert') or has_table_privilege('anon', t.oid, 'update') or has_table_privilege('anon', t.oid, 'delete'))

  union all select 3, 'Neither anon nor authenticated holds TRUNCATE/REFERENCES/TRIGGER on any table',
    (select string_agg(t.relname || ' (' || r || ')', ', ' order by t.relname) from tbl t, unnest(array['anon','authenticated']) r
      where has_table_privilege(r, t.oid, 'truncate') or has_table_privilege(r, t.oid, 'references') or has_table_privilege(r, t.oid, 'trigger'))

  union all select 4, 'Every view is security_invoker (cannot bypass row-level security)',
    (select string_agg(v.relname, ', ' order by v.relname) from vw v where not coalesce(v.reloptions, '{}') @> array['security_invoker=true'])

  union all select 5, 'anon has no privilege on any view; nobody but service_role can write through a view',
    (select string_agg(v.relname, ', ' order by v.relname) from vw v
      where has_table_privilege('anon', v.oid, 'select')
         or has_table_privilege('authenticated', v.oid, 'insert') or has_table_privilege('authenticated', v.oid, 'update') or has_table_privilege('authenticated', v.oid, 'delete'))

  union all select 6, 'The service-role-only functions are not executable by anon, authenticated or PUBLIC',
    (select string_agg(p.proname, ', ' order by p.proname) from pg_proc p join pg_namespace n on n.oid = p.pronamespace
      where n.nspname = 'public'
        and p.proname in ('app_write_school_config','app_set_current_academic_session','app_set_current_term','app_transfer_enrollment',
                          'app_cms_transition','app_application_transition','app_convert_application')
        and (has_function_privilege('anon', p.oid, 'execute') or has_function_privilege('authenticated', p.oid, 'execute') or has_function_privilege('public', p.oid, 'execute')))

  union all select 7, 'service_role (the App Backend) can read and write every table',
    (select string_agg(t.relname, ', ' order by t.relname) from tbl t
      where not (has_table_privilege('service_role', t.oid, 'select') and has_table_privilege('service_role', t.oid, 'insert')
             and has_table_privilege('service_role', t.oid, 'update') and has_table_privilege('service_role', t.oid, 'delete')))

  union all select 8, 'Migrations are applied: the distinctive objects of 0021–0029 all exist',
    (select string_agg(missing, ', ') from (
      select 'table applications (0021)'                     as missing where to_regclass('public.applications') is null
      union all select 'table guardians (0021)'                       where to_regclass('public.guardians') is null
      union all select 'function app_is_guardian_of_student (0022)'   where to_regprocedure('public.app_is_guardian_of_student(uuid)') is null
      union all select 'permission admissions.applications.manage (0023)'
        where to_regclass('public.permissions') is null or not exists (select 1 from public.permissions where key = 'admissions.applications.manage')
      union all select 'function app_convert_application (0024)'      where to_regprocedure('public.app_convert_application(uuid,uuid,uuid,uuid)') is null
      union all select 'trigger on applications for level/campus (0027)'
        where not exists (select 1 from pg_trigger where tgname = 'trg_applications_validate_class_definition_campus' and not tgisinternal)
      union all select 'sequence application_reference_seq (0021/0028)' where to_regclass('public.application_reference_seq') is null
      union all select 'view student_current_enrollments (0010/0029)'  where to_regclass('public.student_current_enrollments') is null
    ) m)

  union all select 9, 'The default Data API privileges do not hand new tables to anon (future tables start closed)',
    (select 'default ACLs grant write to anon in public' from pg_default_acl d join pg_namespace n on n.oid = d.defaclnamespace
      where n.nspname = 'public' and d.defaclobjtype = 'r'
        and exists (select 1 from aclexplode(d.defaclacl) a join pg_roles r on r.oid = a.grantee
                    where r.rolname = 'anon' and a.privilege_type in ('INSERT','UPDATE','DELETE','TRUNCATE')) limit 1)
)
select ord as "#", name as "Check", case when offenders is null then 'OK' else 'FAIL' end as "Result", coalesce(offenders, '') as "Offending objects"
from checks order by ord;
