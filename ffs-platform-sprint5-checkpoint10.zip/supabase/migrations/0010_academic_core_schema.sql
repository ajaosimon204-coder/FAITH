-- =============================================================================
-- Migration 0010: Academic Core Schema
-- Sprint 3 — Faith Foundation Schools Digital Platform
--
-- Scope: academic_sessions, terms, class_definitions, classes, subjects,
-- class_subjects, enrollments (historical, authoritative), teacher_assignments.
--
-- MINIMAL DEPENDENCY (flagged, not silently absorbed — see Sprint 3
-- Completion Report "Architecture Deviations"): `enrollments` and
-- `teacher_assignments` require valid `student_id`/`staff_id` foreign keys.
-- The full "People" domain (students/guardians/staff with admission
-- workflow, demographics, employment records) is Sprint 5's job. This
-- migration adds ONLY the bare minimum needed as FK anchors — no
-- admissions, no HR. Sprint 5 will extend these tables with their real
-- columns; nothing here should need to change shape, only grow.
-- =============================================================================

create table students (
  id              uuid primary key default gen_random_uuid(),
  campus_id       uuid not null references campuses(id) on delete restrict,
  users_id        uuid references users(id) on delete set null,
  display_name    text not null,
  lifecycle_status text not null default 'active',
  created_at      timestamptz not null default now()
);

create index idx_students_campus_id on students(campus_id);
create index idx_students_users_id on students(users_id);

comment on table students is
  'MINIMAL Sprint 3 stub — just enough to anchor enrollments FK-wise. Sprint 5 (Admissions) owns the real student record: admission_no, dob, gender, photo, lifecycle_status enum, guardian links, documents, etc. This table should only ever grow columns, not change shape.';

create table staff (
  id              uuid primary key default gen_random_uuid(),
  campus_id       uuid not null references campuses(id) on delete restrict,
  users_id        uuid references users(id) on delete set null,
  display_name    text not null,
  employment_status text not null default 'active',
  created_at      timestamptz not null default now()
);

create index idx_staff_campus_id on staff(campus_id);
create index idx_staff_users_id on staff(users_id);

comment on table staff is
  'MINIMAL Sprint 3 stub — just enough to anchor teacher_assignments FK-wise. A full HR module is explicitly reserved (not built) per the approved architecture; this table should only ever grow columns, not change shape.';

-- -----------------------------------------------------------------------------
-- Academic sessions & terms
-- -----------------------------------------------------------------------------

create table academic_sessions (
  id            uuid primary key default gen_random_uuid(),
  campus_id     uuid not null references campuses(id) on delete restrict,
  name          text not null,             -- e.g. '2025/2026'
  start_date    date not null,
  end_date      date not null,
  is_current    boolean not null default false,
  created_at    timestamptz not null default now(),
  constraint chk_academic_sessions_dates check (start_date < end_date),
  unique (campus_id, name)
);

create index idx_academic_sessions_campus_id on academic_sessions(campus_id);

-- Exactly one current session per campus.
create unique index uq_academic_sessions_one_current_per_campus
  on academic_sessions(campus_id) where is_current;

create table terms (
  id                    uuid primary key default gen_random_uuid(),
  academic_session_id   uuid not null references academic_sessions(id) on delete cascade,
  campus_id             uuid not null references campuses(id) on delete restrict,
  name                  text not null,     -- e.g. 'First Term'
  start_date            date not null,
  end_date              date not null,
  is_current            boolean not null default false,
  created_at            timestamptz not null default now(),
  constraint chk_terms_dates check (start_date < end_date),
  unique (academic_session_id, name)
);

create index idx_terms_session_id on terms(academic_session_id);
create index idx_terms_campus_id on terms(campus_id);

-- Exactly one current term per session.
create unique index uq_terms_one_current_per_session
  on terms(academic_session_id) where is_current;

-- A term's dates must fall within its parent session's dates, and its
-- campus_id must match — both cross-table checks a plain CHECK constraint
-- cannot express, so enforced via trigger.
create or replace function trg_validate_term_within_session()
returns trigger
language plpgsql
as $$
declare
  v_session academic_sessions;
begin
  select * into v_session from academic_sessions where id = new.academic_session_id;

  if new.campus_id <> v_session.campus_id then
    raise exception 'Term campus_id (%) must match its academic_session''s campus_id (%)',
      new.campus_id, v_session.campus_id;
  end if;

  if new.start_date < v_session.start_date or new.end_date > v_session.end_date then
    raise exception 'Term dates (% to %) must fall within the academic session''s dates (% to %)',
      new.start_date, new.end_date, v_session.start_date, v_session.end_date;
  end if;

  return new;
end;
$$;

create trigger trg_terms_validate_within_session
  before insert or update on terms
  for each row execute function trg_validate_term_within_session();

-- -----------------------------------------------------------------------------
-- Class definitions (level concept), session-specific classes, subjects
-- -----------------------------------------------------------------------------

create type school_level_category as enum (
  'preparatory', 'kg', 'nursery', 'basic', 'junior_secondary', 'senior_secondary'
);

create table class_definitions (
  id            uuid primary key default gen_random_uuid(),
  campus_id     uuid not null references campuses(id) on delete restrict,
  name          text not null,             -- e.g. 'JSS 1' — verified school levels only, no invented names
  level         school_level_category not null,
  created_at    timestamptz not null default now(),
  unique (campus_id, name)
);

create index idx_class_definitions_campus_id on class_definitions(campus_id);

create table classes (
  id                    uuid primary key default gen_random_uuid(),
  class_definition_id   uuid not null references class_definitions(id) on delete restrict,
  academic_session_id   uuid not null references academic_sessions(id) on delete restrict,
  campus_id             uuid not null references campuses(id) on delete restrict,
  name                  text not null,     -- e.g. 'JSS 1A'
  section               text,               -- e.g. 'A' — nullable for single-stream classes
  created_at            timestamptz not null default now(),
  unique (class_definition_id, academic_session_id, section)
);

create index idx_classes_definition_id on classes(class_definition_id);
create index idx_classes_session_id on classes(academic_session_id);
create index idx_classes_campus_id on classes(campus_id);

-- A class's campus_id/academic_session's campus_id must agree — trigger,
-- same reasoning as terms above.
create or replace function trg_validate_class_campus_matches_session()
returns trigger
language plpgsql
as $$
declare
  v_session_campus_id uuid;
  v_definition_campus_id uuid;
begin
  select campus_id into v_session_campus_id from academic_sessions where id = new.academic_session_id;
  select campus_id into v_definition_campus_id from class_definitions where id = new.class_definition_id;

  if new.campus_id <> v_session_campus_id or new.campus_id <> v_definition_campus_id then
    raise exception 'classes.campus_id must match both its academic_session and class_definition campus_id';
  end if;

  return new;
end;
$$;

create trigger trg_classes_validate_campus
  before insert or update on classes
  for each row execute function trg_validate_class_campus_matches_session();

create table subjects (
  id            uuid primary key default gen_random_uuid(),
  campus_id     uuid not null references campuses(id) on delete restrict,
  name          text not null,
  code          text not null,
  created_at    timestamptz not null default now(),
  unique (campus_id, code)
);

create index idx_subjects_campus_id on subjects(campus_id);

create table class_subjects (
  class_id      uuid not null references classes(id) on delete cascade,
  subject_id    uuid not null references subjects(id) on delete restrict,
  created_at    timestamptz not null default now(),
  primary key (class_id, subject_id)
);

-- -----------------------------------------------------------------------------
-- Enrollments — THE historical-integrity-critical table. Never updated in
-- place to change class: a new row is inserted, the prior active row's
-- exited_at/status is closed out. A student's "current class" is always a
-- derived query (see the view below), never a stored column anywhere.
-- -----------------------------------------------------------------------------

create type enrollment_status as enum ('active', 'completed', 'withdrawn', 'transferred');

create table enrollments (
  id                    uuid primary key default gen_random_uuid(),
  student_id            uuid not null references students(id) on delete restrict,
  class_id              uuid not null references classes(id) on delete restrict,
  academic_session_id   uuid not null references academic_sessions(id) on delete restrict,
  term_id               uuid references terms(id) on delete restrict,
  campus_id             uuid not null references campuses(id) on delete restrict,
  status                enrollment_status not null default 'active',
  enrolled_at           timestamptz not null default now(),
  exited_at             timestamptz,
  exit_reason           text,
  created_at            timestamptz not null default now(),
  constraint chk_enrollments_exit_consistency check (
    (status = 'active' and exited_at is null) or
    (status <> 'active' and exited_at is not null)
  )
);

create index idx_enrollments_student_id on enrollments(student_id);
create index idx_enrollments_class_id on enrollments(class_id);
create index idx_enrollments_session_id on enrollments(academic_session_id);
create index idx_enrollments_campus_id on enrollments(campus_id);

-- The core historical-integrity guarantee: at most ONE active enrollment
-- per student per academic session. This is what makes "current class"
-- derivable unambiguously — see the student_current_enrollments view below.
create unique index uq_enrollments_one_active_per_student_per_session
  on enrollments(student_id, academic_session_id) where status = 'active';

-- class_id's session must match the enrollment's own academic_session_id,
-- and campus_id must agree across student/class/session — cross-table
-- checks enforced via trigger.
create or replace function trg_validate_enrollment_consistency()
returns trigger
language plpgsql
as $$
declare
  v_class_session_id uuid;
  v_class_campus_id uuid;
  v_student_campus_id uuid;
begin
  select academic_session_id, campus_id into v_class_session_id, v_class_campus_id
  from classes where id = new.class_id;

  select campus_id into v_student_campus_id from students where id = new.student_id;

  if new.academic_session_id <> v_class_session_id then
    raise exception 'Enrollment academic_session_id (%) must match the class''s own session (%)',
      new.academic_session_id, v_class_session_id;
  end if;

  if new.campus_id <> v_class_campus_id or new.campus_id <> v_student_campus_id then
    raise exception 'Enrollment campus_id must match both the student''s and the class''s campus_id';
  end if;

  return new;
end;
$$;

create trigger trg_enrollments_validate_consistency
  before insert or update on enrollments
  for each row execute function trg_validate_enrollment_consistency();

-- Historical immutability guardrail: once an enrollment is no longer
-- 'active', its class_id/student_id/academic_session_id can never change —
-- corrections happen by inserting a new row, not editing history. Only
-- status/exited_at/exit_reason may still change (e.g. correcting an exit
-- reason after the fact), matching "historical academic records cannot be
-- accidentally overwritten."
create or replace function trg_prevent_enrollment_history_mutation()
returns trigger
language plpgsql
as $$
begin
  if old.status <> 'active' and (
    new.student_id <> old.student_id or
    new.class_id <> old.class_id or
    new.academic_session_id <> old.academic_session_id or
    new.enrolled_at <> old.enrolled_at
  ) then
    raise exception 'Cannot modify the identity/class/session of a closed enrollment (id=%). Insert a new enrollment row instead — history is immutable.', old.id;
  end if;
  return new;
end;
$$;

create trigger trg_enrollments_prevent_history_mutation
  before update on enrollments
  for each row execute function trg_prevent_enrollment_history_mutation();

comment on table enrollments is
  'Historical, authoritative record of every class a student has ever belonged to. NEVER updated in place to move a student to a new class — insert a new row, close the old one. "Current class" is always derived (see student_current_enrollments view), never stored on students.';

-- The derivation mechanism itself: a student's current class is whichever
-- enrollment is `active` in whichever academic_session is `is_current` for
-- that campus. This view is the ONLY sanctioned way to ask "what class is
-- this student in right now" — there is deliberately no students.current_class
-- column anywhere in this schema.
create view student_current_enrollments as
select e.*
from enrollments e
join academic_sessions s on s.id = e.academic_session_id
where e.status = 'active'
  and s.is_current = true;

comment on view student_current_enrollments is
  'The sanctioned way to derive a student''s current class: the active enrollment in whichever academic_session is_current for that campus. There is deliberately no students.current_class column — this view is authoritative instead.';

-- -----------------------------------------------------------------------------
-- Teacher assignments — class-teacher and subject-teacher, both scoped to
-- an academic session. This is what "teacher access must be
-- relationship-based" is built on: RLS/service-layer checks join through
-- THIS table, never through role name alone.
-- -----------------------------------------------------------------------------

create type teacher_assignment_role as enum ('subject_teacher', 'class_teacher');

create table teacher_assignments (
  id                    uuid primary key default gen_random_uuid(),
  staff_id              uuid not null references staff(id) on delete restrict,
  class_id              uuid not null references classes(id) on delete restrict,
  subject_id            uuid references subjects(id) on delete restrict,
  academic_session_id   uuid not null references academic_sessions(id) on delete restrict,
  campus_id             uuid not null references campuses(id) on delete restrict,
  role                  teacher_assignment_role not null,
  assigned_by           uuid not null references users(id),
  assigned_at           timestamptz not null default now(),
  created_at            timestamptz not null default now(),
  constraint chk_teacher_assignment_subject_matches_role check (
    (role = 'class_teacher' and subject_id is null) or
    (role = 'subject_teacher' and subject_id is not null)
  )
);

create index idx_teacher_assignments_staff_id on teacher_assignments(staff_id);
create index idx_teacher_assignments_class_id on teacher_assignments(class_id);
create index idx_teacher_assignments_session_id on teacher_assignments(academic_session_id);
create index idx_teacher_assignments_campus_id on teacher_assignments(campus_id);

-- Prevent duplicate assignments (expression index, same pattern as
-- user_roles in migration 0001, to allow subject_id to be null for
-- class_teacher rows).
create unique index uq_teacher_assignments_no_duplicates on teacher_assignments (
  staff_id, class_id, academic_session_id, coalesce(subject_id, '00000000-0000-0000-0000-000000000000')
);

-- Exactly one class_teacher per class per session.
create unique index uq_teacher_assignments_one_class_teacher_per_class
  on teacher_assignments(class_id, academic_session_id)
  where role = 'class_teacher';

comment on table teacher_assignments is
  'The authoritative source for "which teacher can access which class/subject". RLS and the App Backend both join through this table for authorization — a Teacher role alone never grants access to a specific class.';
