-- =============================================================================
-- Migration 0007: Seed Config Permissions & Definitions
-- Sprint 2 — Faith Foundation Schools Digital Platform
--
-- System configuration (permissions, config_definitions), not school
-- content — safe for every environment including production.
-- =============================================================================

-- -----------------------------------------------------------------------------
-- New permissions, one read + one write per config category, matching the
-- RBAC delta already specified in "Phase 1 Architecture (Revised / Final)",
-- Section D.
-- -----------------------------------------------------------------------------

insert into permissions (key, description) values
  ('config.academic.read',    'Read academic-category configuration.'),
  ('config.academic.write',   'Modify academic-category configuration.'),
  ('config.finance.read',      'Read finance-category configuration.'),
  ('config.finance.write',     'Modify finance-category configuration.'),
  ('config.school.read',        'Read school-category configuration.'),
  ('config.school.write',       'Modify school-category configuration.'),
  ('config.examination.read',   'Read examination-category configuration.'),
  ('config.examination.write',  'Modify examination-category configuration.')
on conflict (key) do nothing;

-- -----------------------------------------------------------------------------
-- Role -> permission grants for Sprint 2.
--
-- Per the approved RBAC delta: school_administrator and principal get
-- academic write; accountant gets finance write; exam_officer gets
-- examination write; super_admin gets everything. Read access is granted
-- more broadly within admin-tier roles, since seeing configuration (without
-- being able to change it) is low-risk and useful for context.
-- -----------------------------------------------------------------------------

insert into role_permissions (role_id, permission_id)
select r.id, p.id
from roles r
cross join permissions p
where (r.key, p.key) in (
  ('super_admin', 'config.academic.read'),   ('super_admin', 'config.academic.write'),
  ('super_admin', 'config.finance.read'),     ('super_admin', 'config.finance.write'),
  ('super_admin', 'config.school.read'),       ('super_admin', 'config.school.write'),
  ('super_admin', 'config.examination.read'),  ('super_admin', 'config.examination.write'),

  ('school_administrator', 'config.academic.read'),  ('school_administrator', 'config.academic.write'),
  ('school_administrator', 'config.finance.read'),
  ('school_administrator', 'config.school.read'),     ('school_administrator', 'config.school.write'),
  ('school_administrator', 'config.examination.read'),

  ('principal', 'config.academic.read'), ('principal', 'config.academic.write'),
  ('principal', 'config.examination.read'),

  ('vice_principal', 'config.academic.read'),
  ('vice_principal', 'config.examination.read'),

  ('accountant', 'config.finance.read'), ('accountant', 'config.finance.write'),

  ('exam_officer', 'config.examination.read'), ('exam_officer', 'config.examination.write'),

  ('proprietor', 'config.academic.read'),
  ('proprietor', 'config.finance.read'),
  ('proprietor', 'config.school.read'),
  ('proprietor', 'config.examination.read')
)
on conflict do nothing;

-- -----------------------------------------------------------------------------
-- Initial config_definitions — one illustrative, genuinely-useful key per
-- category, demonstrating the full validation + permission pipeline works
-- end to end. Deliberately NOT pre-seeding keys that belong to a dedicated
-- table a later sprint will build (e.g. grading_scales, promotion rules) —
-- that would be schema duplication (Governance Rule 4). These four are
-- generic school-operations settings with no other home.
-- -----------------------------------------------------------------------------

insert into config_definitions (category, key, data_type, json_schema, read_permission_key, write_permission_key, description)
values
  (
    'school',
    'school.timezone',
    'string',
    '{"type": "string", "enum": ["Africa/Lagos"]}'::jsonb,
    'config.school.read',
    'config.school.write',
    'IANA timezone the school operates in. Constrained to Africa/Lagos for V1 single-campus Nigerian operation.'
  ),
  (
    'finance',
    'finance.default_currency',
    'string',
    '{"type": "string", "enum": ["NGN"]}'::jsonb,
    'config.finance.read',
    'config.finance.write',
    'ISO 4217 currency code used for all fee/invoice/payment amounts. Constrained to NGN for V1.'
  ),
  (
    'academic',
    'academic.max_class_size',
    'integer',
    '{"type": "integer", "minimum": 1, "maximum": 200}'::jsonb,
    'config.academic.read',
    'config.academic.write',
    'Soft cap used for class-size warnings in later academic-management sprints. Not enforced yet — Sprint 2 only stores and validates the value.'
  ),
  (
    'examination',
    'examination.default_pass_mark_percent',
    'number',
    '{"type": "number", "minimum": 0, "maximum": 100}'::jsonb,
    'config.examination.read',
    'config.examination.write',
    'Fallback pass-mark percentage used where a subject-specific grading scale (built in a later sprint) does not override it.'
  )
on conflict (key) do nothing;
