-- =============================================================================
-- Migration 0013: Atomic "Set Current" Functions
-- Sprint 3 — Faith Foundation Schools Digital Platform
--
-- Same reasoning as app_write_school_config() (migration 0008): unsetting
-- the old is_current row and setting the new one must happen atomically,
-- or a partial failure could leave a campus/session with zero (or two)
-- current rows, which the partial unique indexes in migration 0010 would
-- then reject non-deterministically depending on statement order.
-- =============================================================================

create or replace function app_set_current_academic_session(p_campus_id uuid, p_session_id uuid)
returns academic_sessions
language plpgsql
security definer
set search_path = public
as $$
declare
  v_result academic_sessions;
begin
  if not exists (select 1 from academic_sessions where id = p_session_id and campus_id = p_campus_id) then
    raise exception 'Session % does not belong to campus %', p_session_id, p_campus_id;
  end if;

  update academic_sessions set is_current = false where campus_id = p_campus_id and is_current = true;
  update academic_sessions set is_current = true where id = p_session_id
  returning * into v_result;

  return v_result;
end;
$$;

revoke execute on function app_set_current_academic_session(uuid, uuid) from authenticated, anon;

create or replace function app_set_current_term(p_academic_session_id uuid, p_term_id uuid)
returns terms
language plpgsql
security definer
set search_path = public
as $$
declare
  v_result terms;
begin
  if not exists (select 1 from terms where id = p_term_id and academic_session_id = p_academic_session_id) then
    raise exception 'Term % does not belong to academic_session %', p_term_id, p_academic_session_id;
  end if;

  update terms set is_current = false where academic_session_id = p_academic_session_id and is_current = true;
  update terms set is_current = true where id = p_term_id
  returning * into v_result;

  return v_result;
end;
$$;

revoke execute on function app_set_current_term(uuid, uuid) from authenticated, anon;
