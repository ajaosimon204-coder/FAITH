-- Migration 0022: RLS — Admissions (Sprint 5)
-- Replaces the Sprint 3 app_is_guardian_of_student() stub body.

create or replace function app_is_guardian_of_student(p_student_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from guardian_students gs
    join guardians g on g.id = gs.guardian_id
    where gs.student_id = p_student_id and g.users_id = app_current_user_id()
  );
$$;

alter table guardians enable row level security;
alter table guardian_students enable row level security;
alter table applications enable row level security;
alter table application_documents enable row level security;

create policy guardians_select_self on guardians for select
  using (users_id = app_current_user_id());
create policy guardians_select_admin_same_campus on guardians for select
  using (campus_id = app_current_campus_id()
    and (app_has_permission('admissions.applications.read') or app_has_permission('admissions.applications.manage')));
revoke insert, update, delete on guardians from authenticated;

create policy guardian_students_select_self on guardian_students for select
  using (exists (select 1 from guardians g where g.id = guardian_students.guardian_id and g.users_id = app_current_user_id()));
create policy guardian_students_select_admin_same_campus on guardian_students for select
  using (exists (select 1 from guardians g where g.id = guardian_students.guardian_id and g.campus_id = app_current_campus_id())
    and (app_has_permission('admissions.applications.read') or app_has_permission('admissions.applications.manage')));
revoke insert, update, delete on guardian_students from authenticated;

create policy applications_select_admin_same_campus on applications for select
  using (campus_id = app_current_campus_id()
    and (app_has_permission('admissions.applications.read') or app_has_permission('admissions.applications.manage')));
revoke insert, update, delete on applications from authenticated, anon;

create policy application_documents_select_admin_same_campus on application_documents for select
  using (exists (select 1 from applications a
    where a.id = application_documents.application_id and a.campus_id = app_current_campus_id()
      and (app_has_permission('admissions.applications.read') or app_has_permission('admissions.applications.manage'))));
revoke insert, update, delete on application_documents from authenticated, anon;
