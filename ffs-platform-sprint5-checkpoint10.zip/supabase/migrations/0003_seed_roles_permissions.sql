-- =============================================================================
-- Migration 0003: Seed Roles & Permissions (Sprint 1 scope)
-- Sprint 1 — Faith Foundation Schools Digital Platform
--
-- This is SYSTEM CONFIGURATION (software roles/permissions), not school
-- content — it is safe to apply in every environment including production,
-- and is intentionally a numbered migration rather than a "demo data" seed.
--
-- Only the roles and permissions Sprint 1 actually needs are seeded here.
-- The remaining roles from the approved RBAC matrix are pre-declared with
-- no permissions attached yet — later sprints attach their own permissions
-- to these existing roles rather than re-declaring them (avoids a future
-- migration having to "discover" whether a role already exists).
-- =============================================================================

insert into roles (key, name, description) values
  ('super_admin',          'Super Admin',            'Full platform access across all modules.'),
  ('proprietor',           'Proprietor',              'Ownership-level oversight; broad read access.'),
  ('school_administrator', 'School Administrator',    'Full operational access for day-to-day school administration.'),
  ('principal',            'Principal',               'Academic leadership; approval authority.'),
  ('vice_principal',       'Vice Principal',          'Academic leadership; approval authority.'),
  ('head_teacher',         'Head Teacher',            'Section-level academic leadership.'),
  ('accountant',           'Accountant',              'Finance module access.'),
  ('teacher',              'Teacher',                 'Subject-teaching access, scoped to assigned classes.'),
  ('class_teacher',        'Class Teacher',           'Full access to one assigned class.'),
  ('exam_officer',         'Exam Officer',            'Examination module configuration and oversight.'),
  ('librarian',            'Librarian',               'Reserved — library module not yet implemented.'),
  ('content_editor',       'Content Editor',          'Public website content creation, narrower than admin.'),
  ('student',               'Student',                 'Self-service access to own academic record.'),
  ('parent_guardian',      'Parent / Guardian',       'Access to linked children''s records only.')
on conflict (key) do nothing;

insert into permissions (key, description) values
  ('rbac.manage',           'Assign or revoke roles for users within one''s own campus.'),
  ('rbac.read',              'View role assignments within one''s own campus.'),
  ('organizations.read',     'Read organization and campus information.'),
  ('organizations.manage',   'Modify organization and campus configuration.'),
  ('audit.read',              'Read the audit log within one''s own campus.')
on conflict (key) do nothing;

-- Sprint 1 role -> permission grants. Every other role declared above exists
-- (so later sprints have a stable foreign key to attach to) but intentionally
-- carries NO permissions yet — a role with zero grants is inert, not a
-- security hole, and prevents this migration from guessing at permissions
-- that belong to modules not yet built (Governance Rule 15).

insert into role_permissions (role_id, permission_id)
select r.id, p.id
from roles r
cross join permissions p
where (r.key, p.key) in (
  ('super_admin', 'rbac.manage'),
  ('super_admin', 'rbac.read'),
  ('super_admin', 'organizations.manage'),
  ('super_admin', 'organizations.read'),
  ('super_admin', 'audit.read'),

  ('school_administrator', 'rbac.read'),
  ('school_administrator', 'organizations.read'),
  ('school_administrator', 'audit.read'),

  ('proprietor', 'organizations.read'),
  ('proprietor', 'audit.read')
)
on conflict do nothing;
