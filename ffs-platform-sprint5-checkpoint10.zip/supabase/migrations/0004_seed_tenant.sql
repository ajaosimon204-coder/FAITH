-- =============================================================================
-- Migration 0004: Seed the Real Tenant (Organization & Campus)
-- Sprint 1 — Faith Foundation Schools Digital Platform
--
-- This is real production data, not demo data — but per the no-fake-data
-- rule, only verified information from the master specification is used.
-- Anything not yet supplied is marked [CONTENT REQUIRED], never invented.
-- =============================================================================

insert into organizations (id, name)
values (
  '10000000-0000-0000-0000-000000000001',
  'Faith Foundation Schools'  -- verified: master specification, Section 1
)
on conflict (id) do nothing;

insert into campuses (id, organization_id, name, address)
values (
  '10000000-0000-0000-0000-000000000002',
  '10000000-0000-0000-0000-000000000001',
  '[CONTENT REQUIRED]',  -- campus display name not yet confirmed by the school
  'Oniyefun Zone A1, Thywill, Amuloko, Ibadan, Oyo State, Nigeria'  -- verified
)
on conflict (id) do nothing;

comment on column campuses.name is
  'For the single V1 campus: display name pending confirmation from the school (see Remaining Decisions, Final Architecture doc, item 1). Address is verified from the master specification and safe to use as-is.';
