-- =============================================================================
-- Migration 0014: Atomic Enrollment Transfer Function
-- Sprint 3 — Faith Foundation Schools Digital Platform
--
-- Closing the old enrollment and opening the new one must be atomic — a
-- crash between two separate client calls could otherwise leave a student
-- with NO active enrollment for a session (both trigger and unique-index
-- protections in migration 0010 only stop bad states from being written,
-- they don't make a two-step client operation atomic on their own).
-- =============================================================================

create or replace function app_transfer_enrollment(
  p_student_id uuid,
  p_from_enrollment_id uuid,
  p_new_class_id uuid,
  p_reason text
)
returns enrollments
language plpgsql
security definer
set search_path = public
as $$
declare
  v_academic_session_id uuid;
  v_campus_id uuid;
  v_term_id uuid;
  v_result enrollments;
begin
  select academic_session_id, campus_id, term_id
  into v_academic_session_id, v_campus_id, v_term_id
  from enrollments
  where id = p_from_enrollment_id and student_id = p_student_id and status = 'active';

  if v_academic_session_id is null then
    raise exception 'No active enrollment % found for student % to transfer', p_from_enrollment_id, p_student_id;
  end if;

  update enrollments
  set status = 'transferred', exited_at = now(), exit_reason = p_reason
  where id = p_from_enrollment_id;

  insert into enrollments (student_id, class_id, academic_session_id, term_id, campus_id)
  values (p_student_id, p_new_class_id, v_academic_session_id, v_term_id, v_campus_id)
  returning * into v_result;

  return v_result;
end;
$$;

comment on function app_transfer_enrollment is
  'Atomically closes a student''s current active enrollment (status=transferred) and opens a new one in the target class, within the same academic session. Called only by the App Backend''s service-role connection.';

revoke execute on function app_transfer_enrollment(uuid, uuid, uuid, text) from authenticated, anon;
