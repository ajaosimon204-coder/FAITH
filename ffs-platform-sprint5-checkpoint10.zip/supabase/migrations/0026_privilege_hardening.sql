-- Migration 0026: Privilege-layer hardening (project-wide)
--
-- Supabase's default privileges grant ALL on every new public table to anon,
-- authenticated and service_role, and rely on RLS alone to restrict rows. RLS is
-- enabled everywhere and is the primary control, but the privilege layer should
-- not be wider than the access model intends:
--
--   * anon is a read-only role in this platform (the only anonymous access is the
--     published-CMS read path, which is SELECT). It never needs INSERT/UPDATE/DELETE.
--   * TRUNCATE, REFERENCES and TRIGGER are never needed by anon or authenticated.
--     TRUNCATE in particular is not subject to RLS at all.
--
-- authenticated keeps whatever INSERT/UPDATE/DELETE each earlier migration
-- deliberately left it (those writes are governed per-table by RLS policies).
-- service_role is unchanged. SELECT for anon/authenticated is unchanged.
--
-- Written over every ordinary public table rather than a hand-kept list, so a
-- table added by an earlier or later sprint cannot be missed.

do $$
declare
  t record;
begin
  for t in
    select c.relname
    from pg_class c
    join pg_namespace n on n.oid = c.relnamespace
    where n.nspname = 'public' and c.relkind in ('r', 'p')
  loop
    execute format('revoke insert, update, delete on public.%I from anon', t.relname);
    execute format('revoke truncate, references, trigger on public.%I from anon, authenticated', t.relname);
  end loop;
end $$;

-- Future tables created by this role start closed to the same extent. Each new table
-- then needs an explicit GRANT for any write path it intends to expose.
alter default privileges in schema public revoke insert, update, delete on tables from anon;
alter default privileges in schema public revoke truncate, references, trigger on tables from anon, authenticated;
