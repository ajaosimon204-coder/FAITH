-- =============================================================================
-- Migration 0012: Seed Academic Core Permissions
-- Sprint 3 — Faith Foundation Schools Digital Platform
--
-- System configuration (permissions, role grants), not school content —
-- safe for every environment including production. No class/subject/session
-- DATA is seeded here — that's real school content this migration
-- deliberately does not fabricate (No Fake Data rule).
-- =============================================================================

insert into permissions (key, description) values
  ('academic.sessions.read',            'Read academic sessions and terms.'),
  ('academic.sessions.write',           'Create/modify academic sessions and terms, including setting the current one.'),
  ('academic.classes.read',              'Read class definitions, session-specific classes, subjects, and staff directory.'),
  ('academic.classes.write',             'Create/modify class definitions, session-specific classes, subjects, and class-subject links.'),
  ('academic.enrollments.read',          'Read any student''s enrollment records within one''s own campus.'),
  ('academic.enrollments.manage',        'Create/update enrollment records (enroll, transfer, withdraw) within one''s own campus.'),
  ('academic.teacher_assignments.read',   'Read teacher assignment records within one''s own campus.'),
  ('academic.teacher_assignments.manage', 'Create/remove teacher assignment records within one''s own campus.')
on conflict (key) do nothing;

-- Role -> permission grants, per the approved RBAC matrix's spirit
-- (School Administrator/Principal: broad academic authority; Head
-- Teacher/Class Teacher/Exam Officer: narrower; Accountant/Librarian: none
-- — academic data isn't their domain).

insert into role_permissions (role_id, permission_id)
select r.id, p.id
from roles r
cross join permissions p
where (r.key, p.key) in (
  ('super_admin', 'academic.sessions.read'),   ('super_admin', 'academic.sessions.write'),
  ('super_admin', 'academic.classes.read'),     ('super_admin', 'academic.classes.write'),
  ('super_admin', 'academic.enrollments.read'), ('super_admin', 'academic.enrollments.manage'),
  ('super_admin', 'academic.teacher_assignments.read'), ('super_admin', 'academic.teacher_assignments.manage'),

  ('school_administrator', 'academic.sessions.read'),   ('school_administrator', 'academic.sessions.write'),
  ('school_administrator', 'academic.classes.read'),     ('school_administrator', 'academic.classes.write'),
  ('school_administrator', 'academic.enrollments.read'), ('school_administrator', 'academic.enrollments.manage'),
  ('school_administrator', 'academic.teacher_assignments.read'), ('school_administrator', 'academic.teacher_assignments.manage'),

  ('principal', 'academic.sessions.read'),
  ('principal', 'academic.classes.read'), ('principal', 'academic.classes.write'),
  ('principal', 'academic.enrollments.read'), ('principal', 'academic.enrollments.manage'),
  ('principal', 'academic.teacher_assignments.read'), ('principal', 'academic.teacher_assignments.manage'),

  ('vice_principal', 'academic.sessions.read'),
  ('vice_principal', 'academic.classes.read'),
  ('vice_principal', 'academic.enrollments.read'),
  ('vice_principal', 'academic.teacher_assignments.read'),

  ('head_teacher', 'academic.sessions.read'),
  ('head_teacher', 'academic.classes.read'),
  ('head_teacher', 'academic.enrollments.read'),
  ('head_teacher', 'academic.teacher_assignments.read'),

  ('exam_officer', 'academic.sessions.read'),
  ('exam_officer', 'academic.classes.read'),

  ('proprietor', 'academic.sessions.read'),
  ('proprietor', 'academic.classes.read'),
  ('proprietor', 'academic.enrollments.read')
)
on conflict do nothing;
