-- =============================================================================
-- Migration 0005: School Configuration System
-- Sprint 2 — Faith Foundation Schools Digital Platform
--
-- Architecture reference: Final Architecture doc, Section B.6 / Q
-- ("Configuration Safety"). Core guarantee: JSONB never becomes an
-- unrestricted arbitrary-settings mechanism — a key must be pre-registered
-- in `config_definitions` (via migration, i.e. code-controlled) with a
-- schema, data type, category, and explicit read/write permission BEFORE
-- any value for it can ever be written through the API.
-- =============================================================================

create type config_category as enum ('academic', 'finance', 'school', 'examination');
create type config_data_type as enum ('string', 'number', 'integer', 'boolean', 'object', 'array');

-- -----------------------------------------------------------------------------
-- config_definitions — code/migration-controlled. There is deliberately NO
-- API endpoint that creates or edits rows in this table (Architecture
-- Section Q: "security-relevant settings... remain code/migration
-- controlled, not admin-editable at runtime" — and by extension, so is the
-- definition of what counts as a valid, permitted config key at all).
-- -----------------------------------------------------------------------------

create table config_definitions (
  id                  uuid primary key default gen_random_uuid(),
  category            config_category not null,
  key                 text not null unique,           -- e.g. 'finance.default_currency'
  data_type           config_data_type not null,
  json_schema         jsonb not null,                  -- full JSON Schema, validated at write time
  read_permission_key  text not null references permissions(key),
  write_permission_key text not null references permissions(key),
  description         text not null,
  created_at          timestamptz not null default now()
);

create index idx_config_definitions_category on config_definitions(category);

comment on table config_definitions is
  'Code/migration-controlled catalogue of every configurable setting. No API path creates or modifies rows here — only a new migration can. school_config values are only ever accepted for a key that already exists here.';
comment on column config_definitions.json_schema is
  'Full JSON Schema (draft-07 subset) validated with ajv at write time, in addition to the coarser data_type check — belt and suspenders, not redundant: data_type catches a wrong-shape value fast, json_schema catches an out-of-range or malformed one.';

-- -----------------------------------------------------------------------------
-- school_config — the actual admin-editable values, one row per
-- (definition, campus). Writable only through ConfigService, which
-- validates against the definition before ever reaching this table.
-- -----------------------------------------------------------------------------

create table school_config (
  id                    uuid primary key default gen_random_uuid(),
  config_definition_id  uuid not null references config_definitions(id) on delete restrict,
  campus_id             uuid not null references campuses(id) on delete restrict,
  value_json            jsonb not null,
  updated_by            uuid not null references users(id),
  updated_at            timestamptz not null default now(),
  unique (config_definition_id, campus_id)
);

create index idx_school_config_campus_id on school_config(campus_id);
create index idx_school_config_definition_id on school_config(config_definition_id);

-- -----------------------------------------------------------------------------
-- config_audit_log — every write to school_config produces exactly one row
-- here, in the same service-layer transaction (mirrors the audit_logs
-- pattern already established in Sprint 1 — Governance Rule 2: no
-- duplicate logic, this reuses the same "write in the same call" discipline
-- rather than inventing a second audit mechanism).
-- -----------------------------------------------------------------------------

create table config_audit_log (
  id                    uuid primary key default gen_random_uuid(),
  config_definition_id  uuid not null references config_definitions(id),
  campus_id             uuid not null references campuses(id),
  actor_id              uuid not null references users(id),
  old_value_json        jsonb,   -- null on first-ever write for this key/campus
  new_value_json        jsonb not null,
  created_at            timestamptz not null default now()
);

create index idx_config_audit_log_campus_id on config_audit_log(campus_id);
create index idx_config_audit_log_definition_id on config_audit_log(config_definition_id);
create index idx_config_audit_log_created_at on config_audit_log(created_at desc);

comment on table config_audit_log is
  'Append-only. Every school_config write produces one row here in the same service call — never a separate, best-effort step.';
