-- Migration 0028: Explicit API-role grants (works with or without Supabase's automatic default grants)
--
-- Until now every migration relied on Supabase's default privileges to hand anon, authenticated and
-- service_role their table privileges when a table was created, and then REVOKEd what must not stay.
-- Supabase has changed that default: from 2026-05-30 new projects do NOT grant anything automatically
-- to tables created in `public`, and from 2026-10-30 the change applies to newly created tables
-- generally. On such a project every earlier migration leaves the API roles with NO privileges, so the
-- App Backend (service_role) gets "permission denied" on every table and the platform is inoperable.
--
-- This migration states the intended privileges EXPLICITLY, per table, so the final state is the same
-- on a classic project (where these grants are already present and this is a no-op) and on a current
-- one (where they are what makes the platform work). The lists below were generated from the verified
-- effective privileges of migrations 0001-0027 and are checked for equivalence between both project
-- styles by supabase/local-test-harness/compare_privilege_models.sh.
--
-- Scope: DML (select/insert/update/delete) on tables, and the one sequence. EXECUTE on functions needs
-- no change: functions are PUBLIC-executable by default in Postgres, and the service-role-only
-- functions are already revoked from PUBLIC and granted to service_role explicitly (0020, 0024).
-- Schema USAGE is provided by Supabase on every project.
--
-- GOVERNANCE: every migration that creates a table from now on must GRANT what it needs explicitly.
-- rls_privilege_hardening_tests.sql fails when a public table is missing its service_role grants.

-- anon: read-only. RLS decides which rows are visible (published CMS content is the intended anonymous read path); with no matching policy a table yields zero rows.  (29 tables)
grant select on table
  public.academic_sessions,
  public.application_documents,
  public.applications,
  public.audit_logs,
  public.campuses,
  public.class_definitions,
  public.class_subjects,
  public.classes,
  public.cms_gallery,
  public.cms_news,
  public.cms_pages,
  public.cms_staff_profiles,
  public.config_audit_log,
  public.config_definitions,
  public.enrollments,
  public.guardian_students,
  public.guardians,
  public.organizations,
  public.permissions,
  public.role_permissions,
  public.roles,
  public.school_config,
  public.staff,
  public.students,
  public.subjects,
  public.teacher_assignments,
  public.terms,
  public.user_roles,
  public.users
to anon;

-- authenticated: read-only tables (writes go through the App Backend, i.e. service_role).  (14 tables)
grant select on table
  public.application_documents,
  public.applications,
  public.audit_logs,
  public.cms_gallery,
  public.cms_news,
  public.cms_pages,
  public.cms_staff_profiles,
  public.config_audit_log,
  public.config_definitions,
  public.guardian_students,
  public.guardians,
  public.school_config,
  public.staff,
  public.students
to authenticated;

-- authenticated: select, insert, update (no delete).  (1 tables)
grant select, insert, update on table
  public.enrollments
to authenticated;

-- authenticated: full DML, each write still gated per row by an RLS policy.  (14 tables)
grant select, insert, update, delete on table
  public.academic_sessions,
  public.campuses,
  public.class_definitions,
  public.class_subjects,
  public.classes,
  public.organizations,
  public.permissions,
  public.role_permissions,
  public.roles,
  public.subjects,
  public.teacher_assignments,
  public.terms,
  public.user_roles,
  public.users
to authenticated;

-- service_role (the App Backend): full DML on every table. Bypasses RLS by design; the services authorise explicitly.  (29 tables)
grant select, insert, update, delete on table
  public.academic_sessions,
  public.application_documents,
  public.applications,
  public.audit_logs,
  public.campuses,
  public.class_definitions,
  public.class_subjects,
  public.classes,
  public.cms_gallery,
  public.cms_news,
  public.cms_pages,
  public.cms_staff_profiles,
  public.config_audit_log,
  public.config_definitions,
  public.enrollments,
  public.guardian_students,
  public.guardians,
  public.organizations,
  public.permissions,
  public.role_permissions,
  public.roles,
  public.school_config,
  public.staff,
  public.students,
  public.subjects,
  public.teacher_assignments,
  public.terms,
  public.user_roles,
  public.users
to service_role;

-- Sequence used by trg_set_application_reference_no(), which is not SECURITY DEFINER: only the role
-- that inserts applications (service_role) needs it. Nobody else needs to call nextval() on it.
-- (No role needs setval(), so UPDATE is not granted either; this also makes a classic project, whose default
-- grants include it, end up identical to a current one.)
revoke all on sequence public.application_reference_seq from anon, authenticated, service_role;
grant usage, select on sequence public.application_reference_seq to service_role;
