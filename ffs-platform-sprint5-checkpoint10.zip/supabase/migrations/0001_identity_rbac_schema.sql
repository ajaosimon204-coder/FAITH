-- =============================================================================
-- Migration 0001: Identity, Tenancy & RBAC Foundation Schema
-- Sprint 1 — Faith Foundation Schools Digital Platform
--
-- Scope: organizations, campuses, users (auth bridge only — NO credentials),
-- roles, permissions, role_permissions, user_roles, audit_logs.
--
-- Architecture reference: "Phase 1 Architecture (Revised / Final)", Section
-- B.1 (Authentication & Identity), plus the tenancy boundary from the
-- subsequent hardening pass (Section M).
-- =============================================================================

create extension if not exists "pgcrypto";

-- -----------------------------------------------------------------------------
-- TENANCY
-- -----------------------------------------------------------------------------

create table organizations (
  id              uuid primary key default gen_random_uuid(),
  name            text not null,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

create table campuses (
  id              uuid primary key default gen_random_uuid(),
  organization_id uuid not null references organizations(id) on delete restrict,
  name            text not null,
  address         text,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  unique (organization_id, name)
);

create index idx_campuses_organization_id on campuses(organization_id);

-- -----------------------------------------------------------------------------
-- IDENTITY
--
-- IMPORTANT: this table intentionally has NO password/credential columns.
-- Supabase Auth (auth.users) is the sole owner of credentials, sessions,
-- and password resets. This table only mirrors application-specific state
-- for an already-authenticated identity.
-- -----------------------------------------------------------------------------

create table users (
  id              uuid primary key default gen_random_uuid(),
  auth_user_id    uuid not null unique references auth.users(id) on delete cascade,
  campus_id       uuid not null references campuses(id) on delete restrict,
  email           text,
  phone           text,
  display_name    text,
  status          text not null default 'active' check (status in ('active', 'suspended')),
  mfa_enabled     boolean not null default false,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

create index idx_users_auth_user_id on users(auth_user_id);
create index idx_users_campus_id on users(campus_id);

-- -----------------------------------------------------------------------------
-- RBAC
-- -----------------------------------------------------------------------------

create table roles (
  id              uuid primary key default gen_random_uuid(),
  key             text not null unique,  -- e.g. 'super_admin', 'teacher'
  name            text not null,          -- display name
  description     text,
  created_at      timestamptz not null default now()
);

create table permissions (
  id              uuid primary key default gen_random_uuid(),
  key             text not null unique,  -- e.g. 'rbac.manage'
  description     text not null,
  created_at      timestamptz not null default now()
);

create table role_permissions (
  role_id         uuid not null references roles(id) on delete cascade,
  permission_id   uuid not null references permissions(id) on delete cascade,
  primary key (role_id, permission_id)
);

create table user_roles (
  id              uuid primary key default gen_random_uuid(),
  user_id         uuid not null references users(id) on delete cascade,
  role_id         uuid not null references roles(id) on delete cascade,
  campus_id       uuid not null references campuses(id) on delete restrict,
  scope_type      text,   -- reserved for future fine scoping (e.g. 'class'), nullable
  scope_id        uuid,   -- reserved for future fine scoping, nullable
  assigned_by     uuid not null references users(id),
  assigned_at     timestamptz not null default now()
);

-- Expression-based unique index (table-level UNIQUE constraints cannot use
-- coalesce() directly) — prevents duplicate role assignments while still
-- allowing scope_type/scope_id to be null for an unscoped role grant.
create unique index uq_user_roles_assignment on user_roles (
  user_id,
  role_id,
  campus_id,
  coalesce(scope_type, ''),
  coalesce(scope_id, '00000000-0000-0000-0000-000000000000')
);

create index idx_user_roles_user_id on user_roles(user_id);
create index idx_user_roles_role_id on user_roles(role_id);
create index idx_user_roles_campus_id on user_roles(campus_id);

-- -----------------------------------------------------------------------------
-- AUDIT LOG (append-only)
-- -----------------------------------------------------------------------------

create table audit_logs (
  id              uuid primary key default gen_random_uuid(),
  actor_id        uuid not null references users(id),
  campus_id       uuid not null references campuses(id),
  action          text not null,
  target_type     text not null,
  target_id       text not null,
  metadata_json   jsonb not null default '{}'::jsonb,
  created_at      timestamptz not null default now()
);

create index idx_audit_logs_campus_id on audit_logs(campus_id);
create index idx_audit_logs_actor_id on audit_logs(actor_id);
create index idx_audit_logs_target on audit_logs(target_type, target_id);
create index idx_audit_logs_created_at on audit_logs(created_at desc);

-- Append-only: no UPDATE or DELETE grants are ever issued against this table
-- to any application role (see 0002_rls_policies.sql). This is enforced at
-- the privilege level, not just by application convention.

comment on table users is
  'Application user profile. Credentials live exclusively in auth.users (Supabase Auth) — this table must never gain a password/credential column.';
comment on table audit_logs is
  'Append-only audit trail. INSERT only for application roles; no UPDATE/DELETE grants issued.';
