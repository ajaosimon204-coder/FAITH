-- =============================================================================
-- Migration 0017: CMS RLS + Workflow Transition Guard
-- Sprint 4 — Faith Foundation Schools Digital Platform
-- =============================================================================

alter table cms_pages enable row level security;
alter table cms_news enable row level security;
alter table cms_gallery enable row level security;
alter table cms_staff_profiles enable row level security;

-- -----------------------------------------------------------------------------
-- Shared status-transition guard, applied to all four CMS tables. Mirrors
-- the enrollment historical-integrity trigger pattern (migration 0010):
-- RLS is the coarse "can this actor touch this table" gate; this trigger
-- is the database-level backstop for "is this SPECIFIC transition valid",
-- independent of which connection (service-role or authenticated) wrote it.
-- -----------------------------------------------------------------------------

create or replace function trg_validate_cms_status_transition()
returns trigger
language plpgsql
as $$
begin
  if TG_OP = 'INSERT' then
    if new.status <> 'draft' then
      raise exception 'New CMS content must start in draft status, got %', new.status;
    end if;
    return new;
  end if;

  -- UPDATE: same-status is always allowed (editing content without a
  -- workflow transition). Otherwise, only these forward/reject paths:
  if old.status = new.status then
    return new;
  end if;

  if (old.status = 'draft' and new.status = 'in_review')
     or (old.status = 'in_review' and new.status = 'approved')
     or (old.status = 'in_review' and new.status = 'draft')       -- rejected back
     or (old.status = 'approved' and new.status = 'draft')        -- rejected late
     or (old.status = 'approved' and new.status = 'published')
     or (old.status = 'published' and new.status = 'archived')
  then
    return new;
  end if;

  raise exception 'Invalid CMS status transition: % -> %', old.status, new.status;
end;
$$;

create trigger trg_cms_pages_status
  before insert or update on cms_pages for each row execute function trg_validate_cms_status_transition();
create trigger trg_cms_news_status
  before insert or update on cms_news for each row execute function trg_validate_cms_status_transition();
create trigger trg_cms_gallery_status
  before insert or update on cms_gallery for each row execute function trg_validate_cms_status_transition();
create trigger trg_cms_staff_profiles_status
  before insert or update on cms_staff_profiles for each row execute function trg_validate_cms_status_transition();

-- -----------------------------------------------------------------------------
-- RLS policies — identical shape across all four tables.
--   - PUBLISHED content is readable by anyone, including anonymous
--     visitors (this is public marketing content by definition — no
--     campus scoping for this specific policy, since an anonymous public
--     site visitor has no campus context at all).
--   - Any non-published status is visible only to same-campus staff
--     holding content.create/review/publish/archive.
--   - Writes require content.create (for drafts) — finer-grained
--     transition permission (review vs. publish vs. archive) is enforced
--     in the application service layer, since expressing "which
--     permission is required for THIS SPECIFIC status transition" per-row
--     is impractical as a single RLS USING clause; the trigger above
--     enforces WHICH transitions are structurally valid regardless.
-- -----------------------------------------------------------------------------

do $$
declare
  t text;
begin
  foreach t in array array['cms_pages', 'cms_news', 'cms_gallery', 'cms_staff_profiles']
  loop
    execute format($f$
      create policy %1$I_select_published_public
        on %1$I for select
        using (status = 'published');
    $f$, t);

    execute format($f$
      create policy %1$I_select_same_campus_staff
        on %1$I for select
        using (
          campus_id = app_current_campus_id()
          and (
            app_has_permission('content.create')
            or app_has_permission('content.review')
            or app_has_permission('content.publish')
            or app_has_permission('content.archive')
          )
        );
    $f$, t);

    execute format($f$
      create policy %1$I_insert_content_creators
        on %1$I for insert
        with check (
          campus_id = app_current_campus_id()
          and app_has_permission('content.create')
        );
    $f$, t);

    execute format($f$
      create policy %1$I_update_same_campus_staff
        on %1$I for update
        using (
          campus_id = app_current_campus_id()
          and (
            app_has_permission('content.create')
            or app_has_permission('content.review')
            or app_has_permission('content.publish')
            or app_has_permission('content.archive')
          )
        )
        with check (campus_id = app_current_campus_id());
    $f$, t);

    execute format($f$ revoke delete on %1$I from authenticated; $f$, t);
  end loop;
end $$;

comment on function trg_validate_cms_status_transition() is
  'Database-level backstop enforcing which CMS status transitions are structurally valid, independent of RLS/permission checks. Applied identically to all four CMS tables.';
