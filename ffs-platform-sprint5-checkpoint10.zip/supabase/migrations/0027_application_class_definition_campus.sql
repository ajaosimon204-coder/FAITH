-- Migration 0027: Applications — the applied-for level must belong to the application's campus
--
-- applications.class_definition_id is a plain foreign key, so nothing stopped an
-- application in Campus A from naming a level (class_definition) of Campus B.
-- Conversion would eventually refuse it (the class-level and class-campus checks in
-- app_convert_application), but an inconsistent application row could still be
-- created and sit in the review queue. The database should refuse it at the door,
-- independent of whichever caller (App Backend, script, future module) inserts.
--
-- BEFORE INSERT only: campus_id and class_definition_id are immutable after
-- submission (trg_prevent_application_identity_mutation, migration 0021), so an
-- UPDATE can never introduce the inconsistency.

create or replace function trg_validate_application_class_definition_campus()
returns trigger language plpgsql as $$
declare
  v_definition_campus_id uuid;
begin
  select campus_id into v_definition_campus_id
  from class_definitions where id = new.class_definition_id;

  if v_definition_campus_id is null then
    raise exception 'application: class_definition % does not exist', new.class_definition_id;
  end if;
  if v_definition_campus_id <> new.campus_id then
    raise exception 'application: class_definition % (campus %) does not belong to the application''s campus %',
      new.class_definition_id, v_definition_campus_id, new.campus_id;
  end if;
  return new;
end;
$$;

create trigger trg_applications_validate_class_definition_campus
  before insert on applications
  for each row execute function trg_validate_application_class_definition_campus();
