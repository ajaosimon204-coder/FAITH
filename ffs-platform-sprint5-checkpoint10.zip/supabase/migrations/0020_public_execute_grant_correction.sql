-- =============================================================================
-- Migration 0020: Close the PUBLIC EXECUTE Grant Gap
-- Faith Foundation Schools Digital Platform
--
-- MAJOR FINDING, discovered while re-verifying the Sprint 4 audit fix live:
-- every "revoke execute ... from authenticated, anon" statement in every
-- prior migration (0008, 0013, 0014, and the newly-applied 0019) has been
-- SILENTLY INEFFECTIVE since it was first written. Postgres grants
-- EXECUTE on a newly created function to the PUBLIC pseudo-role by
-- default. Revoking from a specific role (authenticated/anon) does
-- nothing if PUBLIC still holds the grant, because every role implicitly
-- has whatever PUBLIC has. No migration ever revoked from PUBLIC itself.
--
-- Live-confirmed exploitable: an `accountant` role successfully called
-- app_write_school_config() directly and wrote a value that would have
-- failed ConfigService's ajv schema validation entirely — the exact
-- "JSONB must never become an unrestricted arbitrary-settings mechanism"
-- guarantee Sprint 2 (ADR-007) specifically existed to protect.
--
-- This affects every atomic RPC function added since Sprint 2:
--   - app_write_school_config          (migration 0008)
--   - app_set_current_academic_session (migration 0013)
--   - app_set_current_term             (migration 0013)
--   - app_transfer_enrollment          (migration 0014)
--   - app_cms_transition               (migration 0019)
--
-- Fix: revoke EXECUTE from PUBLIC explicitly on every one of these
-- functions. This is the actually-effective form of what every prior
-- migration intended.
-- =============================================================================

revoke execute on function app_write_school_config(uuid, uuid, jsonb, uuid) from public;
revoke execute on function app_set_current_academic_session(uuid, uuid) from public;
revoke execute on function app_set_current_term(uuid, uuid) from public;
revoke execute on function app_transfer_enrollment(uuid, uuid, uuid, text) from public;
revoke execute on function app_cms_transition(text, uuid, cms_content_status, text, uuid, text, uuid, jsonb, jsonb) from public;

-- Explicitly re-grant to service_role, since revoking from PUBLIC also
-- removes service_role's inherited access (service_role gets EXECUTE via
-- PUBLIC just like every other role does, absent an explicit grant).
grant execute on function app_write_school_config(uuid, uuid, jsonb, uuid) to service_role;
grant execute on function app_set_current_academic_session(uuid, uuid) to service_role;
grant execute on function app_set_current_term(uuid, uuid) to service_role;
grant execute on function app_transfer_enrollment(uuid, uuid, uuid, text) to service_role;
grant execute on function app_cms_transition(text, uuid, cms_content_status, text, uuid, text, uuid, jsonb, jsonb) to service_role;

comment on function app_write_school_config is
  'Atomically upserts a school_config value and writes its config_audit_log entry in one transaction. The App Backend must validate the value against config_definitions.json_schema (via ajv) BEFORE calling this. EXECUTE is granted ONLY to service_role — revoked from PUBLIC (migration 0020) in addition to authenticated/anon (migration 0008), since a PUBLIC grant is inherited by every role regardless of role-specific revokes.';

comment on function app_cms_transition is
  'Atomic status transition + audit log entry for any of the four CMS content types. EXECUTE is granted ONLY to service_role — revoked from PUBLIC (migration 0020) in addition to authenticated/anon (migration 0019), for the same reason.';
