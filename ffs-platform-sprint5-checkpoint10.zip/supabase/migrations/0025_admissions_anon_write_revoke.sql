-- Migration 0025: Admissions — close anon write privileges on guardian tables (Sprint 5)
--
-- Migration 0022 revoked INSERT/UPDATE/DELETE from `authenticated` only on
-- guardians and guardian_students, but from `authenticated, anon` on
-- applications and application_documents. Under Supabase's standard default
-- privileges (which grant ALL on new public tables to anon), `anon` therefore
-- still held write privileges on the two guardian tables. RLS (enabled, no
-- INSERT/UPDATE/DELETE policy) already denied the rows, so this was a
-- defense-in-depth gap, not an exploitable one — but the privilege layer
-- should agree with the RLS layer on all four admissions tables.
--
-- Scope note: this only makes Sprint 5's own four tables self-consistent.
-- The same anon-write default exists on earlier sprints' tables; that is a
-- project-wide hardening decision tracked separately (see Sprint 5A
-- verification report), not changed here.

revoke insert, update, delete on guardians from anon;
revoke insert, update, delete on guardian_students from anon;
