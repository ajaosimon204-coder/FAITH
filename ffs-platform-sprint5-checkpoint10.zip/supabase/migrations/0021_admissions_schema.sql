-- Migration 0021: Admissions Schema (Sprint 5)
-- Extends the Sprint 3 students stub (ADR-009) and adds the guardian domain.

alter table students
  add column admission_no    text,
  add column date_of_birth   date,
  add column gender          text,
  add column photo_url       text;

alter table students
  add constraint chk_students_lifecycle_status check (
    lifecycle_status in ('admitted', 'active', 'promoted', 'graduated', 'withdrawn', 'archived')
  );

create unique index uq_students_admission_no_per_campus
  on students(campus_id, admission_no) where admission_no is not null;

create table guardians (
  id              uuid primary key default gen_random_uuid(),
  campus_id       uuid not null references campuses(id) on delete restrict,
  users_id        uuid references users(id) on delete set null,
  first_name      text not null,
  last_name       text not null,
  phone           text,
  email           text,
  created_at      timestamptz not null default now()
);
create index idx_guardians_campus_id on guardians(campus_id);
create index idx_guardians_users_id on guardians(users_id);

create table guardian_students (
  guardian_id     uuid not null references guardians(id) on delete restrict,
  student_id      uuid not null references students(id) on delete restrict,
  relationship    text not null,
  created_at      timestamptz not null default now(),
  primary key (guardian_id, student_id)
);
create index idx_guardian_students_student_id on guardian_students(student_id);
create index idx_guardian_students_guardian_id on guardian_students(guardian_id);

create or replace function trg_validate_guardian_student_same_campus()
returns trigger language plpgsql as $$
declare
  v_guardian_campus_id uuid;
  v_student_campus_id uuid;
begin
  select campus_id into v_guardian_campus_id from guardians where id = new.guardian_id;
  select campus_id into v_student_campus_id from students where id = new.student_id;
  if v_guardian_campus_id is null then
    raise exception 'guardian_students: guardian % does not exist', new.guardian_id;
  end if;
  if v_student_campus_id is null then
    raise exception 'guardian_students: student % does not exist', new.student_id;
  end if;
  if v_guardian_campus_id <> v_student_campus_id then
    raise exception 'guardian_students: guardian (campus %) and student (campus %) must belong to the same campus',
      v_guardian_campus_id, v_student_campus_id;
  end if;
  return new;
end;
$$;
create trigger trg_guardian_students_validate_campus
  before insert or update on guardian_students
  for each row execute function trg_validate_guardian_student_same_campus();

create type application_status as enum (
  'submitted', 'under_review', 'info_requested', 'approved', 'rejected', 'converted'
);

create sequence application_reference_seq;

create or replace function trg_set_application_reference_no()
returns trigger language plpgsql as $$
begin
  if new.reference_no is null or new.reference_no = '' then
    new.reference_no := 'APP-' || to_char(now(), 'YYYY') || '-' || lpad(nextval('application_reference_seq')::text, 6, '0');
  end if;
  return new;
end;
$$;

create table applications (
  id                       uuid primary key default gen_random_uuid(),
  campus_id                uuid not null references campuses(id) on delete restrict,
  reference_no             text not null unique,
  applicant_first_name     text not null,
  applicant_last_name      text not null,
  applicant_date_of_birth  date not null,
  applicant_gender         text,
  class_definition_id      uuid not null references class_definitions(id) on delete restrict,
  guardian_first_name      text not null,
  guardian_last_name       text not null,
  guardian_email           text,
  guardian_phone           text,
  status                   application_status not null default 'submitted',
  submitted_at             timestamptz not null default now(),
  reviewed_by              uuid references users(id),
  review_notes             text,
  decision_reason          text,
  possible_duplicate_of    uuid references applications(id),
  converted_student_id     uuid references students(id),
  created_at               timestamptz not null default now()
);
create index idx_applications_campus_id on applications(campus_id);
create index idx_applications_status on applications(status);
create index idx_applications_class_definition_id on applications(class_definition_id);

create or replace function trg_prevent_application_identity_mutation()
returns trigger language plpgsql as $$
begin
  if new.campus_id <> old.campus_id
     or new.reference_no <> old.reference_no
     or new.applicant_first_name <> old.applicant_first_name
     or new.applicant_last_name <> old.applicant_last_name
     or new.applicant_date_of_birth <> old.applicant_date_of_birth
     or new.class_definition_id <> old.class_definition_id
  then
    raise exception 'Cannot modify the identity fields of application % — immutable once submitted.', old.id;
  end if;
  return new;
end;
$$;
create trigger trg_applications_prevent_identity_mutation
  before update on applications
  for each row execute function trg_prevent_application_identity_mutation();

create or replace function trg_validate_application_status_transition()
returns trigger language plpgsql as $$
begin
  if TG_OP = 'INSERT' then
    if new.status <> 'submitted' then
      raise exception 'A new application must start in submitted status, got %', new.status;
    end if;
    return new;
  end if;
  if old.status = new.status then
    return new;
  end if;
  if not (
    (old.status = 'submitted'      and new.status = 'under_review') or
    (old.status = 'under_review'   and new.status = 'info_requested') or
    (old.status = 'info_requested' and new.status = 'under_review') or
    (old.status = 'under_review'   and new.status = 'approved') or
    (old.status = 'under_review'   and new.status = 'rejected') or
    (old.status = 'approved'       and new.status = 'converted')
  ) then
    raise exception 'Invalid application status transition: % -> %', old.status, new.status;
  end if;
  return new;
end;
$$;
create trigger trg_applications_validate_status
  before insert or update on applications
  for each row execute function trg_validate_application_status_transition();
create trigger trg_applications_set_reference_no
  before insert on applications
  for each row execute function trg_set_application_reference_no();

create table application_documents (
  id              uuid primary key default gen_random_uuid(),
  application_id  uuid not null references applications(id) on delete cascade,
  doc_type        text not null,
  file_url        text not null,
  uploaded_at     timestamptz not null default now()
);
create index idx_application_documents_application_id on application_documents(application_id);
comment on table application_documents is
  'MINIMAL Sprint 5 scope: URL reference only. Storage integration is NOT built in this sprint.';
