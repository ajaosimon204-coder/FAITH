-- =============================================================================
-- Migration 0008: Atomic Config Write Function
-- Sprint 2 — Faith Foundation Schools Digital Platform
--
-- Why this exists: writing a new config value and recording its audit
-- entry must never partially succeed (a value change with no audit trail
-- would violate "every configuration change must be audited" outright).
-- A single Postgres function, called once via RPC from the App Backend,
-- guarantees both writes commit or fail together — two separate client
-- calls could not offer that guarantee without a manually-managed
-- transaction, which the Supabase client does not expose directly.
--
-- SECURITY DEFINER is required because this function is called via the
-- service-role client, which already bypasses RLS — the function itself
-- still re-validates the value against the definition's json_schema
-- server-side (Postgres-side, using the `pg_jsonschema`-free approach of
-- delegating full JSON Schema validation to the App Backend's ajv check
-- BEFORE this function is ever called, and re-checking only structural
-- invariants here — see comment inline).
-- =============================================================================

create or replace function app_write_school_config(
  p_config_definition_id uuid,
  p_campus_id uuid,
  p_new_value jsonb,
  p_actor_id uuid
)
returns school_config
language plpgsql
security definer
set search_path = public
as $$
declare
  v_old_value jsonb;
  v_result school_config;
begin
  -- Fail loudly if the definition genuinely doesn't exist — this function
  -- is only ever called after the App Backend has already validated the
  -- value against config_definitions.json_schema with ajv; this check is
  -- a second, cheap structural guard (the FK on school_config would catch
  -- it too, but a clear error message here is more debuggable).
  if not exists (select 1 from config_definitions where id = p_config_definition_id) then
    raise exception 'Unknown config_definition_id: %', p_config_definition_id;
  end if;

  select value_json into v_old_value
  from school_config
  where config_definition_id = p_config_definition_id
    and campus_id = p_campus_id;

  insert into school_config (config_definition_id, campus_id, value_json, updated_by)
  values (p_config_definition_id, p_campus_id, p_new_value, p_actor_id)
  on conflict (config_definition_id, campus_id)
  do update set
    value_json = excluded.value_json,
    updated_by = excluded.updated_by,
    updated_at = now()
  returning * into v_result;

  insert into config_audit_log (
    config_definition_id, campus_id, actor_id, old_value_json, new_value_json
  ) values (
    p_config_definition_id, p_campus_id, p_actor_id, v_old_value, p_new_value
  );

  return v_result;
end;
$$;

comment on function app_write_school_config is
  'Atomically upserts a school_config value and writes its config_audit_log entry in one transaction. The App Backend must validate the value against config_definitions.json_schema (via ajv) BEFORE calling this — this function performs only a structural existence check, not full schema validation, to avoid duplicating JSON Schema evaluation logic in two languages (Governance Rule 2).';

-- Only the service role should ever call this function directly — the
-- authenticated (frontend) role has no execute grant, closing off any
-- path where a direct Supabase client call could bypass ConfigService's
-- ajv validation entirely.
revoke execute on function app_write_school_config from authenticated, anon;
