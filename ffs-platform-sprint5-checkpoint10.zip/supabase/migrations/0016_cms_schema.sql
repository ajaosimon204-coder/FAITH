-- =============================================================================
-- Migration 0016: CMS Schema
-- Sprint 4 — Faith Foundation Schools Digital Platform
--
-- Four content types, one shared workflow: draft -> in_review -> approved ->
-- published -> archived (Architecture Section B.5). Rich content stored as
-- structured JSON (block-based), not raw HTML, to avoid stored-XSS risk and
-- keep rendering consistent (Architecture Section 12).
-- =============================================================================

create type cms_content_status as enum ('draft', 'in_review', 'approved', 'published', 'archived');

create table cms_pages (
  id              uuid primary key default gen_random_uuid(),
  campus_id       uuid not null references campuses(id) on delete restrict,
  slug            text not null,
  title           text not null,
  content_json    jsonb not null default '[]'::jsonb,   -- block-based content
  status          cms_content_status not null default 'draft',
  created_by      uuid not null references users(id),
  reviewed_by     uuid references users(id),
  approved_by     uuid references users(id),
  published_by    uuid references users(id),
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  unique (campus_id, slug)
);

create index idx_cms_pages_campus_status on cms_pages(campus_id, status);

create table cms_news (
  id              uuid primary key default gen_random_uuid(),
  campus_id       uuid not null references campuses(id) on delete restrict,
  title           text not null,
  body_json       jsonb not null default '[]'::jsonb,
  cover_image_url text,
  status          cms_content_status not null default 'draft',
  created_by      uuid not null references users(id),
  reviewed_by     uuid references users(id),
  approved_by     uuid references users(id),
  published_by    uuid references users(id),
  published_at    timestamptz,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

create index idx_cms_news_campus_status on cms_news(campus_id, status);

create table cms_gallery (
  id              uuid primary key default gen_random_uuid(),
  campus_id       uuid not null references campuses(id) on delete restrict,
  title           text not null,
  image_url       text not null,
  category        text,
  status          cms_content_status not null default 'draft',
  created_by      uuid not null references users(id),
  reviewed_by     uuid references users(id),
  approved_by     uuid references users(id),
  published_by    uuid references users(id),
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

create index idx_cms_gallery_campus_status on cms_gallery(campus_id, status);

create table cms_staff_profiles (
  id              uuid primary key default gen_random_uuid(),
  campus_id       uuid not null references campuses(id) on delete restrict,
  staff_id        uuid references staff(id) on delete set null,   -- links to real staff table (Sprint 3)
  display_name    text not null,
  bio             text,
  photo_url       text,
  display_order   integer not null default 0,
  status          cms_content_status not null default 'draft',
  created_by      uuid not null references users(id),
  reviewed_by     uuid references users(id),
  approved_by     uuid references users(id),
  published_by    uuid references users(id),
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

create index idx_cms_staff_profiles_campus_status on cms_staff_profiles(campus_id, status);

comment on column cms_pages.content_json is
  'Block-based structured content, NOT raw HTML — avoids stored-XSS and keeps rendering consistent across the public site (Architecture Section 12). The frontend renderer maps block types to trusted components; it never dangerouslySetInnerHTML from this column.';
