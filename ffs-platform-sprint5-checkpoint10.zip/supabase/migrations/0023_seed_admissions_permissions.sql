-- Migration 0023: Seed Admissions Permissions (Sprint 5)
insert into permissions (key, description) values
  ('admissions.applications.read',   'Read admissions applications within one''s own campus.'),
  ('admissions.applications.manage', 'Review, request info on, approve, reject, and convert admissions applications within one''s own campus.')
on conflict (key) do nothing;

insert into role_permissions (role_id, permission_id)
select r.id, p.id from roles r cross join permissions p
where (r.key, p.key) in (
  ('super_admin', 'admissions.applications.read'), ('super_admin', 'admissions.applications.manage'),
  ('school_administrator', 'admissions.applications.read'), ('school_administrator', 'admissions.applications.manage'),
  ('principal', 'admissions.applications.read'), ('principal', 'admissions.applications.manage'),
  ('vice_principal', 'admissions.applications.read'),
  ('proprietor', 'admissions.applications.read')
) on conflict do nothing;
