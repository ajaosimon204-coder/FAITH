-- =============================================================================
-- Migration 0019: CMS Adversarial Audit Corrections
-- Faith Foundation Schools Digital Platform
--
-- Fixes two CRITICAL findings from the Sprint 4 adversarial audit, both
-- confirmed live before this migration existed:
--
-- 1. An actor holding ONLY content.create could move approved->published
--    (or perform any other transition) via a direct client write, because
--    the RLS UPDATE policy checked "holds ANY of the 4 content
--    permissions" rather than the SPECIFIC permission the attempted
--    transition requires — that finer-grained mapping only existed in
--    TypeScript (CmsContentWorkflowService), which a direct database
--    client never touches.
-- 2. reviewed_by/approved_by/published_by could be set to an ARBITRARY
--    user id via direct client write — nothing tied those fields to the
--    caller's own identity.
--
-- Fix: remove ALL direct INSERT/UPDATE policies for the `authenticated`
-- role on the four CMS tables entirely. Every write — including plain
-- content edits, not just status transitions — now goes exclusively
-- through the App Backend's service-role connection, via a new atomic
-- Postgres function for status transitions specifically. This mirrors the
-- exact fix already applied to school_config in migration 0009 — the same
-- root cause (a service-role-adjacent write path was more permissive than
-- the application intended), the same fix shape (close the RLS write path
-- entirely, force it through a reviewed, atomic backend function).
-- =============================================================================

-- -----------------------------------------------------------------------------
-- Close the direct-write RLS gap on all four CMS tables.
-- -----------------------------------------------------------------------------

do $$
declare
  t text;
begin
  foreach t in array array['cms_pages', 'cms_news', 'cms_gallery', 'cms_staff_profiles']
  loop
    execute format('drop policy if exists %1$I_insert_content_creators on %1$I;', t);
    execute format('drop policy if exists %1$I_update_same_campus_staff on %1$I;', t);
    execute format('revoke insert, update on %1$I from authenticated;', t);
  end loop;
end $$;

comment on function trg_validate_cms_status_transition() is
  'Database-level backstop enforcing which CMS status transitions are structurally valid. As of migration 0019, this now runs ONLY against writes from the service-role connection (app_cms_create/app_cms_transition below, or direct service-role repository calls), since the authenticated role has no INSERT/UPDATE grant on these tables at all — but it still applies regardless of who/what writes, per its original design intent.';

-- -----------------------------------------------------------------------------
-- Atomic creation + status-transition functions. Generic across all four
-- CMS tables via dynamic SQL (same technique already used in migration
-- 0017's policy-creation loop) — one function serves all four content
-- types rather than four near-identical copies (Governance Rule 2).
--
-- CRITICAL PROPERTY: p_actor_id is the ONLY value ever written to
-- reviewed_by/approved_by/published_by/created_by. The App Backend always
-- passes actor.appUserId here — derived from the verified Supabase Auth
-- token (Architecture Section A), never from client-supplied request
-- body content. This closes Critical Finding 2 (actor-field forgery)
-- structurally: there is no code path, even a compromised or buggy
-- controller, that could pass an arbitrary id here without also passing
-- its own resolved identity's id, since the function signature has no
-- separate "attributed actor" parameter distinct from the caller.
-- -----------------------------------------------------------------------------

create or replace function app_cms_transition(
  p_table_name text,
  p_id uuid,
  p_to_status cms_content_status,
  p_actor_field text,   -- 'reviewed_by' | 'approved_by' | 'published_by' | null
  p_actor_id uuid,
  p_action text,
  p_campus_id uuid,
  p_metadata jsonb,
  p_extra_fields jsonb default '{}'::jsonb  -- type-specific side effects, e.g. cms_news.published_at
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_current_campus_id uuid;
  v_set_clause text;
  v_key text;
begin
  if p_table_name not in ('cms_pages', 'cms_news', 'cms_gallery', 'cms_staff_profiles') then
    raise exception 'app_cms_transition: unknown table %', p_table_name;
  end if;

  execute format('select campus_id from %I where id = $1', p_table_name)
    into v_current_campus_id
    using p_id;

  if v_current_campus_id is null then
    raise exception '% % not found', p_table_name, p_id;
  end if;

  -- Defense in depth: the App Backend's requireRecord() already checks
  -- this in TypeScript (fixed proactively in ADR-015), but this function
  -- re-checks it independently rather than trusting the caller did so.
  if v_current_campus_id <> p_campus_id then
    raise exception '% % not found', p_table_name, p_id;
  end if;

  if p_actor_field is not null then
    v_set_clause := format('status = %L, %I = %L', p_to_status, p_actor_field, p_actor_id);
  else
    v_set_clause := format('status = %L', p_to_status);
  end if;

  for v_key in select jsonb_object_keys(p_extra_fields) loop
    v_set_clause := v_set_clause || format(', %I = %L', v_key, p_extra_fields ->> v_key);
  end loop;

  -- The trigger from migration 0017 still fires on this UPDATE and still
  -- independently validates the transition is structurally legal — this
  -- function does not duplicate that logic (Governance Rule 2), it relies
  -- on the trigger for "is this transition valid at all" and is
  -- responsible only for atomicity and actor-identity trustworthiness.
  execute format('update %I set %s where id = $1', p_table_name, v_set_clause)
    using p_id;

  insert into audit_logs (actor_id, campus_id, action, target_type, target_id, metadata_json)
  values (p_actor_id, p_campus_id, p_action, p_table_name, p_id::text, p_metadata);
end;
$$;

comment on function app_cms_transition is
  'Atomic status transition + audit log entry for any of the four CMS content types. p_actor_id is always the App Backend''s own resolved identity for the request — never client-suppliable independent of who is actually authenticated (closes Critical Finding 2, actor-field forgery). p_extra_fields carries type-specific side effects (e.g. cms_news.published_at). Callable only by service-role.';

revoke execute on function app_cms_transition(text, uuid, cms_content_status, text, uuid, text, uuid, jsonb, jsonb) from authenticated, anon;
