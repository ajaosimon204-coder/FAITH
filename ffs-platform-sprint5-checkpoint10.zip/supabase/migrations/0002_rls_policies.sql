-- =============================================================================
-- Migration 0002: Row-Level Security — Identity, Tenancy & RBAC
-- Sprint 1 — Faith Foundation Schools Digital Platform
--
-- Principle (Architecture Section 9 / E): deny-by-default. RLS is enabled on
-- every table the moment it exists; policies are added explicitly per
-- legitimate access pattern — never the reverse.
--
-- Two client identities interact with Postgres:
--   1. The frontend, using the Supabase anon key -> subject to RLS below.
--   2. The App Backend, using the service-role key -> BYPASSES RLS by
--      design (Architecture Section 4). Every service-role query in the
--      App Backend therefore applies its own explicit scoping in code
--      (see identity.repository.ts, audit.controller.ts) — RLS here
--      protects the frontend's direct-read path specifically.
-- =============================================================================

alter table organizations enable row level security;
alter table campuses enable row level security;
alter table users enable row level security;
alter table roles enable row level security;
alter table permissions enable row level security;
alter table role_permissions enable row level security;
alter table user_roles enable row level security;
alter table audit_logs enable row level security;

-- -----------------------------------------------------------------------------
-- Helper functions — the single source of truth every policy below relies on.
-- Defined once so a fix or refinement never has to be duplicated across
-- policies (mirrors Governance Rule 2: no duplicate business logic).
-- -----------------------------------------------------------------------------

create or replace function app_current_user_id()
returns uuid
language sql
stable
security definer
set search_path = public
as $$
  select id from users where auth_user_id = auth.uid();
$$;

create or replace function app_current_campus_id()
returns uuid
language sql
stable
security definer
set search_path = public
as $$
  select campus_id from users where auth_user_id = auth.uid();
$$;

create or replace function app_has_permission(required_permission text)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from user_roles ur
    join role_permissions rp on rp.role_id = ur.role_id
    join permissions p on p.id = rp.permission_id
    join users u on u.id = ur.user_id
    where u.auth_user_id = auth.uid()
      and p.key = required_permission
  );
$$;

comment on function app_current_user_id() is
  'Resolves the calling auth.uid() to our application users.id. SECURITY DEFINER so it can read `users` regardless of the caller''s own row-level access, without exposing more than a single id.';
comment on function app_has_permission(text) is
  'True if the calling user holds the given permission key via ANY assigned role. Used as the single permission-check primitive across all RLS policies below.';

-- -----------------------------------------------------------------------------
-- organizations — read-only reference data for any authenticated member of
-- that organization; writes restricted to organizations.manage.
-- -----------------------------------------------------------------------------

create policy organizations_select_own
  on organizations for select
  using (
    id in (select organization_id from campuses where id = app_current_campus_id())
  );

create policy organizations_update_privileged
  on organizations for update
  using (app_has_permission('organizations.manage'))
  with check (app_has_permission('organizations.manage'));

-- No INSERT/DELETE policy for any application role: organization creation
-- is a platform-level operation performed via migration/service-role only,
-- not an in-app action in V1 (single-tenant reality, Architecture Section M).

-- -----------------------------------------------------------------------------
-- campuses — visible only within the caller's own organization.
-- -----------------------------------------------------------------------------

create policy campuses_select_own_org
  on campuses for select
  using (
    organization_id in (
      select organization_id from campuses where id = app_current_campus_id()
    )
  );

create policy campuses_update_privileged
  on campuses for update
  using (app_has_permission('organizations.manage'))
  with check (app_has_permission('organizations.manage'));

-- -----------------------------------------------------------------------------
-- users — a user may read their own row; admin-tier (identity read) may
-- read any user within their own campus. No user may read another campus's
-- users, regardless of role (tenant isolation).
-- -----------------------------------------------------------------------------

create policy users_select_self
  on users for select
  using (auth_user_id = auth.uid());

create policy users_select_same_campus_privileged
  on users for select
  using (
    campus_id = app_current_campus_id()
    and app_has_permission('rbac.read')
  );

create policy users_update_self_limited
  on users for update
  using (auth_user_id = auth.uid())
  with check (auth_user_id = auth.uid());
  -- Note: column-level restriction (e.g. preventing a user from setting
  -- their own `status`) is enforced in the App Backend service layer, since
  -- Postgres RLS does not restrict individual column writes on its own.

-- No direct INSERT/DELETE policy: user provisioning happens via the App
-- Backend (service-role) reacting to a Supabase Auth signup event, never
-- as a direct frontend write.

-- -----------------------------------------------------------------------------
-- roles / permissions / role_permissions — readable by any authenticated
-- user (a client needs to know role/permission names to render UI sensibly),
-- writable only by rbac.manage.
-- -----------------------------------------------------------------------------

create policy roles_select_authenticated
  on roles for select
  using (auth.uid() is not null);

create policy roles_write_privileged
  on roles for all
  using (app_has_permission('rbac.manage'))
  with check (app_has_permission('rbac.manage'));

create policy permissions_select_authenticated
  on permissions for select
  using (auth.uid() is not null);

create policy permissions_write_privileged
  on permissions for all
  using (app_has_permission('rbac.manage'))
  with check (app_has_permission('rbac.manage'));

create policy role_permissions_select_authenticated
  on role_permissions for select
  using (auth.uid() is not null);

create policy role_permissions_write_privileged
  on role_permissions for all
  using (app_has_permission('rbac.manage'))
  with check (app_has_permission('rbac.manage'));

-- -----------------------------------------------------------------------------
-- user_roles — a user may read their OWN role assignments; rbac.read holders
-- may read assignments within their own campus; rbac.manage holders may
-- write, but ONLY within their own campus (tenant + IDOR guard combined).
-- -----------------------------------------------------------------------------

create policy user_roles_select_self
  on user_roles for select
  using (
    user_id = app_current_user_id()
  );

create policy user_roles_select_same_campus_privileged
  on user_roles for select
  using (
    campus_id = app_current_campus_id()
    and app_has_permission('rbac.read')
  );

create policy user_roles_insert_privileged_same_campus
  on user_roles for insert
  with check (
    campus_id = app_current_campus_id()
    and app_has_permission('rbac.manage')
  );

create policy user_roles_delete_privileged_same_campus
  on user_roles for delete
  using (
    campus_id = app_current_campus_id()
    and app_has_permission('rbac.manage')
  );

-- -----------------------------------------------------------------------------
-- audit_logs — insert is service-role only (no INSERT policy granted to the
-- authenticated frontend role at all); select restricted to audit.read
-- holders, scoped to their own campus.
-- -----------------------------------------------------------------------------

create policy audit_logs_select_privileged_same_campus
  on audit_logs for select
  using (
    campus_id = app_current_campus_id()
    and app_has_permission('audit.read')
  );

-- Deliberately no INSERT/UPDATE/DELETE policy for the `authenticated` role:
-- audit entries are written exclusively by the App Backend via the
-- service-role client (which bypasses RLS), and are never updatable or
-- deletable by anyone through the standard Postgres grant model.
revoke insert, update, delete on audit_logs from authenticated;
