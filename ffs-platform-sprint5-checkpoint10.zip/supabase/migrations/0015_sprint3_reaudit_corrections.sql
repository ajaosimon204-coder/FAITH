-- =============================================================================
-- Migration 0015: Sprint 3 Re-Audit Corrections
-- Faith Foundation Schools Digital Platform
--
-- Three real gaps found during the Sprint 3 re-audit (requested corrective
-- verification), all sharing one root cause: code paths using the
-- service-role connection (which bypasses RLS) did not independently
-- re-derive campus scoping, the same class of issue Sprint 2's corrective
-- migration (0009) closed for school_config. See ADR-014.
--
-- 1. class_subjects had no cross-campus consistency check at all — neither
--    a database trigger nor a service-layer check prevented linking a
--    class and subject from two different campuses.
-- 2. EnrollmentService.getCurrentEnrollment (assertCanViewStudent) granted
--    access to any actor holding academic.enrollments.read with NO check
--    that the student even belonged to the actor's own campus.
-- 3. EnrollmentService.getEnrollmentHistory had the identical gap.
--
-- Findings 2 and 3 were fixed in application code (enrollment.service.ts)
-- and are not database-fixable on their own, since the service-role
-- connection bypasses RLS by design — this migration adds the DB-level
-- trigger for finding 1 only, which IS expressible as a database
-- constraint independent of which connection is used.
-- =============================================================================

create or replace function trg_validate_class_subject_same_campus()
returns trigger
language plpgsql
as $$
declare
  v_class_campus_id uuid;
  v_subject_campus_id uuid;
begin
  select campus_id into v_class_campus_id from classes where id = new.class_id;
  select campus_id into v_subject_campus_id from subjects where id = new.subject_id;

  if v_class_campus_id is null then
    raise exception 'class_subjects: class % does not exist', new.class_id;
  end if;
  if v_subject_campus_id is null then
    raise exception 'class_subjects: subject % does not exist', new.subject_id;
  end if;
  if v_class_campus_id <> v_subject_campus_id then
    raise exception 'class_subjects: class (campus %) and subject (campus %) must belong to the same campus',
      v_class_campus_id, v_subject_campus_id;
  end if;

  return new;
end;
$$;

create trigger trg_class_subjects_validate_campus
  before insert or update on class_subjects
  for each row execute function trg_validate_class_subject_same_campus();

comment on function trg_validate_class_subject_same_campus() is
  'Database-level backstop for a cross-campus class_subjects link — independent of and in addition to the service-layer check added to ClassesService.linkSubjectToClass during the Sprint 3 re-audit (see ADR-014). Protects against this specific path even if a future code change to ClassesService accidentally removes its own check.';
