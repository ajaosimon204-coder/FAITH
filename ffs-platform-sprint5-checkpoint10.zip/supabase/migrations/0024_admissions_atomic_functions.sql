-- Migration 0024: Admissions Atomic Functions (Sprint 5)
-- Service-role-only. EXECUTE revoked from PUBLIC explicitly (Sprint 4 lesson, migration 0020).

create or replace function app_application_transition(
  p_id uuid,
  p_campus_id uuid,
  p_to_status application_status,
  p_actor_id uuid,
  p_action text,
  p_review_notes text default null,
  p_decision_reason text default null
)
returns applications
language plpgsql
security definer
set search_path = public
as $$
declare
  v_existing_campus_id uuid;
  v_old_status application_status;
  v_result applications;
begin
  select campus_id, status into v_existing_campus_id, v_old_status from applications where id = p_id;

  if v_existing_campus_id is null or v_existing_campus_id <> p_campus_id then
    raise exception 'application % not found', p_id;
  end if;

  update applications
  set status = p_to_status,
      reviewed_by = p_actor_id,
      review_notes = coalesce(p_review_notes, review_notes),
      decision_reason = coalesce(p_decision_reason, decision_reason)
  where id = p_id
  returning * into v_result;

  insert into audit_logs (actor_id, campus_id, action, target_type, target_id, metadata_json)
  values (p_actor_id, p_campus_id, p_action, 'application', p_id::text,
    jsonb_build_object('from', v_old_status, 'to', p_to_status));

  return v_result;
end;
$$;

create or replace function app_convert_application(
  p_application_id uuid,
  p_campus_id uuid,
  p_class_id uuid,
  p_actor_id uuid
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_app applications;
  v_student_id uuid;
  v_guardian_id uuid;
  v_admission_no text;
  v_seq int;
  v_class_campus_id uuid;
  v_class_definition_id uuid;
  v_class_session_id uuid;
begin
  select * into v_app from applications where id = p_application_id for update;

  if v_app.id is null or v_app.campus_id <> p_campus_id then
    raise exception 'application % not found', p_application_id;
  end if;
  if v_app.status <> 'approved' then
    raise exception 'application % must be approved before conversion (current status: %)', p_application_id, v_app.status;
  end if;

  select campus_id, class_definition_id, academic_session_id
    into v_class_campus_id, v_class_definition_id, v_class_session_id
  from classes where id = p_class_id;
  if v_class_campus_id is null or v_class_campus_id <> p_campus_id then
    raise exception 'class % does not belong to this campus', p_class_id;
  end if;
  -- The applicant applied for a specific level (class_definition). Placement
  -- must be into a class of that level, not any class in the campus.
  if v_class_definition_id <> v_app.class_definition_id then
    raise exception 'class % is not a class of the level applied for (application % applied for class_definition %)',
      p_class_id, p_application_id, v_app.class_definition_id;
  end if;

  -- Admission number: per-campus sequential. A transaction-scoped advisory lock keyed on
  -- the campus serializes concurrent conversions, so each one counts after the previous
  -- has committed and receives a distinct number (READ COMMITTED: the count below is a
  -- fresh snapshot taken after the lock is acquired). The unique index
  -- uq_students_admission_no_per_campus remains the backstop: a collision can only ever
  -- fail a transaction, never create a duplicate.
  perform pg_advisory_xact_lock(hashtext('admission_no'), hashtext(p_campus_id::text));
  select count(*) + 1 into v_seq from students where campus_id = p_campus_id and admission_no is not null;
  v_admission_no := 'FFS-' || to_char(now(), 'YYYY') || '-' || lpad(v_seq::text, 5, '0');

  -- Reuse an existing guardian in the same campus by email (siblings), else create.
  if v_app.guardian_email is not null then
    select id into v_guardian_id from guardians
    where campus_id = p_campus_id and lower(email) = lower(v_app.guardian_email)
    limit 1;
  end if;
  if v_guardian_id is null then
    insert into guardians (campus_id, first_name, last_name, phone, email)
    values (p_campus_id, v_app.guardian_first_name, v_app.guardian_last_name, v_app.guardian_phone, v_app.guardian_email)
    returning id into v_guardian_id;
  end if;

  insert into students (campus_id, display_name, lifecycle_status, admission_no, date_of_birth, gender)
  values (p_campus_id, v_app.applicant_first_name || ' ' || v_app.applicant_last_name, 'admitted',
          v_admission_no, v_app.applicant_date_of_birth, v_app.applicant_gender)
  returning id into v_student_id;

  insert into guardian_students (guardian_id, student_id, relationship)
  values (v_guardian_id, v_student_id, 'guardian');

  insert into enrollments (student_id, class_id, academic_session_id, campus_id, status)
  values (v_student_id, p_class_id, v_class_session_id, p_campus_id, 'active');

  update applications
  set status = 'converted', converted_student_id = v_student_id, reviewed_by = p_actor_id
  where id = p_application_id;

  insert into audit_logs (actor_id, campus_id, action, target_type, target_id, metadata_json)
  values (p_actor_id, p_campus_id, 'application.converted', 'application', p_application_id::text,
    jsonb_build_object('student_id', v_student_id, 'guardian_id', v_guardian_id, 'admission_no', v_admission_no));

  return jsonb_build_object('studentId', v_student_id, 'guardianId', v_guardian_id, 'admissionNo', v_admission_no);
end;
$$;

revoke execute on function app_application_transition(uuid, uuid, application_status, uuid, text, text, text) from public, authenticated, anon;
revoke execute on function app_convert_application(uuid, uuid, uuid, uuid) from public, authenticated, anon;
grant execute on function app_application_transition(uuid, uuid, application_status, uuid, text, text, text) to service_role;
grant execute on function app_convert_application(uuid, uuid, uuid, uuid) to service_role;
