-- =============================================================================
-- Migration 0011: RLS — Academic Core
-- Sprint 3 — Faith Foundation Schools Digital Platform
--
-- The central design point this migration exists to prove: a Teacher role
-- alone grants NOTHING. Every teacher-facing policy below joins through
-- teacher_assignments to check a real, specific relationship to the class
-- or subject being accessed — never app_has_role('teacher') or similar.
-- =============================================================================

alter table students enable row level security;
alter table staff enable row level security;
alter table academic_sessions enable row level security;
alter table terms enable row level security;
alter table class_definitions enable row level security;
alter table classes enable row level security;
alter table subjects enable row level security;
alter table class_subjects enable row level security;
alter table enrollments enable row level security;
alter table teacher_assignments enable row level security;

-- -----------------------------------------------------------------------------
-- Helper: does the caller have a teacher_assignments row connecting them to
-- this specific class (in the given academic session)? This is THE
-- relationship-based access primitive for the whole academic domain.
-- -----------------------------------------------------------------------------

create or replace function app_is_assigned_to_class(p_class_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from teacher_assignments ta
    join staff s on s.id = ta.staff_id
    where s.users_id = app_current_user_id()
      and ta.class_id = p_class_id
  );
$$;

comment on function app_is_assigned_to_class(uuid) is
  'THE relationship-based teacher-access primitive. A Teacher role by itself never grants class access — this function is what every teacher-facing policy below actually checks.';

create or replace function app_is_student_self(p_student_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from students where id = p_student_id and users_id = app_current_user_id()
  );
$$;

create or replace function app_is_guardian_of_student(p_student_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  -- guardian_students does not exist until Sprint 5 (Admissions). This
  -- function is defined now, always false, so downstream policies can
  -- reference it without a forward dependency — Sprint 5 will REPLACE this
  -- function body (not the policies that call it) once guardian_students
  -- exists. Documented explicitly rather than silently omitted.
  select false;
$$;

comment on function app_is_guardian_of_student(uuid) is
  'STUB — always false until Sprint 5 creates guardian_students. Policies already reference this function so Sprint 5 only needs to replace the function body, not rewrite RLS policies across the academic domain.';

-- -----------------------------------------------------------------------------
-- students / staff — minimal stub tables (Sprint 3 dependency, see
-- migration 0010's header comment). Read scoped to self, guardian (stub),
-- assigned teacher, or admin-tier; no direct write for authenticated at all
-- (Sprint 5 owns the admission/HR write workflow).
-- -----------------------------------------------------------------------------

create policy students_select_self
  on students for select
  using (users_id = app_current_user_id());

create policy students_select_guardian
  on students for select
  using (app_is_guardian_of_student(id));

create policy students_select_assigned_teacher
  on students for select
  using (
    exists (
      select 1 from student_current_enrollments sce
      where sce.student_id = students.id
        and app_is_assigned_to_class(sce.class_id)
    )
  );

create policy students_select_admin_same_campus
  on students for select
  using (campus_id = app_current_campus_id() and app_has_permission('academic.enrollments.read'));

revoke insert, update, delete on students from authenticated;

create policy staff_select_self
  on staff for select
  using (users_id = app_current_user_id());

create policy staff_select_same_campus_privileged
  on staff for select
  using (campus_id = app_current_campus_id() and app_has_permission('academic.classes.read'));

revoke insert, update, delete on staff from authenticated;

-- -----------------------------------------------------------------------------
-- academic_sessions / terms — read broadly within campus (every role needs
-- to know what session/term it is); write restricted to academic.sessions.write.
-- -----------------------------------------------------------------------------

create policy academic_sessions_select_same_campus
  on academic_sessions for select
  using (campus_id = app_current_campus_id());

create policy academic_sessions_write_privileged
  on academic_sessions for all
  using (campus_id = app_current_campus_id() and app_has_permission('academic.sessions.write'))
  with check (campus_id = app_current_campus_id() and app_has_permission('academic.sessions.write'));

create policy terms_select_same_campus
  on terms for select
  using (campus_id = app_current_campus_id());

create policy terms_write_privileged
  on terms for all
  using (campus_id = app_current_campus_id() and app_has_permission('academic.sessions.write'))
  with check (campus_id = app_current_campus_id() and app_has_permission('academic.sessions.write'));

-- -----------------------------------------------------------------------------
-- class_definitions / classes / subjects / class_subjects — read broadly
-- within campus; write restricted to academic.classes.write.
-- -----------------------------------------------------------------------------

create policy class_definitions_select_same_campus
  on class_definitions for select
  using (campus_id = app_current_campus_id());

create policy class_definitions_write_privileged
  on class_definitions for all
  using (campus_id = app_current_campus_id() and app_has_permission('academic.classes.write'))
  with check (campus_id = app_current_campus_id() and app_has_permission('academic.classes.write'));

create policy classes_select_same_campus
  on classes for select
  using (campus_id = app_current_campus_id());

create policy classes_write_privileged
  on classes for all
  using (campus_id = app_current_campus_id() and app_has_permission('academic.classes.write'))
  with check (campus_id = app_current_campus_id() and app_has_permission('academic.classes.write'));

create policy subjects_select_same_campus
  on subjects for select
  using (campus_id = app_current_campus_id());

create policy subjects_write_privileged
  on subjects for all
  using (campus_id = app_current_campus_id() and app_has_permission('academic.classes.write'))
  with check (campus_id = app_current_campus_id() and app_has_permission('academic.classes.write'));

create policy class_subjects_select_same_campus
  on class_subjects for select
  using (
    exists (select 1 from classes c where c.id = class_subjects.class_id and c.campus_id = app_current_campus_id())
  );

create policy class_subjects_write_privileged
  on class_subjects for all
  using (
    exists (
      select 1 from classes c
      where c.id = class_subjects.class_id
        and c.campus_id = app_current_campus_id()
        and app_has_permission('academic.classes.write')
    )
  )
  with check (
    exists (
      select 1 from classes c
      where c.id = class_subjects.class_id
        and c.campus_id = app_current_campus_id()
        and app_has_permission('academic.classes.write')
    )
  );

-- -----------------------------------------------------------------------------
-- enrollments — THE relationship-based access showcase.
--   - A student can read their own enrollment history.
--   - A guardian can read their linked student's (stub — always false pre-
--     Sprint 5, see app_is_guardian_of_student above).
--   - A teacher can read enrollments ONLY for classes they are actually
--     assigned to (via teacher_assignments) — never "any student", never
--     because they hold a Teacher role.
--   - Admin-tier (academic.enrollments.read/manage) can read/write within
--     their own campus.
--   - NO ONE gets an UPDATE policy on a non-active row (the trigger in
--     0010 is the hard backstop; RLS restricts WHO can even attempt a
--     write, the trigger restricts WHAT they can change once permitted).
-- -----------------------------------------------------------------------------

create policy enrollments_select_self
  on enrollments for select
  using (app_is_student_self(student_id));

create policy enrollments_select_guardian
  on enrollments for select
  using (app_is_guardian_of_student(student_id));

create policy enrollments_select_assigned_teacher
  on enrollments for select
  using (app_is_assigned_to_class(class_id));

create policy enrollments_select_admin_same_campus
  on enrollments for select
  using (campus_id = app_current_campus_id() and app_has_permission('academic.enrollments.read'));

create policy enrollments_insert_privileged
  on enrollments for insert
  with check (campus_id = app_current_campus_id() and app_has_permission('academic.enrollments.manage'));

create policy enrollments_update_privileged
  on enrollments for update
  using (campus_id = app_current_campus_id() and app_has_permission('academic.enrollments.manage'))
  with check (campus_id = app_current_campus_id() and app_has_permission('academic.enrollments.manage'));

-- No DELETE policy at all: enrollment history is never deleted, only
-- closed out (status change), matching "historical academic records
-- cannot be accidentally overwritten."
revoke delete on enrollments from authenticated;

-- -----------------------------------------------------------------------------
-- teacher_assignments — a teacher can read their OWN assignments; admin-tier
-- (academic.teacher_assignments.manage) can read/write within campus.
-- Explicitly NOT readable by "any teacher for any assignment" — that would
-- leak other teachers' schedules without a legitimate need.
-- -----------------------------------------------------------------------------

create policy teacher_assignments_select_self
  on teacher_assignments for select
  using (
    exists (select 1 from staff s where s.id = teacher_assignments.staff_id and s.users_id = app_current_user_id())
  );

create policy teacher_assignments_select_admin_same_campus
  on teacher_assignments for select
  using (campus_id = app_current_campus_id() and app_has_permission('academic.teacher_assignments.read'));

create policy teacher_assignments_write_privileged
  on teacher_assignments for insert
  with check (campus_id = app_current_campus_id() and app_has_permission('academic.teacher_assignments.manage'));

create policy teacher_assignments_delete_privileged
  on teacher_assignments for delete
  using (campus_id = app_current_campus_id() and app_has_permission('academic.teacher_assignments.manage'));

-- No UPDATE policy: a mis-assignment is corrected by deleting and
-- re-inserting (which still goes through the same permission + audit-log
-- call in TeacherAssignmentService), not by editing a row in place — keeps
-- the "who was assigned when" trail unambiguous without needing a separate
-- audit table for this Sprint.
