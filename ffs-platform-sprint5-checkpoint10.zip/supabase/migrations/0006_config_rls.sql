-- =============================================================================
-- Migration 0006: RLS — School Configuration System
-- Sprint 2 — Faith Foundation Schools Digital Platform
--
-- Same deny-by-default principle as Sprint 1. The interesting property here:
-- read/write permission is not hardcoded per policy — it is looked up from
-- config_definitions.read_permission_key / write_permission_key, so a
-- policy never needs to change when a new config category's permission
-- naming is decided; it reads whatever the migration-controlled definition
-- says to check.
-- =============================================================================

alter table config_definitions enable row level security;
alter table school_config enable row level security;
alter table config_audit_log enable row level security;

-- -----------------------------------------------------------------------------
-- config_definitions — readable by any authenticated user (the frontend
-- needs to know a key's schema/type to render a sane settings form), never
-- writable through the authenticated role at all (privilege-revoked, same
-- pattern as audit_logs in Sprint 1).
-- -----------------------------------------------------------------------------

create policy config_definitions_select_authenticated
  on config_definitions for select
  using (auth.uid() is not null);

revoke insert, update, delete on config_definitions from authenticated;

-- -----------------------------------------------------------------------------
-- school_config — read/write gated by the definition's own declared
-- permission key, AND always campus-scoped.
-- -----------------------------------------------------------------------------

create policy school_config_select_permitted
  on school_config for select
  using (
    campus_id = app_current_campus_id()
    and exists (
      select 1 from config_definitions cd
      where cd.id = school_config.config_definition_id
        and app_has_permission(cd.read_permission_key)
    )
  );

create policy school_config_insert_permitted
  on school_config for insert
  with check (
    campus_id = app_current_campus_id()
    and exists (
      select 1 from config_definitions cd
      where cd.id = school_config.config_definition_id
        and app_has_permission(cd.write_permission_key)
    )
  );

create policy school_config_update_permitted
  on school_config for update
  using (
    campus_id = app_current_campus_id()
    and exists (
      select 1 from config_definitions cd
      where cd.id = school_config.config_definition_id
        and app_has_permission(cd.write_permission_key)
    )
  )
  with check (
    campus_id = app_current_campus_id()
    and exists (
      select 1 from config_definitions cd
      where cd.id = school_config.config_definition_id
        and app_has_permission(cd.write_permission_key)
    )
  );

-- Deliberately no DELETE policy: a configuration value is corrected by
-- writing a new value (which the audit trail captures), not by deleting
-- history. Deletion would also orphan config_audit_log's meaning.
revoke delete on school_config from authenticated;

-- -----------------------------------------------------------------------------
-- config_audit_log — read gated the same way as school_config's read
-- permission (if you can see the current value, you can see its history);
-- no write grant for the authenticated role at all (service-role only,
-- written in the same transaction as the school_config write).
-- -----------------------------------------------------------------------------

create policy config_audit_log_select_permitted
  on config_audit_log for select
  using (
    campus_id = app_current_campus_id()
    and exists (
      select 1 from config_definitions cd
      where cd.id = config_audit_log.config_definition_id
        and app_has_permission(cd.read_permission_key)
    )
  );

revoke insert, update, delete on config_audit_log from authenticated;
