-- Migration 0029: student_current_enrollments — stop it bypassing row-level security (SECURITY FIX)
--
-- The view was created without `security_invoker`, so it executes with its OWNER's privileges. The owner
-- (postgres) owns `enrollments` and is exempt from its row-level security, so the view returned EVERY
-- campus's current enrollments to any caller holding SELECT on it — and default privileges had given
-- SELECT (and more) on it to `anon`, the unauthenticated role. Through the Data API that was
--   GET /rest/v1/student_current_enrollments      (no login at all)
-- returning other campuses' enrollment records while the table itself correctly returned nothing.
-- Found by the Sprint 5 hosted-readiness review; confirmed by test before this fix.
--
-- Fix, in two parts:
--   1. security_invoker = true: the view now runs with the CALLER's privileges and row-level security,
--      so it can never show more than `enrollments` itself would. (Requires PostgreSQL 15+, which every
--      current Supabase project runs.)
--   2. Privileges stated explicitly, least privilege: nobody needs to write through a view, and `anon`
--      has no business reading it. `authenticated` keeps SELECT because the RLS policy
--      students_select_assigned_teacher (0011) evaluates this view as the querying user; service_role
--      keeps SELECT for the App Backend.
--
-- Stating the grants here (rather than relying on default privileges) also makes the view work on
-- current Supabase projects, which no longer grant on new relations automatically (see 0028).

alter view student_current_enrollments set (security_invoker = true);

revoke all on student_current_enrollments from anon, authenticated, service_role;
grant select on student_current_enrollments to authenticated, service_role;
