-- =============================================================================
-- Migration 0009: Sprint 2 Corrections (found via live RLS testing)
-- Faith Foundation Schools Digital Platform
--
-- Two genuine bugs were found by actually executing the pgTAP suites
-- against a live Postgres instance (not caught by static review):
--
-- 1. `campuses_select_own_org` (migration 0002) selected from `campuses`
--    inside its own USING clause without SECURITY DEFINER protection,
--    causing infinite recursion — reproduced live: any query touching
--    `campuses`, including indirectly via a foreign-key check on
--    `user_roles.campus_id`, failed with
--    "infinite recursion detected in policy for relation campuses".
--
-- 2. `school_config_insert_permitted` / `school_config_update_permitted`
--    (migration 0006) allowed an authorized `authenticated`-role actor to
--    write directly to `school_config`, bypassing BOTH ConfigService's ajv
--    schema validation AND the audit trail (config_audit_log entries are
--    only produced by app_write_school_config()). Reproduced live: an
--    accountant wrote an out-of-schema value directly and it was
--    completely unaudited. This violated the "every configuration change
--    must be audited" requirement.
--
-- Per the "no destructive migrations unless necessary" rule: this is a
-- forward migration (drop + recreate the specific broken policies/function),
-- not an edit to 0002/0006 in place — the already-applied migrations
-- remain an accurate historical record of what shipped and when the fix
-- landed.
-- =============================================================================

-- -----------------------------------------------------------------------------
-- Fix 1: campuses/organizations recursion.
-- -----------------------------------------------------------------------------

create or replace function app_current_organization_id()
returns uuid
language sql
stable
security definer
set search_path = public
as $$
  select organization_id from campuses where id = app_current_campus_id();
$$;

comment on function app_current_organization_id() is
  'SECURITY DEFINER, mirroring app_current_campus_id() — resolves the caller''s organization without re-triggering campuses'' own RLS policy (the bug this migration fixes was exactly this recursion, in a policy that queried campuses without this protection).';

drop policy if exists campuses_select_own_org on campuses;
create policy campuses_select_own_org
  on campuses for select
  using (organization_id = app_current_organization_id());

drop policy if exists organizations_select_own on organizations;
create policy organizations_select_own
  on organizations for select
  using (id = app_current_organization_id());

-- -----------------------------------------------------------------------------
-- Fix 2: close the school_config direct-write bypass.
--
-- All writes now go exclusively through app_write_school_config() (called
-- only by the App Backend's service-role connection — EXECUTE already
-- revoked from authenticated/anon since migration 0008). The frontend
-- retains SELECT only, consistent with "the frontend's legitimate direct
-- reads" (Architecture Section 4) — writes were never supposed to be a
-- direct-client operation in the first place; migration 0006 mistakenly
-- added policies enabling it anyway.
-- -----------------------------------------------------------------------------

drop policy if exists school_config_insert_permitted on school_config;
drop policy if exists school_config_update_permitted on school_config;

-- Belt and suspenders (mirrors ADR-002's reasoning for audit_logs): revoke
-- the underlying table privilege too, so no future policy addition can
-- accidentally reopen this path without also touching the grant.
revoke insert, update on school_config from authenticated;
