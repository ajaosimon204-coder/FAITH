-- =============================================================================
-- Migration 0018: Seed CMS Permissions
-- Sprint 4 — Faith Foundation Schools Digital Platform
-- =============================================================================

insert into permissions (key, description) values
  ('content.create',   'Create and edit draft CMS content (pages, news, gallery, staff profiles).'),
  ('content.review',    'Move submitted CMS content from in_review to approved, or reject back to draft.'),
  ('content.publish',   'Approve and publish CMS content to the public website. Deliberately narrower than general admin access.'),
  ('content.archive',    'Archive previously-published CMS content.')
on conflict (key) do nothing;

insert into role_permissions (role_id, permission_id)
select r.id, p.id
from roles r
cross join permissions p
where (r.key, p.key) in (
  ('super_admin', 'content.create'), ('super_admin', 'content.review'),
  ('super_admin', 'content.publish'), ('super_admin', 'content.archive'),

  ('content_editor', 'content.create'),

  ('school_administrator', 'content.create'), ('school_administrator', 'content.review'),
  ('school_administrator', 'content.publish'), ('school_administrator', 'content.archive'),

  ('principal', 'content.review'), ('principal', 'content.publish')
)
on conflict do nothing;
