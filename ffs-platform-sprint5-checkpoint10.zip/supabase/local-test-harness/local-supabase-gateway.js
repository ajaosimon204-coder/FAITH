// Local stand-in for the parts of a Supabase project that sit in front of PostgREST — for self-testing the
// hosted smoke test and the API's token handling. NOT a Supabase implementation; it reproduces only what we rely on:
//   POST /auth/v1/token?grant_type=password   password login -> access token (ES256, like a current project)
//   GET  /auth/v1/.well-known/jwks.json        the public signing key
//   /rest/v1/*                                 the gateway in front of PostgREST: requires `apikey`; verifies a
//                                              user's ES256 token itself and hands PostgREST a token it trusts
//                                              (PostgREST here is configured with a shared secret)
// Usage: node local-supabase-gateway.js   (configured by env: GW_PORT, GW_POSTGREST_PORT, GW_PUBLIC_URL,
//        GW_JWT_SECRET, GW_USERS='[{"email","password","sub"}]', GW_ALG=ES256|HS256)
const http = require('http');
const path = require('path');
const { createRequire } = require('module');
const requireFromApi = createRequire(path.resolve(__dirname, '../../apps/api/package.json'));
const { SignJWT, jwtVerify, generateKeyPair, exportJWK, createLocalJWKSet } = requireFromApi('jose');

const port = Number(process.env.GW_PORT);
const pgrstPort = Number(process.env.GW_POSTGREST_PORT);
const publicUrl = process.env.GW_PUBLIC_URL;
const sharedSecret = new TextEncoder().encode(process.env.GW_JWT_SECRET);
const users = JSON.parse(process.env.GW_USERS || '[]');
const alg = process.env.GW_ALG || 'ES256';

(async () => {
  let privateKey, publicJwk, verifyKeys;
  if (alg === 'ES256') {
    const pair = await generateKeyPair('ES256', { extractable: true });
    privateKey = pair.privateKey;
    publicJwk = { ...(await exportJWK(pair.publicKey)), kid: 'local-key-1', alg: 'ES256', use: 'sig' };
    verifyKeys = createLocalJWKSet({ keys: [publicJwk] });
  }

  const json = (res, status, body) => {
    res.writeHead(status, { 'content-type': 'application/json' });
    res.end(JSON.stringify(body));
  };
  const readBody = (req) => new Promise((resolve) => { let d = ''; req.on('data', (c) => (d += c)); req.on('end', () => resolve(d)); });

  async function mintAccessToken(user) {
    const claims = { email: user.email, role: 'authenticated' };
    const builder = new SignJWT(claims).setSubject(user.sub).setIssuer(`${publicUrl}/auth/v1`).setAudience('authenticated').setIssuedAt().setExpirationTime('1h');
    return alg === 'ES256'
      ? builder.setProtectedHeader({ alg: 'ES256', kid: 'local-key-1' }).sign(privateKey)
      : builder.setProtectedHeader({ alg: 'HS256' }).sign(sharedSecret);
  }

  http.createServer(async (req, res) => {
    const url = new URL(req.url, publicUrl);

    if (url.pathname === '/auth/v1/token' && req.method === 'POST') {
      let body = {};
      try { body = JSON.parse(await readBody(req)); } catch { /* fallthrough */ }
      const user = users.find((u) => u.email === body.email && u.password === body.password);
      if (!user) return json(res, 400, { error: 'invalid_grant', error_description: 'Invalid login credentials' });
      return json(res, 200, { access_token: await mintAccessToken(user), token_type: 'bearer', expires_in: 3600, user: { id: user.sub, email: user.email } });
    }
    if (url.pathname === '/auth/v1/.well-known/jwks.json') {
      return json(res, 200, { keys: publicJwk ? [publicJwk] : [] });
    }

    if (url.pathname.startsWith('/rest/v1')) {
      const apikey = req.headers['apikey'];
      if (!apikey) return json(res, 401, { message: 'No API key found in request', hint: 'No `apikey` request header or url param was found.' });
      const headers = { ...req.headers };
      let bearer = (headers['authorization'] || '').replace(/^Bearer\s+/i, '');
      if (!bearer || bearer === apikey) bearer = apikey;            // the key itself is not forwarded as a user token
      try {
        const header = JSON.parse(Buffer.from(bearer.split('.')[0], 'base64url').toString());
        if (header.alg === 'ES256') {                                 // a user session token: the gateway verifies it...
          const { payload } = await jwtVerify(bearer, verifyKeys, { algorithms: ['ES256'], audience: 'authenticated' });
          bearer = await new SignJWT({ role: payload.role, email: payload.email }) // ...and gives PostgREST one it trusts
            .setProtectedHeader({ alg: 'HS256' }).setSubject(payload.sub).setAudience('authenticated').setExpirationTime('5m').sign(sharedSecret);
        }
      } catch { return json(res, 401, { message: 'Invalid JWT' }); }
      headers['authorization'] = `Bearer ${bearer}`;
      const upstream = http.request({ host: '127.0.0.1', port: pgrstPort, method: req.method, path: url.pathname.replace(/^\/rest\/v1/, '') + url.search, headers }, (up) => {
        res.writeHead(up.statusCode, up.headers); up.pipe(res);
      });
      upstream.on('error', (e) => json(res, 502, { message: String(e) }));
      return req.pipe(upstream);
    }
    json(res, 404, { message: 'not found' });
  }).listen(port, '127.0.0.1');
})();
