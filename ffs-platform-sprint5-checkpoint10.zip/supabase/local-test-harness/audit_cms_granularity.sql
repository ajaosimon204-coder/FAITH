begin;

insert into organizations (id, name) values ('a1111111-0000-0000-0000-000000000001', '[AUDIT] Org A');
insert into campuses (id, organization_id, name) values ('a1111111-0000-0000-0000-000000000002', 'a1111111-0000-0000-0000-000000000001', '[AUDIT] Campus A');

insert into auth.users (id, email) values
  ('a1111111-0000-0000-0000-000000000003', 'creator-only@test.invalid'),
  ('a1111111-0000-0000-0000-000000000004', 'super@test.invalid');

insert into users (id, auth_user_id, campus_id, email, status) values
  ('a1111111-0000-0000-0000-000000000005', 'a1111111-0000-0000-0000-000000000003', 'a1111111-0000-0000-0000-000000000002', 'creator-only@test.invalid', 'active'),
  ('a1111111-0000-0000-0000-000000000006', 'a1111111-0000-0000-0000-000000000004', 'a1111111-0000-0000-0000-000000000002', 'super@test.invalid', 'active');

insert into user_roles (user_id, role_id, campus_id, assigned_by)
select 'a1111111-0000-0000-0000-000000000005', id, 'a1111111-0000-0000-0000-000000000002', 'a1111111-0000-0000-0000-000000000005'
from roles where key = 'content_editor';  -- holds ONLY content.create

insert into user_roles (user_id, role_id, campus_id, assigned_by)
select 'a1111111-0000-0000-0000-000000000006', id, 'a1111111-0000-0000-0000-000000000002', 'a1111111-0000-0000-0000-000000000006'
from roles where key = 'super_admin';

-- Set up a page already at 'approved' status (as if content.review/publish
-- holders had legitimately advanced it that far) — done as superuser so
-- setup itself isn't gated by anything under test.
insert into cms_pages (id, campus_id, slug, title, status, created_by, reviewed_by, approved_by)
values ('a1111111-0000-0000-0000-000000000007', 'a1111111-0000-0000-0000-000000000002', 'audit-page', '[AUDIT] Page', 'draft', 'a1111111-0000-0000-0000-000000000005', null, null);
update cms_pages set status = 'in_review' where id = 'a1111111-0000-0000-0000-000000000007';
update cms_pages set status = 'approved', reviewed_by = 'a1111111-0000-0000-0000-000000000006' where id = 'a1111111-0000-0000-0000-000000000007';

set local role authenticated;
set local request.jwt.claim.sub = 'a1111111-0000-0000-0000-000000000003';

-- TEST: this actor holds ONLY content.create (the content_editor role).
-- Per the App Backend's TypeScript logic, approved->published requires
-- content.publish, which this actor does NOT have. Does RLS independently
-- enforce that, for a DIRECT client write bypassing the App Backend?
select 'actor permissions check:' as label, app_has_permission('content.create') as has_create, app_has_permission('content.publish') as has_publish;

update cms_pages
set status = 'published', published_by = 'a1111111-0000-0000-0000-000000000005'
where id = 'a1111111-0000-0000-0000-000000000007';

select 'result after direct-client publish attempt by content.create-only actor:' as label, status, published_by
from cms_pages where id = 'a1111111-0000-0000-0000-000000000007';

rollback;
