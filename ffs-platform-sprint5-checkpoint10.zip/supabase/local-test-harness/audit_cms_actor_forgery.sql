begin;

insert into organizations (id, name) values ('a2222222-0000-0000-0000-000000000001', '[AUDIT] Org A2');
insert into campuses (id, organization_id, name) values ('a2222222-0000-0000-0000-000000000002', 'a2222222-0000-0000-0000-000000000001', '[AUDIT] Campus A2');

insert into auth.users (id, email) values
  ('a2222222-0000-0000-0000-000000000003', 'creator2@test.invalid'),
  ('a2222222-0000-0000-0000-000000000004', 'innocent-victim@test.invalid');

insert into users (id, auth_user_id, campus_id, email, status) values
  ('a2222222-0000-0000-0000-000000000005', 'a2222222-0000-0000-0000-000000000003', 'a2222222-0000-0000-0000-000000000002', 'creator2@test.invalid', 'active'),
  ('a2222222-0000-0000-0000-000000000006', 'a2222222-0000-0000-0000-000000000004', 'a2222222-0000-0000-0000-000000000002', 'innocent-victim@test.invalid', 'active');

insert into user_roles (user_id, role_id, campus_id, assigned_by)
select 'a2222222-0000-0000-0000-000000000005', id, 'a2222222-0000-0000-0000-000000000002', 'a2222222-0000-0000-0000-000000000005'
from roles where key = 'content_editor';

insert into cms_pages (id, campus_id, slug, title, status, created_by)
values ('a2222222-0000-0000-0000-000000000007', 'a2222222-0000-0000-0000-000000000002', 'audit-page2', '[AUDIT] Page2', 'draft', 'a2222222-0000-0000-0000-000000000005');
update cms_pages set status = 'in_review' where id = 'a2222222-0000-0000-0000-000000000007';
update cms_pages set status = 'approved' where id = 'a2222222-0000-0000-0000-000000000007';

set local role authenticated;
set local request.jwt.claim.sub = 'a2222222-0000-0000-0000-000000000003';

-- Can the actor forge published_by to point at someone ELSE entirely (the
-- "innocent victim"), making it look like that other person published it?
update cms_pages
set status = 'published', published_by = 'a2222222-0000-0000-0000-000000000006'
where id = 'a2222222-0000-0000-0000-000000000007';

select 'forged published_by result:' as label, status, published_by,
  (published_by = 'a2222222-0000-0000-0000-000000000006') as matches_forged_victim_id,
  (published_by = 'a2222222-0000-0000-0000-000000000005') as matches_real_actor_id
from cms_pages where id = 'a2222222-0000-0000-0000-000000000007';

rollback;
