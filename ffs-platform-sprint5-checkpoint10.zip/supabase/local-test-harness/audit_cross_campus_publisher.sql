begin;

insert into organizations (id, name) values
  ('a4444444-0000-0000-0000-000000000001', '[AUDIT] Org C4A'),
  ('a4444444-0000-0000-0000-000000000002', '[AUDIT] Org C4B');
insert into campuses (id, organization_id, name) values
  ('a4444444-0000-0000-0000-000000000003', 'a4444444-0000-0000-0000-000000000001', '[AUDIT] Campus 4A'),
  ('a4444444-0000-0000-0000-000000000004', 'a4444444-0000-0000-0000-000000000002', '[AUDIT] Campus 4B');

insert into auth.users (id, email) values
  ('a4444444-0000-0000-0000-000000000005', 'admin-4a@test.invalid'),
  ('a4444444-0000-0000-0000-000000000006', 'publisher-4b@test.invalid');

insert into users (id, auth_user_id, campus_id, email, status) values
  ('a4444444-0000-0000-0000-000000000007', 'a4444444-0000-0000-0000-000000000005', 'a4444444-0000-0000-0000-000000000003', 'admin-4a@test.invalid', 'active'),
  ('a4444444-0000-0000-0000-000000000008', 'a4444444-0000-0000-0000-000000000006', 'a4444444-0000-0000-0000-000000000004', 'publisher-4b@test.invalid', 'active');

insert into user_roles (user_id, role_id, campus_id, assigned_by)
select 'a4444444-0000-0000-0000-000000000007', id, 'a4444444-0000-0000-0000-000000000003', 'a4444444-0000-0000-0000-000000000007'
from roles where key = 'super_admin';

-- Campus 4B actor holding content.publish AND content.review (school_administrator)
insert into user_roles (user_id, role_id, campus_id, assigned_by)
select 'a4444444-0000-0000-0000-000000000008', id, 'a4444444-0000-0000-0000-000000000004', 'a4444444-0000-0000-0000-000000000008'
from roles where key = 'school_administrator';

-- Campus 4A content, approved and ready to publish.
insert into cms_pages (id, campus_id, slug, title, status, created_by)
values ('a4444444-0000-0000-0000-000000000010', 'a4444444-0000-0000-0000-000000000003', 'cross-campus-target', 'Target', 'draft', 'a4444444-0000-0000-0000-000000000007');
update cms_pages set status = 'in_review' where id = 'a4444444-0000-0000-0000-000000000010';
update cms_pages set status = 'approved' where id = 'a4444444-0000-0000-0000-000000000010';

set local role authenticated;
set local request.jwt.claim.sub = 'a4444444-0000-0000-0000-000000000006';

-- A fully-permissioned (content.publish) actor from Campus 4B attempting
-- to publish Campus 4A's content by guessing/knowing its id.
update cms_pages set status = 'published', published_by = 'a4444444-0000-0000-0000-000000000008'
where id = 'a4444444-0000-0000-0000-000000000010';

select 'cross-campus publisher attempt result:' as label, status from cms_pages where id = 'a4444444-0000-0000-0000-000000000010';

-- Can they even SEE it to know it exists (enumerate via select)?
select 'cross-campus visibility of approved content:' as label, count(*) from cms_pages where id = 'a4444444-0000-0000-0000-000000000010';

rollback;
