#!/usr/bin/env bash
# Proves the migrations produce the SAME privilege state whether the project hands out table grants
# automatically (classic Supabase) or not (current Supabase, --modern). Builds both databases, dumps the
# effective privileges of every API role on every table, sequence and function in `public`, and diffs
# them. Any difference means a migration still depends on a platform default. Exits non-zero on a diff.
set -euo pipefail
cd "$(dirname "$0")/.."

./local-test-harness/run_all.sh --no-tests >/dev/null
./local-test-harness/run_all.sh --modern --no-tests >/dev/null

dump() { # $1 = database
  su postgres -c "psql -X -At -d $1" <<'SQL'
select 'table    ' || c.relname || ' ' || r.rolname || ' ' ||
  concat_ws(',',
    case when has_table_privilege(r.rolname, c.oid, 'select')     then 'select' end,
    case when has_table_privilege(r.rolname, c.oid, 'insert')     then 'insert' end,
    case when has_table_privilege(r.rolname, c.oid, 'update')     then 'update' end,
    case when has_table_privilege(r.rolname, c.oid, 'delete')     then 'delete' end,
    case when has_table_privilege(r.rolname, c.oid, 'truncate')   then 'truncate' end,
    case when has_table_privilege(r.rolname, c.oid, 'references') then 'references' end,
    case when has_table_privilege(r.rolname, c.oid, 'trigger')    then 'trigger' end)
from pg_class c join pg_namespace n on n.oid = c.relnamespace,
     (values ('anon'),('authenticated'),('service_role')) r(rolname)
where n.nspname = 'public' and c.relkind in ('r','p')
union all
select 'view     ' || c.relname || ' ' || r.rolname || ' ' ||
  concat_ws(',',
    case when has_table_privilege(r.rolname, c.oid, 'select')   then 'select' end,
    case when has_table_privilege(r.rolname, c.oid, 'insert')   then 'insert' end,
    case when has_table_privilege(r.rolname, c.oid, 'update')   then 'update' end,
    case when has_table_privilege(r.rolname, c.oid, 'delete')   then 'delete' end,
    case when has_table_privilege(r.rolname, c.oid, 'truncate') then 'truncate' end)
from pg_class c join pg_namespace n on n.oid = c.relnamespace,
     (values ('anon'),('authenticated'),('service_role')) r(rolname)
where n.nspname = 'public' and c.relkind in ('v','m')
  and not exists (select 1 from pg_depend d where d.objid = c.oid and d.deptype = 'e')  -- skip extension-owned (pgTAP)
union all
select 'sequence ' || c.relname || ' ' || r.rolname || ' ' ||
  concat_ws(',',
    case when has_sequence_privilege(r.rolname, c.oid, 'usage')  then 'usage' end,
    case when has_sequence_privilege(r.rolname, c.oid, 'select') then 'select' end,
    case when has_sequence_privilege(r.rolname, c.oid, 'update') then 'update' end)
from pg_class c join pg_namespace n on n.oid = c.relnamespace,
     (values ('anon'),('authenticated'),('service_role')) r(rolname)
where n.nspname = 'public' and c.relkind = 'S'
union all
select 'function ' || p.proname || '(' || pg_get_function_identity_arguments(p.oid) || ') ' || r.rolname || ' ' ||
  case when has_function_privilege(r.rolname, p.oid, 'execute') then 'execute' else '-' end
from pg_proc p join pg_namespace n on n.oid = p.pronamespace,
     (values ('anon'),('authenticated'),('service_role'),('public')) r(rolname)
where n.nspname = 'public' and p.prokind = 'f'
order by 1;
SQL
}

dump ffs_verify > /tmp/privs.classic
dump ffs_modern > /tmp/privs.modern

# Only truncate/references/trigger for service_role legitimately differ (classic default-grants them; we
# deliberately do not re-grant them — the API never needs them). Normalise those out; everything else must match.
norm() { sed -E 's/^(table +[a-z_]+ service_role) .*/\1 */' "$1"; }
if diff <(norm /tmp/privs.classic) <(norm /tmp/privs.modern) > /tmp/privs.diff; then
  echo "IDENTICAL: $(wc -l < /tmp/privs.classic) privilege facts match between classic and modern projects"
else
  echo "DIFFERENT: migrations depend on a platform default grant:"; cat /tmp/privs.diff; exit 1
fi
