#!/usr/bin/env bash
# Self-test of the hosted smoke test, run against a LOCAL stand-in for a current Supabase project:
# PostgreSQL (all migrations) + PostgREST + a gateway that issues real ES256 tokens and publishes a JWKS +
# the real compiled API (configured the way a current project is: NO legacy JWT secret).
#   run_smoke_selftest.sh            classic-style project
#   run_smoke_selftest.sh --modern   current-style project (no automatic table grants)
# Proves the smoke script itself works — and, via negative runs, that it FAILS when the deployment is wrong.
set -euo pipefail
cd "$(dirname "$0")/.."
HARNESS="$PWD/local-test-harness"; ROOT="$(cd .. && pwd)"
MODERN_FLAG=""; DB=ffs_verify
[[ "${1:-}" == "--modern" ]] && { MODERN_FLAG="--modern"; DB=ffs_modern; }

JWT_SECRET="integration-jwt-secret-0123456789abcdef"
PGRST_PORT=3100; GW_PORT=3101; API_PORT=3200
GW_URL="http://127.0.0.1:$GW_PORT"; API_URL="http://127.0.0.1:$API_PORT"
PIDS=(); cleanup() { for p in "${PIDS[@]:-}"; do [[ -n "$p" ]] && kill "$p" 2>/dev/null || true; done; }; trap cleanup EXIT

mint() { # mint an HS256 JWT with the given role claim (the local "publishable"/"service" keys)
  (cd "$ROOT/apps/api" && node -e "const j=require('jsonwebtoken');console.log(j.sign({role:process.argv[1]},'$JWT_SECRET',{algorithm:'HS256',expiresIn:'2h'}))" "$1")
}
ANON_KEY="$(mint anon)"; SERVICE_KEY="$(mint service_role)"

PGRST_BIN="$("$HARNESS/install_postgrest.sh")"
"$HARNESS/run_all.sh" $MODERN_FLAG --no-tests >/dev/null
su postgres -c "psql -X -q -v ON_ERROR_STOP=1 -d $DB -f $HARNESS/integration_fixtures.sql"
# Data in BOTH campuses, so the smoke test's isolation checks observe something real (an empty result proves nothing).
su postgres -c "psql -X -q -v ON_ERROR_STOP=1 -d $DB" <<'SQL'
insert into applications (campus_id, applicant_first_name, applicant_last_name, applicant_date_of_birth, class_definition_id, guardian_first_name, guardian_last_name) values
  ('c2000000-0000-0000-0000-000000000001', 'SeedA', 'Pupil', '2014-01-01', 'c6000000-0000-0000-0000-000000000001', 'G', 'A'),
  ('c2000000-0000-0000-0000-000000000002', 'SeedB', 'Pupil', '2014-01-01', 'c6000000-0000-0000-0000-000000000003', 'G', 'B');
insert into students (id, campus_id, display_name) values
  ('c9000000-0000-0000-0000-0000000000a1', 'c2000000-0000-0000-0000-000000000001', 'Seed Student A'),
  ('c9000000-0000-0000-0000-0000000000b1', 'c2000000-0000-0000-0000-000000000002', 'Seed Student B');
insert into enrollments (student_id, class_id, academic_session_id, campus_id, status) values
  ('c9000000-0000-0000-0000-0000000000a1', 'c7000000-0000-0000-0000-000000000001', 'c5000000-0000-0000-0000-000000000001', 'c2000000-0000-0000-0000-000000000001', 'active'),
  ('c9000000-0000-0000-0000-0000000000b1', 'c7000000-0000-0000-0000-000000000003', 'c5000000-0000-0000-0000-000000000002', 'c2000000-0000-0000-0000-000000000002', 'active');
SQL

PGRST_DB_URI="postgres://authenticator:integration-authenticator-pw@127.0.0.1:5432/$DB" PGRST_DB_SCHEMAS=public \
PGRST_DB_ANON_ROLE=anon PGRST_JWT_SECRET="$JWT_SECRET" PGRST_SERVER_HOST=127.0.0.1 PGRST_SERVER_PORT=$PGRST_PORT \
  "$PGRST_BIN" > /tmp/postgrest.log 2>&1 & PIDS+=($!)
GW_PORT=$GW_PORT GW_POSTGREST_PORT=$PGRST_PORT GW_PUBLIC_URL=$GW_URL GW_JWT_SECRET=$JWT_SECRET GW_ALG=ES256 \
GW_USERS='[{"email":"admin-a@int.test","password":"smoke-pass-1","sub":"c3000000-0000-0000-0000-000000000001"},{"email":"accountant-a@int.test","password":"smoke-pass-2","sub":"c3000000-0000-0000-0000-000000000003"}]' \
  node "$HARNESS/local-supabase-gateway.js" > /tmp/gateway.log 2>&1 & PIDS+=($!)

for _ in $(seq 1 30); do curl -fs -o /dev/null -H "apikey: $ANON_KEY" "$GW_URL/rest/v1/" && break; sleep 0.5; done

(cd "$ROOT/apps/api" && rm -rf dist && npm run --silent build)
start_api() { # $1.. = extra env assignments
  env PORT=$API_PORT SUPABASE_URL=$GW_URL SUPABASE_SERVICE_ROLE_KEY="$SERVICE_KEY" "$@" node "$ROOT/apps/api/dist/main.js" > /tmp/api.log 2>&1 &
  API_PID=$!; PIDS+=($API_PID)
  for _ in $(seq 1 30); do curl -s -o /dev/null "$API_URL/api/v1/admissions/applications" && return 0; sleep 0.5; done
  echo "ERROR: API did not start"; tail -20 /tmp/api.log; return 1
}
smoke() {
  SMOKE_API_URL=$API_URL SMOKE_SUPABASE_URL=$GW_URL SMOKE_PUBLISHABLE_KEY=$ANON_KEY \
  SMOKE_STAFF_EMAIL=admin-a@int.test SMOKE_STAFF_PASSWORD=smoke-pass-1 \
  SMOKE_LIMITED_EMAIL=accountant-a@int.test SMOKE_LIMITED_PASSWORD=smoke-pass-2 \
  SMOKE_CAMPUS_ID=c2000000-0000-0000-0000-000000000001 SMOKE_CLASS_DEFINITION_ID=c6000000-0000-0000-0000-000000000001 \
  node "$ROOT/scripts/smoke-test.mjs" "$@"
}

echo "################ A. correctly configured current-style project: the smoke test must PASS"
start_api            # note: no SUPABASE_JWT_SECRET — asymmetric tokens verified through the JWKS endpoint
smoke --with-writes
kill $API_PID; wait $API_PID 2>/dev/null || true

echo; echo "################ B. API with the WRONG issuer: the smoke test must FAIL and say why"
start_api SUPABASE_JWT_ISSUER=https://wrong.example.test/auth/v1
if smoke > /tmp/smoke-b.out 2>&1; then echo "UNEXPECTED: smoke test passed against a misconfigured API"; cat /tmp/smoke-b.out; exit 1; fi
grep -E "✗|!  |SMOKE TEST FAILED" /tmp/smoke-b.out | head -6
kill $API_PID; wait $API_PID 2>/dev/null || true

echo; echo "################ C. JWKS unreachable from the API: the smoke test must FAIL with a 503 diagnosis"
start_api SUPABASE_JWKS_URL=http://127.0.0.1:1/jwks.json
if smoke > /tmp/smoke-c.out 2>&1; then echo "UNEXPECTED: smoke test passed with the JWKS unreachable"; exit 1; fi
grep -E "✗|503|JWKS" /tmp/smoke-c.out | head -4
echo; echo "SELF-TEST OK: passes when right, fails (with a diagnosis) when wrong"
