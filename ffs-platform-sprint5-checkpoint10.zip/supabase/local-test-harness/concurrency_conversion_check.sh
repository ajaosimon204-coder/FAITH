#!/usr/bin/env bash
# Concurrency check for app_convert_application() — the one thing pgTAP (single session) cannot test.
# Two sessions convert two different approved applications in the SAME campus at the same moment.
# Session 1 holds its transaction open (pg_sleep) so session 2 genuinely overlaps it.
# PASS = both succeed with two DISTINCT admission numbers (the per-campus advisory lock serializes them).
# Resets the verification database. Requires root + local Postgres (see run_all.sh).
set -euo pipefail
cd "$(dirname "$0")/.."
DB=ffs_verify
./local-test-harness/run_all.sh --no-tests >/dev/null
q() { su postgres -c "psql -X -q -v ON_ERROR_STOP=1 -d $DB $*"; }

su postgres -c "psql -X -q -v ON_ERROR_STOP=1 -d $DB" <<'SQL'
insert into organizations (id, name) values ('c0000000-0000-0000-0000-000000000001', 'Concurrency Org');
insert into campuses (id, organization_id, name) values ('c0000000-0000-0000-0000-000000000002', 'c0000000-0000-0000-0000-000000000001', 'Concurrency Campus');
insert into auth.users (id, email) values ('c0000000-0000-0000-0000-000000000003', 'conc@test.invalid');
insert into users (id, auth_user_id, campus_id, email, status) values ('c0000000-0000-0000-0000-000000000004', 'c0000000-0000-0000-0000-000000000003', 'c0000000-0000-0000-0000-000000000002', 'conc@test.invalid', 'active');
insert into academic_sessions (id, campus_id, name, start_date, end_date, is_current) values ('c0000000-0000-0000-0000-000000000005', 'c0000000-0000-0000-0000-000000000002', 'S', '2025-09-01', '2026-07-31', true);
insert into class_definitions (id, campus_id, name, level) values ('c0000000-0000-0000-0000-000000000006', 'c0000000-0000-0000-0000-000000000002', 'JSS 1', 'junior_secondary');
insert into classes (id, class_definition_id, academic_session_id, campus_id, name, section) values ('c0000000-0000-0000-0000-000000000007', 'c0000000-0000-0000-0000-000000000006', 'c0000000-0000-0000-0000-000000000005', 'c0000000-0000-0000-0000-000000000002', 'JSS 1A', 'A');
insert into applications (id, campus_id, applicant_first_name, applicant_last_name, applicant_date_of_birth, class_definition_id, guardian_first_name, guardian_last_name, guardian_email) values
  ('c0000000-0000-0000-0000-0000000000a1', 'c0000000-0000-0000-0000-000000000002', 'Conc', 'One', '2014-01-01', 'c0000000-0000-0000-0000-000000000006', 'G', 'One', 'one@test.invalid'),
  ('c0000000-0000-0000-0000-0000000000a2', 'c0000000-0000-0000-0000-000000000002', 'Conc', 'Two', '2014-02-02', 'c0000000-0000-0000-0000-000000000006', 'G', 'Two', 'two@test.invalid');
update applications set status = 'under_review';
update applications set status = 'approved';
SQL

CALL="app_convert_application('%s','c0000000-0000-0000-0000-000000000002','c0000000-0000-0000-0000-000000000007','c0000000-0000-0000-0000-000000000004')"
S1=$(printf "$CALL" c0000000-0000-0000-0000-0000000000a1)
S2=$(printf "$CALL" c0000000-0000-0000-0000-0000000000a2)

( su postgres -c "psql -X -At -d $DB" > /tmp/conc1.out 2>&1 <<SQL
begin;
select ($S1)->>'admissionNo';
select pg_sleep(3);
commit;
SQL
) &
sleep 1
( su postgres -c "psql -X -At -d $DB -c \"select ($S2)->>'admissionNo'\"" > /tmp/conc2.out 2>&1 ) &
wait

n1=$(grep -E '^FFS-' /tmp/conc1.out || true); n2=$(grep -E '^FFS-' /tmp/conc2.out || true)
echo "session 1: ${n1:-FAILED ($(grep -m1 -E 'ERROR' /tmp/conc1.out))}"
echo "session 2: ${n2:-FAILED ($(grep -m1 -E 'ERROR' /tmp/conc2.out))}"
if [[ -n "$n1" && -n "$n2" && "$n1" != "$n2" ]]; then echo "PASS: two concurrent conversions, two distinct admission numbers"; else echo "FAIL"; exit 1; fi
