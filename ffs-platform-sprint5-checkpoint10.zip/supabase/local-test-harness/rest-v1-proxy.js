// supabase-js addresses PostgREST at <project-url>/rest/v1/...; a bare PostgREST serves at the root.
// On real Supabase the gateway strips that prefix. This 20-line shim does the same, so the integration
// tests can use the REAL, unmodified supabase-js client (and so exercise the production request shape).
// Usage: node rest-v1-proxy.js <listen-port> <postgrest-port>
const http = require('http');
const [listenPort, targetPort] = process.argv.slice(2).map(Number);

http
  .createServer((req, res) => {
    const path = req.url.replace(/^\/rest\/v1/, '') || '/';
    const upstream = http.request(
      { host: '127.0.0.1', port: targetPort, method: req.method, path, headers: req.headers },
      (up) => {
        res.writeHead(up.statusCode, up.headers);
        up.pipe(res);
      },
    );
    upstream.on('error', (e) => {
      res.writeHead(502);
      res.end(String(e));
    });
    req.pipe(upstream);
  })
  .listen(listenPort, '127.0.0.1');
