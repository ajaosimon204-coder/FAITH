-- Minimal stand-in for what a real Supabase project provides out of the box.
-- pgcrypto for gen_random_uuid(), an auth.users table, and auth.uid()
-- reading the same GUC Supabase's local dev stack uses.

create extension if not exists pgcrypto;
create extension if not exists pgtap;

create table if not exists auth.users (
  id uuid primary key default gen_random_uuid(),
  email text
);

-- Same definition as Supabase's: older PostgREST/GoTrue set the per-claim GUC
-- (request.jwt.claim.sub); PostgREST 9+ sets the JSON form (request.jwt.claims).
-- Both must work, or RLS silently sees "no user" under the real API layer while
-- passing under SET LOCAL shortcuts in tests.
create or replace function auth.uid() returns uuid
language sql stable
as $$
  select coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid;
$$;
