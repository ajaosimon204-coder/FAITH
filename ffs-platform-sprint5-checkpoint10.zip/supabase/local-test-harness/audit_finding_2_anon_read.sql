begin;

insert into organizations (id, name) values ('a0000002-0000-0000-0000-000000000001','[AUDIT] Org A2');
insert into campuses (id, organization_id, name) values ('a0000002-0000-0000-0000-000000000002','a0000002-0000-0000-0000-000000000001','[AUDIT] Campus A2');
insert into auth.users (id, email) values ('a0000002-0000-0000-0000-000000000003','admin-audit2@test.invalid');
insert into users (id, auth_user_id, campus_id, email, status) values ('a0000002-0000-0000-0000-000000000004','a0000002-0000-0000-0000-000000000003','a0000002-0000-0000-0000-000000000002','admin-audit2@test.invalid','active');
insert into user_roles (user_id, role_id, campus_id, assigned_by)
select 'a0000002-0000-0000-0000-000000000004', id, 'a0000002-0000-0000-0000-000000000002', 'a0000002-0000-0000-0000-000000000004'
from roles where key = 'super_admin';

set local role authenticated;
set local request.jwt.claim.sub = 'a0000002-0000-0000-0000-000000000003';

insert into cms_pages (campus_id, slug, title, status, created_by) values
  ('a0000002-0000-0000-0000-000000000002', 'status-draft', '[AUDIT] Draft', 'draft', 'a0000002-0000-0000-0000-000000000004') returning id as id_draft \gset
insert into cms_pages (campus_id, slug, title, status, created_by) values
  ('a0000002-0000-0000-0000-000000000002', 'status-review', '[AUDIT] Review', 'draft', 'a0000002-0000-0000-0000-000000000004') returning id as id_review \gset
update cms_pages set status = 'in_review' where id = :'id_review';

insert into cms_pages (campus_id, slug, title, status, created_by) values
  ('a0000002-0000-0000-0000-000000000002', 'status-approved', '[AUDIT] Approved', 'draft', 'a0000002-0000-0000-0000-000000000004') returning id as id_approved \gset
update cms_pages set status = 'in_review' where id = :'id_approved';
update cms_pages set status = 'approved', reviewed_by = 'a0000002-0000-0000-0000-000000000004' where id = :'id_approved';

insert into cms_pages (campus_id, slug, title, status, created_by) values
  ('a0000002-0000-0000-0000-000000000002', 'status-published', '[AUDIT] Published', 'draft', 'a0000002-0000-0000-0000-000000000004') returning id as id_published \gset
update cms_pages set status = 'in_review' where id = :'id_published';
update cms_pages set status = 'approved', reviewed_by = 'a0000002-0000-0000-0000-000000000004' where id = :'id_published';
update cms_pages set status = 'published', approved_by = 'a0000002-0000-0000-0000-000000000004', published_by = 'a0000002-0000-0000-0000-000000000004' where id = :'id_published';

insert into cms_pages (campus_id, slug, title, status, created_by) values
  ('a0000002-0000-0000-0000-000000000002', 'status-archived', '[AUDIT] Archived', 'draft', 'a0000002-0000-0000-0000-000000000004') returning id as id_archived \gset
update cms_pages set status = 'in_review' where id = :'id_archived';
update cms_pages set status = 'approved', reviewed_by = 'a0000002-0000-0000-0000-000000000004' where id = :'id_archived';
update cms_pages set status = 'published', approved_by = 'a0000002-0000-0000-0000-000000000004', published_by = 'a0000002-0000-0000-0000-000000000004' where id = :'id_archived';
update cms_pages set status = 'archived' where id = :'id_archived';

reset role;
set local role anon;
set local request.jwt.claim.sub = '';

select 'anon sees DRAFT (want 0):' as label, count(*) from cms_pages where slug = 'status-draft';
select 'anon sees IN_REVIEW (want 0):' as label, count(*) from cms_pages where slug = 'status-review';
select 'anon sees APPROVED (want 0):' as label, count(*) from cms_pages where slug = 'status-approved';
select 'anon sees PUBLISHED (want 1):' as label, count(*) from cms_pages where slug = 'status-published';
select 'anon sees ARCHIVED (want 0):' as label, count(*) from cms_pages where slug = 'status-archived';

insert into cms_pages (campus_id, slug, title, status, created_by)
  values ('a0000002-0000-0000-0000-000000000002', 'anon-forged', '[AUDIT] Forged', 'draft', 'a0000002-0000-0000-0000-000000000004');

rollback;
