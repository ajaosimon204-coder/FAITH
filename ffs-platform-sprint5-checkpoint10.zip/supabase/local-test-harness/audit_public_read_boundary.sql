begin;

insert into organizations (id, name) values ('a3333333-0000-0000-0000-000000000001', '[AUDIT] Org P');
insert into campuses (id, organization_id, name) values ('a3333333-0000-0000-0000-000000000002', 'a3333333-0000-0000-0000-000000000001', '[AUDIT] Campus P');
insert into auth.users (id, email) values ('a3333333-0000-0000-0000-000000000003', 'creator3@test.invalid');
insert into users (id, auth_user_id, campus_id, email, status) values ('a3333333-0000-0000-0000-000000000004', 'a3333333-0000-0000-0000-000000000003', 'a3333333-0000-0000-0000-000000000002', 'creator3@test.invalid', 'active');
insert into user_roles (user_id, role_id, campus_id, assigned_by)
select 'a3333333-0000-0000-0000-000000000004', id, 'a3333333-0000-0000-0000-000000000002', 'a3333333-0000-0000-0000-000000000004'
from roles where key = 'super_admin';

insert into cms_pages (id, campus_id, slug, title, status, created_by) values
  ('a3333333-0000-0000-0000-000000000010', 'a3333333-0000-0000-0000-000000000002', 'p-draft', 'Draft', 'draft', 'a3333333-0000-0000-0000-000000000004'),
  ('a3333333-0000-0000-0000-000000000011', 'a3333333-0000-0000-0000-000000000002', 'p-review', 'Review', 'draft', 'a3333333-0000-0000-0000-000000000004'),
  ('a3333333-0000-0000-0000-000000000012', 'a3333333-0000-0000-0000-000000000002', 'p-approved', 'Approved', 'draft', 'a3333333-0000-0000-0000-000000000004'),
  ('a3333333-0000-0000-0000-000000000013', 'a3333333-0000-0000-0000-000000000002', 'p-published', 'Published', 'draft', 'a3333333-0000-0000-0000-000000000004'),
  ('a3333333-0000-0000-0000-000000000014', 'a3333333-0000-0000-0000-000000000002', 'p-archived', 'Archived', 'draft', 'a3333333-0000-0000-0000-000000000004');

update cms_pages set status = 'in_review' where slug in ('p-review','p-approved','p-published','p-archived');
update cms_pages set status = 'approved' where slug in ('p-approved','p-published','p-archived');
update cms_pages set status = 'published' where slug in ('p-published','p-archived');
update cms_pages set status = 'archived' where slug = 'p-archived';

set local role anon;

select 'anon sees:' as label, slug, status from cms_pages order by slug;

select 'anon total visible rows:' as label, count(*) from cms_pages;

-- Anon write attempts:
do $$
begin
  begin
    update cms_pages set status = 'draft' where slug = 'p-published';
    raise notice 'ANON UPDATE: no error raised (rows affected unknown here)';
  exception when others then
    raise notice 'ANON UPDATE blocked: %', sqlerrm;
  end;
end $$;

select 'status of p-published after anon update attempt:' as label, status from cms_pages where slug = 'p-published';

do $$
begin
  begin
    insert into cms_pages (campus_id, slug, title, status, created_by)
    values ('a3333333-0000-0000-0000-000000000002', 'anon-forged', 'Forged', 'draft', 'a3333333-0000-0000-0000-000000000004');
    raise notice 'ANON INSERT: succeeded (!)';
  exception when others then
    raise notice 'ANON INSERT blocked: %', sqlerrm;
  end;
end $$;

rollback;
