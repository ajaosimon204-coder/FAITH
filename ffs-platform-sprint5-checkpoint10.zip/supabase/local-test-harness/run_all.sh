#!/usr/bin/env bash
# Reproducible local verification (harness only — not an application migration).
#
#   run_all.sh              reset -> default privileges (as Supabase sets them) -> auth stub ->
#                           migrations -> pgTAP (every suite in supabase/tests/)
#   run_all.sh --modern     model a CURRENT hosted Supabase project: new tables get NO automatic grants
#                           to anon/authenticated/service_role (default since 2026-05-30; mandatory for new
#                           tables from 2026-10-30). Migrations must then grant everything they need
#                           explicitly. Uses its own database (ffs_modern).
#   run_all.sh --no-tests   apply migrations only
#
# Faithful model: Supabase grants privileges on objects at creation (default privileges), so a
# migration's REVOKE is the last word. This harness does the same. It deliberately has NO
# post-migration "grants stub": that earlier design re-opened privileges migrations had revoked
# and could mask a missing revoke (ADR-013, ADR-019, ADR-021). Requires local Postgres 16 + pgTAP
# and root (uses `su postgres`).
set -euo pipefail
cd "$(dirname "$0")/.."

RUN_TESTS=1
MODERN=0
for a in "$@"; do
  case "$a" in
    --no-tests) RUN_TESTS=0 ;;
    --modern) MODERN=1 ;;
    *) echo "unknown flag $a"; exit 2 ;;
  esac
done
DB=ffs_verify; [[ $MODERN == 1 ]] && DB=ffs_modern
PSQL="psql -X -v ON_ERROR_STOP=1 -q"
as_pg() { su postgres -c "$*"; }

# Preflight: make sure a local cluster is accepting connections (start it if it is merely stopped).
if ! su postgres -c "pg_isready -q"; then
  pg_ctlcluster 16 main start 2>/dev/null || true
  for _ in 1 2 3 4 5 6 7 8 9 10; do su postgres -c "pg_isready -q" && break; sleep 1; done
fi
su postgres -c "pg_isready -q" || { echo "ERROR: no PostgreSQL server is accepting connections (install postgresql-16 + postgresql-16-pgtap)"; exit 3; }

as_pg "psql -X -q -c \"drop database if exists $DB\"" >/dev/null
as_pg "psql -X -q -c \"create database $DB\""
as_pg "psql -X -q -d $DB" <<'SQL'
do $$ begin
  if not exists (select 1 from pg_roles where rolname='anon') then create role anon nologin; end if;
  if not exists (select 1 from pg_roles where rolname='authenticated') then create role authenticated nologin; end if;
  if not exists (select 1 from pg_roles where rolname='service_role') then create role service_role nologin; end if;
end $$;
-- Supabase's service_role bypasses RLS. Roles persist across db drops, so alter explicitly.
alter role service_role bypassrls;
create schema if not exists auth;
grant usage on schema public, auth to anon, authenticated, service_role;
SQL
if [[ $MODERN == 0 ]]; then
  as_pg "psql -X -q -d $DB" <<'SQL'
-- Classic Supabase: objects created in public are granted to the API roles automatically.
alter default privileges in schema public grant all on tables to anon, authenticated, service_role;
alter default privileges in schema public grant all on sequences to anon, authenticated, service_role;
alter default privileges in schema public grant all on functions to anon, authenticated, service_role;
SQL
fi

run_file() { as_pg "$PSQL -d $DB -f $PWD/$1" >/tmp/mig.out 2>&1 && echo "OK   $1" || { echo "FAIL $1"; cat /tmp/mig.out; exit 1; }; }

run_file local-test-harness/00_auth_stub.sql
for f in $(ls migrations/*.sql | sort); do run_file "$f"; done

[[ $RUN_TESTS == 0 ]] && exit 0
rc=0
for t in tests/*.sql; do
  out=$(as_pg "pg_prove -d $DB $PWD/$t" 2>&1) || rc=1
  printf '%-48s %s  %s\n' "$(basename "$t" .sql)" "$(echo "$out" | grep -E '^Result' | awk '{print $2}')" "$(echo "$out" | grep -oE 'Tests=[0-9]+' | head -1)"
  echo "$out" | grep -E "Failed test|ERROR|not ok" || true
done
exit $rc
