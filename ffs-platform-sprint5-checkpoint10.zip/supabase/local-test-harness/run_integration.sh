#!/usr/bin/env bash
# Integration verification against the REAL API layer: PostgreSQL (all migrations) -> PostgREST
# (the component Supabase runs) -> the real, unmodified supabase-js client -> the application's
# own repository and services, with real JWTs. Complements the hermetic suites (pgTAP tests the
# SQL; Jest with fakes tests the logic); this proves the seam between them.
#   run_integration.sh            full run on a classic-style project (resets the verification database)
#   run_integration.sh --modern   same, on a current-style project (no automatic grants; see run_all.sh --modern)
# Requires: root, local Postgres 16 + pgTAP, network access to GitHub once (PostgREST download),
#           and `npm ci` already run in apps/api.
set -euo pipefail
cd "$(dirname "$0")/.."
HARNESS="$PWD/local-test-harness"
MODERN_FLAG=""; DB=ffs_verify
if [[ "${1:-}" == "--modern" ]]; then MODERN_FLAG="--modern"; DB=ffs_modern; fi
JWT_SECRET="integration-jwt-secret-0123456789abcdef"
PG_PORT=3100        # PostgREST
URL_PORT=3101       # /rest/v1 shim, what supabase-js talks to
PIDS=()
cleanup() { for p in "${PIDS[@]:-}"; do [[ -n "$p" ]] && kill "$p" 2>/dev/null || true; done; }
trap cleanup EXIT

PGRST_BIN="$("$HARNESS/install_postgrest.sh")"
"$HARNESS/run_all.sh" $MODERN_FLAG --no-tests >/dev/null
su postgres -c "psql -X -q -v ON_ERROR_STOP=1 -d $DB -f $HARNESS/integration_fixtures.sql"

# PostgREST connects over TCP as `authenticator` (peer auth would refuse a non-OS user).
PGRST_DB_URI="postgres://authenticator:integration-authenticator-pw@127.0.0.1:5432/$DB" \
PGRST_DB_SCHEMAS="public" PGRST_DB_ANON_ROLE="anon" PGRST_JWT_SECRET="$JWT_SECRET" \
PGRST_SERVER_HOST="127.0.0.1" PGRST_SERVER_PORT="$PG_PORT" \
  "$PGRST_BIN" > /tmp/postgrest.log 2>&1 &
PIDS+=($!)
node "$HARNESS/rest-v1-proxy.js" "$URL_PORT" "$PG_PORT" > /tmp/rest-proxy.log 2>&1 &
PIDS+=($!)

for _ in $(seq 1 30); do
  curl -fs -o /dev/null "http://127.0.0.1:$URL_PORT/rest/v1/" && break
  sleep 0.5
done
curl -fs -o /dev/null "http://127.0.0.1:$URL_PORT/rest/v1/" || { echo "ERROR: PostgREST did not come up"; tail -20 /tmp/postgrest.log; exit 1; }
echo "PostgREST $("$PGRST_BIN" --version | head -1) up on :$URL_PORT"

cd ../apps/api
INTEGRATION_URL="http://127.0.0.1:$URL_PORT" INTEGRATION_JWT_SECRET="$JWT_SECRET" npm run --silent test:integration
