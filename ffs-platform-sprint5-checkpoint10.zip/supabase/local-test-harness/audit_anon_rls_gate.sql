-- This grant is NOT applied to the real harness file (audit-only, in a
-- rolled-back transaction) — it exists to answer a methodology question:
-- does RLS itself block anon writes, or does my harness's more
-- restrictive anon grant (SELECT only) merely prevent the write from
-- reaching RLS at all? A real Supabase project typically grants anon
-- broader table privileges by default, with RLS as the actual gate — so
-- testing against my harness's narrower grant could produce a false
-- positive "anon can't write" result for the wrong reason.

grant insert, update, delete on cms_pages to anon;

begin;

insert into organizations (id, name) values ('a0000000-0000-0000-0000-00000000d001','[AUDIT2] Org');
insert into campuses (id, organization_id, name) values ('a0000000-0000-0000-0000-00000000d002','a0000000-0000-0000-0000-00000000d001','[AUDIT2] Campus');
insert into auth.users (id, email) values ('a0000000-0000-0000-0000-00000000d004','audit2@test.invalid');
insert into users (id, auth_user_id, campus_id, email, status) values
  ('a0000000-0000-0000-0000-00000000d005','a0000000-0000-0000-0000-00000000d004','a0000000-0000-0000-0000-00000000d002','audit2@test.invalid','active');
insert into cms_pages (id, campus_id, slug, title, status, created_by) values
  ('a0000000-0000-0000-0000-00000000d003','a0000000-0000-0000-0000-00000000d002','audit2-draft','[AUDIT2] Draft','draft',
   'a0000000-0000-0000-0000-00000000d005');

set local role anon;

-- With anon now holding a raw table-level INSERT grant (matching a
-- realistic worst-case Supabase default), does RLS alone still block it?
insert into cms_pages (campus_id, slug, title, status, created_by)
values ('a0000000-0000-0000-0000-00000000d002', 'anon-forged', '[AUDIT2] Forged', 'draft', 'a0000000-0000-0000-0000-00000000d005');

select 'anon insert row count (should be 0 if RLS blocks it):' as label, count(*) from cms_pages where slug = 'anon-forged';

update cms_pages set status = 'published' where slug = 'audit2-draft';
select 'anon update on someone elses draft (should remain draft):' as label, status from cms_pages where slug = 'audit2-draft';

rollback;

-- Clean up the temporary grant so it doesn't linger in this disposable
-- test database beyond this one audit query.
revoke insert, update, delete on cms_pages from anon;
