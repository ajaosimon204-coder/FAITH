-- Base data for the integration suite (apps/api/test-integration). Applied once by run_integration.sh
-- after the migrations. Tests create their own applications on top of this and never depend on
-- another test's rows. IDs are fixed so the TypeScript side can reference them.

-- Role PostgREST connects as, then switches from per the JWT's `role` claim (as on Supabase).
do $$ begin
  if not exists (select 1 from pg_roles where rolname = 'authenticator') then
    create role authenticator noinherit login password 'integration-authenticator-pw';
  end if;
end $$;
grant anon, authenticated, service_role to authenticator;

insert into organizations (id, name) values
  ('c1000000-0000-0000-0000-000000000001', 'Integration Org A'),
  ('c1000000-0000-0000-0000-000000000002', 'Integration Org B');
insert into campuses (id, organization_id, name) values
  ('c2000000-0000-0000-0000-000000000001', 'c1000000-0000-0000-0000-000000000001', 'Integration Campus A'),
  ('c2000000-0000-0000-0000-000000000002', 'c1000000-0000-0000-0000-000000000002', 'Integration Campus B');

insert into auth.users (id, email) values
  ('c3000000-0000-0000-0000-000000000001', 'admin-a@int.test'),
  ('c3000000-0000-0000-0000-000000000002', 'vp-a@int.test'),
  ('c3000000-0000-0000-0000-000000000003', 'accountant-a@int.test'),
  ('c3000000-0000-0000-0000-000000000004', 'guardian-a@int.test'),
  ('c3000000-0000-0000-0000-000000000005', 'admin-b@int.test');
insert into users (id, auth_user_id, campus_id, email, status) values
  ('c4000000-0000-0000-0000-000000000001', 'c3000000-0000-0000-0000-000000000001', 'c2000000-0000-0000-0000-000000000001', 'admin-a@int.test', 'active'),
  ('c4000000-0000-0000-0000-000000000002', 'c3000000-0000-0000-0000-000000000002', 'c2000000-0000-0000-0000-000000000001', 'vp-a@int.test', 'active'),
  ('c4000000-0000-0000-0000-000000000003', 'c3000000-0000-0000-0000-000000000003', 'c2000000-0000-0000-0000-000000000001', 'accountant-a@int.test', 'active'),
  ('c4000000-0000-0000-0000-000000000004', 'c3000000-0000-0000-0000-000000000004', 'c2000000-0000-0000-0000-000000000001', 'guardian-a@int.test', 'active'),
  ('c4000000-0000-0000-0000-000000000005', 'c3000000-0000-0000-0000-000000000005', 'c2000000-0000-0000-0000-000000000002', 'admin-b@int.test', 'active');

insert into user_roles (user_id, role_id, campus_id, assigned_by)
select 'c4000000-0000-0000-0000-000000000001', id, 'c2000000-0000-0000-0000-000000000001', 'c4000000-0000-0000-0000-000000000001' from roles where key = 'school_administrator';
insert into user_roles (user_id, role_id, campus_id, assigned_by)
select 'c4000000-0000-0000-0000-000000000002', id, 'c2000000-0000-0000-0000-000000000001', 'c4000000-0000-0000-0000-000000000001' from roles where key = 'vice_principal';
insert into user_roles (user_id, role_id, campus_id, assigned_by)
select 'c4000000-0000-0000-0000-000000000003', id, 'c2000000-0000-0000-0000-000000000001', 'c4000000-0000-0000-0000-000000000001' from roles where key = 'accountant';
insert into user_roles (user_id, role_id, campus_id, assigned_by)
select 'c4000000-0000-0000-0000-000000000005', id, 'c2000000-0000-0000-0000-000000000002', 'c4000000-0000-0000-0000-000000000005' from roles where key = 'school_administrator';

insert into academic_sessions (id, campus_id, name, start_date, end_date, is_current) values
  ('c5000000-0000-0000-0000-000000000001', 'c2000000-0000-0000-0000-000000000001', '2025/2026', '2025-09-01', '2026-07-31', true),
  ('c5000000-0000-0000-0000-000000000002', 'c2000000-0000-0000-0000-000000000002', '2025/2026', '2025-09-01', '2026-07-31', true);
insert into class_definitions (id, campus_id, name, level) values
  ('c6000000-0000-0000-0000-000000000001', 'c2000000-0000-0000-0000-000000000001', 'JSS 1', 'junior_secondary'),
  ('c6000000-0000-0000-0000-000000000002', 'c2000000-0000-0000-0000-000000000001', 'SS 1', 'senior_secondary'),
  ('c6000000-0000-0000-0000-000000000003', 'c2000000-0000-0000-0000-000000000002', 'JSS 1', 'junior_secondary');
insert into classes (id, class_definition_id, academic_session_id, campus_id, name, section) values
  ('c7000000-0000-0000-0000-000000000001', 'c6000000-0000-0000-0000-000000000001', 'c5000000-0000-0000-0000-000000000001', 'c2000000-0000-0000-0000-000000000001', 'JSS 1A', 'A'),
  ('c7000000-0000-0000-0000-000000000002', 'c6000000-0000-0000-0000-000000000002', 'c5000000-0000-0000-0000-000000000001', 'c2000000-0000-0000-0000-000000000001', 'SS 1A', 'A'),
  ('c7000000-0000-0000-0000-000000000003', 'c6000000-0000-0000-0000-000000000003', 'c5000000-0000-0000-0000-000000000002', 'c2000000-0000-0000-0000-000000000002', 'JSS 1A', 'A');

-- A login-linked guardian with a child, for the guardian self-access RLS checks.
insert into guardians (id, campus_id, users_id, first_name, last_name) values
  ('c8000000-0000-0000-0000-000000000001', 'c2000000-0000-0000-0000-000000000001', 'c4000000-0000-0000-0000-000000000004', 'Linked', 'Guardian'),
  ('c8000000-0000-0000-0000-000000000002', 'c2000000-0000-0000-0000-000000000001', null, 'Other', 'Guardian');
insert into students (id, campus_id, display_name) values
  ('c9000000-0000-0000-0000-000000000001', 'c2000000-0000-0000-0000-000000000001', 'Linked Child');
insert into guardian_students (guardian_id, student_id, relationship) values
  ('c8000000-0000-0000-0000-000000000001', 'c9000000-0000-0000-0000-000000000001', 'mother');
