#!/usr/bin/env bash
# Installs the PostgREST binary used by the integration harness (the same API layer Supabase runs),
# pinned to an exact version and verified by checksum. Idempotent. Prints the binary path.
set -euo pipefail
VERSION="12.2.3"
SHA256="9f71269e61ac3a940281e93ff415760f5957e430e475ba4c3889f3ede7d5527c"
DEST="${POSTGREST_DIR:-/tmp/pgrst}"
BIN="$DEST/postgrest"

if [[ -x "$BIN" ]] && "$BIN" --version 2>/dev/null | grep -q "$VERSION"; then echo "$BIN"; exit 0; fi

mkdir -p "$DEST"
URL="https://github.com/PostgREST/postgrest/releases/download/v${VERSION}/postgrest-v${VERSION}-linux-static-x64.tar.xz"
curl -fsSL -o "$DEST/postgrest.tar.xz" "$URL"
echo "$SHA256  $DEST/postgrest.tar.xz" | sha256sum -c - >&2 || { echo "ERROR: PostgREST checksum mismatch" >&2; exit 1; }
tar -xJf "$DEST/postgrest.tar.xz" -C "$DEST"
echo "$BIN"
