begin;

insert into organizations (id, name) values ('a0000000-0000-0000-0000-00000000c001','[AUDIT] Org');
insert into campuses (id, organization_id, name) values ('a0000000-0000-0000-0000-00000000c002','a0000000-0000-0000-0000-00000000c001','[AUDIT] Campus');
insert into auth.users (id, email) values ('a0000000-0000-0000-0000-00000000c003','editor-only@audit.invalid');
insert into users (id, auth_user_id, campus_id, email, status) values ('a0000000-0000-0000-0000-00000000c004','a0000000-0000-0000-0000-00000000c003','a0000000-0000-0000-0000-00000000c002','editor-only@audit.invalid','active');

-- Grant ONLY content.create (a content_editor whose job, per the
-- application's REQUIRED_PERMISSION_FOR_TRANSITION map, should be limited
-- to creating drafts and submitting them for review — nothing more).
insert into user_roles (user_id, role_id, campus_id, assigned_by)
select 'a0000000-0000-0000-0000-00000000c004', id, 'a0000000-0000-0000-0000-00000000c002', 'a0000000-0000-0000-0000-00000000c004'
from roles where key = 'content_editor';

select 'granted permissions:' as label, p.key
from user_roles ur join role_permissions rp on rp.role_id = ur.role_id join permissions p on p.id = rp.permission_id
where ur.user_id = 'a0000000-0000-0000-0000-00000000c004';

set local role authenticated;
set local request.jwt.claim.sub = 'a0000000-0000-0000-0000-00000000c003';

-- Step 1: create a draft (should be allowed — this IS content.create's job).
insert into cms_pages (campus_id, slug, title, status, created_by)
values ('a0000000-0000-0000-0000-00000000c002', 'audit-test', '[AUDIT] Test', 'draft', 'a0000000-0000-0000-0000-00000000c004');

select 'after insert, status:' as label, status from cms_pages where slug = 'audit-test';

-- Step 2: submit for review (draft -> in_review). Per the app's own
-- permission map this correctly requires content.create — should succeed.
update cms_pages set status = 'in_review' where slug = 'audit-test';
select 'after draft->in_review direct write:' as label, status from cms_pages where slug = 'audit-test';

-- Step 3 — THE ADVERSARIAL TEST: in_review -> approved. Per the app's own
-- REQUIRED_PERMISSION_FOR_TRANSITION map this requires content.review,
-- which this actor does NOT hold. Does RLS block it anyway?
update cms_pages set status = 'approved', reviewed_by = 'a0000000-0000-0000-0000-00000000c004' where slug = 'audit-test';
select 'after in_review->approved direct write (should have been BLOCKED, actor has no content.review):' as label, status from cms_pages where slug = 'audit-test';

-- Step 4 — even further: approved -> published. Requires content.publish,
-- which this actor ALSO does not hold.
update cms_pages set status = 'published', published_by = 'a0000000-0000-0000-0000-00000000c004' where slug = 'audit-test';
select 'after approved->published direct write (should have been BLOCKED, actor has no content.publish):' as label, status from cms_pages where slug = 'audit-test';

rollback;
