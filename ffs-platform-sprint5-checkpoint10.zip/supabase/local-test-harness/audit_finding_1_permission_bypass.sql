begin;

insert into organizations (id, name) values ('a0000001-0000-0000-0000-000000000001','[AUDIT] Org A');
insert into campuses (id, organization_id, name) values ('a0000001-0000-0000-0000-000000000002','a0000001-0000-0000-0000-000000000001','[AUDIT] Campus A');
insert into auth.users (id, email) values ('a0000001-0000-0000-0000-000000000003','editor-audit@test.invalid');
insert into users (id, auth_user_id, campus_id, email, status) values ('a0000001-0000-0000-0000-000000000004','a0000001-0000-0000-0000-000000000003','a0000001-0000-0000-0000-000000000002','editor-audit@test.invalid','active');
insert into user_roles (user_id, role_id, campus_id, assigned_by)
select 'a0000001-0000-0000-0000-000000000004', id, 'a0000001-0000-0000-0000-000000000002', 'a0000001-0000-0000-0000-000000000004'
from roles where key = 'content_editor';

set local role authenticated;
set local request.jwt.claim.sub = 'a0000001-0000-0000-0000-000000000003';

-- Sanity: confirm this actor ONLY holds content.create.
select 'has content.create:' as label, app_has_permission('content.create') as result;
select 'has content.review:' as label, app_has_permission('content.review') as result;
select 'has content.publish:' as label, app_has_permission('content.publish') as result;
select 'has content.archive:' as label, app_has_permission('content.archive') as result;

-- Create a draft (legitimately, this IS their permission).
insert into cms_pages (campus_id, slug, title, status, created_by)
values ('a0000001-0000-0000-0000-000000000002', 'audit-test', '[AUDIT] Test', 'draft', 'a0000001-0000-0000-0000-000000000004')
returning id as page_id \gset

-- ADVERSARIAL TEST: attempt to walk the SAME actor's content.create-only
-- permission all the way to 'published' via DIRECT table UPDATEs, never
-- going through CmsContentWorkflowService's per-transition permission checks.
update cms_pages set status = 'in_review' where id = :'page_id';
select 'after draft->in_review:' as label, status, reviewed_by, approved_by, published_by from cms_pages where id = :'page_id';

update cms_pages set status = 'approved' where id = :'page_id';
select 'after in_review->approved (should require content.review, actor has NONE):' as label, status, reviewed_by, approved_by, published_by from cms_pages where id = :'page_id';

update cms_pages set status = 'published' where id = :'page_id';
select 'after approved->published (should require content.publish, actor has NONE):' as label, status, reviewed_by, approved_by, published_by from cms_pages where id = :'page_id';

update cms_pages set status = 'archived' where id = :'page_id';
select 'after published->archived (should require content.archive, actor has NONE):' as label, status, reviewed_by, approved_by, published_by from cms_pages where id = :'page_id';

-- Was ANY of this audited?
select 'audit_logs entries for this actor/action:' as label, count(*) from audit_logs
where actor_id = 'a0000001-0000-0000-0000-000000000004' and target_type = 'cms_pages';

rollback;
