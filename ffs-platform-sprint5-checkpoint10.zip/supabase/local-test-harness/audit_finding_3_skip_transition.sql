begin;

insert into organizations (id, name) values ('a0000003-0000-0000-0000-000000000001','[AUDIT] Org A3');
insert into campuses (id, organization_id, name) values ('a0000003-0000-0000-0000-000000000002','a0000003-0000-0000-0000-000000000001','[AUDIT] Campus A3');
insert into auth.users (id, email) values ('a0000003-0000-0000-0000-000000000003','admin-audit3@test.invalid');
insert into users (id, auth_user_id, campus_id, email, status) values ('a0000003-0000-0000-0000-000000000004','a0000003-0000-0000-0000-000000000003','a0000003-0000-0000-0000-000000000002','admin-audit3@test.invalid','active');
insert into user_roles (user_id, role_id, campus_id, assigned_by)
select 'a0000003-0000-0000-0000-000000000004', id, 'a0000003-0000-0000-0000-000000000002', 'a0000003-0000-0000-0000-000000000004'
from roles where key = 'super_admin';

set local role authenticated;
set local request.jwt.claim.sub = 'a0000003-0000-0000-0000-000000000003';

insert into cms_pages (campus_id, slug, title, status, created_by) values
  ('a0000003-0000-0000-0000-000000000002', 'skip-test', '[AUDIT] Skip', 'draft', 'a0000003-0000-0000-0000-000000000004') returning id as page_id \gset

-- This actor holds ALL FOUR content permissions (super_admin). Can they
-- skip straight from draft to published, bypassing in_review/approved?
update cms_pages set status = 'published' where id = :'page_id';

rollback;
