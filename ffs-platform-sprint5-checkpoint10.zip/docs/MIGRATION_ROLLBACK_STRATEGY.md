# Migration Rollback & Recovery Strategy
## Migrations 0001–0029 — Faith Foundation Schools Platform

*No destructive down-migrations exist, deliberately. This document explains what to do instead, for each situation that might call for one.*

---

## Why there are no down-migrations

An automated "reverse" migration that drops tables/columns is dangerous once real data exists — it doesn't know the difference between a schema that's never been used and one holding a term's worth of attendance and payment records. Writing down-migrations that are safe in every environment but genuinely reversive in none of them would be worse than no down-migrations at all: a false sense of safety. Instead, this document classifies every migration by what kind of rollback actually applies to it.

---

## Classification of Migrations 0001–0029

| Migration | Reversibility | Notes |
|---|---|---|
| `0001` Identity/RBAC schema | **Reversible pre-production** | Pure `CREATE TABLE`. Safe to drop entirely if no real accounts exist yet. |
| `0002` RLS policies | **Reversible pre-production** | Policy-only; drop/recreate freely before go-live. |
| `0003` Seed roles/permissions | **Reversible pre-production**; **destructive in production** | Once real `user_roles` rows reference these roles/permissions, deleting them cascades. |
| `0004` Seed tenant | **Contains real data** (org name) | The `[CONTENT REQUIRED]` campus name placeholder should be updated in place via a new migration when supplied, never deleted-and-reinserted. |
| `0005`–`0006` Config schema/RLS | **Reversible pre-production** | Pure schema. |
| `0007` Seed config definitions | **Reversible pre-production**; **destructive once `school_config` values reference these definitions** | `config_definitions` has `ON DELETE RESTRICT` semantics implicitly via FK — cannot be dropped once referenced. |
| `0008` Config write function | **Reversible pre-production** | Function-only. |
| `0009` Sprint 2 corrections | **Not reversible — do not revert** | Reverting reopens the `campuses` recursion bug and the `school_config` write-bypass. This migration is a one-way fix. |
| `0010`–`0014` Academic core | **Reversible pre-production**; **destructive once enrollments/assignments exist** | See "Historical Data" below — `enrollments` in particular should never be schema-rolled-back once real student data exists. |
| `0015` Sprint 3 re-audit corrections | **Not reversible — do not revert** | Same reasoning as `0009`: reverting reopens the `class_subjects` cross-campus gap. |
| `0016`–`0018` CMS schema/RLS/permissions seed | **Reversible pre-production**; **destructive once CMS content exists** | Schema, policy and seed only. |
| `0019` CMS audit corrections | **Not reversible — do not revert** | Replaces `app_cms_transition()` so every state change writes its audit entry atomically; reverting reintroduces the missing-audit defect. |
| `0020` PUBLIC EXECUTE grant correction | **Not reversible — do not revert** | Security fix: revokes the implicit PUBLIC `EXECUTE` on service-role-only functions. Reverting makes them callable by any role. |
| `0021` Admissions schema | **Reversible pre-production**; **destructive once applications, guardians or admission numbers exist** | Adds `guardians`, `guardian_students`, `applications`, `application_documents` and student columns. Admission numbers and guardian links are real records once issued. |
| `0022` Admissions RLS | **Reversible pre-production** | Policy-only, plus the real body of `app_is_guardian_of_student()`. |
| `0023` Admissions permissions seed | **Reversible pre-production**; **destructive in production** | Same reasoning as `0003`/`0018`. |
| `0024` Admissions atomic functions | **Reversible pre-production** | Function-only (`app_application_transition`, `app_convert_application`); dropping them leaves data untouched but removes the only sanctioned write path. |
| `0025` Admissions `anon` write revoke | **Not reversible — do not revert** | Reverting reopens `anon` write privileges on the guardian tables. |
| `0026` Privilege hardening | **Not reversible — do not revert** | Reverting restores `anon` write and `TRUNCATE` privileges across every public table. |
| `0027` Application level/campus trigger | **Not reversible — do not revert** | Reverting lets an application name a level from another campus. Trigger only; no data is affected. |
| `0028` Explicit API-role grants | **Not reversible — do not revert** | Reverting removes the privileges the App Backend needs on a current Supabase project (which grants nothing automatically); the platform stops working. Grants only; no data is affected. |
| `0029` `student_current_enrollments` security fix | **Not reversible — do not revert** | Security fix. Reverting restores a view that bypasses row-level security and was readable by unauthenticated callers. |

---

## Pre-Production Rollback (current state — no real school data yet)

Since this platform has not yet been used with real student/staff/financial data, **any** migration can currently be reverted by:

1. `DROP SCHEMA public CASCADE; DROP SCHEMA auth CASCADE;` (or the Supabase-project equivalent: reset the project)
2. Re-apply migrations `0001` through the desired point, in order

This is what the local test harness already does before every verification run (see `supabase/local-test-harness/`). **This approach must stop being used the moment real production data exists** — see below.

---

## Production Rollback Strategy (once real data exists)

Once real students, staff, sessions, or configuration values exist, "rollback" means one of three different things depending on what went wrong:

### A. A migration itself was buggy (schema/policy/function logic error)
**Fix forward with a new corrective migration**, exactly as `0009` and `0015` did. Never edit or delete an already-applied migration file — the migration history is itself an audit trail of what the schema looked like at any point in time. This is why `0009`/`0015` exist as new files rather than edits to `0002`/`0006`/`0011`.

### B. A migration was applied but should not have been (wrong environment, premature)
**Do not attempt an automatic down-migration.** Instead:
1. Identify exactly what the migration added (tables/columns/policies/functions — every migration in this set is additive only, so this is always a clean, enumerable list)
2. Manually verify no data depends on the addition
3. Write and review a specific, one-off reversal migration for that exact situation, scoped narrowly, reviewed by a human before running

### C. Data was corrupted or lost (not a schema problem — a data problem)
**This is a restore situation, not a rollback situation** — see Backup/PITR Recovery below. Schema rollback cannot fix bad data.

---

## Backup / Point-in-Time Recovery (PITR)

Per the Final Architecture document's recommended V1 targets (unchanged, restated here for completeness):

- **RPO:** ≤ 24 hours general data; ≤ 1 hour for finance/CBT during active windows
- **RTO:** ≤ 4 hours during school hours
- **Mechanism:** Supabase-managed daily backups + continuous PITR
- **Restore procedure:** restore to a **staging** project first, verify integrity (student count, latest invoice, latest result entry — and as of Sprint 3, latest enrollment/teacher_assignment counts), then cut over
- **Never restore directly into production** without a staging verification pass first

If a migration-level rollback (Category B above) also requires restoring data that a bad migration deleted, PITR restore to a point before the migration ran — followed by careful, manual replay of any legitimate data written after that point but before the rollback — is the only safe path. This is inherently a human-supervised process, not an automated one.

---

## Historical Data — Never Automatically Reversed

Per Sprint 3's own core requirement, three things must **never** be touched by any rollback, automated or otherwise:

1. **`enrollments` rows** — even a "clearly wrong" enrollment is corrected by inserting a new row and closing the old one (exactly as `EnrollmentService.transferStudent` already does), never by deleting or schema-rolling-back the table. The triggers from migration `0010` already prevent this at the database level for anyone with write access; this policy extends that same principle to anyone with migration/admin access too.
2. **`audit_logs` / `config_audit_log`** — append-only by database privilege (not just RLS), and that must remain true through any future migration. A "rollback" that finds a way to delete audit history has failed at its one job.
3. **`config_audit_log` / `result_audit_log`-style tables in future sprints** — the same principle extends forward; any future sprint introducing a new audit table should be held to the same append-only standard as a matter of course, not something to re-derive each time.

---

## What a Future Contributor Should Do

- **Schema was wrong, no real data yet:** reset and reapply (see Pre-Production Rollback).
- **Schema was wrong, real data exists:** write a new corrective migration (Category A).
- **Migration ran in the wrong environment:** stop, assess, write a scoped one-off reversal, get it reviewed (Category B) — do not improvise this under time pressure.
- **Data itself is wrong or lost:** this is a restore, not a rollback (Category C / PITR).
- **Under no circumstances:** delete or edit an already-shipped migration file, or attempt to programmatically "undo" `enrollments`/audit-table history.
