# Changelog

All notable changes to the Faith Foundation Schools platform, sprint by sprint.

## [Sprint 1] — Identity & RBAC Foundation

### Added
- Database: `organizations`, `campuses`, `users`, `roles`, `permissions`, `role_permissions`, `user_roles`, `audit_logs` (migration `0001_identity_rbac_schema.sql`)
- Database: deny-by-default RLS policies + `app_current_user_id()`, `app_current_campus_id()`, `app_has_permission()` helper functions (migration `0002_rls_policies.sql`)
- Database: seeded system roles/permissions for Sprint 1 scope (migration `0003_seed_roles_permissions.sql`)
- Database: seeded the real Faith Foundation Schools tenant, with `[CONTENT REQUIRED]` placeholder for campus name pending confirmation (migration `0004_seed_tenant.sql`)
- Database: DEMO DATA seed template, environment-guarded, not part of the migration pipeline (`supabase/seed/demo_seed.sql`)
- Backend: `IdentityModule` — `JwtVerificationService`, `IdentityResolutionService`, `SupabaseIdentityRepository`, `SupabaseAuthGuard`
- Backend: `RbacModule` — `PermissionGuard`, `RbacService`, `RbacController` (`GET /api/v1/me`, `POST /api/v1/admin/users/:userId/roles`)
- Backend: `OrganizationsModule` — `GET /api/v1/organizations/mine`
- Backend: `AuditModule` — `GET /api/v1/audit-logs` (tenant-scoped explicitly, since this controller uses the service-role client which bypasses RLS)
- Tests: 20 Jest unit tests across JWT verification, identity resolution, permission guard, and RBAC service
- Tests: 17 pgTAP RLS tests covering tenant isolation, permission gating, and IDOR resistance (written; execution pending a live database — see Sprint 1 Completion Report)
- Docs: this changelog, `IMPLEMENTATION_STATUS.md`, `ADR_LOG.md`, `SPRINT_1_COMPLETION_REPORT.md`

### Notes
- No password/credential column exists anywhere in the `users` table by design — Supabase Auth is the sole credential owner.
- `audit_logs` has no INSERT/UPDATE/DELETE grant for the `authenticated` Postgres role at all — writes are service-role only, enforced at the privilege level, not just by RLS policy.

## [Sprint 2] — School Configuration System

### Added
- Database: `config_category`, `config_data_type` enums; `config_definitions`, `school_config`, `config_audit_log` tables (migration `0005_config_schema.sql`)
- Database: deny-by-default RLS for all three config tables, permission checks resolved dynamically from each definition's own `read_permission_key`/`write_permission_key` rather than hardcoded per policy (migration `0006_config_rls.sql`)
- Database: seeded 8 new permissions (`config.{category}.{read,write}`) and role grants; seeded 4 illustrative `config_definitions` rows, one per category (migration `0007_seed_config_definitions.sql`)
- Database: `app_write_school_config()` — atomic upsert + audit Postgres function, execute-revoked from the frontend role so the write path cannot be reached except through `ConfigService`'s ajv validation (migration `0008_config_write_function.sql`)
- Backend: `ConfigModule` — `ConfigService` (ajv JSON-Schema validation, per-definition permission enforcement), `ConfigController` (`GET /api/v1/config/:category`, `GET/PUT /api/v1/config/value/:key`)
- Tests: 12 new Jest unit tests covering schema validation (type, enum, range), permission enforcement (per-category, read-without-write, wrong-category), unregistered-key rejection, and audit-trail correctness on repeated writes
- Tests: 12 new pgTAP RLS tests covering catalogue readability, tenant isolation on config values, read/write permission asymmetry (a role with read but not write), and privilege-level write protection on `config_audit_log`
- Docs: this changelog entry, updated `IMPLEMENTATION_STATUS.md`, `ADR_LOG.md`, `SPRINT_2_COMPLETION_REPORT.md`

### Notes
- `config_definitions` has no INSERT/UPDATE/DELETE grant for `authenticated` at all — new configurable keys can only ever be introduced by a migration, never through the API, which is the concrete mechanism behind "JSONB must never become an unrestricted arbitrary-settings mechanism."
- Permission checks in `ConfigController`/`ConfigService` are resource-aware (per-definition) rather than declared via the static `@RequirePermissions` decorator used elsewhere — documented as a deliberate, narrow exception to the Sprint 1 pattern, since a single route (`PUT /config/value/:key`) can point at any of several different required permissions depending on which key is being written.

## [Sprint 2 — Correction] — Live RLS Verification & Two Real Bug Fixes

### Context
Sprint 2 was initially reported with RLS tests "written but not executed" (no live database available). A live PostgreSQL 16 instance with `pgtap`/`pg_prove` was found to already exist in the development sandbox. Provisioning it and actually running the Sprint 1 and Sprint 2 RLS suites surfaced two real bugs that static review had missed.

### Added
- `supabase/local-test-harness/00_auth_stub.sql` — minimal Supabase-parity `auth` schema for local testing (not an application migration)
- `supabase/local-test-harness/01_supabase_platform_grants_stub.sql` — replicates Supabase platform-level table grants a real project provisions automatically (not an application migration)
- `supabase/migrations/0009_sprint2_corrections.sql` — fixes both bugs found below

### Fixed
- **`campuses` RLS infinite recursion** (migration `0002`): `campuses_select_own_org` queried `campuses` from inside its own policy without `SECURITY DEFINER` protection. Fixed with a new `app_current_organization_id()` helper function, matching the existing pattern.
- **`school_config` direct-write bypass** (migration `0006`): direct `INSERT`/`UPDATE` RLS policies allowed an authorized frontend client to write directly to `school_config`, skipping both ajv validation and the audit trail. Fixed by removing those policies entirely — all writes now go exclusively through `app_write_school_config()`, callable only by the service-role connection.
- Two test-authorship bugs in the RLS suites themselves: a `throws_ok` misused for an RLS-blocked `UPDATE` that correctly affects zero rows without raising (rewritten as a row-count/unchanged-value assertion), and a fixture that incorrectly assumed `school_administrator` holds `rbac.manage` (rewritten using a dedicated `super_admin` fixture user).

### Verified
- All 9 migrations (`0001`–`0009`) apply cleanly, in order, against a real Postgres 16 database, from a clean reset.
- **31/31 pgTAP RLS tests pass** (17 identity/RBAC + 14 config), executed for real via `pg_prove`.
- All 32 Jest unit tests, `tsc --noEmit`, and `eslint --max-warnings=0` remain green, confirming the SQL-only corrections didn't affect the TypeScript layer.

## [Sprint 3] — Academic Core

### Added
- Database: `students`, `staff` (MINIMAL Sprint 3 stubs — see "Architecture Deviations" in the Sprint 3 Completion Report), `academic_sessions`, `terms`, `class_definitions`, `classes`, `subjects`, `class_subjects`, `enrollments`, `teacher_assignments` (migration `0010_academic_core_schema.sql`)
- Database: `student_current_enrollments` view — the sanctioned mechanism for deriving a student's current class; confirmed no `students.current_class` column exists anywhere in the schema
- Database: historical-integrity enforcement via three independent mechanisms on `enrollments` — a unique partial index (at most one `active` enrollment per student per session), a consistency trigger (class/session/campus agreement), and an immutability trigger (a closed enrollment's identity fields cannot be changed, only its status/exit fields)
- Database: RLS policies (migration `0011_academic_core_rls.sql`) built around `app_is_assigned_to_class()` — every teacher-facing policy checks a real `teacher_assignments` relationship, never role name
- Database: 8 new permissions and role grants (migration `0012_seed_academic_permissions.sql`)
- Database: `app_set_current_academic_session()`, `app_set_current_term()` (migration `0013`), `app_transfer_enrollment()` (migration `0014`) — atomic swap/transfer functions, execute-revoked from the frontend role
- Backend: `AcademicModule` — `SessionsService`, `ClassesService`, `EnrollmentService`, `TeacherAssignmentService`, `AcademicController`, wired into `app.module.ts`
- Tests: 22 new Jest unit tests (54 total) covering historical-integrity rules (no double-active-enrollment, transfer preserves both rows) and relationship-based authorization (the single most important negative test: a Teacher-role holder with NO `teacher_assignments` row for a class is denied — proven both in Jest against a fake repository and live against real Postgres RLS)
- Tests: 19 new pgTAP RLS tests (50 total, all executed live) — including the same Teacher-role-grants-nothing proof at the database layer, IDOR checks between students, and direct verification that a closed enrollment's `class_id` cannot be mutated

### Fixed (harness only, found during Sprint 3's live verification)
- `01_supabase_platform_grants_stub.sql`'s broad `GRANT ... ON ALL TABLES` was being applied AFTER all migrations, silently re-opening every write-path `REVOKE` those migrations had issued (Sprint 1/2/3 alike) — confirmed live (`has_table_privilege` returned `true` for revoked grants). Fixed by re-applying all revokes after the broad grant, matching a real Supabase project's actual chronology (platform grant happens first, our migrations' revokes are the final word). This was a harness sequencing bug, not a product bug — flagged with the same rigor as the Sprint 2 corrections regardless.

### Notes
- **Minimal dependency, explicitly flagged, not silently absorbed:** `enrollments`/`teacher_assignments` need `student_id`/`staff_id` foreign keys. Sprint 3 adds only bare-minimum stub tables for this — no admission workflow, no HR. Sprint 5 (Admissions) owns the real tables and is expected to only ADD columns, not restructure.
- `app_is_guardian_of_student()` is defined now as a permanent stub (always `false`) specifically so Sprint 5 can replace its body once `guardian_students` exists, without needing to rewrite any RLS policy that already references it.

## [Sprint 3 Re-Audit] — Three Real Gaps Found and Closed

Requested corrective verification, prompted specifically by asking for a dedicated service-role authorization review and focused `class_subjects` cross-campus test coverage. Writing those tests honestly (rather than only exercising already-safe paths) surfaced three genuine gaps — see ADR-014 for full detail.

### Added
- Migration `0015_sprint3_reaudit_corrections.sql` — database-level cross-campus trigger for `class_subjects`
- `IAcademicRepository.getStudentCampusId()`, `.getSubjectById()` — new repository methods needed for the fixes below
- `apps/api/test/class-subjects.spec.ts` — 5 new tests (valid link, duplicate rejection, unauthorized rejection, two cross-campus rejection cases)
- New IDOR tests in `enrollment.service.spec.ts`: cross-campus access denial (the exact case that was previously unguarded), Teacher-B-cannot-see-Teacher-A's-student, unauthorized-staff-denied-history
- New live pgTAP test in `rls_academic_tests.sql`: the `class_subjects` cross-campus trigger, exercised directly
- `docs/MIGRATION_ROLLBACK_STRATEGY.md` — full rollback/recovery documentation for migrations `0001`–`0015`

### Fixed
- **`EnrollmentService.getCurrentEnrollment`/`getEnrollmentHistory`**: added an unconditional campus-membership check as the first authorization step in both methods — previously, holding `academic.enrollments.read` alone granted access regardless of the student's campus.
- **`ClassesService.linkSubjectToClass`**: added explicit checks that both the class and the subject belong to the actor's own campus, and to each other's campus — previously unchecked entirely.

### Verified (live, from a clean database reset)
- Migrations `0001`–`0015`: all apply cleanly, in order.
- **52/52 pgTAP tests pass** (17 identity + 14 config + 21 academic).
- **63/63 Jest tests pass.** `tsc --noEmit` and `eslint --max-warnings=0` both clean.
- The Sprint 1 `campuses` recursion fix and the Sprint 2 `school_config` write-bypass fix were both **re-demonstrated live** via direct reproduction of the original exploit scenarios (not merely re-asserted) — see the Sprint 3 Re-Audit Report for the exact commands and output.

## [Sprint 4] — Design System Contract, CMS, Public Website (begins)

### Added
- `docs/DESIGN_SYSTEM_CONTRACT.md` — ratified visual/interaction specification: brand tokens (Royal Blue/Gold), typography, spacing/grid, breakpoints, two density modes sharing one token set, full component catalogue (buttons, forms, cards, tables, nav, modals, toasts, badges, charts, empty/loading/error states), WCAG-aligned accessibility baseline
- Database: `cms_content_status` enum, `cms_pages`/`cms_news`/`cms_gallery`/`cms_staff_profiles` tables — structurally identical, one shared workflow (migration `0016_cms_schema.sql`)
- Database: shared `trg_validate_cms_status_transition()` trigger (database-level backstop for valid status transitions, independent of RLS), deny-by-default RLS with a genuinely public read path for published content (migration `0017_cms_rls.sql`)
- Database: `content.{create,review,publish,archive}` permissions and role grants (migration `0018_seed_cms_permissions.sql`)
- Backend: `CmsContentWorkflowService<T>` — the one shared workflow engine (draft→in_review→approved→published→archived) instantiated once per content type, `CmsPagesService`, four per-type repositories, `CmsController` (authenticated authoring routes for `cms_pages`), `PublicCmsController` (genuinely unauthenticated published-content reads)
- Backend: `@Public()` decorator + `SupabaseAuthGuard` opt-out mechanism — the single, explicit, reviewable exception to "every route authenticated by default" (Sprint 1's original fail-closed design), used only for the public CMS read path
- Frontend: `apps/web` — real Next.js 14 App Router application. Design tokens implemented as CSS custom properties copied exactly from the ratified contract. One page (Home) built: real verified school facts only (name, motto, address, established year, the 15-level academic pathway as a genuine sequential visual), explicit `[CONTENT REQUIRED]` placeholders for anything not yet supplied (history, mission/vision, leadership, contact details), and an honest empty state for CMS-sourced content — never fabricated copy
- Tests: 6 new backend Jest tests (`SupabaseAuthGuard` @Public() coverage, CMS cross-campus IDOR), 11 new frontend Jest tests (component + page level), 15 new pgTAP tests (67 total across all 4 suites)

### Fixed (found via live execution, this sprint)
- **`CmsContentWorkflowService.requireRecord` had no campus check at all** — same class of cross-campus IDOR gap as the Sprint 3 re-audit findings, caught proactively this time (per that audit's own recommendation to treat this as a standing checklist item) rather than requiring a separate corrective-verification round. Fixed by adding an unconditional campus check as the first step of every workflow transition, applied once in the shared service so all four content types inherit the fix.
- **Migration `0017`'s four `CREATE TRIGGER` statements had a duplicated `on <table>` clause** — a genuine SQL syntax error that would have failed on first real application. Never previously executed; caught immediately by live verification and fixed in place (appropriate since this migration had never been shipped/approved before this sprint).
- **Harness grant-ordering issue recurred** for the four new CMS tables (same root cause as Sprint 3) — fixed the same way, by adding the CMS `DELETE` revokes to the harness's post-grant re-apply list.
- **An architectural bug in the new frontend code**: an async Server Component was nested inside another async Server Component, which cannot be exercised by `@testing-library/react` outside Next's actual RSC pipeline. Refactored `PublishedPageSection` into a data-fetching function plus a synchronous presentational component — one async boundary at the page level, not a test-only workaround.
- Two SQL test-fixture bugs (insert ordering; a `throws_ok` misused against a zero-row RLS-blocked update) — same category as prior sprints, caught by live re-runs.

### Verified (live, from a clean database reset)
- All 18 migrations apply cleanly, in order.
- **67/67 pgTAP tests pass** across all 4 suites (17 identity + 14 config + 21 academic + 15 CMS).
- **81/81 backend Jest tests pass.** Backend `tsc --noEmit` and `eslint --max-warnings=0` clean.
- **11/11 frontend Jest tests pass.** Frontend `tsc --noEmit` and `eslint --max-warnings=0` clean. Production `next build` succeeds, including correct static generation of the Home page with its honest empty-state CMS fallback exercised at build time (no backend configured in this environment).

### Notes
- Sprint 4 deliberately **begins** the public website/CMS rather than completing it — only `cms_pages` has full controller routes wired (the reference implementation); `cms_news`/`cms_gallery`/`cms_staff_profiles` have complete repositories sharing the same workflow service but their routes are a small, mechanical follow-up, not a redesign. Only the Home page is built on the frontend; the full site architecture (About, Admissions, Academics sub-pages, etc.) is explicitly out of this sprint's scope.
- No school content was fabricated. The Home page uses only facts already verified in the master specification; everything else is a clearly labeled `[CONTENT REQUIRED]` placeholder.

## [Sprint 4 — Adversarial Audit Corrections] — Two Critical, One High, One Major Cross-Sprint Finding, All Closed

A requested adversarial audit of the Sprint 4 CMS implementation found and led to fixing:

### Fixed — Critical
- **CMS RLS write-granularity bypass**: an actor holding only `content.create` could perform ANY status transition (including `approved → published`) via a direct client write, bypassing the fine-grained permission mapping that only existed in TypeScript. Live-confirmed before the fix.
- **Actor-field forgery**: `reviewed_by`/`approved_by`/`published_by` could be set to an arbitrary user id via the same direct-write path. Live-confirmed before the fix.
- Both closed by migration `0019`: removing all direct `INSERT`/`UPDATE` RLS policies on the four CMS tables, forcing every write through a new atomic `app_cms_transition()` function whose `p_actor_id` is always the App Backend's own resolved identity. See ADR-018.

### Fixed — High
- `CmsContentWorkflowService.list()` had no permission check at all — any authenticated user, any role, could enumerate non-published CMS content for their own campus. Fixed with an explicit "holds any content.* permission" gate.
- CMS status-update and audit-log write were two separate, non-atomic Supabase calls — now one atomic transaction via `app_cms_transition()`.

### Fixed — Major, Cross-Sprint (discovered while verifying the above)
- **The PUBLIC EXECUTE grant gap**: every `revoke execute ... from authenticated, anon` statement since Sprint 2 (`app_write_school_config`, `app_set_current_academic_session`, `app_set_current_term`, `app_transfer_enrollment`, `app_cms_transition`) has been silently ineffective, because Postgres grants EXECUTE to the `PUBLIC` pseudo-role by default and no migration ever revoked from `PUBLIC` specifically. **Live-confirmed exploitable**: an `accountant` successfully called `app_write_school_config()` directly, bypassing `ConfigService`'s ajv validation entirely. Fixed by migration `0020`, revoking EXECUTE from `PUBLIC` on all five affected functions and re-granting explicitly to `service_role`. See ADR-019 for the full, unsoftened account of what this means for Sprint 2/3's prior "live-verified" claims.

### Fixed — Medium
- Design System Contract typography ("Source Serif 4", "Inter") was referenced in CSS but never actually loaded — fixed via `next/font/google`. Production-build verification of this specific fix is blocked by this development sandbox's network restrictions (not a defect in the fix itself) — see ADR-020.

### Explicitly NOT resolved — flagged for your decision, not silently chosen
- **Global (non-campus-scoped) visibility of published content** remains as originally implemented and documented in migration `0017`. Whether this is the intended behavior for a future multi-campus deployment or should be campus-scoped is a product decision, not a code defect — not changed without your explicit instruction.

### Added — Test Coverage
- **A dedicated, standalone regression suite** (`rls_public_grant_regression_tests.sql`, 14 tests) specifically for the PUBLIC-grant class of bug: checks `has_function_privilege('public', ..., 'EXECUTE')` is `false` and `has_function_privilege('service_role', ..., 'EXECUTE')` is `true` for all five affected functions, plus one end-to-end functional re-run of the original exploit scenario. This check is deliberately more explicit than a functional "expect throw" test alone — it fails immediately and specifically the moment any future migration reintroduces this exact class of gap, rather than requiring someone to notice and diagnose a functional test failure.
- Corrected 4 parameter-order bugs and 1 stale `plan()` count in `rls_cms_tests.sql`, found while adding the above (my own reordering attempt initially introduced new bugs before being reverted to match the correct, pre-existing function signature).
- Removed a duplicate, conflicting `0019` migration file created during this response before discovering a correct one already existed — the correct file (`0019_cms_audit_corrections.sql`) was kept; my incorrect duplicate was deleted.

### Verified (live, from a clean database reset)
- All 20 migrations apply cleanly, in order.
- **87/87 pgTAP tests pass** across all 5 suites (17 identity + 14 config + 21 academic + 18 CMS + 14 PUBLIC-grant regression, exact counts as of this correction).
- **83/83 backend Jest tests pass.** Backend `tsc --noEmit` and `eslint --max-warnings=0` clean.
- **11/11 frontend Jest tests pass.** Frontend `tsc --noEmit` and `eslint --max-warnings=0` clean.
- The original `app_write_school_config` exploit was re-run against the corrected schema and now fails with `permission denied for function app_write_school_config`, confirming closure by direct reproduction rather than by re-reading a prior report.

## [Sprint 5A] — Admissions Schema: Live Verification and Hardening

### Added
- `0025_admissions_anon_write_revoke.sql` — closes `anon` writes on `guardians`/`guardian_students`.
- `0026_privilege_hardening.sql` — project-wide: no `anon` writes, no TRUNCATE/REFERENCES/TRIGGER for `anon`/`authenticated`, on every public table; future tables start closed (ADR-023).
- `tests/rls_admissions_tests.sql` (67), `tests/rls_privilege_hardening_tests.sql` (7); 6 new tests in `rls_public_grant_regression_tests.sql`.
- `local-test-harness/run_all.sh` (reproducible reset/apply/test) and `concurrency_conversion_check.sh` (two-session check).
- `docs/SPRINT_5A_VERIFICATION_REPORT.md`; ADR-021, ADR-022, ADR-023.

### Changed
- `0024`: `app_convert_application` now requires a class of the level applied for, takes the enrollment session from the class (the `p_academic_session_id` parameter was removed), and serializes admission-number assignment per campus with an advisory lock.
- `rls_config_tests.sql`: two stale assumptions about direct `school_config` UPDATEs corrected (migration `0009` revokes UPDATE).
- Harness: faithful model only; the post-migration grants stub (`01_supabase_platform_grants_stub.sql`) was retired (ADR-021).

### Verified (live, PostgreSQL 16, from a clean database)
- Migrations `0001`–`0026` apply cleanly; **167/167 pgTAP tests** pass across 7 suites.
- Each fix mutation-checked (reverting it fails the suite); concurrency check passes with the lock and fails without it.

### Not verified
- Not run on a real Supabase project. Jest not re-run in this step (no backend changes).

## [Sprint 5B — Step 2] — Admissions backend: types, repository, fake

### Added
- `apps/api/src/modules/admissions/admissions.types.ts` — domain types (`Application`, `ApplicationDocument`, `ConversionResult`, …), `ApplicationStatus`, and the `admissions.applications.read|manage` permission keys seeded by migration 0023.
- `apps/api/src/modules/admissions/admissions.repository.ts` — `IAdmissionsRepository`, `SupabaseAdmissionsRepository`, row mappers, `escapeIlike`, and `AdmissionsRuleViolationError` (ADR-024). State changes go only through the two atomic functions; the repository never writes `status` or `reference_no`.
- `apps/api/test/fakes/fake-admissions.repository.ts` — in-memory stand-in reproducing the database's transition table, rejection messages, per-campus numbering and case-insensitive guardian reuse.
- `apps/api/test/admissions.repository.spec.ts` (26) and `fake-admissions.repository.spec.ts` (16) — mappers, RPC parameter-name contract, error classification, query construction, and the fake pinned to the scenarios verified against PostgreSQL.
- 4 pgTAP tests in `rls_admissions_tests.sql`: the SQL side of the RPC contract and the `ILIKE` escaping behavior the duplicate lookup relies on.

### Changed
- `run_all.sh`: preflight starts a stopped local Postgres or fails with a clear message (it previously failed silently).

### Verified
- `tsc` clean, `eslint --max-warnings=0` clean, **125/125 Jest tests** (83 existing + 42 new), **167/167 pgTAP tests**.

### Not included (by design, next steps)
- Services, controller and module wiring (Steps 3–4). The admissions module is not yet registered in `app.module.ts`, so nothing is exposed over HTTP yet.

## [Sprint 5B — Step 3] — Admissions services

### Added
- `supabase/migrations/0027_application_class_definition_campus.sql` — an application can no longer name a level (`class_definition`) from another campus; enforced by the database, not only the service. Mutation-checked (removing it fails the admissions suite).
- `admissions.validation.ts` — validates and normalises a submission, collecting every problem into one 400: names (trimmed, unicode-safe, must contain a letter), real calendar date of birth (not future, at most 25 years old), optional gender (`female`/`male`), email (stored lower-case), phone (7–15 digits), at least one guardian contact, up to 10 `https` document URLs without credentials.
- `AdmissionsSubmissionService` — the public intake trust boundary. Returns a minimal receipt (never the duplicate flag); a level that does not exist and one from another campus produce the same answer; a duplicate (same child in the same campus) is flagged, never blocked; a failure attaching one document does not lose the application and the receipt reports how many were stored.
- `AdmissionsReviewService` — list/get, `startReview`, `requestInfo` (notes required), `resumeReview`, `approve`, `reject` (reason required), `convert`. Order of refusal: 403 → 400 → 404 → 409. Another campus's application is "not found", identical to a missing one. A database rule rejection after the pre-check is a 409. Conversion pre-validates the class (exists in the actor's campus, right level).
- `findClassDefinition` on the repository, fake and specs.
- 118 new Jest tests across 5 admissions suites; one safety property each for campus isolation, the manage gate, the read gate and the required rejection reason was mutation-checked.

### Changed
- The in-memory fake now generates UUID-shaped ids like the database, and enforces the 0027 rule.

### Verified
- `tsc` clean, `eslint --max-warnings=0` clean, **201/201 Jest tests**, **168/168 pgTAP tests**, concurrency check passing.

### Not included (by design, next step)
- Controller, DTO wiring and module registration (Step 4). Nothing is exposed over HTTP yet; rate-limiting the public submission route belongs with the controller/deployment.

## [Sprint 5B — Step 4] — Admissions controllers, module wiring, and startup fixes

### Added
- `AdmissionsController` (staff) and `PublicAdmissionsController`, `AdmissionsModule`, registered in `AppModule`. Staff: `GET /api/v1/admissions/applications[?status]`, `GET …/:id`, `POST …/:id/{start-review,request-info,resume-review,approve,reject,convert}`. Public: `POST /api/v1/public/admissions/applications` (rate-limited, write-only).
- `src/app.setup.ts` (`configureApp`) and `src/config/trust-proxy.ts` (`TRUST_PROXY`); `main.ts` now uses them (ADR-026).
- `tsconfig.build.json` — source-only production build.
- Tests: `admissions.http.spec.ts` (28), `app.boot.spec.ts` (3), `trust-proxy.spec.ts` (14).
- Dependencies: `@nestjs/throttler`, `class-validator`, `class-transformer`; dev: `@nestjs/testing`, `supertest`, `@types/supertest`.
- `docs/SPRINT_5_COMPLETION_REPORT.md`; ADR-026; rollback strategy extended to migrations 0001–0027.

### Fixed (pre-existing, found by booting the real application for the first time)
- The API could not start: `class-validator`/`class-transformer` missing (`main.ts`), `AuditController` could not be injected, and `npm start` pointed at a file the build never produced.

### Verified
- `tsc` clean, `eslint --max-warnings=0` clean, production build emits `dist/main.js`, **246/246 Jest tests**, **168/168 pgTAP tests**.
- The compiled server was run as a real process and exercised over the network. Mutation-checked: removing the throttler guard or `@Public()` from the public route fails the HTTP suite.

### Not verified
- Not run against a real Supabase project; the database was faked at the HTTP layer and verified separately by pgTAP.

## [Sprint 5 — Close-out] — Real-stack integration verification, one verification command, CI

### Added
- `supabase/local-test-harness/`: `install_postgrest.sh` (pinned, checksum-verified PostgREST 12.2.3), `rest-v1-proxy.js`, `integration_fixtures.sql`, `run_integration.sh`.
- `apps/api/test-integration/admissions.int.spec.ts` (29 tests) with `jest.integration.config.js` and `npm run test:integration`: the repository and services through the real supabase-js → PostgREST → PostgreSQL path with real JWTs.
- `scripts/verify-all.sh` — the single command for everything; `.github/workflows/verify.yml` — CI that runs it.
- ADR-027.

### Changed
- Harness `auth.uid()` now matches Supabase's real definition (reads `request.jwt.claims` as well as `request.jwt.claim.sub`). The previous stub would have made RLS see no user under the real API layer.
- `jest.config.js` excludes `test-integration/` so `npm test` stays hermetic; `tsconfig.json` and `lint` cover the new folder.

### Verified
- Integration: **29/29** against PostgREST 12.2.3. Full `scripts/verify-all.sh --skip-web-build`: database (168 pgTAP + concurrency), API (typecheck, lint, 246 Jest, build), integration, web (typecheck, lint, 11 tests) — all pass. Mutation-checked: reverting the `auth.uid()` fix fails three integration tests. `verify-all` itself checked to fail, continue and exit non-zero when a step breaks.

### Not verified
- Hosted Supabase project, real GoTrue login tokens, Supabase's gateway; the GitHub workflow has not been run on GitHub; `next build` needs internet (Google Fonts) so it was not run in the offline sandbox.

## [Sprint 5 — Hosted readiness] — security fix, current-Supabase compatibility, smoke test

### Security
- **`0029`: `student_current_enrollments` bypassed row-level security** and was readable by unauthenticated callers (every campus's enrollments). Now `security_invoker`, least-privilege grants, regression-tested at three levels.

### Fixed
- **Every authenticated API request failed (HTTP 500):** `SupabaseIdentityRepository` selected the non-existent `users.organization_id`; the organization is now read through the campus.
- Config write returned `key`/`category` as `undefined`; the repository now returns the complete value.

### Added
- `0028`: explicit per-table grants, so the platform works on current Supabase projects that no longer grant automatically. `run_all.sh --modern`, `compare_privilege_models.sh` (classic = current).
- `JwtVerificationService` supports asymmetric signing keys (JWKS) as well as the legacy HS256 secret; issuer/audience enforced; 503 on key-retrieval outage; `SUPABASE_JWT_SECRET` now optional; `SUPABASE_JWKS_URL`, `SUPABASE_JWT_ISSUER`. `jose` added; supabase-js floor `^2.112.3`.
- `scripts/smoke-test.mjs`, `supabase/smoke/hosted_audit.sql`, `docs/HOSTED_SMOKE_TEST.md`; local stand-in gateway and `run_smoke_selftest.sh`.
- Integration sweep of every repository (`repositories.int.spec.ts`); `run_integration.sh --modern`.
- Tests: 9 view-exposure + 4 sweeps (pgTAP), 30 verifier, 7 env, 5 JWKS HTTP (Jest), 24 integration.
- ADR-028; rollback strategy extended to 0029.

### Verified
- See `docs/SPRINT_5_COMPLETION_REPORT.md` for the final tallies; every fix was mutation-checked (reverting it fails a test).

### Not verified
- A real hosted Supabase project (run the smoke test), real GoTrue login, Supabase's gateway; the GitHub workflow has not run on GitHub; `next build` needs internet.
