# Faith Foundation Schools Platform — Implementation Status

*Living document. Updated at the end of every sprint. Last updated: Sprint 5A verified and hardened (database layer); Sprint 5 complete and closed out: admissions (migrations 0021–0027, services, routes), startup fixes, real-stack integration suite, one verification command and CI.*

---

## Completed

### Sprint 1 — Identity & RBAC Foundation
- Tenancy schema: `organizations`, `campuses`
- Identity schema: `users` (Supabase Auth bridge, no credential columns)
- RBAC schema: `roles`, `permissions`, `role_permissions`, `user_roles`
- Audit schema: `audit_logs` (append-only, no UPDATE/DELETE grants)
- Deny-by-default RLS on all seven tables above, with helper functions (`app_current_user_id`, `app_current_campus_id`, `app_has_permission`)
- App Backend (NestJS): JWT verification, identity resolution, `SupabaseAuthGuard` (global), `PermissionGuard` (permission + cross-tenant IDOR check), `RbacService` (role assignment with audit logging)
- Endpoints: `GET /api/v1/me`, `POST /api/v1/admin/users/:userId/roles`, `GET /api/v1/organizations/mine`, `GET /api/v1/audit-logs`
- Seed data: system roles/permissions, real tenant with `[CONTENT REQUIRED]` placeholder for campus name, DEMO DATA seed template
- Tests: 20 Jest unit tests + 17 pgTAP RLS tests (written, execution pending — see Known Limitations)

### Sprint 2 — School Configuration System (corrected)
- Schema: `config_definitions` (code/migration-controlled catalogue), `school_config` (campus-scoped values), `config_audit_log` (append-only)
- New enums: `config_category`, `config_data_type`
- Atomic write path: `app_write_school_config()` Postgres function (upsert + audit in one transaction), execute-revoked from the frontend role, and — per migration `0009` — the *only* write path at all, since the direct-write RLS policies that mistakenly allowed authorized frontend clients to bypass it have been removed
- Deny-by-default RLS, with read/write permission looked up dynamically from each `config_definitions` row rather than hardcoded per policy
- New permissions: `config.{academic,finance,school,examination}.{read,write}` (8 total), granted per the approved RBAC delta
- Seeded 4 illustrative config keys (one per category), each schema-validated end to end
- App Backend: `ConfigService` (ajv JSON-Schema validation + per-definition permission enforcement), `ConfigController`
- **Corrective migration `0009_sprint2_corrections.sql`**, added after live RLS testing surfaced two real bugs — see "Live Verification" below
- Tests: 32 Jest unit tests (full project total) + **31 pgTAP RLS tests, actually executed against a real local Postgres 16 instance** (not merely written — see below)

## Live Verification (Sprints 1 & 2)

Previously reported as "written but not executed, no live database available." That has changed: this sandbox has PostgreSQL 16 with `pgtap`/`pg_prove` pre-installed. A reproducible local harness now exists under `supabase/local-test-harness/`:
- `00_auth_stub.sql` — minimal Supabase-parity `auth` schema (`auth.users`, `auth.uid()`) + `pgcrypto`/`pgtap` extensions

**Full reproducible sequence:** `supabase/local-test-harness/run_all.sh` (reset → default privileges → auth stub → all migrations → every pgTAP suite). The earlier post-migration grants stub was retired (ADR-021).

**Result: 31/31 pgTAP tests passing** (17 identity/RBAC + 14 config), from a genuinely clean database reset, against the actual committed migrations.

**Two real bugs were found and fixed during this process** (both confirmed via manual reproduction before being treated as real, and both fixed via a new corrective migration rather than editing already-shipped migration files):
1. **`campuses` RLS self-recursion** (migration `0002`): a policy selected from `campuses` inside its own `USING` clause without `SECURITY DEFINER` protection, causing `infinite recursion detected in policy for relation "campuses"` on any query touching campuses, including indirectly via a foreign-key check. Fixed in `0009` with a `SECURITY DEFINER` helper function, matching the pattern already used elsewhere.
2. **`school_config` direct-write bypass** (migration `0006`): RLS policies allowed an *authorized* frontend client to write directly to `school_config`, bypassing both ajv schema validation and the audit trail (`config_audit_log` entries are only produced by `app_write_school_config()`). Reproduced live: an accountant wrote an out-of-schema value directly and it went completely unaudited. Fixed in `0009` by removing the direct-write policies entirely — all writes now go exclusively through the service-role RPC function.

Two test-authorship bugs (not product bugs) were also found and corrected: a `throws_ok` assertion misused for an RLS-blocked `UPDATE` that correctly affects zero rows rather than raising, and a fixture that incorrectly assumed `school_administrator` holds `rbac.manage` (only `super_admin` does, per the actual Sprint 1 seed).

## In Progress
- None — Sprint 4 audit corrections are complete and live-verified.

## Sprint 4 Adversarial Audit — Summary (see docs/SPRINT_4_AUDIT_CORRECTIONS_REPORT.md for full detail)
- **Two Critical findings** (CMS RLS write-granularity bypass; actor-field forgery) — fixed via migration `0019`, closing all direct client writes to CMS tables.
- **One High finding** (`list()` had no permission check) — fixed.
- **One Major, cross-sprint finding**: `EXECUTE` on 5 atomic RPC functions across Sprints 2/3/4 was never actually restricted to `service_role`, due to Postgres's default `PUBLIC` grant never being revoked by any prior migration. Live-confirmed exploitable (ajv validation bypass via direct `app_write_school_config()` call). Fixed via migration `0020`. **This means Sprint 2 and Sprint 3's prior "callable only by service-role" claims were incorrect for the entire time between deployment and this fix** — stated plainly in ADR-019, not minimized.
- One Medium finding (typography not loaded) fixed; one Medium finding (global public-content visibility across campuses) deliberately left unresolved pending your explicit product decision.
- All findings verified live: 87/87 pgTAP (up from 67 — includes a new dedicated 14-test regression suite for the PUBLIC-grant class of bug specifically), 83/83 backend Jest (up from 81), 11/11 frontend Jest, 20/20 migrations clean from a fresh reset.

## Sprint 5A — Admissions Schema (verified live and hardened)
- Migrations `0021`–`0029`: students extension (admission_no, dob, gender, photo, lifecycle constraint), `guardians`, `guardian_students`, `applications` (status workflow, immutable identity, auto reference number), `application_documents` (URL reference only), RLS, permissions seed, two service-role-only atomic functions (`app_application_transition`, `app_convert_application`), `anon` write revoke, a project-wide privilege hardening, and a campus-consistency trigger on applications (`0027`).
- Verified on PostgreSQL 16: **181/181 pgTAP tests** across 8 suites on both a classic and a current-style Supabase project, a two-session concurrency check, and a 53-test integration suite against real PostgREST. No open findings. See `docs/SPRINT_5A_VERIFICATION_REPORT.md` and ADR-021–023.
- `app_is_guardian_of_student()` is no longer a stub (real body in `0022`).
- Sprint 5B (backend) — **complete.** Admissions types, repository, fake, validation, public **submission service**, staff **review service**, controllers and module wiring (`/api/v1/admissions/*` for staff, `POST /api/v1/public/admissions/applications` public and rate-limited). 246 Jest tests including an HTTP-level suite and a real-`AppModule` boot test. Fixes three pre-existing startup defects (ADR-026). See `docs/SPRINT_5_COMPLETION_REPORT.md`.

## Upcoming (per approved roadmap)
- **Sprint 5 (Admissions):** owns extending the `students`/`staff` stub tables (Sprint 3) into full records, plus `guardian_students` (which will replace the `app_is_guardian_of_student()` stub function's body — no RLS policy rewrite needed), plus the real admissions application workflow
- Sprints 6–15: per the Final Sprint Roadmap (Final Architecture document, Section O)

## Blocked
- None currently blocking Sprint 5 start.

## Incomplete / Deferred Within Completed Sprints' Own Scope
- **Campus display name:** still seeded as `[CONTENT REQUIRED]`.
- **`academic.max_class_size` has no enforcement logic yet** — still just stored/validated (Sprint 2), no enrollment-capacity check wired up yet.
- **Down-migrations / formal rollback procedures** for `0001`–`0014` are not yet written.
- **`app_is_guardian_of_student()` is a stub, always `false`** — RLS policies for enrollments/students already reference it, so Sprint 5 only needs to replace the function body once `guardian_students` exists, not rewrite any policy. **[Resolved in Sprint 5A: real body in migration `0022`.]**
- **`class_subjects` write-path service method exists but has no dedicated controller test** — covered indirectly by `ClassesService`, no direct unit test written for `linkSubjectToClass` specifically (low-risk, thin pass-through).

### Sprint 3 — Academic Core
- **Minimal dependency flagged and built:** `students`/`staff` stub tables (bare FK anchors only — id, campus_id, nullable `users_id` link, display name) since `enrollments`/`teacher_assignments` need valid foreign keys and the full "People" domain is Sprint 5's job. Documented in migration `0010`'s header and the Sprint 3 Completion Report.
- Schema: `academic_sessions`, `terms` (with cross-table date/campus validation via trigger), `class_definitions`, `classes`, `subjects`, `class_subjects`, `enrollments` (historical, append-only, protected by 3 separate mechanisms — unique partial index, consistency trigger, immutability trigger), `teacher_assignments`
- `student_current_enrollments` — the sanctioned view for deriving "current class"; **no `students.current_class` column exists anywhere**, as required
- Two atomic Postgres functions: `app_set_current_academic_session`/`app_set_current_term` (atomic current-session/term swap), `app_transfer_enrollment` (atomic close-old/open-new)
- RLS: the centerpiece is `app_is_assigned_to_class()` — every teacher-facing policy checks an actual `teacher_assignments` relationship, never role name alone
- New permissions: `academic.sessions.{read,write}`, `academic.classes.{read,write}`, `academic.enrollments.{read,manage}`, `academic.teacher_assignments.{read,manage}` (8 total)
- App Backend: `AcademicModule` — `SessionsService`, `ClassesService`, `EnrollmentService` (the historical-integrity-critical one, with an explicit relationship-based authorization check since it runs under the service-role connection where RLS doesn't apply), `TeacherAssignmentService`, `AcademicController`
- Tests: 22 new Jest unit tests (54 total) + 19 new pgTAP RLS tests (50 total), **all actually executed against live Postgres**

### Sprint 3 Re-Audit — Three Real Gaps Found and Closed
- Migration `0015`: database-level cross-campus trigger for `class_subjects`
- Fixed cross-campus IDOR gaps in `EnrollmentService` (both read methods) and `ClassesService.linkSubjectToClass` — none were exploitable in the current single-campus deployment, but all three were genuine defects in the tenancy-isolation guarantee
- New: 5 `class_subjects` tests, 3 new `EnrollmentService` IDOR tests, 1 new live pgTAP test
- `docs/MIGRATION_ROLLBACK_STRATEGY.md` — full rollback/recovery documentation for migrations `0001`–`0015`
- Verified live: 52/52 pgTAP, 63/63 Jest, from a clean database reset

### Sprint 4 — Design System Contract + CMS + Public Website (begins)
- `docs/DESIGN_SYSTEM_CONTRACT.md` — ratified visual/interaction specification (brand tokens, typography, spacing, breakpoints, two density modes, full component catalogue, accessibility baseline). Governs both the public site and the future authenticated platform from one token set.
- Database: `cms_pages`, `cms_news`, `cms_gallery`, `cms_staff_profiles` — four structurally-identical content types sharing one workflow (`draft → in_review → approved → published → archived`), a shared database trigger validating transitions independent of RLS/permission checks, deny-by-default RLS with a genuinely public read path (published content readable by the `anon` role, no auth) (migrations `0016`–`0018`)
- Backend: `CmsModule` — `CmsContentWorkflowService<T>` (the one shared workflow engine for all four content types), per-type repositories, `CmsController` (authenticated authoring/workflow routes for `cms_pages`, the reference implementation) and `PublicCmsController` (genuinely unauthenticated published-content reads via a new `@Public()` decorator + `SupabaseAuthGuard` opt-out mechanism)
- **Real gap found and fixed during this sprint** (see Changelog/ADR-015): `CmsContentWorkflowService.requireRecord` had no campus check at all — same class of bug as the Sprint 3 re-audit findings, caught proactively this time rather than needing a separate audit request
- **A real migration syntax bug** found and fixed by live execution: all four CMS status-transition triggers had a duplicated `on <table>` clause that would have failed on first real application
- New: `apps/web` — a real Next.js 14 App Router application, consuming the Design System Contract's tokens directly as CSS custom properties. One page (Home) implemented; further pages are explicitly Sprint 4.x/5 scope, not built here (see Completion Report, "Architecture Deviations")
- Tests: 6 new Jest tests on the backend (guard + CMS cross-campus), 11 new Jest tests on the frontend (component + page level, all asserting real/verified content only and honest empty states — never fabricated copy), 15 new pgTAP tests (67 total across all 4 suites, all executed live)

---

## Open Decisions Awaiting Your Input (carried forward, non-blocking for Sprint 5)
- Result-workflow role mapping (Head Teacher vs. Exam Officer review step)
- Content Editor role: standalone vs. delegated Admin permission subset
- Exam-window RPO target confirmation
- Result-correction visibility policy (silent vs. "corrected on [date]" indicator)
- Blueprint adoption policy (mandatory vs. advisory for formal exams)
- Discussion/interaction feature timing (V1.1 vs. near-launch)
- Expected concurrent CBT load
- Hosting/infra preference
- SMS/WhatsApp provider preference
- **New this sprint:** interim admissions contact details (phone/email) for the public site's Admissions section, pending the real Admissions system (Sprint 5)
- **New this sprint:** phone number, email, and social media links for the site footer

