# Faith Foundation Schools — Design System Contract
## Ratified Prior to UI Implementation (Sprint 4)

*Per the Final Architecture document, Section L: "Future sprints must consume this system rather than inventing independent UI patterns." This is the authoritative visual/interaction specification for both the public website and the authenticated platform, sharing one token set expressed through two density modes.*

---

## 1. Brand Tokens

```css
:root {
  /* Primary — Royal Blue. Trust, academic authority. */
  --color-primary-50:  #eef2fb;
  --color-primary-100: #d6e0f5;
  --color-primary-300: #7d95d9;
  --color-primary-500: #2d4494;   /* Royal Blue — primary brand color */
  --color-primary-700: #1f3068;
  --color-primary-900: #131d40;

  /* Secondary — Gold. Achievement, warmth. Used as ACCENT, never large fills. */
  --color-gold-50:  #fdf8ec;
  --color-gold-300: #e9c667;
  --color-gold-500: #c9a13a;   /* Gold — accent only */
  --color-gold-700: #96751f;

  /* Neutral / ink scale */
  --color-ink-50:  #f8f9fb;
  --color-ink-100: #eef0f4;
  --color-ink-300: #c3c9d4;
  --color-ink-500: #6b7280;
  --color-ink-700: #374151;
  --color-ink-900: #111827;

  /* Semantic */
  --color-success: #1f7a4d;
  --color-warning: #b8860b;
  --color-error:   #b3261e;
  --color-info:    #2d4494;   /* reuses primary — one blue, not two */
}
```

**Usage rule:** Gold never fills a background larger than a button, badge, or thin border/accent line. Large gold fills read as gaudy at scale — this is a deliberate constraint, not an oversight.

---

## 2. Typography

| Role | Family | Notes |
|---|---|---|
| Display / Headings | A humanist serif (e.g. "Source Serif 4" or equivalent) | Conveys "established institution." Used for H1–H3 only. |
| Body / UI | A clean humanist sans (e.g. "Inter" or equivalent) | All body text, UI labels, forms, tables — must read well at small sizes on low-end Android screens. |

**Scale** (rem, 16px base):
```
--text-xs:   0.75rem   (12px)
--text-sm:   0.875rem  (14px)
--text-base: 1rem      (16px)  — minimum body size, never smaller
--text-lg:   1.125rem  (18px)
--text-xl:   1.5rem    (24px)
--text-2xl:  2rem      (32px)
--text-3xl:  2.75rem   (44px)  — public hero headings only
```

Line height: 1.5 for body, 1.2 for headings. Never justify text.

---

## 3. Spacing & Grid

8px base unit: `--space-1: 0.5rem` through `--space-12: 6rem`, in steps of 1 (4px half-steps permitted only for icon/text alignment, never for layout rhythm).

**Grid:** 12-column, max content width 1280px (public), full-bleed with a persistent nav rail (authenticated).

**Breakpoints:**
```
--bp-sm: 640px    (large phone)
--bp-md: 768px    (tablet)
--bp-lg: 1024px   (small laptop)
--bp-xl: 1280px   (desktop)
```
Design mobile-first. Every breakpoint above is a min-width query, never a max-width override of a desktop-first design.

---

## 4. Two Density Modes, One Token Set

| | Public | Application |
|---|---|---|
| Spacing scale | Generous — `--space-8`+ between sections | Tight — `--space-2`–`--space-4` typical |
| Typography | Larger, more display-weight usage | Smaller, body-weight dominant, data-dense |
| Imagery | Large hero/editorial photography | Icons and small avatars only |
| Purpose | Trust, storytelling, conversion | Productivity, clarity, speed-to-action |

Both consume the exact same color/spacing/type tokens above — never a second palette. A component library built for one must not need new tokens to serve the other, only different application of the same ones (larger padding, bigger type scale step, etc.).

---

## 5. Components

### Buttons
- **Primary:** solid `--color-primary-500`, white text, `--space-2`/`--space-4` padding, 6px radius.
- **Secondary:** outline `--color-primary-500`, transparent fill.
- **Gold accent (CTA only, sparingly):** solid `--color-gold-500`, `--color-ink-900` text — reserved for the single highest-priority action on a page (e.g. "Apply Now"), never more than one per screen.
- States: default, hover (8% darken), focus (2px `--color-primary-300` ring, always visible, never `outline: none` without a replacement), disabled (40% opacity, no hover), loading (spinner replaces label, button stays same width).

### Inputs / Forms
- Label always visible above the field (no placeholder-as-label).
- Border `--color-ink-300`, focus border `--color-primary-500` + ring.
- Error state: `--color-error` border + inline message below field, referenced via `aria-describedby`.
- Every field has a real, associated `<label>` — accessibility non-negotiable.

### Cards
- White surface, `--color-ink-100` border or subtle shadow (never both heavily), 8px radius, `--space-4`–`--space-6` internal padding depending on density mode.

### Tables (application density primarily)
- Sticky header, zebra striping optional but subtle (`--color-ink-50`), row hover highlight, right-aligned numeric columns.

### Navigation
- Public: horizontal top nav, mobile hamburger below `--bp-md`.
- Application: persistent left rail, collapsible below `--bp-lg`, role-aware (only shows sections the current role can access — this is UX convenience, never the actual security boundary).

### Modals
- Centered, max-width 480px (confirmation) or 720px (form), backdrop `rgba(17,24,39,0.5)`, focus-trapped, `Escape` closes, initial focus on the primary action or first field.

### Notifications / Toasts
- Top-right on desktop, full-width top on mobile. Success (`--color-success`), error (`--color-error`), info (`--color-primary-500`) variants, auto-dismiss 5s for success/info, manual-dismiss only for error.

### Badges
- Small, pill-shaped, used for status (e.g. enrollment status, CMS content status) — color mapped to semantic tokens, text always included (never color-only, for colorblind accessibility).

### Charts (application density)
- Primary series in `--color-primary-500`, secondary in `--color-gold-500`, never more than 4 series without a legend, always a text-alternative summary for screen readers.

### Empty / Loading / Error States
- **Empty:** an icon + one sentence explaining why it's empty + (where applicable) a primary action. Never a blank white area.
- **Loading:** skeleton shapes matching the eventual content's layout, not a generic spinner, for anything taking >300ms.
- **Error:** plain-language message (no stack traces, ever, per Architecture Section 42), a retry action where meaningful.

---

## 6. Accessibility Baseline (WCAG-Aligned)

- Contrast: body text ≥ 4.5:1, large text (`--text-xl`+) ≥ 3:1 — `--color-primary-500` on white passes both; verify any new color pairing before shipping.
- Every interactive element has a visible focus state (the ring described above) — never removed without an equally visible replacement.
- All images have `alt` text; decorative images use `alt=""`.
- Forms: every input has a programmatically associated label; errors are announced via `aria-live` regions.
- Keyboard navigation: full tab-order coverage, no keyboard traps, modal focus-trapping as specified above.
- Color is never the only signal (status badges carry text, not just color).

---

## 7. Governance Rule

Once ratified, this contract is the single source of visual truth. A future sprint needing a new component pattern **extends this document first** (reviewed the same as a schema change would be), rather than inventing a one-off pattern inside a feature. Component implementations live in a shared package (`packages/ui`, per the Final Architecture's folder structure) consumed by both the public site and the authenticated platform — never duplicated per-app.
