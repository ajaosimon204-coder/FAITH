# Deploying the API

The API is a standard Node.js (NestJS) service. It needs a host that runs Node 20+ and gives it HTTPS. It keeps no files and no state of its own (all data lives in Supabase), so any host works and you can move later.

**Recommended for a first deployment: Render** (or Railway — the steps are nearly identical). They deploy straight from GitHub, provide HTTPS and a free subdomain, and need no server administration. The steps below follow each platform's normal workflow but have **not been run from here**; the API itself *was* tested exactly as such a host starts it (clean install, build, start with only environment variables, `/health`).

## Before you deploy

1. **Supabase is ready**: migrations 0001–0029 applied (see `docs/HOSTED_SMOKE_TEST.md`).
2. **Your code is on GitHub** in a *private* repository. `.gitignore` already keeps `node_modules`, build output and any `.env` file out. Never commit a secret key.
3. **Have these values ready** (Supabase dashboard → Project Settings → API / API Keys): the project URL, and the **secret key** (`sb_secret_…`). The secret key is the one value that must never leave the server or a chat.

## Deploy on Render

1. render.com → **New → Web Service** → connect your GitHub repository.
2. Settings:

   | Setting | Value |
   |---|---|
   | Root Directory | `apps/api` |
   | Runtime | Node |
   | Build Command | `npm ci && npm run build` |
   | Start Command | `node dist/main.js` |
   | Health Check Path | `/health` |
   | Instance type | a paid one (**not** the free tier: it sleeps when idle, so the first applicant each time waits ~30 s) |
   | Region | the one closest to your Supabase project |

3. **Environment** (add each): `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`, `TRUST_PROXY=1`, `CORS_ORIGIN` (your web app's address), and `NODE_VERSION=22`. See `apps/api/.env.example` for what each means. Do **not** set `PORT` (Render sets it). Do **not** set `SUPABASE_JWT_SECRET` on a current project.
4. **Create Web Service.** The first build takes a few minutes. It is live when the dashboard shows "Live" and `https://<your-service>.onrender.com/health` returns `{"status":"ok"}`.
5. **Auto-deploy**: in the service settings choose to deploy only after your checks pass (the repository's GitHub workflow, `.github/workflows/verify.yml`, runs everything), so a broken change never reaches production.

## Deploy on Railway (alternative)

New Project → Deploy from GitHub repo → set the service's root directory to `apps/api`, build `npm ci && npm run build`, start `node dist/main.js`, add the same environment variables, and generate a public domain. Health check path: `/health`.

## After it is live

1. **Run the hosted smoke test** against the live address (`SMOKE_API_URL=https://<your-service>.onrender.com`). Follow `docs/HOSTED_SMOKE_TEST.md`. Do not announce the application form until it passes.
2. **Custom domain** (optional, e.g. `api.yourschool.example`): add it in the host's settings and create the DNS record it shows. If your Supabase project uses a custom auth domain, set `SUPABASE_JWT_ISSUER` accordingly (the smoke test tells you if the issuer differs).
3. **Point the web app** at the API address, and set `CORS_ORIGIN` to the web app's address exactly (scheme and host, no trailing slash).

## Operating it

- **Logs**: the host's log view. The API logs *why* a sign-in was rejected (never the token itself), which is the first place to look if staff cannot sign in.
- **Updating**: push to `main`; the host rebuilds and swaps in the new version.
- **Rotating a key**: change the environment variable on the host (it restarts automatically), then re-run the smoke test.
- **Scaling beyond one instance**: the submission rate limit is counted per instance (so the effective ceiling multiplies); move it to a shared store if you scale out (see ADR-026).
- **Cost**: roughly the price of one small always-on web service, plus Supabase.

## What the API does not need

No database of its own, no file storage, no scheduled jobs, no extra ports. If the host asks for any of these, leave them out.
