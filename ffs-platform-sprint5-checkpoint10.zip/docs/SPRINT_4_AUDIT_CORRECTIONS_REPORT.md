# Sprint 4 Audit Corrections Report
## Faith Foundation Schools Platform

*Follow-up to the Sprint 4 Adversarial Audit findings. All fixes described below have been applied and live-verified. No new features implemented — corrective work only.*

---

## Summary

The adversarial audit found 2 Critical, 2 High, and 2 Medium findings in the Sprint 4 CMS implementation. Fixing and verifying them live surfaced a third, larger issue: **a previously-undetected gap affecting every atomic RPC function since Sprint 2**, not just this sprint's new one. All findings below are now closed except one Medium finding, which is a product decision left explicitly to you rather than resolved unilaterally.

---

## Findings and Resolution

### Critical — CMS RLS write-granularity bypass
**Finding:** an actor holding only `content.create` could perform any CMS status transition (including `approved → published`) via a direct client write — the fine-grained permission-per-transition mapping only existed in TypeScript, never reaching the database layer.

**Fix (migration `0019`):** removed all direct `INSERT`/`UPDATE` RLS policies on the four CMS tables entirely. Every write now goes exclusively through a new atomic `app_cms_transition()` function.

### Critical — Actor-field forgery
**Finding:** `reviewed_by`/`approved_by`/`published_by` could be set to an arbitrary user ID via the same direct-write path — an attacker could fabricate audit metadata attributing actions to an uninvolved person.

**Fix:** closed by the same migration `0019` change. `app_cms_transition()`'s `p_actor_id` is always the App Backend's own resolved identity — there is no parameter through which a caller could specify a different "attributed actor" independent of who is actually authenticated.

### High — `list()` had no permission check
**Finding:** any authenticated user, any role, could call `CmsController.list()` and enumerate non-published CMS content (draft/in_review/approved/archived) for their own campus.

**Fix:** added an explicit "holds any `content.*` permission" gate to `CmsContentWorkflowService.list()`.

### High — Non-atomic write + audit
**Finding:** CMS status update and its `audit_logs` entry were two separate, sequential Supabase calls — a failure between them left a status change with no audit trail, and the Critical-1 exploit path bypassed `audit_logs` entirely.

**Fix:** both operations now happen in one transaction inside `app_cms_transition()`.

### Major, Cross-Sprint — The PUBLIC EXECUTE grant gap

This was found while live-verifying the fixes above, not something the original audit request anticipated.

**Finding:** every `revoke execute ... from authenticated, anon` statement written since Sprint 2 — on `app_write_school_config`, `app_set_current_academic_session`, `app_set_current_term`, `app_transfer_enrollment`, and the new `app_cms_transition` — has been **silently ineffective**. Postgres grants `EXECUTE` to the `PUBLIC` pseudo-role by default when a function is created. Every database role implicitly inherits whatever `PUBLIC` has. No migration, in any sprint, ever revoked from `PUBLIC` specifically.

**Live-confirmed exploitable:** an `accountant` role (whose only legitimate config permission is `config.finance.read`/`write`, not a blanket bypass) successfully called `app_write_school_config()` directly and wrote `"NOT-A-VALID-CURRENCY-BYPASSES-AJV"` as a currency value — a value `ConfigService`'s ajv schema validation would have rejected outright. This is the exact guarantee ADR-007 (Sprint 2) was written to protect, and it did not hold.

**Fix (migration `0020`):** revoked `EXECUTE` from `PUBLIC` explicitly on all five functions, and re-granted explicitly to `service_role` (which also only inherited access via `PUBLIC` before this fix — the re-grant was necessary, not optional).

**What this means for prior sprint reports, stated plainly:** Sprint 2's and Sprint 3's completion reports both claimed these functions were "callable only by service-role." That claim was false for the entire period between each function's creation and this fix. Every RLS test that exercised these functions and "confirmed" the restriction was testing `authenticated`/`anon` role privileges specifically — which is exactly the check that missed this, since those checks were individually correct and still insufficient. This is documented without softening in ADR-019.

### Medium — Typography not actually loaded
**Finding:** "Source Serif 4" and "Inter" were referenced in CSS `font-family` stacks but never loaded — every browser silently fell back to Georgia/system-ui.

**Fix:** loaded both via `next/font/google` in `layout.tsx`, exposed as CSS custom properties consumed by the existing token structure in `globals.css`.

**Honest caveat:** `tsc`, `eslint`, and the full Jest suite all pass with this change, but **`next build` could not be verified in this development sandbox** — `next/font/google` needs to fetch font metadata from `fonts.googleapis.com` at build time, and this environment's network egress proxy explicitly blocks that domain (`x-deny-reason: host_not_allowed`, confirmed directly via `curl`). This is a sandbox limitation, not a defect in the fix — it is the standard, Next.js-recommended way to self-host Google Fonts, and would build successfully in any normal deployment environment. **This should be verified once in a real CI/deployment pipeline before being considered fully closed.**

### Medium — Global public-content visibility across campuses
**Finding:** published CMS content is visible to any visitor regardless of which campus it belongs to (no campus filter on the public-read RLS policy) — documented as intentional in the original migration comment, but never confirmed with you as the actual desired product behavior.

**Not resolved — deliberately.** This is a product decision, not a code defect. I have not changed this policy. If a second campus/organization is ever onboarded, its published content would currently appear alongside every other campus's on any public read of these tables. Please confirm whether that's the intended behavior (a shared network-wide public feed) or whether it should be campus-scoped instead.

---

## A Process Error I Made During This Work

While applying these fixes, I initially wrote a new, redundant `0019` migration file without first checking whether one already existed from earlier in this session — one already did, correctly designed, and already applied. My duplicate had an incompatible function signature and briefly broke the migration sequence. I caught this via the live migration run failing with "function name is not unique," deleted my duplicate, and reverted a parameter-reordering "fix" I'd mistakenly applied to the test suite (which had actually been correct before I touched it). Noting this plainly rather than glossing over it — it's the same "inspect before modifying" discipline this project has required throughout, and I fell short of it in the moment before self-correcting.

---

## Test Coverage Added

- 6 tests directly exercising the two Critical CMS findings (RLS-layer, live).
- 1 Jest test for the `list()` permission gate.
- A dedicated, standalone 14-test regression suite (`rls_public_grant_regression_tests.sql`) for the PUBLIC-grant class of bug specifically — checking the grant table directly (`has_function_privilege`) for all five functions, not just a functional "expect failure" test, so a future regression fails immediately and specifically rather than requiring diagnosis.
- 4 parameter-order bugs and 1 stale `plan()` count fixed in the existing CMS test suite, found while adding the above.

---

## Final Verification (live, from a clean database reset)

```
Migrations:  20/20 apply cleanly, in order
pgTAP:       87/87 passing, across 5 suites (17 identity + 14 config + 21 academic + 18 CMS + 14 PUBLIC-grant regression)
Backend:     83/83 Jest passing, tsc clean, eslint clean
Frontend:    11/11 Jest passing, tsc clean, eslint clean
             next build: verified for correctness (tsc/eslint/tests), NOT verified for the font-loading
             step specifically, due to this sandbox's network restrictions (see above)
```

The original `app_write_school_config` exploit was re-run against the corrected schema and now fails with `permission denied for function app_write_school_config` — confirmed by direct reproduction, not by re-reading this report.

---

## Remaining Open Items

1. **Global public-content visibility** — awaiting your explicit decision (see above).
2. **`next build`'s font-loading step** — should be verified once in a real CI/deployment environment with normal network access.
3. Everything else from the original Sprint 4 Completion Report's "Remaining Work" section (unwired CMS routes for news/gallery/staff-profiles, CMS block-content renderer, remaining public site pages, CMS admin UI) is unchanged by this corrective pass.

---

**All Critical, High, and one Medium finding are closed and live-verified. One Medium finding awaits your decision. Stopping here per your process.**
