# Sprint 3 Completion Report
## Academic Core — Faith Foundation Schools Platform

---

## 1. Sprint Objective

Build the academic foundation: academic sessions/terms, class definitions, session-specific classes, subjects, historical student enrollments, and teacher assignments — with the historical model authoritative (no `students.current_class` field, ever) and teacher access strictly relationship-based (a Teacher role grants nothing by itself; a `teacher_assignments` row does).

---

## 2. What Was Implemented

- **Academic sessions & terms**, campus-scoped, with exactly-one-current enforced by partial unique indexes and cross-table date/campus validation via trigger.
- **Class definitions** (the level concept, e.g. "JSS 1") and **session-specific classes** (e.g. "JSS 1A" for 2025/2026), plus **subjects** and the **class↔subject** link table.
- **Enrollments** — the historically-critical table. A student's current class is *derived* via the `student_current_enrollments` view (active enrollment in whichever session is current), never stored. Protected by three independent mechanisms: a unique partial index (one active enrollment per student per session), a consistency trigger, and an immutability trigger (a closed enrollment's identity fields cannot be edited).
- **Teacher assignments** — `class_teacher` and `subject_teacher` roles, one class-teacher per class per session enforced by a partial unique index, role/subject pairing enforced by a CHECK constraint.
- **Two atomic Postgres functions**: `app_transfer_enrollment` (close old + open new enrollment atomically) and `app_set_current_academic_session`/`app_set_current_term` (atomic current-flag swap) — same reasoning as Sprint 2's `app_write_school_config`.
- **Backend**: `AcademicModule` with `SessionsService`, `ClassesService`, `EnrollmentService`, `TeacherAssignmentService`, and a single `AcademicController` exposing all of the above.
- **RLS**: built around one new helper, `app_is_assigned_to_class()` — every teacher-facing policy checks this, never a role name.

---

## 3. Database Changes

| Migration | Purpose |
|---|---|
| `0010_academic_core_schema.sql` | Tables, constraints, indexes, 4 triggers |
| `0011_academic_core_rls.sql` | RLS policies, `app_is_assigned_to_class()`, `app_is_student_self()`, `app_is_guardian_of_student()` (stub) |
| `0012_seed_academic_permissions.sql` | 8 new permissions, role grants |
| `0013_academic_helper_functions.sql` | Atomic set-current-session/term functions |
| `0014_enrollment_transfer_function.sql` | Atomic enrollment-transfer function |

**Required constraints implemented:** session/term date containment (trigger), class/session/campus agreement (trigger), enrollment/class/campus agreement (trigger), enrollment uniqueness (`students.id, academic_session.id` partial unique where active), enrollment history immutability (trigger), teacher-assignment uniqueness (expression unique index), one-class-teacher-per-class-per-session (partial unique index), role/subject CHECK constraint. **Required indexes**: on every foreign key and every RLS-relevant lookup column (campus_id, staff_id, student_id, class_id, session_id).

**No destructive migrations.** All 14 migrations to date are additive.

---

## 4. API/Backend Changes

New endpoints under `/api/v1/academic/`: session/term creation and current-setting, class-definition/class/subject creation and linking, enrollment (`enroll`, `transfer`, `withdraw`, current-class lookup, history lookup), teacher-assignment (create, remove, list-for-staff). Full list in `academic.controller.ts`.

**Notable design point:** `EnrollmentService`'s read methods run under the service-role connection (which bypasses RLS) and therefore re-implement the same relationship checks RLS enforces — documented in ADR-011. This means authorization is genuinely checked twice, by two independently-written code paths, and both are tested.

---

## 5. Frontend Changes

None — no frontend work has begun in any sprint to date; Sprint 4 is the first to touch the public site/design system.

---

## 6. RLS/Security Changes

- `app_is_assigned_to_class(class_id)` — the relationship-based access primitive. Every enrollment/student-facing teacher policy calls this, never `app_has_role('teacher')` (no such function exists in this codebase, deliberately).
- Deny-by-default RLS on all 8 new tables.
- No DELETE grant on `enrollments` at all (history is closed, never deleted). No UPDATE grant on `teacher_assignments` (corrections are delete+recreate, preserving an unambiguous "who was assigned when" trail).
- `students`/`staff` writable only by nothing at all for `authenticated` (Sprint 5 will need to open a controlled write path when it builds the real admission/HR workflow).

---

## 7. Tests Performed

- Unit tests (Jest) for `EnrollmentService` and `TeacherAssignmentService` against an in-memory fake repository.
- pgTAP RLS tests, actually executed against a live local Postgres 16 instance (not merely written).
- Full-stack re-verification: `tsc --noEmit`, `eslint --max-warnings=0`, full Jest run, all 14 migrations applied fresh, all 3 pgTAP suites run together from a clean database reset.
- Negative/IDOR tests specifically: unassigned-teacher denial (the central test of this sprint), cross-student denial, direct database write attempts by unauthorized roles, immutable-history mutation attempts.

---

## 8. Test Results

```
Jest:      54/54 passing (22 new)      tsc --noEmit: PASS      eslint: PASS
pgTAP:     50/50 passing (19 new), executed live via pg_prove
Migrations: 14/14 apply cleanly from a clean database reset
```

`EnrollmentService`: 98% statement coverage. `TeacherAssignmentService`: 93% statement coverage.

**One real (harness-only) bug found and fixed during this sprint's live verification**, documented in CHANGELOG/ADR-013: the local test harness's broad grant script was silently re-opening write paths that Sprint 1/2/3 migrations had revoked, because of a grant-vs-revoke ordering issue in the harness itself (not any application migration). Confirmed via direct `has_table_privilege()` checks before and after the fix — not just by re-running tests and seeing green, given how easy it would have been for this class of bug to produce a false-positive "RLS is enforcing this" result.

---

## 9. Files/Modules Changed

**New:** `supabase/migrations/0010`–`0014` (5 files), `supabase/tests/rls_academic_tests.sql`, `apps/api/src/modules/academic/*` (9 files: types, repository, 4 services, controller, module), `apps/api/test/enrollment.service.spec.ts`, `apps/api/test/teacher-assignment.service.spec.ts`, `apps/api/test/fakes/fake-academic.repository.ts`.
**Modified:** `apps/api/src/app.module.ts` (registered `AcademicModule`), `supabase/local-test-harness/01_supabase_platform_grants_stub.sql` (ordering fix), `docs/IMPLEMENTATION_STATUS.md`, `docs/CHANGELOG.md`, `docs/ADR_LOG.md`.
**Unmodified, confirmed reused as-is:** all Sprint 1/2 identity, RBAC, config, audit, organizations code — nothing was rewritten.

---

## 10. Known Issues

- `class_subjects` linking has service-layer logic (`ClassesService.linkSubjectToClass`) but no dedicated unit test — it's a thin pass-through with low behavioral risk, but flagged rather than silently omitted.
- Down-migrations still don't exist for any of the 14 migrations to date (a Sprint 2-era gap, still open).

---

## 11. Remaining Work

- Sprint 5 must extend `students`/`staff` from stubs into full records — expected to be additive only, per ADR-009.
- Sprint 5 must replace `app_is_guardian_of_student()`'s stub body once `guardian_students` exists — no RLS policy rewrite needed, by design.
- `academic.max_class_size` (Sprint 2 config value) still has no enforcement wired into `EnrollmentService.enrollStudent` — a reasonable Sprint 3.x/5 addition, not done here to avoid scope creep into a config-integration feature not explicitly requested this sprint.

---

## 12. Architecture Deviations

**One flagged, not silent, deviation:** `students` and `staff` tables were built now (Sprint 3) rather than Sprint 5, in deliberately minimal form (bare FK anchors only), because `enrollments`/`teacher_assignments` cannot exist without them. This was surfaced explicitly per your instruction to explain rather than silently expand scope — see ADR-009 for the full reasoning and the boundary of what was/wasn't built.

No other deviations. The historical-enrollment model, the relationship-based teacher-access model, and the absence of any `current_class` column all match your explicit Sprint 3 instructions exactly.

---

## 13. Content Still Required From the School

No new items this sprint — Sprint 3 seeded zero school-specific data (no real sessions, classes, or subjects were fabricated, per the No Fake Data rule). The existing open items (campus display name, real fee/academic-calendar content, etc.) carry forward unchanged from prior sprints' reports.

---

## 14. Recommended Next Sprint

Per the approved roadmap: **Sprint 4 — Design System Contract ratification, public website and CMS build begins.** This is a genuine shift in kind (first frontend/design work, first sprint touching the public-facing site) rather than a continuation of backend/schema work — worth confirming you want to proceed straight into it, or whether you'd rather sequence Sprint 5 (Admissions, which would upgrade the `students`/`staff` stubs from this sprint into real records) first, given Sprint 3 just built directly on top of that dependency.

---

**Sprint 3 implementation, testing, and documentation are complete. Stopping here per your process — awaiting your explicit approval before Sprint 4 begins.**
