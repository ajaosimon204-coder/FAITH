# Sprint 5A — Live Verification Report (Admissions Schema, Migrations 0021–0029; superseded in scope by ADR-028 and the completion report)

*Scope: database layer. Sprint 5B (backend services + controller) is tracked separately.*

## Result

Migrations `0001`–`0029` apply cleanly, in order, from an empty PostgreSQL 16 database. All **181 pgTAP tests pass**
across 7 suites, plus a two-session concurrency check. No open findings remain from this verification.

| Suite | Tests |
|---|---|
| `rls_identity_tests` | 17 |
| `rls_config_tests` | 15 |
| `rls_academic_tests` | 23 |
| `rls_cms_tests` | 18 |
| `rls_public_grant_regression_tests` | 20 (+6: the two admissions functions) |
| `rls_admissions_tests` (new) | 68 |
| `rls_privilege_hardening_tests` (new) | 7 |

Environment: PostgreSQL 16 + pgTAP in the dev container. **Not** run against a real Supabase project.

## Findings and how each was closed

| # | Finding | Resolution | Proof |
|---|---|---|---|
| 1 | `app_convert_application` did not require the class to match the level applied for (JSS 1 applicant could be placed into SS 1) | Fixed in `0024` | Reverting it fails admissions tests 46–48, 50, 60 |
| 2 | `0022` left `anon` write privileges on `guardians`/`guardian_students` | `0025` | Removing it fails admissions test 1 |
| 3 | `anon` held INSERT/UPDATE/DELETE on 27 public tables, and `anon`/`authenticated` held TRUNCATE/REFERENCES/TRIGGER on all of them, under Supabase default privileges. RLS blocked row access, but TRUNCATE is not subject to RLS. Not exploitable through the API; a privilege-layer gap | `0026` revokes across **every** public table (dynamic, no hand-kept list) and sets default privileges so future tables start closed | Removing it fails hardening tests 1, 2, 6, 7 |
| 4 | Sprint 2 `rls_config_tests` encoded a stale assumption (a direct UPDATE "matches zero rows"); migration `0009` actually revokes UPDATE, so it raises `permission denied` | Both statements corrected; the real assertion (stored value unchanged) is kept | Suite passes 15/15 on the faithful model |
| 5 | `app_convert_application` took `p_academic_session_id` separately from the class — a caller-supplied value that could only ever be wrong or redundant | Parameter removed; the enrollment takes the class's own session. Signature is now `(application, campus, class, actor)` | Admissions test asserts the enrollment session |
| 6 | Admission number was `count+1`: concurrent conversions could collide (failing one) | Per-campus transaction-scoped advisory lock serializes assignment; the unique index remains the backstop | `local-test-harness/concurrency_conversion_check.sh`: PASS with the lock; with the lock removed the second session fails with a unique violation |
| 8 | An application could name a level (`class_definition`) belonging to a different campus; nothing but a plain foreign key linked them. Conversion would later refuse it, but the inconsistent row could exist in the review queue. Found while designing Sprint 5B's submission service | `0027` trigger refuses it at insert, independent of the caller | Removing it fails admissions test 10 |
| 7 | The old harness applied a grants stub *after* the migrations, re-opening revoked privileges (ADR-013/019 class) | Harness replaced by a single faithful model; stub retired (ADR-021) | Every suite passes on it |

## Known limitations (stated, not hidden)

- Verified on local PostgreSQL 16 with a harness that models Supabase's role/default-privilege setup. A real Supabase
  project (or `supabase start`) run is still recommended before go-live.
- Admission numbers continue across calendar years (`FFS-<year>-<count+1>`; the year is cosmetic, the count is campus-wide).
  Unchanged from the original design.
- Sprint 5B does not exist yet; Jest suites were not part of this verification.

## Reproduce

```
supabase/local-test-harness/run_all.sh                          # reset, apply 0001–0029, run all 8 pgTAP suites
supabase/local-test-harness/concurrency_conversion_check.sh     # two-session concurrency check
```
