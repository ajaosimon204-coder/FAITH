# Architectural Decision Log

Records decisions made *during implementation* that weren't already fully specified by the approved architecture — small enough not to require stopping and asking, per the controlled development rules, but worth a permanent record.

---

## ADR-001: `user_roles` uniqueness via expression index, not a table-level constraint

**Context:** the approved schema wants `user_roles` to prevent duplicate assignments while allowing `scope_type`/`scope_id` to be null (reserved for future fine-grained scoping).

**Decision:** implemented as a `create unique index ... (user_id, role_id, campus_id, coalesce(scope_type, ''), coalesce(scope_id, '00000000...'))` rather than a table-level `UNIQUE` constraint, because Postgres table-level `UNIQUE` constraints cannot reference expressions like `coalesce()` directly.

**Impact:** none on behavior — purely a syntactic necessity. No architecture change.

---

## ADR-002: Audit log write path uses Postgres privilege revocation, not RLS alone

**Context:** the architecture requires `audit_logs` to be append-only and writable only by the App Backend.

**Decision:** in addition to having no INSERT/UPDATE/DELETE *policy* for the `authenticated` role, we explicitly `revoke insert, update, delete on audit_logs from authenticated`. This means even a future policy added carelessly (e.g., a broad `for all` policy accidentally applied) cannot open a write hole, because the underlying table grant is absent — RLS policies only apply to actions a role already has a grant for.

**Impact:** stronger guarantee than RLS alone would provide. No architecture change — this is an implementation-level hardening consistent with "defense in depth," not a deviation from it.

---

## ADR-003: `AuditController` applies explicit campus filtering in application code

**Context:** the App Backend's Supabase client uses the service-role key, which bypasses RLS by design (Architecture Section 4).

**Decision:** `AuditController.list()` explicitly filters `.eq('campus_id', identity.campusId)` in code, rather than relying on RLS, since RLS does not apply to service-role queries at all.

**Impact:** this is not a new decision so much as a made-explicit consequence of the approved architecture's own service-role design — flagged here because it would be an easy place for a future developer to accidentally introduce a cross-tenant leak by forgetting this filter on a new service-role query. Recorded so code review has something concrete to check against.

---

## ADR-004: Helper RLS functions are `SECURITY DEFINER`

**Context:** `app_current_campus_id()` and `app_has_permission()` need to query the `users`/`user_roles`/`role_permissions` tables, which themselves have RLS enabled — a naive implementation would recurse into the very policies calling the function.

**Decision:** these helper functions are `SECURITY DEFINER`, so they execute with the privileges of the function owner (bypassing RLS internally) rather than the calling role. Each function is narrowly scoped (returns a single id or boolean, never a full row), so this doesn't leak more than the policy already intends to check.

**Impact:** standard, documented Supabase/Postgres RLS pattern. No architecture change.

---

## ADR-005: Sprint 1 pgTAP tests are written but not executed in this environment

**Context:** the sandbox used to build Sprint 1 has no live Postgres/Supabase instance.

**Decision:** the RLS test suite is written to the full rigor the architecture calls for (tenant isolation, permission gating, IDOR resistance) and is ready to run via `pg_prove` or the Supabase CLI's test runner against a real database, but has not actually been executed as part of this sprint's local verification.

**Impact:** flagged as a known limitation in the Sprint 1 Completion Report, not silently glossed over. This is the one place Sprint 1's "tests passing" claim is partial rather than complete — Jest unit tests are fully executed and passing; SQL/RLS tests are authored and pending execution in a provisioned environment.

---

## ADR-006: Config permission checks are resource-aware, not declared via `@RequirePermissions`

**Context:** every other permission-gated route in the platform so far (`RbacController.assignRole`) requires a single, statically-known permission, declared via `@RequirePermissions(...)` and enforced by `PermissionGuard`. `ConfigController`'s `PUT /config/value/:key` route, by contrast, requires a *different* permission depending on which key is being written (`config.finance.write` for a finance key, `config.academic.write` for an academic key, etc.) — the permission isn't knowable from the route alone.

**Decision:** `ConfigController` does not use `@RequirePermissions`/`PermissionGuard` at all. Instead, `ConfigService` looks up the target `ConfigDefinition`, reads its `writePermissionKey` (or `readPermissionKey`), and checks the caller's permissions against that value directly, throwing `ForbiddenException` itself.

**Impact:** this is a deliberate, narrow exception to the Sprint 1 pattern, not a weakening of it — the check still happens, still fails closed, and is still unit-tested exhaustively (12 tests covering every combination of read/write/wrong-category/no-permission). Documented here specifically so a future code reviewer doesn't "fix" `ConfigController` by bolting on a static decorator that can't actually express a per-key permission requirement.

---

## ADR-007: Config value writes go through a single Postgres function, not two sequential client calls

**Context:** Architecture Section Q requires every configuration change to be audited — an upsert that "usually" gets audited, with a separate best-effort audit-insert call, would leave a window where a config value changes with no corresponding `config_audit_log` row (e.g., if the process crashes between the two calls).

**Decision:** `app_write_school_config()` (migration `0008`) performs the upsert into `school_config` and the insert into `config_audit_log` inside one Postgres function body, called once via Supabase RPC from `SupabaseConfigRepository.upsertValueWithAudit()`. Both writes commit or fail together.

**Impact:** the App Backend still performs full JSON-Schema validation via ajv *before* calling this function — the Postgres function itself only re-checks that the `config_definition_id` exists (a cheap structural guard, not a duplicate of the JSON-Schema logic, consistent with Governance Rule 2's "no duplicate business logic"). The function's `EXECUTE` privilege is revoked from the `authenticated`/`anon` roles, so this atomic path is only reachable through the App Backend's service-role connection — a direct Supabase client call from the frontend cannot invoke it and bypass ajv validation.

---

## ADR-008 (Sprint 3 note on naming): "Decision Log" vs. this file

Sprint 3's instructions asked for updates to `/docs/DECISION_LOG.md`. This file (`ADR_LOG.md`) already serves exactly that purpose and has since Sprint 1. Rather than create a second, duplicate log (which Governance Rule 4 — "no unapproved schema/artifact duplication" — argues against by the same logic applied to database tables), Sprint 3's decisions are recorded below under this existing file. Flagging the naming mismatch explicitly rather than silently doing something different from what was asked.

## ADR-009: `students`/`staff` minimal stub tables — a flagged, not silent, dependency

**Context:** Sprint 3's `enrollments` and `teacher_assignments` tables require valid `student_id`/`staff_id` foreign keys. The full "People" domain (admission workflow, demographics, guardian links, employment records) was correctly scoped to Sprint 5 (Admissions), not Sprint 3.

**Decision:** migration `0010` adds `students` and `staff` as deliberately bare tables — `id`, `campus_id`, a nullable `users_id` link, a `display_name`, and one status field each. No admission fields, no HR fields. This was flagged explicitly per your instruction ("if a dependency from a future sprint is discovered, explain it rather than silently expanding scope") rather than either (a) silently building a fuller version of these tables, or (b) refusing to implement enrollments/teacher_assignments at all until Sprint 5.

**Impact:** Sprint 5 is expected to only ADD columns to these two tables, never restructure them — the `id` as primary key and the FK relationships `enrollments`/`teacher_assignments` depend on are stable from Sprint 3 onward. If Sprint 5 discovers a reason this shape doesn't work, that's a genuine finding to surface then, not a foregone conclusion now.

## ADR-010: Historical-integrity enforced three independent ways, not one

**Context:** Sprint 3's instructions state the historical model "must remain authoritative" and that historical records "cannot be accidentally overwritten" — stronger language than a typical CRUD table warrants.

**Decision:** rather than relying on a single mechanism, `enrollments` is protected by three independent, differently-shaped guarantees: (1) a unique partial index (`WHERE status = 'active'`) making a second concurrent active enrollment for the same student/session a constraint violation, not an application-level check that could race; (2) a `BEFORE INSERT OR UPDATE` trigger validating that `class_id`/`academic_session_id`/`campus_id` are mutually consistent; (3) a separate `BEFORE UPDATE` trigger specifically rejecting any change to a *closed* enrollment's identity fields (`student_id`, `class_id`, `academic_session_id`, `enrolled_at`), while still permitting status/exit-reason corrections.

**Impact:** this is deliberately redundant — (1) and (2) protect data integrity in general, (3) protects history specifically once it's closed. A bug in the application layer (or a future direct database access) cannot silently corrupt closed history, because the database itself refuses the write regardless of who's asking.

## ADR-011: `EnrollmentService`'s read methods re-implement RLS's relationship logic in TypeScript

**Context:** `EnrollmentService` uses the service-role repository, which bypasses RLS entirely (same as every service-role-backed service since Sprint 1's `AuditController`).

**Decision:** `getCurrentEnrollment`/`getEnrollmentHistory` explicitly re-check the same relationships the RLS policies in migration `0011` check — self, assigned teacher (via `teacher_assignments`), or `academic.enrollments.read` — rather than trusting the service-role connection's unrestricted access.

**Impact:** this is the same pattern established in ADR-003 (Sprint 2), applied here to a case with materially more relationship complexity (three different ways to legitimately access one student's data, one of which — teacher assignment — requires a live database lookup, not just a permission-string check). Both the Jest suite (against a fake repository) and the live pgTAP suite (against real RLS) independently verify the SAME authorization outcomes, specifically so a divergence between "what the API allows" and "what the database allows" would be caught by at least one of the two test layers.

## ADR-012: Enrollment history access is narrower than current-class access, by service-layer decision

**Context:** nothing in the approved architecture explicitly states whether a teacher assigned to a student's current class should see that student's *entire* multi-year enrollment history, or just their current placement.

**Decision:** `EnrollmentService.getEnrollmentHistory` only grants access to the student themself or an `academic.enrollments.read` holder — a teacher's `teacher_assignments` relationship grants current-class visibility only, not history. This is a genuine design decision I made, not a literal requirement from any prior document — flagged here rather than presented as if the architecture mandated it.

**Impact:** a teacher can see "this student is in my class now," which is what they need day-to-day, without being able to see, e.g., a student's withdrawal-and-return history from a prior session, which is arguably not a current subject teacher's business. If this is wrong for the school's actual needs, it is a one-line permission-check change in `EnrollmentService`, not a schema or RLS change.

## ADR-013: Harness grant-ordering bug found during Sprint 3's live verification

**Context:** see the Changelog entry for the mechanical detail. Summarized here as a decision record: the fix was to re-order the harness's revokes to run AFTER its broad grant, not to change any application migration.

**Impact:** none on the shipped schema — this was purely a defect in the disposable local-test harness that could have produced a false "RLS is enforcing this" result for Sprint 3's suite specifically (and would have quietly done the same for a hypothetical Sprint 4+ suite, had it gone uncaught). Confirmed via direct `has_table_privilege()` checks before and after the fix, not just by re-running the test suite and seeing green.

## ADR-014: Three real gaps found during the Sprint 3 re-audit (requested corrective verification)

**Context:** you specifically requested a dedicated security review of `EnrollmentService`'s read paths (which use the service-role connection, bypassing RLS) and focused `class_subjects` test coverage including cross-campus rejection. Writing the requested tests honestly (rather than only testing already-safe behavior) surfaced three real, live gaps:

1. **`ClassesService.linkSubjectToClass`** performed no campus check at all — an actor with `academic.classes.write` could link a class and subject from two different campuses, or reference a class/subject entirely outside their own campus, since the service-role connection bypasses RLS and no application-layer check existed.
2. **`EnrollmentService.assertCanViewStudent`** (backing `getCurrentEnrollment`) returned early on `hasPermission(actor, 'academic.enrollments.read')` alone, with **no check that the student belonged to the actor's own campus at all**.
3. **`EnrollmentService.getEnrollmentHistory`** had the identical gap on its own permission-based branch.

**Decision:** 
- Added explicit campus-membership checks as the *first* thing both `EnrollmentService` read paths do, before any permission or relationship branch — see `enrollment.service.ts`.
- Added explicit campus-matching checks to `ClassesService.linkSubjectToClass`, checking both the class's and the subject's campus against the actor's own.
- Added a database-level trigger (migration `0015`) as an independent backstop for the `class_subjects` case specifically, since that property (two resources must share a campus) is cleanly expressible as a database constraint, unlike the enrollment read-authorization logic which is inherently service-layer (it depends on relationship data, not just column equality).

**Impact:** in the current single-campus V1 reality, none of these three gaps were exploitable in practice (there is only one campus). They are real defects in the tenancy-isolation guarantee itself, though, and would have become exploitable the moment a second campus/organization was onboarded — exactly the scenario the approved architecture's tenancy groundwork (Final Architecture doc, Section M) was meant to make safe in advance. Found and closed before that ever mattered, which is the entire point of building the boundary early. All three fixes are covered by new tests — 5 new `class_subjects` Jest tests, 2 new `EnrollmentService` cross-campus/cross-teacher Jest tests, and 1 new live pgTAP test for the `class_subjects` trigger — and re-verified against a live database, not just asserted.

## ADR-015: Cross-campus check applied proactively to `CmsContentWorkflowService`

**Context:** Sprint 3's re-audit (ADR-014) established that any service-role-backed read/write path needs an explicit campus check, since RLS doesn't run under the service-role connection. `CmsContentWorkflowService` — built during Sprint 4 — had exactly this gap: `requireRecord()` looked up content by id alone, with no check that the record belonged to the caller's own campus.

**Decision:** added an unconditional campus check as the first thing `requireRecord()` does, before any transition/permission logic. Because `CmsContentWorkflowService` is generic (`<TRecord extends CmsContentBase>`) and instantiated once per content type, this one fix covers all four CMS content types simultaneously — no repository-level duplication needed, unlike the Sprint 3 case where the equivalent fix had to be applied to two separate services.

**Impact:** this is presented honestly as a gap I found and fixed myself during ordinary Sprint 4 development, not as evidence the "standing checklist item" recommendation from ADR-014 is already fully internalized — it was caught by re-reading the code with that lesson in mind while reviewing prior in-progress work, not by a systematic pass across every new service-role-backed method in this sprint. Two new tests cover it: a direct cross-campus transition-denial test, and an IDOR-safety test confirming a cross-campus record and a nonexistent one produce indistinguishable errors.

## ADR-016: A genuine SQL syntax bug in migration `0017`, never previously executed

**Context:** all four `CREATE TRIGGER` statements in `0017_cms_rls.sql` had a duplicated `on <table_name>` clause (`create trigger x on cms_pages before insert or update on cms_pages ...`), which is invalid syntax.

**Decision:** fixed directly in the migration file, rather than via a new corrective migration. This is different from how `0009` and `0015` were handled — those migrations had already been applied and treated as an approved historical record; `0017` had never been successfully applied even once (this was its first live execution), so there was no shipped state to preserve.

**Impact:** a reminder that "written, reviewed, looks correct" and "actually executed" remain different claims — this bug was invisible to `tsc`/`eslint`/code review since it's pure SQL, and would only ever surface the moment someone tried to run it. Consistent with this project's now-established practice of treating live execution as required verification, not optional.

## ADR-017: `PublishedPageSection` split into a data-fetching function and a synchronous component

**Context:** the original implementation was a single async Server Component (`PublishedPageSection`) that both fetched CMS content and rendered it, called as JSX (`<PublishedPageSection campusId={...} slug={...} />`) from within `HomePage`, itself also an async Server Component.

**Decision:** split into `getPublishedPageContent()` (an async function, not a component) called directly and awaited inside `HomePage`, and `PublishedPageSection` (now a plain synchronous component taking already-resolved `page` data as a prop).

**Impact:** the original shape is exactly the pattern Next.js's real RSC rendering pipeline supports, but `@testing-library/react`'s DOM-based `render()` cannot execute an async component nested inside another async component — there is no standard, stable way to test that composition outside Next's own request-handling pipeline. The fix is also arguably better architecture on its own terms: exactly one async/data-fetching boundary per page, with every deeper component staying synchronous and trivially testable — a pattern worth carrying into future pages rather than treating as a one-off workaround.

## ADR-018: Closing the CMS RLS write-granularity bypass and actor-field forgery (adversarial audit, Critical findings 1 & 2)

**Context:** a requested adversarial audit of Sprint 4 found, live and reproducibly, that the `_update_same_campus_staff` RLS policy on all four CMS tables allowed ANY of `content.create`/`review`/`publish`/`archive` to perform ANY valid status transition via a direct client write — the fine-grained per-transition permission mapping only existed in `CmsContentWorkflowService` (TypeScript), which a direct database client never touches. The same write path also let a caller set `reviewed_by`/`approved_by`/`published_by` to an arbitrary user id, unrelated to the actual caller.

**Decision:** closed both findings the same way Sprint 2's `school_config` write-bypass (migration 0009) was closed — remove ALL direct `INSERT`/`UPDATE` RLS policies for `authenticated` on the four CMS tables entirely, forcing every write through a new atomic Postgres function (`app_cms_transition`), generic across all four content types via dynamic SQL. The function's `p_actor_id` parameter is always the App Backend's own resolved identity (`actor.appUserId`, derived from the verified Supabase Auth token) — there is no code path where an arbitrary, client-suppliable id could reach this parameter independent of who is actually authenticated, which closes the forgery finding structurally rather than by convention.

**Impact:** matches the established Sprint 2 pattern exactly. The trigger from migration 0017 still independently validates transition legality on every write this function performs — `app_cms_transition` does not duplicate that logic, it adds atomicity (status change + audit_logs entry in one transaction) and actor-identity trustworthiness on top of it.

## ADR-019: The PUBLIC EXECUTE grant gap — a major, previously-undetected, cross-sprint finding

**Context:** while live-verifying ADR-018's fix, a further test (an authenticated-but-unprivileged-for-this-specific-transition actor attempting to call `app_cms_transition` directly) unexpectedly succeeded. Investigation found the root cause: Postgres grants `EXECUTE` on a newly created function to the `PUBLIC` pseudo-role by default. Every `revoke execute on function ... from authenticated, anon` statement written since Sprint 2 — in migrations `0008` (`app_write_school_config`), `0013` (`app_set_current_academic_session`, `app_set_current_term`), `0014` (`app_transfer_enrollment`), and the newly-written `0019` (`app_cms_transition`) — has been **silently ineffective the entire time**, because revoking from a specific role does nothing while `PUBLIC` still holds the grant; every role implicitly inherits whatever `PUBLIC` has.

**This was live-confirmed exploitable**, not merely theoretical: an `accountant` role successfully called `app_write_school_config()` directly and wrote `"NOT-A-VALID-CURRENCY-BYPASSES-AJV"` as a value — a value that `ConfigService`'s ajv schema validation would have rejected outright had the write gone through the intended App Backend path. This is the exact guarantee ADR-007 (Sprint 2) specifically existed to protect, and it has not held since the moment `app_write_school_config` was first deployed.

**Decision:** migration `0020` explicitly revokes `EXECUTE` from `PUBLIC` on all five affected functions, then explicitly re-grants to `service_role` (which itself only had access via the same `PUBLIC` inheritance, and would otherwise lose access too). The local test harness (`01_supabase_platform_grants_stub.sql`) was updated identically, so it now honestly models the corrected reality rather than continuing to mask the gap on every future reset.

**Also added:** direct negative tests in `rls_config_tests.sql` and `rls_academic_tests.sql` asserting that even a fully-permissioned actor cannot call `app_write_school_config`/`app_transfer_enrollment`/`app_set_current_academic_session` directly — these specific tests did not exist before this audit, for any of the affected functions, in any prior sprint. Their absence is exactly why this went undetected for two full sprints despite each sprint's own "live-verified" claims.

**Impact — stated plainly, not softened:** this retroactively means the Sprint 2 and Sprint 3 completion reports' claims that these functions were "callable only by the service-role connection" were false for the entire time between their creation and this fix, despite passing live database verification at the time. The verification method itself (checking `has_function_privilege(role, ...)` for the specific named role, and/or attempting a functional call) was sound where actually applied — the gap is that no prior sprint's test suite ever attempted the specific "can an ordinary authenticated actor call this RPC function directly" test for any function except (accidentally, structurally) the ones where a different check happened to catch it. This is now closed, live-verified via direct reproduction of the exact original exploit, and permanently guarded by new regression tests in every affected suite.

## ADR-020: Typography fix — real font loading via `next/font/google`, build verification blocked by sandbox network restrictions

**Context:** the adversarial audit found that the Design System Contract's specified typefaces ("Source Serif 4", "Inter") were referenced by name in `globals.css` but never actually loaded — no `next/font`, no `@font-face`, no CDN link — so every browser silently rendered the fallback fonts (Georgia, system-ui) instead.

**Decision:** loaded both fonts via `next/font/google` in `layout.tsx`, exposing them as CSS custom properties (`--font-display-loaded`, `--font-body-loaded`) that `globals.css`'s existing `--font-display`/`--font-body` variables now reference as their first choice, with the original fallback stacks preserved unchanged as the fallback.

**Impact — honestly qualified:** `tsc --noEmit`, `eslint`, and the full Jest suite (11/11) all pass with this change. However, **`next build` could not be verified in this development sandbox**, because `next/font/google` needs to fetch font files from `fonts.googleapis.com` at build time, and that domain is not in this environment's network allowlist. This is a sandbox limitation, not a defect in the fix — in any normal CI or deployment environment with standard internet access, this is the correct, standard way to load Google Fonts in a Next.js application (self-hosted at build time, no runtime CDN dependency, per Next.js's own recommended practice). **This specific fix's production-build success should be verified once in a real CI/deployment pipeline before being considered fully closed** — flagged explicitly rather than silently assumed.

## ADR-021: Faithful harness model — default privileges first; the post-migration grants stub is retired

**Context:** the original harness applied `01_supabase_platform_grants_stub.sql` *after* all migrations. A real Supabase project does the opposite: default privileges grant on objects at creation, so a migration's `REVOKE` is the last word. The old order re-opened whatever migrations revoked (ADR-013 and ADR-019 were both this class), so a suite could pass while a revoke was missing. During Sprint 5A verification it showed `authenticated` holding EXECUTE on the new `0024` functions and write privileges on all four admissions tables, neither true on a real project.

**Decision:** `run_all.sh` now sets `ALTER DEFAULT PRIVILEGES ... GRANT ALL ... TO anon, authenticated, service_role` before the migrations and applies nothing afterwards; `service_role` is created with `BYPASSRLS`, as on Supabase. The legacy mode and the stub file were removed rather than maintained as a second, known-inaccurate model.

**Impact:** the faithful model exposed three things the old one hid: the `anon` write gap on the guardian tables (`0025`), the project-wide privilege over-grant (`0026`, ADR-023), and a stale assumption in the Sprint 2 config test (corrected). All Sprint 1–4 suites pass unchanged on it. Older completion reports that mention the stub describe the harness as it was at the time.

## ADR-022: Sprint 5A conversion hardening (`0024`) and `0025`

**Context:** Sprint 5A verification found that `app_convert_application` (a) did not require the target class to match the applicant's applied-for level, (b) accepted a caller-supplied academic session that could only be redundant or wrong, and (c) assigned admission numbers with `count+1`, which can collide under concurrent conversions. Separately, `0022` left `anon` write privileges on `guardians`/`guardian_students`.

**Decision:** `0024` was edited directly (it was rebuilt from notes and never applied anywhere): level check added; the session parameter removed and taken from the class; a per-campus advisory lock added around number assignment, with the unique index kept as the backstop. The `anon` privilege gap was closed with a new `0025` rather than by editing `0022`, because `0021`–`0023` had been verified and should not change underneath that verification.

**Impact:** each fix is mutation-checked (reverting it fails the suite), and the concurrency fix is demonstrated by a two-session script that fails without the lock.

## ADR-023: Project-wide privilege hardening (`0026`)

**Context:** under Supabase's default privileges, `anon` held INSERT/UPDATE/DELETE on 27 public tables, and `anon`/`authenticated` held TRUNCATE, REFERENCES and TRIGGER on all of them. RLS (enabled everywhere, deny-by-default) blocked row access, so this was a privilege-layer gap rather than an exploitable one, but TRUNCATE is not subject to RLS, and the privilege layer should not be wider than the access model.

**Decision:** `0026` revokes `anon` writes and `anon`/`authenticated` TRUNCATE/REFERENCES/TRIGGER across every ordinary public table (dynamically, so no table is missed) and revokes the same from default privileges so future tables start closed. `authenticated`'s deliberate per-table writes, `service_role`, and `anon` SELECT (the published-CMS read path) are unchanged. A dedicated suite (`rls_privilege_hardening_tests`) checks the grants across all tables and on a freshly created probe table.

**Impact:** a future table needs an explicit GRANT for any write path it intends to expose; forgetting one fails closed. Nothing in Sprints 1–5 relied on the removed privileges (all suites pass).

## ADR-024: Database business-rule rejections surface as a typed error (Sprint 5B)

**Context:** the admissions atomic functions and triggers reject illegal operations with `RAISE EXCEPTION` (SQLSTATE `P0001`): an illegal status transition, converting an application that is not approved, a class that does not fit. When the service layer has already pre-checked, such a rejection means another reviewer got there first — an expected race, not a server fault. Existing repositories throw a plain `Error` for every database failure, which would surface it as HTTP 500.

**Decision:** `SupabaseAdmissionsRepository` throws `AdmissionsRuleViolationError` when the database reports `P0001`, and a plain contextual `Error` for everything else. The service layer (Step 3) maps the former to 409 Conflict. The service still pre-validates for earlier, friendlier errors; the database remains the final authority. The SQL function parameter names are a cross-language contract, asserted on both sides (pgTAP `proargnames` tests and the repository spec) so a rename on either side fails a test on the other.

**Impact:** no change to existing modules. If a later sprint wants the same distinction elsewhere, the same pattern applies.

## ADR-025: Public application intake and staff review — behavioral decisions (Sprint 5B)

**Context:** the admissions services are the trust boundary for two very different callers: an anonymous parent submitting an application, and an authenticated staff member acting through the service-role client (which bypasses RLS).

**Decisions:**
1. **Minimal public receipt.** Submission returns only the application id, reference number, timestamp and document counts. The possible-duplicate flag is stored for staff but never returned: it would reveal another child's application to an anonymous caller.
2. **Flag duplicates, never block.** Twins and re-applications are real; the school decides what a duplicate means.
3. **No existence probing.** A class level that does not exist and one belonging to another campus produce the identical 400; likewise a staff caller gets the same 404 for a missing application and another campus's.
4. **Documents are best-effort after the application exists.** Attaching URL references is not part of a database transaction; losing a family's submitted application over one failed attachment would be worse than a short document list. The receipt reports `documentsStored` against `documentsRequested`, and `info_requested` is the school's route to the rest. A single atomic submission function was considered and rejected as disproportionate for URL references.
5. **Order of refusal:** 403 (permission) → 400 (input) → 404 (scope) → 409 (state). Permission first so a forbidden caller learns nothing; input before state so a malformed request is a 400 wherever the application is.
6. **Data-quality rules:** at least one guardian contact is required (the `info_requested` loop is useless without a way to reach the family); guardian email is stored lower-case; gender is limited to `female`/`male` and applicant age to 25 years — these are editable constants in `admissions.validation.ts`, not schema constraints.

**Impact:** migration `0027` moves the campus-consistency rule for the applied-for level into the database, so it holds for every caller, not just these services.

## ADR-026: Rate limiting and proxy trust for the public admissions route; the application must be proven to boot (Sprint 5B)

**Context:** the public submission route (`POST /api/v1/public/admissions/applications`) is the first unauthenticated route that *writes*. Authentication is deliberately absent, so abuse protection has to come from elsewhere. Separately, building the HTTP layer exposed that the API from earlier sprints could not start at all (three defects, below), because no test had ever booted the real application.

**Decisions:**
1. **Per-client rate limit** with the standard `@nestjs/throttler`, applied to that one route only (10 submissions per client address per hour; invalid attempts count). Counted in process memory, so with N instances the ceiling is N times the limit; a shared store is the upgrade path if instances are scaled out. A CAPTCHA/bot challenge is not included and is a product decision for later.
2. **`TRUST_PROXY` (number of proxy hops)** controls how Express derives the client address. Without it, behind a load balancer every applicant shares one address and the limit would lock everyone out; with it, the address comes from `X-Forwarded-For` through only the trusted hops, so a client cannot spoof its own. Only a non-negative integer is accepted — `true` (trust any proxy, spoofable) and unparseable values refuse to start, matching the fail-closed handling in `config/env.ts`. Unset means no proxy.
3. **One `configureApp()`** holds pipes, CORS and proxy handling, used by `main.ts` and by the tests, so tests exercise production configuration rather than a copy.
4. **A boot test is mandatory.** `test/app.boot.spec.ts` compiles the real `AppModule` and initialises it through `configureApp()`. `test/admissions.http.spec.ts` drives the real guard, JWT verification, identity resolution, pipes and throttler over HTTP, with only the database faked.

**Defects found by this and fixed (all pre-existing, none in Sprint 5 code):**
- `main.ts` created a `ValidationPipe` but `class-validator` and `class-transformer` were never in `package.json` — the process exited at startup.
- `AuditController` injected `SupabaseClient` by class type while the client is registered under the string token `SUPABASE_CLIENT`, so Nest could not resolve it; the redundant provider in `AuditModule` could not help.
- `npm start` ran `node dist/main.js`, but the build included `test/`, so the entry point was `dist/src/main.js`. A source-only `tsconfig.build.json` now makes the build emit `dist/main.js` and keeps compiled tests out of the deployable.

**Impact:** `@nestjs/throttler`, `class-validator`, `class-transformer` added; `@nestjs/testing`, `supertest` added for tests. The compiled server was started as a real process and exercised over the network (401 without a token, 400 on bad input, 429 on the eleventh request from one client while a different client behind the same proxy was unaffected).

## ADR-027: Integration verification against the real API layer; one verification command; CI (Sprint 5 close-out)

**Context:** until now the database was verified by pgTAP (SQL alone) and the application by Jest (logic against fakes). The seam between them — the real `supabase-js` client talking to PostgREST talking to PostgreSQL, with real JWTs — was never exercised, and several assumptions lived exactly there. There was also no automated gate at all: the API shipped unable to start (ADR-026) because nothing ran it.

**Decisions:**
1. **Integration suite on the real stack.** `supabase/local-test-harness/run_integration.sh` provisions PostgreSQL (all migrations), PostgREST 12.2.3 (the API layer Supabase runs; pinned and checksum-verified by `install_postgrest.sh`), and a 20-line `/rest/v1` path shim so the real, unmodified `supabase-js` client works. `apps/api/test-integration/` drives the application's own repository and services through it with real JWTs. Kept out of `npm test` (which stays hermetic and fast) via a separate Jest config.
2. **`auth.uid()` in the harness now matches Supabase's definition** (reads both `request.jwt.claim.sub` and the JSON `request.jwt.claims`). The old stub read only the former; PostgREST 9+ sets only the latter, so under the real API layer RLS would have seen "no user" for everyone while every SET-LOCAL-based test passed. Mutation-checked: reverting the stub fails three integration tests.
3. **Denials must be proven at the privilege layer.** Integration tests assert SQLSTATE `42501` *and* "permission denied", because an RLS refusal also reports `42501` and would hide a regression in the grants.
4. **`scripts/verify-all.sh`** runs everything (database, API, integration, web), runs every step even after a failure, prints a summary, and exits non-zero on any failure. `.github/workflows/verify.yml` runs exactly that on every push to `main` and every pull request.

**What it confirmed (first live run, 27 of 29 on the first attempt; the other 2 were a bug in the test payload):** the RPC argument names and result shapes as PostgREST really sends them; that a database `RAISE EXCEPTION` really arrives as `P0001` and maps to `AdmissionsRuleViolationError` while other database errors stay plain errors; that `ILIKE` escaping behaves as the duplicate lookup assumes; that JWT claims reach RLS; that `anon`/`authenticated` are refused direct writes and the atomic functions at the privilege layer; that forged tokens are refused; and that simultaneous conversions through real HTTP get distinct admission numbers.

**Not covered, stated plainly:** a hosted Supabase project, tokens issued by Supabase's real login service (GoTrue), and Supabase's gateway. The CI workflow itself has not been executed on GitHub from here; the script it calls has been run end to end locally. `next build` downloads Google Fonts, so it needs internet (it fails offline), which is an environment property rather than a code defect.

## ADR-028: Hosted-readiness findings and fixes (Sprint 5 close-out)

**Context:** before the first run against a hosted Supabase project, the current state of Supabase was checked against what the platform assumed, and the repository was exercised against a stand-in for a current project. Four findings changed what "ready" means.

**Findings and decisions:**
1. **New projects no longer grant table privileges automatically** (default since 2026-05-30; mandatory for new tables from 2026-10-30). Every earlier migration relied on those defaults, so on a current project the App Backend would get `permission denied` on every table. *Decision:* migration `0028` states the intended privileges explicitly, per table, generated from the verified effective state; a `--modern` harness mode models a current project; `compare_privilege_models.sh` proves both project styles end in the identical privilege state; a sweep test fails any table created without grants. Governance rule: **every migration that creates a table must GRANT what it needs explicitly.**
2. **`student_current_enrollments` bypassed row-level security** (Sprint 3 defect). The view ran as its owner and default privileges had granted `anon` access, so an unauthenticated caller could read every campus's enrollments through the Data API. *Decision:* `0029` makes it `security_invoker` and grants only `SELECT` to `authenticated` and `service_role`. Regression tests exist at three levels (pgTAP behavior, a sweep over every view, and through the real API). The sweep also guards every future view.
3. **Current projects sign login tokens asymmetrically** (ES256/RS256 via a published JWKS) and no longer expose a shared secret; the API verified HS256 only and would have rejected every user. *Decision:* `JwtVerificationService` verifies both styles, chosen by the token's algorithm header, each with a fixed allowlist (so algorithm-confusion is refused); enforces issuer and audience; answers an unreachable key endpoint with 503 rather than a false 401; the legacy secret is now optional. Legacy `anon`/`service_role` keys are being retired; `sb_secret_…` is accepted (supabase-js floor raised to the verified version).
4. **Repositories had never met a database.** `SupabaseIdentityRepository` selected `users.organization_id`, a column that does not exist, so *every authenticated request failed with a 500*; the config repository's write returned a value with `key`/`category` undefined. Fakes cannot catch wrong column names, embeds or RPC shapes. *Decision:* an integration sweep (`test-integration/repositories.int.spec.ts`) calls every method of every repository against real PostgREST, in both project styles; both bugs fixed.

**Hosted smoke test:** `scripts/smoke-test.mjs` (dependency-free; needs only the publishable key and optional test-user logins, never the secret key) plus a read-only database audit (`supabase/smoke/hosted_audit.sql`) and a runbook (`docs/HOSTED_SMOKE_TEST.md`). It is itself tested against a local stand-in for a current project (real ES256 tokens and JWKS): it passes when configured correctly and fails, with a diagnosis, for a wrong issuer or an unreachable key endpoint. Its isolation checks warn rather than pass when there is no data to observe.

**Not covered:** a real hosted project, real Supabase login (GoTrue), Supabase's gateway. The smoke test is how those are confirmed.
