# Sprint 4 Completion Report
## Design System Contract, CMS, Public Website (Begins) — Faith Foundation Schools Platform

---

## 1. Sprint Objective

Per the approved roadmap: ratify the Design System Contract, then begin the public website and CMS build in parallel with backend work. This is the platform's first frontend-facing sprint — everything through Sprint 3 was backend/schema only.

---

## 2. What Was Implemented

- **Design System Contract** (`docs/DESIGN_SYSTEM_CONTRACT.md`): the full ratified specification — Royal Blue/Gold brand tokens, typography (serif display + sans body), 8px-based spacing scale, responsive breakpoints, two density modes (public/application) sharing one token set, a complete component catalogue (buttons, forms, cards, tables, nav, modals, toasts, badges, charts, empty/loading/error states), and a WCAG-aligned accessibility baseline.
- **CMS backend**: four structurally identical content types (`cms_pages`, `cms_news`, `cms_gallery`, `cms_staff_profiles`) sharing one workflow engine (`CmsContentWorkflowService<T>`) implementing `draft → in_review → approved → published → archived`, with a database trigger enforcing valid transitions independent of RLS. A genuinely public, unauthenticated read path for published content, via a new `@Public()` decorator mechanism on the previously fail-closed-by-default `SupabaseAuthGuard`.
- **Public website**: a real Next.js 14 App Router application (`apps/web`) consuming the Design System Contract's tokens directly. One page built — Home — using only verified school facts, with explicit `[CONTENT REQUIRED]` placeholders for everything not yet supplied, and an honest empty state (never fabricated copy) for CMS-sourced content.

---

## 3. Database Changes

| Migration | Purpose |
|---|---|
| `0016_cms_schema.sql` | Four CMS tables, shared status enum |
| `0017_cms_rls.sql` | Status-transition trigger, deny-by-default RLS with public read path |
| `0018_seed_cms_permissions.sql` | `content.{create,review,publish,archive}` permissions and role grants |

Migration `0017` contained a genuine SQL syntax bug (duplicated `on <table>` clause in every `CREATE TRIGGER`) — found by live execution and fixed directly in the file, since it had never been successfully applied before.

---

## 4. API/Backend Changes

- `CmsModule`: `CmsContentWorkflowService<T>`, four repositories, `CmsPagesService`, `CmsController` (authenticated authoring routes — `cms_pages` only, the reference implementation), `PublicCmsController` (unauthenticated published-content reads).
- `@Public()` decorator + `SupabaseAuthGuard` update: the single, explicit, reviewable exception to "every route authenticated by default." Zero other routes in the application use it.
- **A real cross-campus IDOR gap found and fixed**: `CmsContentWorkflowService.requireRecord()` had no campus check at all. Fixed once, in the shared service, covering all four content types simultaneously.

---

## 5. Frontend Changes

New `apps/web` package: Next.js 14, TypeScript, CSS Modules implementing the Design System Contract's tokens verbatim. Components: `Header`, `Footer`, `LevelsPathway` (the page's deliberate signature element — the real 15-level academic progression, grouped into its real stages, which genuinely is a sequence rather than an arbitrary list), `PublishedPageSection` (CMS content display with honest empty state), and the Home page composing all of them. `src/lib/school-facts.ts` is the single source of truth for verified content, with every value traceable to the master specification.

---

## 6. RLS/Security Changes

- CMS RLS: published content readable by `anon` (no authentication at all — this is the actual public-website read path); non-published content visible only to same-campus staff holding a `content.*` permission; writes require `content.create`; no `DELETE` grant for `authenticated` at all (corrections go through `archived`, never row deletion).
- `CmsContentWorkflowService`'s cross-campus fix (Section 4) — same defense-in-depth principle established in Sprint 3: RLS protects the frontend's direct-read path, the service layer independently re-derives campus scoping for the service-role path.

---

## 7. Tests Performed

- Backend: unit tests for the new `@Public()` bypass mechanism (previously untested despite being new, security-relevant logic) and the CMS cross-campus fix.
- Frontend: component-level tests (`LevelsPathway` renders all 15 real levels in correct order/grouping; `PublishedPageSection` never fabricates content, always shows an honest empty state) and page-level tests (Home page renders only verified facts, marks unsupplied content honestly).
- Live database: full clean-reset sequence — all 18 migrations, all 4 pgTAP suites together.
- Production build: `next build` executed successfully, including static generation of the Home page with its CMS-fetch-failure path genuinely exercised (no backend configured in this environment).

---

## 8. Test Results

```
Backend:  81/81 Jest passing        tsc --noEmit: PASS        eslint: PASS
Frontend: 11/11 Jest passing        tsc --noEmit: PASS        eslint: PASS        next build: PASS
pgTAP:    67/67 passing (17 identity + 14 config + 21 academic + 15 CMS), executed live
Migrations: 18/18 apply cleanly, in order, from a clean database reset
```

---

## 9. Files/Modules Changed

**New (backend):** `apps/api/src/modules/cms/*` (9 files), `apps/api/src/modules/identity/public.decorator.ts`, `apps/api/test/cms-workflow.service.spec.ts`, `apps/api/test/fakes/fake-cms.repository.ts`, `apps/api/test/supabase-auth.guard.spec.ts`, `supabase/migrations/0016`–`0018`, `supabase/tests/rls_cms_tests.sql`.

**New (frontend):** the entire `apps/web` package — `package.json`, config files, `src/app/{layout,page,globals.css,page.module.css}`, `src/components/*` (4 components + CSS modules), `src/lib/{school-facts,cms-client}.ts`, `test/*` (3 spec files + setup).

**New (docs):** `docs/DESIGN_SYSTEM_CONTRACT.md`.

**Modified:** `apps/api/src/modules/identity/supabase-auth.guard.ts` (Reflector injection for `@Public()`), `apps/api/src/app.module.ts` (CmsModule registration), `supabase/local-test-harness/01_supabase_platform_grants_stub.sql` (CMS delete-revoke ordering fix), `docs/IMPLEMENTATION_STATUS.md`, `docs/CHANGELOG.md`, `docs/ADR_LOG.md`.

---

## 10. Known Issues

- Only `cms_pages` has controller routes wired; `cms_news`/`cms_gallery`/`cms_staff_profiles` have complete repositories and share the same workflow service, but their routes are unwired — a small, mechanical follow-up.
- Only the Home page exists on the frontend. No About, Admissions, Academics sub-pages, News listing, Gallery, or CMS admin UI yet.
- No image/asset handling, no SEO metadata beyond the basic `<title>`/`<meta description>`, no sitemap/robots.txt — all explicitly deferred, matching "begins, not completes."
- The CMS block-content renderer (mapping `content_json` block types to trusted components) is not built — `PublishedPageSection` shows a placeholder noting how many blocks exist rather than rendering them.

---

## 11. Remaining Work

- Wire the remaining three CMS controllers (news, gallery, staff profiles) — mechanical, not architectural.
- Build the CMS block-content renderer.
- Build out the remaining public site pages per the original site architecture (Section 5 of the master spec) as subsequent sprints/phases progress and real content becomes available.
- A CMS authoring UI (currently API-only — content creation happens via the authenticated API routes, with no admin screen yet).

---

## 12. Architecture Deviations

None from the approved architecture itself. Two implementation-level fixes were needed during this sprint (both documented in ADR-015/ADR-016/ADR-017) — a proactively-applied campus check consistent with the Sprint 3 re-audit's own recommendation, and a migration syntax fix. Neither changes any approved design decision.

**Scope boundary, stated explicitly rather than left implicit:** "public website + CMS build begins in parallel with backend work" (Final Architecture, Section O) is interpreted here as literally beginning — one page, one fully-wired content type, the contract ratified — not completing the full site. This was a judgment call on how much "begins" should include; flagging it in case your expectation was broader.

---

## 13. Content Still Required From the School

Carried forward from prior sprints, plus two new items surfaced by actually building the Home page:
- Campus display name (still `[CONTENT REQUIRED]` since Sprint 1)
- Full history, mission & vision statement, leadership profiles (needed for the About section)
- Phone number, email address, social media links (needed for the Footer)
- Interim contact details for prospective families (needed for the Admissions section, pending the real Admissions system in Sprint 5)

---

## 14. Recommended Next Sprint

Per the approved roadmap: **Sprint 5 — Admissions.** This directly extends the `students`/`staff` stub tables from Sprint 3 into full records and adds `guardian_students` (which will replace the `app_is_guardian_of_student()` stub function's body with no RLS policy rewrite needed, per that function's original design). It also would let the public site's Admissions section move from an honest "not yet available" placeholder to a real, working application flow.

---

**Sprint 4 implementation, testing, and documentation are complete. Stopping here per your established process — awaiting your review before Sprint 5 begins.**
