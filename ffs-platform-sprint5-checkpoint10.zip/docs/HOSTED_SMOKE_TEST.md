# Hosted Smoke Test — Runbook

Run this **before go-live** and after any infrastructure change (new Supabase project, key rotation, new API deployment, custom domain). It takes about ten minutes the first time.

It checks the things unit and integration tests cannot: that *this deployment* fails closed, that the Data API is locked down, that real login tokens are accepted by the API, and that row-level security holds under real tokens.

> **Why this exists.** Supabase changed how new projects work in 2026: tables are no longer granted to the API roles automatically (so the platform was inoperable without explicit grants), login tokens are signed with asymmetric keys (so a shared-secret verifier rejects every user), and API keys are moving to `sb_publishable_…` / `sb_secret_…`. Preparing for this also found a data exposure and a bug that would have broken every sign-in. Those are fixed (migrations 0028–0029, the JWKS verifier, the identity lookup). This test proves the *deployed* system has them.

## 1. Before you start

1. **Apply all migrations (0001–0029)** to the project, in order. Two ways:
   - **Supabase CLI** (preferred): `supabase link` then `supabase db push`.
   - **SQL editor**: combine them with `cat supabase/migrations/*.sql > all.sql` (the numbered file names sort correctly), paste the result and run it. This was tested on a fresh database and applies cleanly in one go. If the editor rejects the size, run the files one by one, in numeric order.

   Migration 0029 uses `security_invoker` views, which need PostgreSQL 15+ (every current Supabase project qualifies). A fresh project already contains the one campus and all 14 roles after migration.
2. **Deploy the API** with the environment variables in the table at the end. On a current project you do **not** set a JWT secret. (Running it on your own computer is fine for this test: `cd apps/api && npm ci && npm run build && node dist/main.js`, with the variables set.)
3. **Create two test users**: in the dashboard, Authentication → Users → *Add user*, with *Auto Confirm User* ticked, using throwaway addresses and strong passwords. Then open `supabase/smoke/hosted_create_test_users.sql`, replace the two example e-mail addresses with yours, and run it in the SQL editor. It links them to the platform: a **staff** user (`school_administrator`, holds the admissions permissions) and a **limited** user (`accountant`, holds none). It ends with a check that lists both users with their roles; you should see two rows. Safe to run twice.
4. Have ready: the **publishable key** (Dashboard → Project Settings → API Keys). It is designed to be exposed. **You never need the secret / service-role key for this test.**

## 2. Run the database audit (read-only, 1 minute)

Open the Supabase **SQL editor** and run `supabase/smoke/hosted_audit.sql`. It only reads catalog information.

- **Every check should report `OK`** with zero offending rows.
- Anything else lists the exact table, view or function and what is wrong. Do not go live until it is clean.

## 3. Run the smoke test

From a machine with Node 20+ (no install needed; the script has no dependencies):

```bash
export SMOKE_API_URL=https://api.yourschool.example
export SMOKE_SUPABASE_URL=https://<project-ref>.supabase.co
export SMOKE_PUBLISHABLE_KEY=sb_publishable_xxxxxxxx
export SMOKE_STAFF_EMAIL=smoke-staff@yourschool.example
export SMOKE_STAFF_PASSWORD='…'
export SMOKE_LIMITED_EMAIL=smoke-limited@yourschool.example
export SMOKE_LIMITED_PASSWORD='…'

node scripts/smoke-test.mjs
```

The default run **writes nothing**. Passwords and keys are read from the environment only and are redacted from all output. Do not paste them into chat or commit them; clear your shell history afterwards.

### Optional: the end-to-end journey (writes one labelled record)

```bash
export SMOKE_CAMPUS_ID=<a campus id>
export SMOKE_CLASS_DEFINITION_ID=<a class level of that campus>
node scripts/smoke-test.mjs --with-writes
```

This submits one application named `SMOKE TEST-<date>` through the public route, then reviews and **rejects** it. It is never converted, so no student or guardian is created. One rejected, clearly labelled application remains; ignore or archive it.

## 4. Reading the result

Exit code `0` and **no `FAIL`** means ready. `SKIP` means you did not supply inputs for a check (it tells you which); `WARN` means a check could not conclude (for example, no data to observe campus isolation) and should be repeated once the project holds real data for at least two campuses.

| You see | It means | Do this |
|---|---|---|
| `A staff route without a token is refused` fails | The API is not enforcing authentication | **Stop.** Do not expose it. |
| `Anonymous callers are refused the enrollments view` fails with rows | Migration 0029 is not applied. Other campuses' enrollments are publicly readable | **Stop.** Apply 0029 now. |
| `Anonymous callers cannot INSERT/UPDATE/DELETE/call …` fails | A privilege is too open (migrations 0022/0025/0026/0028 not fully applied) | Re-run the audit SQL; apply the missing migrations. |
| `The API accepts a real login token` → **401** | The API rejected a valid token. The printed `alg / iss / aud` tell you why | `alg=HS256`: set `SUPABASE_JWT_SECRET` (legacy projects only). `iss` differs from `<SUPABASE_URL>/auth/v1`: set `SUPABASE_JWT_ISSUER` to the printed value. Otherwise: the user has no row in the platform `users` table. The API log states the exact reason. |
| …→ **403** | Signed in, but the user has no admissions permission | Assign the role. |
| …→ **503** | The API cannot fetch the project's signing keys | Check the API's outbound network access to `<SUPABASE_URL>/auth/v1/.well-known/jwks.json`. |
| …→ **500** | A server error after sign-in | Read the API log. (This is how the missing-column bug presented.) |
| `The Data API honours the staff token` fails | PostgREST rejected the user token | Check the project's JWT signing configuration and that the publishable key belongs to this project. |

## 5. Environment variables for the API

| Variable | Required | Meaning |
|---|---|---|
| `SUPABASE_URL` | yes | Project URL, `https://<ref>.supabase.co` (no trailing path) |
| `SUPABASE_SERVICE_ROLE_KEY` | yes | Server-side only. Accepts the legacy `service_role` JWT **or** a `sb_secret_…` key. Never expose it |
| `SUPABASE_JWT_SECRET` | legacy projects only | HS256 shared secret. A current project has none; leave unset |
| `SUPABASE_JWKS_URL` | no | Defaults to `<SUPABASE_URL>/auth/v1/.well-known/jwks.json` |
| `SUPABASE_JWT_ISSUER` | no | Defaults to `<SUPABASE_URL>/auth/v1`. Override for a custom auth domain |
| `TRUST_PROXY` | behind a load balancer | Number of proxy hops (integer). Without it the per-client rate limit on public submissions is shared by all applicants |
| `CORS_ORIGIN` | recommended | The frontend's origin |
| `PORT` | no | Default 4000 |

Legacy `anon` / `service_role` keys are being retired by Supabase by the end of 2026. Prefer `sb_publishable_…` and `sb_secret_…` for a new deployment.

## 6. After the test

- Delete or disable the two test users once go-live checks are done (or keep them disabled for re-runs).
- Re-run this test after any key rotation, new deployment of the API, or migration applied to production.
- The same script runs in CI against a local stand-in (`supabase/local-test-harness/run_smoke_selftest.sh`), which also proves the test *fails* when the API is misconfigured.

## What this test does not cover

Email confirmation and password-reset flows, rate limits on Supabase's own login endpoint, backups, and anything in the (not yet built) frontend for applications and review. It confirms the backend contract, not the whole product.
