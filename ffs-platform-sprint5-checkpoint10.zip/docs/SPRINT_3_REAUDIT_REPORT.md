# Sprint 3 Re-Audit / Approval Readiness Report
## Faith Foundation Schools Platform

---

## 1. Files Changed

**New:**
- `supabase/migrations/0015_sprint3_reaudit_corrections.sql`
- `apps/api/test/class-subjects.spec.ts`
- `docs/MIGRATION_ROLLBACK_STRATEGY.md`

**Modified:**
- `apps/api/src/modules/academic/enrollment.service.ts` (cross-campus authorization fix)
- `apps/api/src/modules/academic/classes.service.ts` (cross-campus authorization fix)
- `apps/api/src/modules/academic/academic.repository.ts` (new methods: `getStudentCampusId`, `getSubjectById`)
- `apps/api/test/fakes/fake-academic.repository.ts` (new methods + made `linkSubjectToClass` model real DB constraint behavior instead of a no-op)
- `apps/api/test/enrollment.service.spec.ts` (campus fixtures + new IDOR tests)
- `supabase/tests/rls_academic_tests.sql` (new cross-campus trigger test)
- `docs/IMPLEMENTATION_STATUS.md`, `docs/CHANGELOG.md`, `docs/ADR_LOG.md`

**Unmodified, confirmed reused as-is:** all Sprint 1/2 code, all of Sprint 3's original schema/services beyond the three specific fixes above.

---

## 2. Migrations Changed

Only one new migration: `0015_sprint3_reaudit_corrections.sql` (database trigger for `class_subjects` cross-campus consistency). No existing migration file (`0001`–`0014`) was edited, per the "fix forward, never edit history" principle established in Sprint 2's `0009`.

---

## 3. Previous Sprint 1/2 Findings — Final Status

| Finding | Fixed In | Live Demonstration Performed |
|---|---|---|
| `campuses` RLS infinite recursion | Migration `0009` | ✅ Re-ran the exact original trigger path (an FK check against `campuses` during a `user_roles` insert) live, post-`0015`. Result: succeeds cleanly, no recursion error. `pg_policy` inspection confirms only the corrected `app_current_organization_id()`-based policy exists. |
| `school_config` direct-write bypass | Migration `0009` | ✅ Re-ran the exact original exploit (an authorized accountant issuing a direct `UPDATE` on `school_config`) live, post-`0015`. Result: `UPDATE 0` rows, value unchanged, zero audit entries for the attempt — the precise opposite of the original finding (`UPDATE 1`, value changed, zero audit entries). `pg_policy` inspection confirms only the `select` policy remains on `school_config`. |
| Sprint 1/2 pgTAP test-authorship errors | Test files themselves | ✅ Confirmed present via `grep` against the committed `rls_identity_tests.sql`/`rls_config_tests.sql` — the corrective comments and rewritten assertions are in the files being executed, not just described in a report. |

**All three are confirmed closed by direct live reproduction, not by re-reading a prior report or trusting a passing test count alone.**

---

## 4. New Tests Added (This Re-Audit)

- **5 `class_subjects` tests** (`class-subjects.spec.ts`): valid link, duplicate rejection, unauthorized-actor rejection, class-in-different-campus rejection, subject-in-different-campus rejection.
- **3 new `EnrollmentService` IDOR tests**: cross-campus denial (the specific case that was previously unguarded), Teacher-B-cannot-see-Teacher-A's-student, unauthorized-staff-denied-history.
- **1 new live pgTAP test**: `class_subjects` cross-campus database trigger, exercised directly against real Postgres.
- **1 documentation test-of-fact** (not an assertion, a recorded confirmation): the "teacher supplies an unrelated class_id" attack vector from your request does not apply to this service's actual API shape — `getCurrentEnrollment`/`getEnrollmentHistory` take only `(actor, studentId)`; there is no endpoint accepting a client-supplied `class_id` that influences a read-authorization decision. Documented rather than silently omitted, since claiming to "test" something structurally impossible would be misleading.

---

## 5. Complete Test Results

```
Jest:       63/63 passing        tsc --noEmit: PASS        eslint --max-warnings=0: PASS
pgTAP:      52/52 passing (17 identity + 14 config + 21 academic), executed live via pg_prove
Migrations: 15/15 apply cleanly, in order, from a clean database reset
```

Full clean-reset sequence re-run once more, end to end, immediately before writing this report, to confirm nothing regressed while assembling it.

---

## 6. IDOR Results

| Scenario (from your request) | Result |
|---|---|
| Teacher requesting a student from an unassigned class | **Denied.** Covered since original Sprint 3 (`EnrollmentService` test + live RLS test). |
| Teacher supplying a valid `student_id` with an unrelated `class_id` | **Not applicable by design** — no API accepts a client-supplied `class_id` for read authorization; documented explicitly rather than assumed. |
| Teacher attempting to access another teacher's assigned student | **Denied.** New test added this re-audit (`denies Teacher B access to a student assigned only to Teacher A's class`). |
| Cross-campus student access | **Was previously ungated for `academic.enrollments.read` holders — now denied.** This was the most significant finding of this re-audit; see ADR-014. |
| Student attempting to access another student's enrollment | **Denied.** Covered since original Sprint 3, both in Jest and live pgTAP. |
| Unauthorized staff attempting to access enrollment history | **Denied.** New explicit test added this re-audit. |

---

## 7. Service-Role Authorization Findings

`EnrollmentService`'s read methods (`getCurrentEnrollment`, `getEnrollmentHistory`) use the service-role connection, which bypasses RLS entirely — this was always documented, but the *completeness* of the service layer's own authorization logic had a real gap until this re-audit.

**Finding:** both methods derived their permission-based access decision from `hasPermission(actor, 'academic.enrollments.read')` alone, without independently verifying the target student belonged to the actor's own campus. In the current single-campus V1 deployment this was not exploitable (only one campus exists), but it was a genuine defect in the tenancy-isolation guarantee, not a hypothetical one.

**Fix:** both methods now resolve the student's `campus_id` from the database and compare it against `actor.campusId` as the *first*, unconditional check — before any permission or relationship branch. This mirrors the pattern already used for `ClassesService.linkSubjectToClass` after today's fix, and is consistent with ADR-011's original principle (re-derive RLS's relationship logic in code, since RLS itself doesn't run here) — that principle was correctly stated in Sprint 3's original report but incompletely implemented for the campus dimension specifically.

**Proof:** every authorization decision in `EnrollmentService`'s read paths is now derived from a database-fetched relationship (student's own `campus_id`/`users_id`, an actual `teacher_assignments` row) — never from a client-supplied identifier. Verified by the new Jest tests and confirmed structurally by inspection (no controller endpoint passes a client-supplied `class_id` or `campus_id` into these methods at all).

---

## 8. Migration Rollback Documentation Status

**Complete.** `docs/MIGRATION_ROLLBACK_STRATEGY.md` classifies all 15 migrations by reversibility, and explicitly documents:
- Reversible-pre-production vs. destructive-in-production, per migration
- Fix-forward as the standard response to a buggy migration (not a down-migration)
- The distinction between schema rollback (Category A/B) and data restore (Category C / PITR)
- Explicit, permanent protection for `enrollments`/audit-table history — never automatically reversed, corrected only by inserting new rows

No destructive down-migrations were created. This satisfies your instruction to document strategy rather than build dangerous automated reversals.

---

## 9. Scope Verification

Confirmed via direct code search (`grep -rli` across `apps/api/src/modules/academic/` and all Sprint 3 migrations) for admission/applicant/guardian/salary/payroll/portal terminology: **zero matches.** `students`/`staff` tables confirmed at 6 and 6 columns respectively (id, campus_id, users_id, display_name, one status field, created_at) — bare FK anchors only, no admission workflow, no HR fields, no portal-related code anywhere in this sprint's scope.

---

## 10. Remaining Issues

- Down-migration *scripts* still don't exist (by design — see Section 8; this is a documented strategy, not a gap).
- `academic.max_class_size` (Sprint 2 config) still has no enforcement wired into `EnrollmentService.enrollStudent` — unchanged from the original Sprint 3 report, not addressed in this re-audit since it was out of the requested scope.
- The `class_subjects` cross-campus fix was added reactively, discovered only because this re-audit specifically asked for that test coverage — worth noting as a process point: **future sprints should proactively ask "does every service-role-backed write/read path re-check campus scoping" as a standing checklist item**, rather than relying on being asked each time.

---

## 11. Final Recommendation

## **APPROVE**

All three items from your original approval-blocking list are now confirmed fixed, with live re-demonstration rather than assertion. The corrective verification process itself surfaced three additional real gaps (cross-campus student data access, cross-campus `class_subjects` linking) that had gone undetected through Sprint 3's original testing — all three are now fixed, tested twice (Jest + live pgTAP where applicable), and re-verified end to end from a clean database reset.

The one honest caveat: this re-audit process demonstrates that even a sprint with "50/50 tests passing" can still contain real authorization gaps if the tests don't specifically probe for them. I'd recommend treating "explicit cross-campus IDOR tests for every service-role-backed read/write path" as a standing item in every future sprint's test checklist, not something that needs to be separately requested each time — noted in Section 10, flagged here as the actual lesson from this exercise rather than just a compliance note.

---

Stopping here per your instruction. Not beginning Sprint 4.
