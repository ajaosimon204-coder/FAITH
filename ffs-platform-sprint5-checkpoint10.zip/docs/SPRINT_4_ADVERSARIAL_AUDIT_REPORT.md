# Sprint 4 Adversarial Audit Report
## Faith Foundation Schools Platform — Findings Only, Nothing Fixed

*Per your instructions, no migrations, code, tests, or documentation were modified during this audit. Three reproduction scripts were added to `supabase/local-test-harness/` as evidence (`audit_finding_1_permission_bypass.sql`, `audit_finding_2_anon_read.sql`, `audit_finding_3_skip_transition.sql`) — these are new, isolated files only, not changes to anything previously delivered.*

---

## Headline Finding (read this first)

**A `content_editor` holding only `content.create` can, via a direct table write using the `authenticated` role (i.e., exactly what a browser using the Supabase anon/authenticated key would do, bypassing the App Backend entirely), walk any CMS row through the *entire* workflow — `draft → in_review → approved → published → archived` — with no permission check at the database layer at all.**

Confirmed live (`audit_finding_1_permission_bypass.sql`):
```
has content.create: t   has content.review: f   has content.publish: f   has content.archive: f

after draft->in_review:                    status=in_review  reviewed_by=NULL  approved_by=NULL  published_by=NULL
after in_review->approved (needs review):  status=approved   reviewed_by=NULL  approved_by=NULL  published_by=NULL
after approved->published (needs publish): status=published  reviewed_by=NULL  approved_by=NULL  published_by=NULL
after published->archived (needs archive): status=archived   reviewed_by=NULL  approved_by=NULL  published_by=NULL

audit_logs entries for this actor/action: 0
```

Every transition succeeded. None of `reviewed_by`/`approved_by`/`published_by` were ever set. Zero audit log entries were created. This single root cause explains several of your numbered items at once — see below.

**Root cause:** `0017_cms_rls.sql`'s `%_update_same_campus_staff` policy's `USING` clause grants UPDATE to anyone holding *any* of `content.create`/`review`/`publish`/`archive` — not the *specific* permission the transition requires. The migration's own comment acknowledges this directly: *"finer-grained transition permission... is enforced in the application service layer."* That's true for the App Backend API, but the RLS layer independently grants direct write access to `authenticated`, and nothing at that layer enforces per-transition permission. The database trigger (`trg_validate_cms_status_transition`) only validates that the transition is *structurally* possible (a valid state-machine edge) — it has no concept of *who* is allowed to make it.

**Severity: Critical.**

---

## 1. Public CMS Security

| Check | Result |
|---|---|
| `anon` can read published content | ✅ Confirmed live |
| `anon` cannot read draft/in_review/approved/archived | ✅ Confirmed live, after correcting my own first test attempt (see "Corrected False Positive" below) |
| `anon` cannot write | ✅ Confirmed live — `permission denied for table cms_pages` |
| `@Public()` used only on the intended route | ✅ Confirmed via full codebase grep — exactly one usage, on `PublicCmsController.getPublishedPage` |
| No alternate endpoint exposes unpublished content | ✅ `findPublishedBySlug` filters `status = 'published'` at the query level, independent of the workflow engine |

**Corrected false positive:** my first live test of `anon` incorrectly showed full read access to all five statuses. Root cause was my own test-script error — I switched `SET ROLE` to `anon` without clearing the `request.jwt.claim.sub` GUC left over from the previous actor in the same transaction, so `auth.uid()` still resolved to a real, permissioned user. Re-run with the GUC correctly cleared produced the expected result (`anon` sees only published). Documenting this prominently because it's exactly the kind of test-fixture mistake your Sprint 3 audit already warned about, and I want to be transparent that I made it here too before catching it myself.

---

## 2. CMS Workflow Authorization

- **Valid transitions, tested independently, through the App Backend service layer**: all five (`draft→in_review`, `in_review→approved`, `approved→published`, `published→archived`, plus the two reject-back paths) work correctly and require the correct permission (`cms-workflow.service.spec.ts`, 11 tests).
- **Permission separation, at the service layer**: confirmed correct — `REQUIRED_PERMISSION_FOR_TRANSITION` maps each transition to exactly one permission, checked via `hasPermission()`.
- **Permission separation, at the database/RLS layer**: **not enforced** — this is the Headline Finding. Possessing `content.create` alone effectively grants every other transition too, via a direct write.
- **Invalid transitions**: structurally invalid jumps (e.g. `draft→published`) are correctly rejected by the trigger, for every actor including a fully-privileged `super_admin` — confirmed live (`audit_finding_3_skip_transition.sql`).

---

## 3. Cross-Campus / IDOR Testing

- Campus A actor cannot modify/review/publish/archive Campus B content: ✅ confirmed, both at the service layer (Jest, `cms-workflow.service.spec.ts`'s cross-campus tests) and via live RLS (`rls_cms_tests.sql`).
- A guessed CMS record ID does not bypass campus authorization: ✅ `CmsContentWorkflowService.requireRecord()` checks `record.campusId !== actor.campusId` before any transition logic runs (this is the ADR-015 fix from ordinary Sprint 4 development, already in place).
- **Repeated through the service-role path specifically, not only RLS**: ✅ yes — this is exactly what `requireRecord()`'s check covers, since it's what runs when the App Backend (service-role) executes a transition. I did not find a second, un-checked service-role code path.
- **Public content cross-campus visibility — explicitly not assumed, checked directly**: **the RLS `SELECT` policy for published content has no campus filter at all** (`using (status = 'published')`) — this is stated as intentional in the migration's own comment. Separately, **the public API route's campus scoping is entirely client-controlled**: `PublicCmsController.getPublishedPage` takes `campusId` as a query parameter with no server-side validation, and `findPublishedBySlug` simply filters by whatever value was passed. In the current single-campus deployment this has no practical effect, but the actual behavior is: *published content is globally visible at the RLS layer, and campus-scoping for public reads exists only as an accidental byproduct of the frontend always passing the correct campus ID* — not as an enforced boundary. **This is a design question you should decide explicitly, not something the current code has actually decided.**

---

## 4. Auditability

- `created_by` is always set (`NOT NULL` at the schema level) — ✅.
- `reviewed_by`/`approved_by`/`published_by` are set correctly **only when transitions go through the App Backend** — confirmed via Jest tests. **Via the direct-write bypass (Headline Finding), they are never set**, even as content reaches `published`/`archived` — this is exactly the "misleading audit metadata" scenario your request anticipated, and it's real, not hypothetical.
- Unauthorized transitions attempted *through the App Backend* correctly fail before any write happens, so no misleading metadata is possible on that path. Unauthorized transitions via the *direct-write bypass* are not just possible but leave **no record at all** — not in the row's own actor fields, and not in `audit_logs` (confirmed: 0 entries).
- **Dedicated CMS audit log**: does not exist. The design relies on (a) the content row's own actor fields, plus (b) the general `audit_logs` table, written explicitly by `CmsContentWorkflowService.transition()`. This matches the pattern used for RBAC/config/academic audit logging throughout the platform — no architecture document I can find requires a *separate* CMS-specific audit table, so this appears consistent with the approved architecture's general pattern, not a deviation. I did not find an explicit CMS-specific audit-log requirement to check it against.

---

## 5. Database Enforcement

- **Structurally invalid transitions** (skipping steps, e.g. `draft→published`) are rejected by the trigger **regardless of role or permission level**, including for a fully-privileged `super_admin` attempting a direct write — confirmed live.
- **Structurally valid but unauthorized transitions** (the Headline Finding) are **not** rejected by the trigger, because the trigger has no concept of the acting user's permissions at all — it only validates the `(old_status, new_status)` pair.
- Read literally, "the trigger must independently reject invalid status transitions" is **partially true**: true for structural validity, false for authorization. I want to flag this distinction precisely rather than give a single yes/no, since your request's wording could support either reading.

---

## 6. Public Website Content Integrity

- No fabricated school facts: ✅ — every fact in `school-facts.ts` traces to the master specification; spot-checked against the source document.
- `[CONTENT REQUIRED]` used correctly: ✅ — three placeholders present (About narrative, Footer contact details, Admissions interim contact), all genuinely unsupplied content.
- CMS fetch failures do not produce fabricated fallback content: ✅ — confirmed via `PublishedPageSection` test (`page: null` renders only the honest empty-state sentence) and via the successful `next build`, which genuinely exercised the no-backend-configured path.
- Frontend does not expose unpublished content: ✅ — the frontend's only CMS access path is `fetchPublishedPage()` → the public API route → `findPublishedBySlug()` (status filter enforced at the query level, independent of the Headline Finding, which only affects the *authoring/transition* write path, not this read path).

---

## 7. Design System Contract Compliance

- **Colors**: exact match — every hex value in `globals.css` matches the contract byte-for-byte (verified by diffing extracted hex codes from both files).
- **Spacing scale, typography scale, breakpoints**: exact match.
- **Typefaces — meaningful deviation found**: the contract specifies `Source Serif 4` (display) and `Inter` (body). The CSS variables reference these names correctly, but **no font-loading mechanism exists anywhere in the app** — no `next/font`, no `@font-face`, no Google Fonts link. This means the browser will always fall back to the declared fallback fonts (`Georgia, serif` / system sans), never actually rendering the specified typefaces. Classified **Medium** — a real, visible brand-fidelity gap, not a functional or security issue.
- **Accessibility**: focus-visible states implemented with the contract's exact treatment (2px ring, `--color-primary-300`). Semantic heading structure present. No `alt` text issues found (no images yet exist to require it). No ARIA-live regions needed yet (no dynamic error/form states built this sprint).
- **Component states (empty/loading/error)**: the one CMS-driven section correctly implements the contract's empty-state pattern (icon + one sentence). No loading state exists, but none was needed — the page is server-rendered with no client-side async UI yet.
- **Public/application density modes**: only "public" density is applicable — no authenticated-platform UI exists yet in this sprint, so there's nothing to compare against the "application" mode column. Not a deviation, just not yet applicable.

---

## 8. Sprint Boundary

- No admissions functionality implemented — the two "admission" keyword matches in the codebase are a nav link anchor and an honest "not yet available" placeholder sentence, not a form, workflow, or backend logic.
- `students`/`staff` tables unchanged since Sprint 3 — confirmed via direct check that no Sprint 4 migration contains an `ALTER TABLE` against either.
- No finance, results, attendance, LMS, CBT, or portal functionality found anywhere in Sprint 4's code.

---

## 9. Test Quality

**The existing 67 pgTAP + 87 Jest tests do not catch the Headline Finding.** Specifically:

- `rls_cms_tests.sql` tests INSERT-permission enforcement and structural transition validity, and cross-campus denial **between two different actors**, but **never tests the same actor attempting a transition beyond their own specific permission** (e.g., a `content.create`-only actor attempting `in_review→approved` directly). This is precisely the missing negative-test category.
- The Jest suite (`cms-workflow.service.spec.ts`) only exercises the **service layer**, where permission separation *is* correctly enforced — so 100% of those tests passing is fully consistent with the RLS-layer vulnerability existing undetected. This is exactly your concern #9c: "tests that could pass while an IDOR-adjacent vulnerability still exists."
- **Test-fixture assumption that nearly created a false positive in my own audit**: forgetting to clear `request.jwt.claim.sub` when switching `SET ROLE` mid-transaction. I don't have evidence this specific mistake exists in the *committed* test suite (I checked — every committed test file sets a fresh `request.jwt.claim.sub` immediately after each `SET ROLE`), but it's a fragile pattern worth a standing lint/review check given how easy it is to get wrong, as I just demonstrated myself.
- No existing test asserts that `reviewed_by`/`approved_by`/`published_by` are populated correctly, or that they're *absent* on an illegitimate transition — an assertion gap directly related to item 4.

---

## 10. Final Verdict

## **REJECT / REWORK REQUIRED**

The Headline Finding is a live, confirmed, Critical-severity authorization gap: any actor holding the narrowest CMS permission (`content.create`) can bypass the entire review/approval/publish/archive workflow via a direct database write, leaving no audit trail and incorrect actor metadata. This directly contradicts the approved architecture's stated workflow model and the explicit "possessing one permission must not grant another" property you asked me to verify.

### Findings Summary

| # | Finding | Severity |
|---|---|---|
| 1 | RLS write policies grant any content permission holder the ability to perform any transition via direct write, bypassing per-transition authorization | **Critical** |
| 2 | Direct-write transitions leave `reviewed_by`/`approved_by`/`published_by` unset and unaudited, even as content reaches `published`/`archived` | **Critical** (direct consequence of #1) |
| 3 | Public content's cross-campus visibility is undocumented-as-a-decision: globally visible at RLS, and application-layer campus filtering is entirely client-controlled with no server-side validation | **Medium** — needs an explicit decision, not urgent given single-campus V1 |
| 4 | Display/body typefaces specified in the Design System Contract are never actually loaded; the page always renders fallback fonts | **Medium** |
| 5 | Test suite has no negative tests for same-actor permission-boundary violations at the RLS layer | **Test-quality issue** (root enabler of #1 going undetected) |
| 6 | My own first-pass anon test produced a false positive due to a GUC-clearing mistake in my adversarial script, not the product | **Test-quality issue**, corrected within this audit, documented for transparency |

Everything else checked (public read/write restrictions once correctly tested, structural transition enforcement, cross-campus IDOR on the authenticated/service-role path, color/spacing/breakpoint fidelity, sprint-boundary discipline, content integrity) held up under adversarial live testing.

Stopping here per your instructions. Nothing has been fixed. Awaiting your explicit direction on how to proceed.
