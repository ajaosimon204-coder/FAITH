# Sprint 5 Completion Report — Admissions

*Faith Foundation Schools Digital Platform. Scope: online applications, staff review and decision, and conversion of an approved application into a student with a guardian and an active enrollment.*

## Outcome

Sprint 5 is complete on the backend and database. A parent applies without an account; staff review, request information, approve or reject; an approved application converts atomically into a student, guardian, guardian link and active enrollment with a per-campus admission number. Verified on PostgreSQL 16, by 284 hermetic Jest tests, and by a 53-test integration suite that runs the application's own code through the **real PostgREST + `supabase-js` stack with real JWTs**. Not yet run on a hosted Supabase project (see limitations).

## API surface

| Method & route | Auth | Permission | Notes |
|---|---|---|---|
| `POST /api/v1/public/admissions/applications` | none (`@Public()`) | — | Rate-limited per client address; write-only; returns a minimal receipt |
| `GET /api/v1/admissions/applications?status=` | token | `read` or `manage` | Actor's campus only |
| `GET /api/v1/admissions/applications/:id` | token | `read` or `manage` | Application + documents |
| `POST …/:id/start-review` | token | `manage` | submitted → under_review |
| `POST …/:id/request-info` | token | `manage` | under_review → info_requested; notes required |
| `POST …/:id/resume-review` | token | `manage` | info_requested → under_review |
| `POST …/:id/approve` | token | `manage` | under_review → approved |
| `POST …/:id/reject` | token | `manage` | under_review → rejected; reason required |
| `POST …/:id/convert` | token | `manage` | approved → converted; body `{ classId }` |

Order of refusal everywhere: 403 → 400 → 404 → 409. Another campus's application is "not found", identical to a missing one.

## Delivered

- **Database (migrations 0021–0029):** guardians, applications and documents; RLS; permission seed; two service-role-only atomic functions (status change + audit, and conversion) with a per-campus lock on admission numbers; `anon` write revoke; project-wide privilege hardening; a trigger keeping an application's level inside its campus.
- **Backend:** types, repository (Supabase) and a faithful in-memory fake, input validation, `AdmissionsSubmissionService`, `AdmissionsReviewService`, two controllers, `AdmissionsModule`.
- **Test harness:** one reproducible, Supabase-faithful harness (`run_all.sh`) and a two-session concurrency check.

## Verification

| Check | Result |
|---|---|
| pgTAP, 8 suites, on both a classic and a current-style Supabase project | 181 / 181 each |
| Classic and current-style projects end in an identical privilege state | identical |
| Jest, 20 suites (hermetic) | 284 / 284 |
| `tsc`, `eslint --max-warnings=0`, production build | clean |
| Two concurrent conversions, same campus | two distinct admission numbers (fails without the lock) |
| Real `AppModule` boot test | passes |
| Integration: repository + services through real PostgREST 12.2.3 and `supabase-js`, real JWTs, every repository method, both project styles | 53 / 53 each |
| Hosted smoke test, self-tested against a local stand-in for a current project (passes when right; fails with a diagnosis for a wrong issuer and an unreachable key endpoint) | passes |
| `scripts/verify-all.sh` (database, API, integration, web) | all steps pass |
| Compiled server run as a real process, exercised over the network | 401 without token, 400 on bad input, 404 on no public read route, 429 on the 11th request from one client while another client behind the same proxy was unaffected |
| Mutation checks | each safety property fails the suite when removed: level/campus rules, `anon`/hardening grants, campus isolation, manage and read gates, required rejection reason, throttler guard, `@Public()` |

## Hosted readiness (added at close-out)

Checking the platform against how Supabase works *now* found four problems that would have stopped go-live; all are fixed and tested (ADR-028, `docs/HOSTED_SMOKE_TEST.md`):

1. **Security:** `student_current_enrollments` bypassed row-level security and was readable by unauthenticated callers (migration `0029`).
2. **Current Supabase projects grant nothing automatically**, so the platform would have been unusable (migration `0028`, explicit grants).
3. **Current projects sign login tokens asymmetrically**; the API now verifies both styles.
4. **Every authenticated request failed (HTTP 500)** because the identity lookup selected a non-existent column; found because every repository now runs against the real stack.

**Before go-live, run the hosted smoke test** (`docs/HOSTED_SMOKE_TEST.md`) against the real project: it is how the parts no local stand-in can cover (real Supabase login, the gateway, your actual configuration) are confirmed.

## Defects found and fixed

**In Sprint 5 work:** cross-level conversion (a JSS 1 applicant placeable into SS 1); `anon` write privileges on the guardian tables; a caller-supplied session that could only be redundant or wrong; an admission-number race; an application able to name another campus's level.

**Pre-existing, found by booting the real application for the first time:** the API could not start (missing `class-validator`/`class-transformer`; `AuditController` not injectable; `npm start` pointing at a file the build never produced). Also project-wide: `anon` held write privileges on 27 tables and `TRUNCATE` (not subject to RLS) was granted broadly (`0026`); a Sprint 2 test encoded a stale assumption; the old harness hid several of these by re-opening revoked privileges (ADR-021).

## Configuration

| Variable | Meaning |
|---|---|
| `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY` | Required. The key accepts the legacy `service_role` JWT or a `sb_secret_…` key. |
| `SUPABASE_JWT_SECRET` | **Optional.** Only for legacy projects still on the shared HS256 secret; a current project has none. |
| `SUPABASE_JWKS_URL`, `SUPABASE_JWT_ISSUER` | Optional overrides (default: derived from `SUPABASE_URL`). |
| `TRUST_PROXY` | Number of reverse-proxy hops in front of the API (integer, `0` = none). **Set it when deployed behind a load balancer**, or the per-client rate limit is shared by all applicants. `true`/non-integers refuse to start. Unset = no proxy. |

The submission limit (10 per client address per hour) is a constant in `admissions.module.ts`.

## Known limitations and decisions deferred

- **Not run on a hosted Supabase project, with tokens from Supabase's real login service (GoTrue), or through Supabase's gateway.** Everything beneath those is verified against the real API layer (PostgREST 12.2.3) with real signed JWTs. A smoke test on the hosted project at go-live is still sensible.
- **CI is defined but not yet proven on GitHub** (`.github/workflows/verify.yml` runs `scripts/verify-all.sh`, which passes locally). Expect to confirm the first run.
- **`next build` needs internet** (it downloads Google Fonts); it fails offline. The web app's typecheck, lint and tests pass.
- **Rate limit is per process.** With several API instances the ceiling multiplies; use a shared store if scaled out. No CAPTCHA or bot challenge — a product decision.
- **Documents are URL references**; nothing in the platform uploads or stores files. Attachment is best-effort after the application exists, and the receipt reports how many were stored (ADR-025).
- **Editable business constants** in `admissions.validation.ts`: applicant gender (`female`/`male`), maximum applicant age (25), documents per application (10), and the rule that one guardian contact is required.
- **No guardian notification** (email/SMS) on submission or decision.
- **No frontend** for applications or review in this sprint.
- Admission numbers continue across calendar years (`FFS-<year>-<count+1>`; the year is cosmetic).
- `class-validator` is installed for the global pipe but no DTO classes use it yet; validation lives in the services.

## Reproduce

```
scripts/verify-all.sh                                          # EVERYTHING: database, API, integration, web (add --skip-web-build offline)
supabase/local-test-harness/run_all.sh                         # reset, apply 0001–0029, run all pgTAP suites (add --modern for a current-style project)
supabase/local-test-harness/concurrency_conversion_check.sh    # two-session concurrency check
supabase/local-test-harness/run_integration.sh                 # real PostgREST + supabase-js integration suite
cd apps/api && npm ci && npm run typecheck && npm run lint && npm test && npm run build
```
